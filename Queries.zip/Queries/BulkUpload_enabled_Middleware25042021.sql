



select * from AssetEntityType ----->  68	Middleware	Middleware	Middleware	1	2	1

----4	Laptop	Laptop	Laptop
--5	Desktop	Desktop	Desktop

--> step 1: Enable the AssetEntityType to the isBulkuploadEnabled=1

--Update AssetEntityType set isBulkuploadEnabled =1 where id =68

select * from AssetEntityType where id in (4, 5 , 68)

---->  step: 2 Enable the coulmns:

--exec usp_assetmanagement_getcustomattributecolumnmapping

select * from CustomAttributeColumnMapping where SourceId = 68 and PageId = 3

--Update CustomAttributeColumnMapping set IsBulkUpdate = 1 
--where SourceId = 68 and PageId = 3



----> exec Asset_ProvideAssPermission 6,1,1

select top 100  * from  Asset_EntityTabAndEntityUserMapping where entityTabId =68


select * from KM_EntityTabAndEntityUserMapping

select * from Asset_EntityTabAndEntityUserMapping

select top 100  * from Asset_EntityTabConfiguration where sourceAssetTypeId = 68

select top 100  * from Asset_EntityTabConfiguration where sourceAssetTypeId = 4

----->  Step 3: AutoDiscovery

select * from Asset_AutoDiscoverConfiguration where ToolId = 3

-----> Webserver Hostname

--Insert into Asset_AutoDiscoverConfiguration (	CustomerId,	AssetEntityId,	isAutoUpdate,	isVersioning	,UniqueKeys,	isDeleted	,CreatedOn,	CreatedById	,ToolId	,isDeletedRequired	,IsInsertRequired	,IsUpdateRequired)

--select 1, 68, 1, 0, 'Webserver Hostname', 0, GETDATE(), 6, 3, 0, 1,1

--select * from Assets where SourceId = 68
-- order by 1 desc

-- 21171
--21170
--21169


--select * from VarcharCustomAttribute where PrimaryId in (21171, 21170, 21169)


select * from Asset_BulkUploadProgress

select * from CustomAttributeColumnMapping where SourceId = 68 and PageId = 2

select * from CustomAttributeColumnMapping where SourceId = 68 and PageId = 3

-----> First: issue unable to update asset giving the issue like duplicate AssetNumber.

----->  OS 

----> employeeId , Location and SubStatus not coming in page 1 (in GRID):
----> In the view page

----> enable all procerurement details
-----> PO Number, PO Date and Invoice number and invoice date
-----> Procerurement details are not updatinng PO number  via Bulk Update not adding
-----> need to add OS List: in DDL

----> DP 18 182 duplicates in assets: 
----> Report issue: assets coming in report and visible in search:
----> HP not taking while bulk upload need to update to "HP".


----> IM2959817

----> test ticket: SR2969410




	    select * from Customer where customername like '%Unity%' -- 207	Unity Bio

		select * from Customer where customername like '%Bosc%' -- 61	BOSCH	BOSCH

		--  189	BOSCH DCS	BOSCH DCS
  --        203	Bosch � Scottsdale	Bosch � Scottsdale

         select * from notificationRules where customerid = 61 and deleted = 0 and notificationMode like '%Sms%' and notifybasedonid = 2

		select * from notificationRules where customerid = 61 and deleted = 0 and notificationMode like '%Sms%' and notifybasedonid = 3

        select * from notificationRules where customerid = 189 and deleted = 0 and notificationMode like '%Sms%' and notifybasedonid = 2

		select * from notificationRules where customerid = 189 and deleted = 0 and notificationMode like '%Sms%' and notifybasedonid = 3

		select * from notificationRules where customerid = 207 and deleted = 0 and notificationMode like '%Sms%' and notifybasedonid = 2

		
		select * from notificationRules where customerid = 207 and deleted = 0 and notificationMode like '%Sms%' and notifybasedonid = 3

		
		select * from notificationRules where customerid = 203 and deleted = 0 and notificationMode like '%Sms%' and notifybasedonid = 2

		
		select * from notificationRules where customerid = 203 and deleted = 0 and notificationMode like '%Sms%' and notifybasedonid = 3

	   Select * from NotificationEmailTemplate where customerId = 3 and templateName like '%sms%'

			Select * from NotificationEmailTemplate where customerId =207 and templateName like '%sms%'  

		   Select * from NotificationEmailTemplate where customerId =61 and templateName like '%sms%' 



		select * from ServiceCustomerMapping where customerId = 61
		select * from ServiceCustomerMapping where customerId = 207  
		select * from ServiceCustomerMapping where customerId = 203
		select * from ServiceCustomerMapping where customerId = 189  -- Issue in this configurations, i.e need to configure more.

		select * from Service where serviceId in (
		select distinct serviceId from ServiceCustomerMapping where customerId = 207 )


		select  * from NotificationHistory where TicketNo = 2638269


		--        207	Unity Bio
		--        203	Bosch � Scottsdale	Bosch � Scottsdale

		select distinct ruleName from notificationRules where customerid = 203 and deleted = 0 and duePercent is not null and notifyBasedOnId = 3

		-- ResponseSLA 25 %
  --      ResponseSLA 90 %
  --      SLA Response 40
  --      SLA Response 50
  --      SLA Response 60
  --      SLA Response 70

		--ResolutionSLA 75 %
  --      ResolutionSLA 90 %


            SELECT * FROM NotificationRegistry WHERE sourceId = 2637301

			SELECT * FROM TicketStatus

			

			Select * from NotificationEmailTemplate where customerId =189 and templateName like '%sms%'





			Select * from NotificationEmailTemplate where customerId =203 and templateName like '%sms%'

			--ResponseSLA 90 %
   --         SLA Response 40
   --         SLA Response 50
   --         SLA Response 60
   --         SLA Response 70

        --   ResolutionSLA 75 %
        --    ResolutionSLA 90 %




	       select distinct ruleName from notificationRules where customerid = 189 and deleted = 0 and duePercent is not null and notifyBasedOnId = 2



            SLA Response 60
            SLA Response 70
            

	        select * from Customer where customername like '%Unity%' -- 207	Unity Bio
		    
		    select * from Customer where customername like '%Bosc%' -- 61	BOSCH	BOSCH
		    
	    	Select * from NotificationEmailTemplate where customerId = 3 and templateName like '%sms%'

			Select * from NotificationEmailTemplate where customerId =207 and templateName like '%sms%'  

		   Select * from NotificationEmailTemplate where customerId =61 and templateName like '%sms%' 

			select * from notificationRules where customerid = 3 and deleted = 0 and duePercent >=60 and notificationMode like '%AWSSMS%'

			select top 100 * from ServiceCustomerMapping where customerid =203 

			select * from notificationRules where customerid = 189 and deleted = 0 and duePercent> = 60 and notificationMode like '%AWSSMS%'

			select * from notificationRules where customerid = 203 and deleted = 0 and duePercent> = 60 and notificationMode like '%AWSSMS%'

			Select * from NotificationEmailTemplate where customerId =189 and templateName like '%sms%'
			Select * from NotificationEmailTemplate where customerId =203 and templateName like '%sms%'


     --         insert into NotificationRules (serviceid, customerId,ticketTypeId, duePercent, notificationMode, notificationTo, templateId, ruleName, notifyBasedOnId, deleted)

			  --select distinct (serviceid), 203, ticketTypeId, 90,  'AWSSMS', '919739886229;918748857574', 1981, 'SLA 90 SMS Response', 2, 0  from NotificationRules where customerId = 203 and deleted = 0 


     --        insert into NotificationRules (serviceid, customerId,ticketTypeId, duePercent, notificationMode, notificationTo, templateId, ruleName, notifyBasedOnId, deleted)

			  --select distinct (serviceid), 203, ticketTypeId, 90,  'AWSSMS', '919739886229;918748857574', 1983, 'SLA 90 SMS Resolution', 3, 0  from NotificationRules where customerId = 203 and deleted = 0 


			  -- select * from ServiceCustomerMapping where customerId = 61


			select * from notificationRules where customerid = 207 and deleted = 0



			--ResponseSLA 90 %
   --         SLA Response 40
   --         SLA Response 50
   --         SLA Response 60
   --         SLA Response 70

			-- INSERT INTO NotificationEmailTemplate (templateName, template, customerId, isOutageNotificationTemplate, isOutageSMSNotification)

			values ('SLA 60 SMS Response', 'Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 60% Response SLA', 203, 0, 0),
			('SLA 70 SMS Response', 'Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 70% Response SLA', 203, 0, 0),
			('SLA 90 SMS Response', 'Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 90% Response SLA', 203, 0, 0)


			-- ('SLA 90 SMS Responce', 'Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 90% Responce SLA', 189, 0, 0),
			-- ('SLA 100 SMS Responce', 'Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 100% Responce SLA', 61, 0, 0)

       --   ResolutionSLA 75 %
        --    ResolutionSLA 90 %

		    -- INSERT INTO NotificationEmailTemplate (templateName, template, customerId, isOutageNotificationTemplate, isOutageSMSNotification)

			 values ('SLA 75 SMS Resolution', 'Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 75% Resolution SLA', 203, 0, 0),
			 ('SLA 90 SMS Resolution', 'Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 90% Resolution SLA', 203, 0, 0)


			 --('SLA 85 SMS Resolution', 'Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 85% Resolution SLA', 207, 0, 0),
			 --('SLA 90 SMS Resolution', 'Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 90% Resolution SLA', 207, 0, 0)



		Select * from NotificationEmailTemplate where customerId = 61

		--     Karthik - 9739886229
        --     Dilip - 8748857574

	select * from customer where customerid = 3


	select * from Service where serviceName like '%CIS%'

	---  Issue in Work group: 193

	select * from Customer where customername like '%SMC RMC%' -- 154

	select * from Customer where customername like '%unity bio%' -- 207

	select * from Service where serviceName like '%cloud%'


--	499	Cloud Services	Cloud Services	NULL	Cloud Services	NULL	2020-03-23 05:41:37.733	NULL	1
--502	Cloud Service	Cloud Service	NULL	Cloud Service	NULL	2020-06-01 09:30:47.613	NULL	4

   select * from Service where serviceid in 
  ( select serviceId from ServiceCustomerMapping where customerId = 207)  --  499	Cloud Services	Cloud Services


	select * from customer where customername like '%MLCIS%'  --3

	select * from Device where DeviceName like '%BLRECPSECPOD101%' and customerId =3   --- 25789

	--  update Device set deviceName = 'BLRECOSECPOD101', alternateName = 'BLRECOSECPOD101', hostName = 'BLRECOSECPOD101' where deviceId = 25789

	--   cellranger-svr-3 : 10.0.0.5

	      INSERT INTO device(devicename,alternateName,ipAddress,customerId,deleted,hostName) 
	      values('cellranger-svr-3','cellranger-svr-3','10.0.0.5',207,0,'cellranger-svr-3');

		  select top 1 * from device order by 1 desc   ---- 29842


---->  SR3 , Low, 
---->  Sivagami.  

select * from Workgroup where workgroup like '%VPF%'    ---->  227

select * from Workgroup where workgroupId = 227  ---->  

--insert into Workgroup (workgroup, displayName,deleted, UpdatedBy, UpdatedDateTime, CreatedBy, CreatedDateTime, ServiceProviderId)


select * from Workgroup where workgroup like '%VPF%'    ---->  765

select * from AssignmentGroup where workgroupId = 765  ---->  900 

select * from CustomerAssignmentGroupMapping where assignmentgroupId = 900  ---->  3062	Ask Microland - VPF - Queue

select * from Service where serviceName like '%HR%'  ---->  84	HR

select * from Impact --->  5	Low (1 Person Affected)

select * from Priority where ticketTypeId = 2  ---->  14	SR3

select top 100 * from RulesForPriority ---> 

select * from SubCategory where subCategory like '%VPF%'  ---->  22757 , CategoryId: 4718

select * from Category where categoryId = 4718 

select * from Classification where subCategoryId = 22757   ---->  91042

--update Classification set classification ='VPF contribution' where classificationId = 91042

--Insert into RulesForPriority (RuleDescr, PriorityRule, PriorityId, ImpactId, RulePriority, Deleted, RuleTemplateId, customerid)

--values ('ASKL ML Rule', '{customerid=147;serviceid=84;categoryid=4718;subcategoryid=22757;classificationid=91042;tickettypeid=2;}', 
--14, 5, 1, 0, 1890, 147)

select top 1 * from RulesForPriority order by 1 desc  --->  89725

select top 100 * from RulesForAssignment 
where customerId = 147 and Deleted = 0 and RuleTemplateId =1890  and RuleId = 34110

--Insert into RulesForAssignment (RuleDescr, AssignmentRule, PrimaryAssignmentGroupId, SecondaryAssignmentGroupId, RulePriority, Deleted, 
--                      RuleTemplateId, customerId, AssignmentType, AssignToId, NoOfParams)
--values ('Rules', '{customerId=147;serviceId=84;categoryId=4718;subCategoryId=22757;classificationId=91042;ticketTypeId=2;}', 
--900,900, 1, 0, 1890, 147, 3, 26384, 6)

select top 1 * from RulesForAssignment order by 1 desc ----> 83314 

--Update RulesForAssignment set AssignToId = 1577 where RuleId = 83314

select * from Users where loginName like '%MonicaS%' ---->  26384
select * from Users where email like '%payroll1@microland.com%' ---->  1577  Shivagami A

select * from UserCustomerAssignGroupMapping where userId = 26384

select * from UserCustomerAssignGroupMapping where userId = 1577

select * from users where userId = 6

--insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
--values (6, 3062, 0, 0, 0)

--SR2948799

---->   RP000025

select * from ReportMaster where reportMasterID = 25  ---->  usp_StandardReport_getAllIM&SRCombinedSLATicketDump

 --exec deletetickets @ticketNo = '2895124'

 ----->  IM1561215



		--  insert into HolidayCalendarDetail(holidayCalendarId,holidayDate,holidayName)
		--  values(26,'2020-01-01 00:00:00.000','holiday');


		 select * from HolidayCalendar where holidayCalendarId =24

		 select * from HolidayCalendar where holidayCalendarId =61

		 select * from HolidayCalendar   where Name like '%KM%'  --->  61	KAM Holiday	KAM Holiday

		 select top 100 * from  HolidayCalendarDetail 
		 where holidayCalendarId =61 order by 1 desc


		  --insert into HolidayCalendarDetail(holidayCalendarId,holidayDate,holidayName)
    --      values
		  --(61,'2021-01-26 00:00:00.000', 'Republic Day January'),
		  --(61,'2021-03-11 00:00:00.000', 'Mahashivratri'),
		  --(61,'2021-03-29 00:00:00.000', 'Holi'),
		  --(61,'2021-04-02 00:00:00.000', 'Good Friday'),
		  --(61,'2021-04-14 00:00:00.000', 'Dr.Baba Saheb Ambedkar Jayanti'),
		  --(61,'2021-04-21 00:00:00.000', 'Rama Navami'),
		  --(61,'2021-05-13 00:00:00.000', 'Id-Ul-Fitr (Ramzan Id)'),
		  --(61,'2021-07-21 00:00:00.000', 'Bakri Id'),
		  --(61,'2021-08-19 00:00:00.000', 'Muharram'),
		  --(61,'2021-09-10 00:00:00.000', 'Ganesh Chaturthi'),
		  --(61,'2021-10-15 00:00:00.000', 'Dussehra'),
		  --(61,'2021-11-04 00:00:00.000', 'Diwali Laxmi Pujan'),
		  --(61,'2021-11-05 00:00:00.000', 'Diwali Balipratipada'),
		  --(61,'2021-11-19 00:00:00.000', 'Gurunanak Jayanti'),

		  --(61,'2021-04-25 00:00:00.000', 'Mahavir Jayanti'),
		  --(61,'2021-05-01 00:00:00.000', 'Maharashtra Din'),
		  --(61,'2021-08-15 00:00:00.000', 'Independence day'),
		  --(61,'2021-10-02 00:00:00.000', 'Mahatma Gandhi Jayanti'),
		  --(61,'2021-12-25 00:00:00.000', 'Christmas')
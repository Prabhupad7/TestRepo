

      select * from Users where loginName in ('LE66882')  ---> 1268 

	    select * from Users where loginName in ('OM15895')  ---> Sunil Jadhav-  OM15895 
		--->  jadhav.sunil@kotak.com 

	  select * from Users where loginName in ('LO4461', 'LO3901', 'OM15895')  ---> 1268

	  --->  Sunil Jadhav-  OM15895  no access we need to give access: 

	   select * from CustomerAssignmentGroupMapping 

	   select * from UserCustomerAssignGroupMapping where userid in (1268)
	   select * from UserCustomerAssignGroupMapping where userid in (1335)
	      select * from UserCustomerAssignGroupMapping where userid in (991, 994)

		  	-- Insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
				values
			(991, 224,0,1,1),
			(994, 224,0,1,1)

			--Update UserCustomerAssignGroupMapping set AssignToWorkgroup =1 where userCustomerAssignGroupId in (
			--12010, 12013
			--)


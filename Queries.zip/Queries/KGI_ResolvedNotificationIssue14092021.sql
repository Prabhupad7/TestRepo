

select * from NotificationHistory where NotificationId in(
select top 1000 NotificationId from NotificationRegistry where templateId = 646
order by 1 desc
)


select top 1000 * from NotificationRegistry where sourceId = 100825

select top 1000 * from NotificationRegistry where sourceId = 101705 and ruleid = 54587  ---> 2681870


select * from Ticket Where TicketNo =  101705 

select * from NotificationRules where customerid = 1 
and priorityId = 28 and workgroupid = 10 and serviceid = 12 and templateid = 646  --> 54587

select * from NotificationRules where ruleId = 54587

select * from NotificationRules where templateid = 646 and notificationCC ='$ASSIGNEDENGINEEREMAIL;$WORKGROUPEMAIL;'

--Update NotificationRules set notificationCC ='$ASSIGNEDENGINEEREMAIL;$WORKGROUPEMAIL'
--where templateid = 646 and notificationCC   ='$ASSIGNEDENGINEEREMAIL;$WORKGROUPEMAIL;'

--Update NotificationRules set notificationCC ='$ASSIGNEDENGINEEREMAIL' where ruleId = 54587

select * from NotificationRules where customerid = 1 
and priorityId = 28 and workgroupid = 10 and serviceid = 12 and duePercent is null


select * from TicketStatus where ticketTypeId = 2  ---> 19	Resolved
 
select * from NotificationEmailTemplate where templateId in ( 646, 648,
666,
658,
649,
665,
650	)

select * from Requestor where requestorEmail like '%venkataramana%' ---> 15552 venkataramanaiahk@microland.com

select top 100 * from Users where userId  = 6 ----> 6  smcadmin narendrans@microland.com


select top 1000 * from NotificationRegistry where templateId = 646
order by 1 desc


select * from NotificationHistory where TicketNo = 101736  
select * from TicketStatus where status like '%Cancel%'


--statusId	status	deleted	ticketTypeId
--65	Cancelled	0	1
--66	Cancelled	0	2
--67	Cancelled	0	4
--68	Cancelled	0	3

select top 50 * from workflowmaster

--id	name
--6	Default - Incident
--7	Default - Request
--9	TATAAIG - Incident
--10	TATAAIG - Request

select  * from workflow where workflowMasterId = 6 and deleted  = 0 and workflowActivityId=36


select  * from workflow where workflowMasterId = 6

and deleted  = 0 and nextStatusId= 36


select  * from workflowstatus  ----> 36	Cancelled

select  * from WorkflowMapping

--update WorkflowMapping set workflowMasterId = 10 where id = 10


select  * from WorkflowActivity  ---> 37	37	_CancelAndClose

select  * from workflow 

select  * from workflow where workflowMasterId = 7
and deleted  = 0 and currentStatusId= 36

select  * from workflow where workflowMasterId = 7
and deleted  = 0 and workflowActivityId= 36


select  * from workflowstatus 

--35	Work in Progress

--exec usp_GetPossibleActivities 1,10,1,null

--exec usp_GetPossibleActivities 1,3,1



select  * from workflow where workflowMasterId = 6 and nextStatusId = 37

select  * from workflow where workflowMasterId = 6 and workflowActivityId = 37


select w.currentStatusId, w.nextStatusId,wsn.name as nextstatusname, w.workflowActivityId, wa.name as activityname,
        wa.isselfdriven, wa.executionName, wa.executionPath
        from Workflow w
        inner join WorkflowStatus ws on ws.id = w.currentStatusId
        inner join WorkflowTicketStatusMapping wts on wts.WorkflowStatusId = ws.id
        inner join TicketStatus ts on ts.statusid = wts.ticketStatusId
        and ts.statusid = 3 and ts.ticketTypeId = 1
        left outer join WorkflowStatus wsn on wsn.id = w.nextStatusId
        inner join WorkflowMaster wm on wm.id = w.workflowMasterId and wm.deleted = 0
        inner join WorkflowActivity wa on wa.activityId = w.workflowActivityId
        inner join WorkflowMapping wmp on wmp.workflowMasterId = wm.id
        where wts.ticketStatusId = 3 and wm.sourceTypeId = 1
            and isnull(wm.sourceSubtypeId, 0) = isnull(null, 0) and wmp.customerId = 1 and w.deleted = 0
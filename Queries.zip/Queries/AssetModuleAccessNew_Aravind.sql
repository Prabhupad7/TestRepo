

        select * from Customer where customerid = 216
	--->  216	Tata Consumer Products Ltd 

	   select * from Users where email like '%kgi.assetmanagement%' ---> 26569  145

	   	select * from Users where userid in (145) 
		
		select * from CustomerAssignmentGroupMapping where custAssignmentGroupId in (
		select custAssignmentGroupId from UserCustomerAssignGroupMapping where userid in (26137, 26095)) 

		select * from customer where customerId = 16
   
  --   exec Asset_ProvideAssPermission 26137,167,1
	
  --   exec Asset_ProvideAssPermission 26095,167,1 

  --    exec Asset_ProvideAssPermission 145,1,1 


    --  exec Asset_ProvideAssPermission 26651,1,1 

	  --sp_helptext Asset_ProvideAssPermission


	  select * from NotificationRegistry where sourceid = 2900113 ---->  IM2901053 

	  select * from NotificationRegistry where sourceid = 2901053 

	  select * from notificationRules where ruleid in(
	 select ruleid from NotificationRegistry where sourceid = 2900113 ) and duePercent is null 

--	 2178670
--2178673
--2178676
--2178678
	  

	  select deleted,ruleName,* from notificationRules where ruleid in(
	 select ruleid from NotificationRegistry where sourceid = 2901053 ) and duePercent is null 


--	 Update NotificationRules set deleted =1 where ruleId in (
--	 2178668
--,2178670
--,2178673
--,2178676
--	 )\


   select deleted,ruleName,* from notificationRules 
   where notificationCC like '%VitalisJJC@microland.com%'


   select * from Users where email like '%MaheshwariM@microland.com%' ---> 26689



   select cg.customerId, cg.customerName from UserCustomerAssignGroupMapping Ug
   inner join CustomerAssignmentGroupMapping Cg on cg.custAssignmentGroupId = ug.custAssignmentGroupId
   where ug.userId = 26689

   select * from Workgroup where workgroup like '%Oncall%' -----> 694 693

   --693	Oncall Hardware
   --694	OnCall Software

   select top 1000 * from Feedback f
   inner join Ticket t on t.ticketNo = f.TicketNo 
   where t.workgroupId in (694)
   order by f.Id desc

      select top 1000 * from Feedback f
   inner join Ticket t on t.ticketNo = f.TicketNo 
   where t.workgroupId in (693)
   order by f.Id desc
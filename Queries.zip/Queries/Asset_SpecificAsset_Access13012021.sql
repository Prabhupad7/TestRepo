
 step1: providing all Asset access:

  --   exec Asset_ProvideAssPermission 26137,167,1

 step: Need do mark deleted as 1 which asset access need to remove or need to restrict:

 select * from Asset_UserEntityConfiguration 
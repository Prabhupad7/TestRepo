




  select COUNT(*)Count, classification,subcategoryid from classification  where deleted = 0 
  group by  classification,subcategoryid having count(*) > 1

    select COUNT(*)Count, subCategory,categoryId from SubCategory  where deleted = 0 
  group by  SubCategory,categoryId having count(*) > 1




--  select * from Classification where deleted = 0 and classification ='Windows ID-Undefined' and subCategoryId = 21

--	Update Classification set deleted = 1 where classificationId in (
-- 4058
--,4082
--,4147
--,4283
--,4741
--	)
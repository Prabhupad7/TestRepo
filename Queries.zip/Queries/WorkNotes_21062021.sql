

    select t.customerId,TicketTypeid,t.serviceid, t.serviceName,t.priorityid,t.priorityname ,t.statusid,t.statusName,t.categoryId, t.subCategoryId, t.classificationid,impactId, impactName, deviceId, deviceName
	,* from ticket t where t.ticketno= 3030382   -- 14	SR3  9	P3   10823	Generic

	 select * from priority where tickettypeid = 1  ---> 9	P3

	  select * from ticketStatus where  tickettypeid = 1 ---> 13	Assigned

	  select * from Impact

	  	select * from servicecustomerMapping 
		where  customerid = 194 and deleted = 0 and ticketTypeId = 1 ---> 328

		select * from Service where serviceId = 328  ----> 328	DCS

		select * from DeviceServiceMapping 
		where serviceId = 328 and deleted = 0 and ticketTypeId = 1  ----> 10823	Generic

		select * from Device where deviceId = 10426  ----> 

		--select * from Device where deviceId in (
		--select deviceId from DeviceServiceMapping 
		--where serviceId = 328 and deleted = 0 and ticketTypeId = 1
		--) and deviceName like '%Gene%'

		select * from ServiceCategoryMapping
		where serviceId = 328 and deleted = 0 and ticketTypeId =1 ---> 4102

		select * from Category where categoryId = 4102  ----> 4102	Application

		select * from SubCategory where categoryId = 4102 ----> 17601	Software-Druva

		select * from Classification where subCategoryId = 17601 ----> 74733	System down or slow






		--152 and 149

		select top 50 * from Log 
		order by 1 desc

--Timestamp: 6/21/2021 5:48:33 AM Message: Inner Exception is: No inner exception raised Category: ServiceRequest Priority: 1 EventId: 3 Severity:
--Error Title:page = ServiceRequestTicketBL , method= CloseServiceRequestTicket, UserID= user Machine: RD00155DF227B2 Application Domain:
--/LM/W3SVC/1240477980/ROOT-1-132687186782046535 Process Id: 6980 Process Name: d:\windows\system32\inetsrv\w3wp.exe Win32 Thread Id:
--7264 Thread Name:  Extended Properties: 
--Timestamp: 6/21/2021 5:48:33 AM Message: Error Message is: Object reference not set to an instance of an object. Category:
--ServiceRequest Priority: 1 EventId: 1 Severity: Error Title:page = ServiceRequestTicketBL , method= CloseServiceRequestTicket,
--UserID= user Machine: RD00155DF227B2 Application Domain: /LM/W3SVC/1240477980/ROOT-1-132687186782046535 Process Id: 6980 Process Name: 
--d:\windows\system32\inetsrv\w3wp.exe Win32 Thread Id: 7264 Thread Name:  Extended Properties: 
--Timestamp: 6/21/2021 5:48:33 AM Message: Stack Trace is:    at Microland.SmartCenter.Business.SmartCenter.ServiceRequestTicketBL.

--CloseServiceRequestTicket(ServiceRequestTicketViewModel serviceRequestTicketViewModel, Boolean isFromTool)    
--at Microland.SmartCenter.Business.SmartCenter.ServiceBL.GetResolvedTicketsForAutoClosure() Category: Common Priority: 1 EventId: 2 Severity: 
--Error Title:page = Update Auto Close time , method= GetResolvedTicketsForAutoClosure, UserID= user Machine: RD00155DF227B2 Application Domain:
--/LM/W3SVC/1240477980/ROOT-1-132687186782046535 Process Id: 
--6980 Process Name: d:\windows\system32\inetsrv\w3wp.exe Win32 Thread Id: 7264 Thread Name:  Extended Properties: 


select * from Users where email like '%RMCCollab%'  ----> 115, 330

select * from Users where email like '%RMCShif%'  ----> 113

select * from Users where email like '%RMCTool%'  ----> 121

select * from Customer where customerName like '%Bunge%'  ---> 218	Bunge

select * from CustomerAssignmentGroupMapping where customerId = 218 and deleted = 0

select * from  UserCustomerAssignGroupMapping where deleted = 0 and userId in (115, 330, 113, 121)  
and custAssignmentGroupId in (2989,2993,2988,2992,2990,2991,3042,3043,3059)

select workgroupId, workgroupName , * from Ticket where ticketNo in (
2967676,
2968962,
2968965,
2969238,
2969498,
2969723,
2969977,
2970970,
2971175
)

---> 13	RMC Tools
---> 7	RMC Collaboration

select * from Workgroup where workgroupEmail like '%RMC%'  ---> 
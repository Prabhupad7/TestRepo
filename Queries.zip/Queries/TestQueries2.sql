

select * from ServiceLevelAgreement where customerid = 192

--240	Jubilent RCA
--373	Jubilent Proactive tickets
--395	Jubilent RFO

select * from ServiceLevelObjective where ServiceLevelAgreementid = 240

select * from ServiceLevelObjective where ServiceLevelAgreementid = 395

select * from ServiceLevelAgreement where customerid = 147

--294	Problem Management-RCA
--295	Problem Management-RFO

select * from ServiceLevelObjective where ServiceLevelAgreementid = 295

select * from ServiceLevelObjective where ServiceLevelAgreementid = 294




select top 50 * from smc_userotp order by 1 desc

---> IM3158032 Test ticket: 

---> Test Tickets
--> IM3158485  , IM3158535

select * from NotificationEmailTemplate where customerid = 68  ---> 417	HMCL_SMS_Template

select * from NotificationEmailTemplate where customerid = 147  ---> 417	HMCL_SMS_Template

select * from NotificationEmailTemplate where templateid in (417, 684,685, 686, 687 )


select top 100 * from NotificationRegistry where notificationMode='AWSSMS' and templateid = 417
order by 1 desc

select *from NotificationRegistry where sourceid = 3158032 and notificationMode='AWSSMS'



--->  notificationId


select  * from SMSnotificationLogs where notificationId in (
select top 1000 notificationId from NotificationRegistry where notificationMode='AWSSMS' and templateid = 417
order by 1 desc)

select *from NotificationRegistry 
where notificationId in ( 39502639 , 39503562 , 39503563,  39503915, 39504417 , 39509848 , 39509849 , 39511028 )


---> IM3158485

select *from NotificationRegistry 
where  Sourceid = 3158535 and notificationMode='AWSSMS' 

select *from NotificationRegistry  where sourceid = 3158535   and notificationMode='AWSSMS' 

select *from NotificationRegistry  where sourceid = 3158583   and notificationMode='AWSSMS' 

select *from SMSnotificationLogs where  notificationId in (39559606) 

select *from SMSnotificationLogs where  notificationId in (39560361) 



select workgroupid, serviceId,customerid,* from Ticket where ticketno = 3155057

select * from NotificationRules where customerid = 68 
and serviceid = 51 and workgroupid = 101 and notificationMode='AWSSMS' 
 
 select * from NotificationRules where  ruleid = 1506787

 select * from NotificationEmailTemplate where templateid in (417, 684,685, 686, 687 )

 --Update NotificationRules set notificationTo = '$ASSIGNEDENGINEERMOBILE,919000309621,919700940947'
 --where ruleid = 1506787

 -- Update NotificationRules set templateid = 417
 --where ruleid = 1506787


select * from NotificationRules where ruleid in (
1401635,1400267,2160454,1506787,2339467,1401179,2339505,2339508,2339510,2339664,1464053,1464167,1464281,
1464395,1464509,1464623,1464737,1464851,1464965,1465079)


select *from SMSnotificationLogs where  notificationId in ()

--3157933
--3157933

select* from NotificationRules where customerid  = 68 
and notificationTo like '%9000309621%'

---> $ASSIGNEDENGINEERMOBILE,919000309621,919700940947,919632359091

--Update NotificationRules Set NotificationTo =  Replace (NotificationTo, '919000309621,919700940947,919632359091', '')

--where ruleid in (1507635,1507667,1507699,2342701,2342709,2342730,1517081,1517537,1517993,1518449,1518905,1519361,1507631,
--1507663,1507695,2342708,2342729,1517080,1517536,1517992,1518448,1518904,1519360,1507643,1507675,2342703,2342711,2342732,
--1517195,1517651,1518107,1518563,1519019,1507615,1507647,1507679,2342704,2342725,2342733,1517308,1517764,
--1518220,1518676,1519132,1507627,1507659,1507691,2342707,2342728,1516967,1517423,1517879,1518335,1518791,1519247,1507639,
--1507671,2342702,2342710,2342731,1517194,1517650,1518106,1518562,1519018,1507623,1507655,1507687,2342706,2342727,2342735,1516966)

select* from NotificationRules where customerid  = 68 
and notificationcc like '%9000309621%'

----> IM3158032


select * from Workgroup where workgroup like '%Infosec%' ---> 206

SankarR same access

--Update Workgroup set workgroupEmail ='Anandvk@microland.com;Sankarr@microland.com;SasikumarN@microland.com;SantoshK@microland.com;BalaRB@microland.com;infosec@microland.com;manikandanc@microland.com;'
--where workgroupid = 206

select * from NotificationRules where customerid = 147 
and deleted = 0 and workgroupid = 206


------------------------>

select * from customer where customerName like '%Enzen%'  ---> 158	Enzen-NGN

select * from Priority where ticketTypeid = 4  ---> 12	P3 , 4	P1

select * from TicketType  ---> 4	Problem	PRO

select * from ServiceLevelAgreement where customerid = 158

--112	Enzen-NGN - PM
--317	Enzen-NGN - PM
--370	Enzen-NGN-Proactivetickets

select top 100 * from ServiceLevelObjective where serviceLevelAgreementId in (112, 317, 370) 
and serviceLevelObjectiveTypeId = 1

select top 100 * from ServiceLevelObjective where serviceLevelAgreementId in (112, 317, 370) 
and serviceLevelObjectiveTypeId = 2

--Update  ServiceLevelObjective set responseTimeInMin = 14400
--where serviceLevelAgreementId in (112, 317, 370) 
--and serviceLevelObjectiveTypeId = 2

-------------------------------------------------------------------------------------------------------->

select customerid, * from Ticket where Ticketno = 3137589   ---> 158

select * from Customer where customerid = 158  ----> 158	Enzen-NGN

select * from AutoTicketEventLog where ticketno = 3137589 

------> ngn.enzensupport@enzen.com  51


select customerid, * from Ticket where Ticketno = 3137589   ---> 158

select * from Customer where customerid = 158  ----> 158	Enzen-NGN

select * from APIKey where customerid = 158  ----->  51  'E2E6B27C-D988-4B94-9630-F9028AA9D679'

select * from autoticketserviceemailconfig 
where apikey ='E2E6B27C-D988-4B94-9630-F9028AA9D679'  ---> 280	Enzen Generic

---> enzen-ngnautoticket@microlandsmartcenter.com

M!cr0land@bng1

enzen-ngnautoticket@microlandsmartcenter.com
enzen-ngnautoticket@microlandsmartcenter.com

----> srinivasan.n@enzen.com

select  top 1000 * from AutoTicketEventLog where inRequestorEmail = 'srinivasan.n@enzen.com'
order by 1 desc

---> 3156561

select top 100  * from AutoTicketServiceRule where apikeyid = 51 and deviceid = 31180 

select top 50 * from SMC_UserOtp order by 1 desc


 select * from workGroupEscalationMatrix_AskML where CustomerId = 147 and WorkgroupName like '%ML IT Servicedesk%'

  select * from workGroupEscalationMatrix where CustomerId = 147 and deleted = 0 and workGroupId in (
  212,769,216,200, 699, 247)


  select * from workGroupEscalationMatrix where CustomerId = 147 and deleted = 0 and workGroupId in (
  212,769,216,200, 699, 247)


  select * from NotificationRules where notificationCC like '%AyubA@microland.com%'

  select * from Workgroup where workgroupemail like '%AyubA@microland.com%'

  --->  IM3158874

  select * from ServiceLevelTracking where sourceid = 3157766

  --Update ServiceLevelTracking set expectedDuration = 120 , isbreached = 0, statusid = 3 
  --where  serviceLevelTrackingId= 7292274

  select customerid, serviceid, Workgroupid,* from Ticket where ticketno = 3157766

--> 68	51	93

select * from ServiceLevelAgreement where customerid = 68

--54	HeroMotoCorpLtd INC
--55	HeroMotoCorpLtd SR

select * from TicketStatus where ticketTypeId  = 2

--statusId	status
--1	Open
--2	Assigned
--3	Work in Progress
--64	Open
--13	Assigned	0
--14	Work in Progress	0

select * from Priority where ticketTypeid = 2 --> 120

select top 1000 * from ServiceLevelObjective where serviceLevelAgreementId = 55 and serviceLevelObjectiveTypeId = 1
and serviceid = 51 and PriorityId =14  and workgroupid = 93


---> SR3161541

User ID= smartcenter ; Password= M!cr0land@smc$999 ; 

---> Asset Number : 102 max value:


select * from TicketStatus where TicketTypeid = 1

----> 65	Cancelled
--->  66	Cancelled

Select * from Workflow where nextStatusid in (65, 66)

---. SR3162517  IM3162523

select top 50 * from SMC_UserOtp 
order by 1 desc

https://iaccess.tataaig.com



   select * from Ticket where ticketno = 2757885  ----> 

   select impactId, impactName,statusId, statusName,customerid, customerName, serviceid, serviceName, deviceId,deviceName, workgroupId, workgroupName, priorityId, priorityName,
   categoryId, categoryName,* from Ticket where ticketno = 1560772 

   ---->  1	Generic
   -----> 1721

   ---->  328 , 

   select * from Impact

   select * from Priority where ticketTypeId = 2

   select * from TicketStatus where ticketTypeId =2

   select * from DeviceServiceMapping where deviceId = 1 and ticketTypeId =2 and serviceId =11

   --Update ticket set statusId= 64, statusName='Open',priorityId=16, 
   --priorityName='SR4', impactId=4, impactName='LOW'  where ticketNo = 1560772

   select * from ServiceLevelTracking where sourceId = 1560772 ---->  

   select * from Service where serviceName like '%Desktop%' --->  1 Desktop-Laptop Management

   select * from ServiceCustomerMapping where serviceId =1 and ticketTypeId = 2 ---->  1

   select * from ServiceCategoryMapping where serviceId = 1and ticketTypeId =2 and categoryId = 1721

   ---->  1729	Desktop
   ---->  4991	Desktop Handover

   select * from Category where categoryId in (
   
   select categoryId from ServiceCategoryMapping where serviceId = 1and ticketTypeId =2 )

   select * from SubCategory where categoryId = 1729

   select * from Classification where subCategoryId = 4991

   select * from DeviceServiceMapping where deviceId = 1 and serviceId = 1 and ticketTypeId =2

 --  	Update Ticket set serviceId= 1, serviceName='Desktop-Laptop Management',categoryId = 1729, subCategoryId = 4991, classificationId =9091, 
	--categoryName ='Desktop', subCategoryName='Desktop Handover',
	--classificationName='Others-Undefined', deviceId=1, deviceName='Generic' where ticketno = 1560772 




   select * from ServiceCategoryMapping where serviceId = 489 and deleted =0

   select * from Category where categoryId = 5316

   --->  5316

   select * From SubCategory where categoryId = 5316,

   ---> 20822	others

   select * from Classification where subCategoryId = 20822

   --->  85872

   ----->  177	SMC New KGI

   select * from ServiceCustomerMapping where customerId = 177 and deleted =0 --->  serviceid-- 489


   select * from service where serviceid = 489 --->  AD Self Service Portal

   select d.deviceId, d.deviceName, dsm.ticketTypeId from Device D
   inner join DeviceServiceMapping DSM on D.deviceId = DSM.deviceId
   where DSM.serviceId = 489 and d.deleted =0

   ---->  deviceId	deviceName	ticketTypeId
           6440	    Generic	     1


	-- Update Ticket set serviceId = 489, serviceName ='AD Self Service Portal', 
	-- deviceId = 6440, deviceName ='Generic' where ticketno = 2757885 

	--Update Ticket set categoryId = 5316, subCategoryId = 20822, classificationId =85872, 
	--categoryName ='Active Directory', subCategoryName='others',
	--classificationName='others' where ticketno = 2757885 


		select * from NotificationEmailTemplate  where customerId =192
		and templateName like '%SMS%'


	 select * from ServiceLevelTracking where sourceid	= 1453555
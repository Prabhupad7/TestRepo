


select * from NotificationRegistry where sourceId = 2898937 ---->

select * from NotificationEmailTemplate where templateid in (

select templateid from NotificationRegistry where sourceId = 2898937

)

--MLTagicHelpdeskSupport1@tataaig.com


--EUS_Lead.Microland@tataaig.com 

-- Ashutosh.Dubey@tataaig.com


select * from Requestor where requestorEmail like '%ArchitaB@microland.com%' ----> 57607

--update Requestor set failedLoginAttemptCount =0, isAccountLocked =0 where requestorId = 57607 

select * from Requestor where requestorEmail like '%venkataramanaiahk@microland.com%' ----> 54539


select * from Requestor where requestorEmail like '%vigneshan%' ----> 50482  53778

---->   microland@bng1 Microland@bng1

--update Requestor set Password ='SUv/GzSv2NSYGeW1YMGviQ==' where requestorId = 54539 ----> 

--update Requestor set Password ='SUv/GzSv2NSYGeW1YMGviQ==', alias ='' where requestorId = 57607 ----> 

select * from CustomerRequestorMapping where requestorId = 57607


--insert into CustomerRequestorMapping (requestorId, customerId, customerName, isLoginAllowed)

--values (54539, 152, 'SMC HMCL', 0)

--update CustomerRequestorMapping set isLoginAllowed =1 where customerRequestorMappingId  = 68154
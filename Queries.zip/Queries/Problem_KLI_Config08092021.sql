
select * from TicketType ---> 4	Problem

select * from ServiceLevelAgreement where customerid = 1

--3	MLRMC PROBLEM
--20	Problem Management-RCA
--21	Problem Management-RFO

--1	MLRMC SR
--2	MLRMC INCIDENT


select * from ServiceLevelObjective where serviceLevelAgreementId in (3,20, 21)

select top 1000 * from ServiceLevelObjective where serviceLevelAgreementId in (1)

select top 1000 * from ServiceLevelObjective where serviceLevelAgreementId in (2)

select distinct workHourId from ServiceLevelObjective where serviceLevelAgreementId in (1,2)

select distinct locationId from ServiceLevelObjective where serviceLevelAgreementId in (1,2)

select distinct locationId from ServiceLevelObjective where serviceLevelAgreementId in (1,2)

select * from Priority where ticketTypeId = 4

select * from TicketStatus where ticketTypeId = 4

---> 22	Open , 27	RCA Approved , 39	Resolved , 74	On Hold (Others)

--priorityId	priority
--4	    P1
--8	    P2
--12	P3

---> Impact id's 1,5,6,7

select * from ServiceLevelObjective where serviceLevelAgreementId in (3,20, 21) and serviceLevelObjectiveTypeId = 1

--Update ServiceLevelObjective set excludeStatusIds = '25,74'
--where serviceLevelAgreementId in (3,20, 21) and serviceLevelObjectiveTypeId = 2


select top 2000 * from ServiceLevelObjective
where serviceLevelAgreementId in (1, 2) and serviceLevelObjectiveTypeId = 2


--8307351
--8307352
--8307353
--8307354

--Insert into ServiceLevelObjective (serviceLevelAgreementId,	serviceLevelObjectiveTypeId,	initialStatusId,	finalStatusId,	responseTimeInMin,	excludeStatusIds,	serviceId,	priorityId,	impactId,	holidayCalendarId,	workHourId,	is24X7Service,	locationId,	workgroupId, isDelete,	isDefault)


--select 21,	serviceLevelObjectiveTypeId,	initialStatusId,	finalStatusId,	responseTimeInMin,	excludeStatusIds,	serviceId,	priorityId,	impactId,	holidayCalendarId,	workHourId,	is24X7Service,	locationId,	workgroupId, isDelete,	isDefault
--from ServiceLevelObjective where serviceLevelAgreementId = 20

---> 25,74

select 20, 2, 22, 39, 43200, 25, 1, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 1, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 1, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 1, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
					 
select 20, 2, 22, 39, 43200, 25, 1, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 1, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 1, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 1, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
					
select 20, 2, 22, 39, 43200, 25, 1, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 1, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 1, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 1, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
					
-----> 				 
select 20, 2, 22, 39, 43200, 25, 2, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 2, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 2, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 2, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 2, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 2, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 2, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 2, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 2, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 2, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 2, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 2, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		  
------->	2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 3, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 3, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 3, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 3, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 3, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 3, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 3, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 3, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 3, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 3, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 3, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 3, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		  
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 4, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 4, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 4, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 4, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 4, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 4, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 4, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 4, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 4, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 4, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 4, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 4, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		  
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 6, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 6, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 6, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 6, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 6, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 6, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 6, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 6, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 6, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 6, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 6, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 6, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		  
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 7, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 7, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 7, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 7, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 7, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 7, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 7, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 7, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 7, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 7, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 7, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 7, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		  
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 8, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 8, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 8, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 8, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 8, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 8, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 8, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 8, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 8, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 8, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 8, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 8, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		  
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 11, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 11, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 11, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 11, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 11, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 11, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 11, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 11, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 11, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 11, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 11, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 11, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		  
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 14, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 14, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 14, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 14, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 14, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 14, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 14, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 14, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 14, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 14, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 14, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 14, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		 
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 15, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 15, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 15, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 15, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 15, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 15, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 15, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 15, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 15, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 15, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 15, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 15, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		   
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 16, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 16, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 16, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 16, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 16, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 16, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 16, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 16, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 16, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 16, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 16, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 16, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		  
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 17, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 17, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 17, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 17, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 17, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 17, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 17, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 17, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 17, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 17, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 17, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 17, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		 
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 18, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 18, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 18, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 18, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 18, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 18, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 18, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 18, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 18, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 18, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 18, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 18, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		  
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 31, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 31, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 31, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 31, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 31, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 31, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 31, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 31, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 31, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 31, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 31, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 31, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		 
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 47, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 47, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 47, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 47, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 47, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 47, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 47, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 47, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 47, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 47, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 47, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 47, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		   
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 87, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 87, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 87, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 87, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 87, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 87, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 87, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 87, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 87, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 87, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 87, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 87, 12, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
		   
---> 	   2, 22, 39, 43200,
select 20, 2, 22, 39, 43200, 25, 94, 4, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 94, 4, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 94, 4, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 94, 4, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 94, 8, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 94, 8, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 94, 8, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 94, 8, 7, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 94, 12, 1, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 94, 12, 5, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 94, 12, 6, 1, 1, 0, 0, NULL, 0, 0 UNION ALL
select 20, 2, 22, 39, 43200, 25, 94, 12, 7, 1, 1, 0, 0, NULL, 0, 0 


select * from Service where serviceName like '%Virtual Desktop Management%'

--> 14	AIU  Management
--47	AIX Admin
--2	  Application Management
--87	Channel Support
--11	Database Management
--1	   Desktop-Laptop Management
--7	    ID Management
--8	    IMACD
--94	Infra Security device Management
--3	   Network  Management
--16	Outage
--6	   Purchase Management
--17	Purchase Management - Peripherals
--15	Security Management
--4	    Server Management
--18	UAT Server Access Management
--31	Virtual Desktop Management

----> Category Schema adding, Rules for assignment and RulesForPriority:

select * from Service where serviceId in (14, 47,2,	87,11,1,7,8,94,3,16,6,17,15,4,18,31)

select * from Service where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)

select * from ServiceCustomerMapping 
where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)
and customerId = 1 and ticketTypeId = 4

select * from CustomerPriorityMapping where customerId = 1  ---> 89	12

select * from servicePriorityMapping where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)
and PriorityId = 12

--and ticketTypeId = 4

select * from Priority where ticketTypeid = 4   ----> 12	P3

select * from Impact   ----> 4	Low

select * from servicePriorityMapping 
where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)
and customerid =1 and  priorityId = 12


select * from ServiceCategoryMapping where ticketTypeid= 4

select * from Service where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)

---> 2	  Application Management

      select  top 100 * from category where deleted = 0

--  Insert into Category(category,deleted,ticketTypeId,serviceId,Isdefaultcategory,isEUPVisible,icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)
--values
--('ABU', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('AllSec', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('AML', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('ARL System', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('Asset management', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('Boost', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('Boost for advisors', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('Boost for Agents', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),








select top 102 * from Category order by 1 desc



   --   Insert into ServiceCategorymapping (serviceId, categoryId, deleted, ticketTypeId) 
	  --values 
(2, 1798, 0, 4),
(2, 1799, 0, 4),
(2, 1800, 0, 4),
(2, 1801, 0, 4),

	  ------> 

	   Insert into SubCategory (subCategory,categoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)
     Values
	   ('Data Update', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()), 
       ('Production Issue � Genie', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   ('Production Issue � IONE-LA Integration', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   ('Production Issue � IR', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
       ('Production Issue � Miscellaneous', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   ('Production Issue � Online PDR', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
       ('Production Issue � OPM-PS Integration', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   ('Production Issue � Other', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   ('Production Issue � Seibel Integration', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()), 
       ('Response timed out Undefined', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   ('Slow response Undefined', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   ('UAT Issue � IONE-LA Integration', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
       ('UAT Issue � LifeAsia BO', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   ('UAT Issue � Miscellaneous', 1825,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())



	   select top 14 * from SubCategory order by 1 desc

	   ('Laptop Battery', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
       ('Monitor', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   ('Mouse', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())

    --   ('PC', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   --('Printer', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
    --   ('Projector', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   --('RAM', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())

  ---------------------------> 

  select top 3  * from Classification where deleted = 0
  order by 1 desc



   
 Insert into Classification(classification,subCategoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,Updatedon)
		 values 
		 ('Others-Undefined', 5457, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5456, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5455, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5454, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5453, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5452, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5451, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),	 
		 ('Others-Undefined', 5450, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5449, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5448, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5447, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5446, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5445, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5444, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate())
		

	-------------> Rules for Assignment and Rules for Priority:

	select top 100 * from RulesForAssignment order by 1 desc

	---> 1050	KLI Rule	{customerId=1;serviceId=2;categoryId=1735;}

	select * from workgroup ----> 14	AIU  Management

	select * from workgroup where workgroup like '%ALX%'  ---> 3	Application Management

	select * from AssignmentGroup where workgroupId = 3  ---> 16	Application Management-Queue

	select * from AssignmentGroup where assignmentgroupId = 155  --> AIX Admin-Queue	85

	select top 1000 * from RulesForAssignment where AssignmentRule like '%serviceId=47%'  --->  155

	--Insert into RulesForAssignment
	
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1798;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1799;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1800;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1801;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1802;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL


		select top 105 * from RulesForAssignment order by 1 desc

--		Update RulesForAssignment set AssignmentRule = Replace(AssignmentRule, 'serviceId=47','serviceId=2' )
--where RuleId in (
--1065,
--1064,
--1063
--)


   -----------> Rules for Priority:


   select top 1000 * from RulesForPriority where RuleTemplateId = 97  order by 1 desc

   ---> 2505	Apc assist	{customerid=93;serviceid=89;tickettypeid=1;}
  ----> 2658	Rules	{customerId=1;serviceId=2;ticketTypeId=1;}	1	10	1	0	97	NULL

  select * from Service where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)


  select * from Priority where ticketTypeId = 4  ---> 12	P3

     select top 100 * from RulesForPriority 
	 order by 1 desc

  select * from Impact  --> 1	Minor, 4	Low

  --Insert into RulesForPriority 

  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=1;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=2;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=3;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=4;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=6;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=7;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=8;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=11;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=14;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=15;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=16;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=17;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=18;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=31;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=47;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=87;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=94;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL 


  --------------> NotificationRules:

  
  select * from TicketType  ---> 4	Problem	PM

  select * from CustomerPriorityMapping where priorityId = 12 ---> 89 1	Kotak Life Insurance

  --<option value="4">Problem Management</option>




select * from ticket t
left outer join IncidentTicket it on it.ticketno = t.ticketNo
left outer join ServiceRequestTicket sr on sr.ticketNo = t.ticketNo
where customerid in (select customerid from customer where customerName like 'SMC %')
and tickettypeid in (1, 2)
and dateadd(mi, 330, case when t.TicketTypeid = 1 then it.resolvedTime else sr.resolvedTime end)
> cast(dateadd(mi, 330, getdate()) as date)
and t.LastUpdatedById in (
26093)


---->   26093 Venkat

---->  25892  mohammed

---->  26549


---->  TSK2827031
Please examine WiFi connectivity for SVP Line 1 and SVP Line 2 and SLM core areas to ensure that there is proper connectivity. Hi Luis - As per your last update this ticket had to be addressed during shutdown. Please let me know if there is any progress on this ticket. Why is this ticket sitting on hold status


2900346

2900347


  select * from Ticket where ticketno = '2827031'

  ---->  ticket  taskticket 


  select * from users where email like '%SuhasSn%'  ----> 26395

  select * from AssetEntityType where name like '%Knowledge Management%'

    select * from AssetEntityType where id in (285, 66)

  Select * from Asset_EntityTypeUserMapping where entityTypeId = 285



  --insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)

  --Select 26395,66,GETDATE(),6,0


    select * from users where email like '%InduN%' ----> 25704

	select * from users where email like '%SuvarnaKR@microland.com%' ----> 26093

	select * from users where loginName like '%SuvarnaKR%' ---->  1539	Suvarna	K

	select * from users where userid in (25704, 26093) 

	-- jnanendraph@microland.com - JNANENDRAPH

	select * from Workgroup where workgroup like '%Remote resolution%' ---->  247	Remote Resolution Group

	select * from Assignmentgroup where workgroupid = 247 ---->  364

	select * from CustomerAssignmentGroupMapping where assignmentgroupId = 364 ---> 1271
	 
	select * from UserCustomerAssignGroupMapping 
    where userId = 1539 and custAssignmentGroupId = 1271

	---->   91  7795437762

	--Update UserCustomerAssignGroupMapping set deleted =0 where userCustomerAssignGroupId = 95467


--	Please do the needful .

--User Name 	Sudip Kumar Giri
--Email ID	sudipkumar.giri@heromotocorp.com
--IMP Code	13991



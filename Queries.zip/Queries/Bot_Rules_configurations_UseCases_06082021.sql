
 
select * from Device where deviceName like '%R22%' ---> 26579	R22  10.16.16.252

select * from RulesForAutomationRemedial where CustomerId = 50 
and RuleDescription like '%R11%'

select * from RulesForAutomationRemedial where CustomerId = 50 
and AssignmentRule like '%26579%'


select * from RulesForAutomationRemedial where RUleid = 81


Gi1021 BTP NOC Status has entered Critical state with polled result 2 [ Down ]. Test has been in state for 223d 09:34
                                       customerid=50;description like [ Down ]. Test has been in state;ticketTypeId=1;

--Update RulesForAutomationRemedial set AssignmentRule ='customerid=50;description like Test has been in state;ticketTypeId=1;'
--where ruleid = 95


----> [ Down ]. Test has been in state;ticketTypeId=1;

select top 1000 * from AutoTicketServiceRuleDetails 

select * from RulesForAutomationRemedial where CustomerId = 50 
and RuleDescription like '%Port Utilization Abnormality%'

select * from RulesForAutomationRemedial where CustomerId = 50 
and RuleDescription like '%Network High CPU Utilization%'

select * from RunbookMaster 

----> Network High CPU Utilization 


--update RulesForAutomationRemedial set AssignmentRule = 'customerid=50;description like (Util In has entered Critical state | Util Out has entered Critical state);ticketTypeId=1;',NoOfParams = 3 where CustomerId = 50 and RuleId = 82

--update RulesForAutomationRemedial set ApiJson = '{
--  "apiurl": http://203.90.4.94:3000/apis/resolve,
--  "apimethod": "Post",
--  "Headers": {
--    "AuthToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2MDIzYjVjZjRhNjkwZDAwMTU2YjYzMTYiLCJpYXQiOjE2MTI5NTMxNDcsImV4cCI6MTY0NDQ4OTE0N30.mSBhy0bXA-yW1NgyTkaga3eyLRWYXN8hokb3s9HUbTc"
--  },
--  "ContentType": "application/json; charset=utf-8",
--  "apiparameters": {
--    "ticket": {
--      "ticketNo": "$TICKETNO",
--      "source": "smartcenter",
--      "customer_id": "$customerName",
--      "description": "$DESCRIPTION",
--      "deviceName": "$DEVICENAME",
--      "ip": "$IPADDRESS",
--      "prioritycolorcode": "DarkBlue"
--    }
--  }
--}' where RuleId = 82

[ Down ]. Test has been in state

select * from RulesForAutomationRemedial where CustomerId = 50 and AssignmentRule like '%87465%'

select * from RulesForAutomationRemedial where CustomerId = 50 and AssignmentRule like '%87465%'



select * from Classification where classificationId like '%87465%'   

select * from Classification where classificationId like '%87466%'  

select * from Classification 
where classification like '%Port Utilization Abnormality%'  ----> 87466	Port Utilization Abnormality

select * from Classification 
where classification like '%Packet Loss%'  
 

select * from SubCategory where subCategory like '%Performance Down%'

select * from SubCategory where subcategoryid = 21099 ---> 21099	Port Utilization Abnormality

--------------> 

select top 10 * from Trans_AutomationRemedial where ticketno= 2542072
order by 1 desc  

--StatusCode: 500, ReasonPhrase: 'Internal Server Error', Version: 1.1, Content: System.Net.Http.StreamContent, Headers:  {    Connection: keep-alive    Keep-Alive: timeout=5    Date: Wed, 11 Aug 2021 05:49:10 GMT    ETag: W/"95-246c63LSFRtIiM2frXAJfbMdRvg"    X-Powered-By: Express    Content-Length: 149    Content-Type: application/json; charset=utf-8  }
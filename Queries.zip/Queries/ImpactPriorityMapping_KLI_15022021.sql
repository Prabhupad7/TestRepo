 
 
 
 SELECT  DISTINCT CASE scm.tickettypeid WHEN 1 THEN 'Incident' WHEN 2 THEN 'Service Request' WHEN 3 THEN 'Change' WHEN 4 THEN 'Problem' END TicketType,   s.servicename,   c.category, sc.subcategory,   cl.classification, CASE WHEN scm.deleted = 0   AND c.deleted = 0   AND
sc.deleted = 0   AND cl.deleted = 0   AND scc.deleted = 0  THEN 'Yes' ELSE 'No' END AS IsActive,   CASE WHEN s.iseupvisible = 0  AND c.iseupvisible = 0   AND sc.iseupvisible = 0   AND cl.iseupvisible = 0  THEN 'Yes' ELSE 'No' END AS IsEupEnabled,p.priority, i.impact
FROM   servicecustomermapping scc  JOIN tickettype t ON t.tickettypeid = scc.tickettypeid  
JOIN servicecategorymapping scm ON scc.serviceid = scm.serviceid   AND scm.tickettypeid = t.tickettypeid
JOIN service s ON s.serviceid = scm.serviceid   JOIN category c ON scm.categoryid = c.categoryid  
JOIN subcategory sc ON sc.categoryid = c.categoryid   JOIN classification cl ON cl.subcategoryid = sc.subcategoryid  
join serviceprioritymapping spm on spm.serviceid=s.serviceid  join Priority p on p.priorityid = spm.priorityid
join ImpactTicketTypeMapping ip on ip.serviceId=s.serviceId join Impact i on i.impactId=ip.impactid
WHERE     s.serviceId in (1 )   AND scm.deleted = 0  AND c.deleted = 0  AND sc.deleted = 0
AND cl.deleted = 0   AND scc.deleted = 0 and spm.deleted=0 and ip.deleted=0 and scc.customerId =1


-----> 
 SELECT  DISTINCT CASE scm.tickettypeid WHEN 1 THEN 'Incident' WHEN 2 THEN 'Service Request' WHEN 3 THEN 'Change' WHEN 4 THEN 'Problem' END TicketType,   s.servicename, s.serviceId,  c.category, c.categoryId,  sc.subcategory,   cl.classification, CASE WHEN scm.deleted = 0   AND c.deleted = 0   AND
sc.deleted = 0   AND cl.deleted = 0   AND scc.deleted = 0  THEN 'Yes' ELSE 'No' END AS IsActive,   CASE WHEN s.iseupvisible = 0  AND c.iseupvisible = 0   AND sc.iseupvisible = 0   AND cl.iseupvisible = 0  THEN 'Yes' ELSE 'No' END AS IsEupEnabled,p.priority, i.impact
FROM   servicecustomermapping scc  JOIN tickettype t ON t.tickettypeid = scc.tickettypeid  
JOIN servicecategorymapping scm ON scc.serviceid = scm.serviceid   AND scm.tickettypeid = t.tickettypeid
JOIN service s ON s.serviceid = scm.serviceid   JOIN category c ON scm.categoryid = c.categoryid  
JOIN subcategory sc ON sc.categoryid = c.categoryid   JOIN classification cl ON cl.subcategoryid = sc.subcategoryid  
join serviceprioritymapping spm on spm.serviceid=s.serviceid  join Priority p on p.priorityid = spm.priorityid
join ImpactTicketTypeMapping ip on ip.serviceId=s.serviceId join Impact i on i.impactId=ip.impactid
WHERE     s.serviceId in (1 )   AND scm.deleted = 0  AND c.deleted = 0  AND sc.deleted = 0   AND cl.deleted = 0   AND scc.deleted = 0 and spm.deleted=0 and ip.deleted=0

  select * from Users where email like '%niharika%' --->  25448

  select * from Workgroup where workgroup like '%SMC Password%' --> 725

  select * from AssignmentGroup where workgroupId  = 725  --->  859

  select * from CustomerAssignmentGroupMapping where assignmentgroupId = 859 --->  2984

  select * from UserCustomerAssignGroupMapping where userId = 25448 and custAssignmentGroupId = 2984


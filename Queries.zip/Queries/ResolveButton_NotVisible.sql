

  ---> we need to check the approval date of the ticket and 

  -->  Update in approval table in approval completion time col

  -->  Update approval set ApprovalCompletedTime ='07/12/2020 22:42:58'  where approvalNo =  2974784

  select ApprovalCompletedTime,* from Approval where approvalNo = 3132103  

  --Update approval set ApprovalCompletedTime = '23/8/2021 15:46:08'  where approvalNo =  3132103

    Update approval set ApprovalCompletedTime = '23/8/2021 15:46:08'  where approvalNo =  3132103

  --->  17/03/2021 03:09:42

  --Update approval set ApprovalCompletedTime ='06/04/2021 01:18:20'  where approvalNo =  2935320

  --->  RP000024 

  select * from ReportMaster where reportMasterID = 24

  select roleId,* from Users where email like '%HariTN@microland.com%'   ----->  HariTN@microland.com  38

  select * from ReportRoleMapping where roleid =  38 and ReportMasterId = 24

  --Insert into ReportRoleMapping (RoleId, ReportMasterId, IsDeleted)
  --values (38, 24, 0)


  select * from Approval where approvalNo = '2974784' 
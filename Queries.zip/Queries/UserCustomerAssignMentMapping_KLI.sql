
        select * from Users where email like '%suhas%'   --->  26395

		--update users set mobileNo = '9880802160' where userId = 26395

		select * from customer  where customerName like '%Bell%'--->  186

		---> SI L1 Support

		select * from Workgroup where Workgroup like '%SI L1 Support%'  --->  498
		
		select * from AssignmentGroup where workgroupId = 498 --->  617

		select * from CustomerAssignmentGroupMapping where assignmentgroupId = 617 --->  2387

		select * from UserCustomerAssignGroupMapping where userId = 26395 and custAssignmentGroupId = 2387


		select * from CustomerAssignmentGroupMapping where customerId = 186 and deleted =0


	select * from Workgroup W
   inner join AssignmentGroup Ag on Ag.workgroupId = W.workgroupId
   inner join CustomerAssignmentGroupMapping CM on CM.assignmentgroupId =Ag.assignmentgroupId
   where cm.customerId = 186
   and w.workgroupId in (
   2,3,4,5,9,10,13,47,104,169,442,490,492,523,541,556,609,727,729,731,732,733 )




	    select * from Users where loginName in ('OM15895')  ---> Sunil Jadhav-  OM15895 
		--->  jadhav.sunil@kotak.com 

	  select * from Users where loginName in ('LO4461', 'LO3901', 'OM15895')  ---> 1268

	  --->  Sunil Jadhav-  OM15895  no access we need to give access: 

	   select * from CustomerAssignmentGroupMapping 

	   select * from UserCustomerAssignGroupMapping where userid in (1268)
	   select * from UserCustomerAssignGroupMapping where userid in (1335)
	   select * from UserCustomerAssignGroupMapping where userid in (991, 994)

		  	-- Insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
				values
			(991, 224,0,1,1),
			(994, 224,0,1,1)

			--Update UserCustomerAssignGroupMapping set AssignToWorkgroup =1 where userCustomerAssignGroupId in (
			--12010, 12013
			--)


			   select * from Workgroup W
   inner join AssignmentGroup Ag on Ag.workgroupId = W.workgroupId
   inner join CustomerAssignmentGroupMapping CM on CM.assignmentgroupId =Ag.assignmentgroupId
   where cm.customerId = 194 and w.workgroupId in (
   2,3,4,5,9,10,13,47,104,169,442,490,492,523,541,556,609,727,729,731,732,733 )


      select cm.custAssignmentGroupName, cm.custAssignmentGroupId from Workgroup W
   inner join AssignmentGroup Ag on Ag.workgroupId = W.workgroupId
   inner join CustomerAssignmentGroupMapping CM on CM.assignmentgroupId =Ag.assignmentgroupId
   where cm.customerId = 194 and w.workgroupId in (
 3,4,5,9,10,47,104,169,492,541,556 )

  Select * from Category where category like '%Life Asia%'

  select * from ServiceCategoryMapping where categoryId = 946

  -- update ServiceCategoryMapping set deleted = 1 where serviceCategoryMappingId = 1175


  --->  SR1448687 

  select customerId, serviceId, workgroupId, categoryId, subCategoryId, classificationId, priorityId,
  * from Ticket where ticketNo = 1448687 
  ---> 7 serviceId

  Select * from Workgroup where workgroupId = 3 --->  Application Management

  select * from Users where firstName like '%Mayuri%' --->  1107

   select * from Users where firstName like '%sonali%' --->  952

     select * from Users where firstName like '%Juli%' --->  1090

   select * from UserCustomerAssignGroupMapping where userid in (1107)

      select * from UserCustomerAssignGroupMapping where userid in (1107) and custAssignmentGroupId =16

	  select * from UserCustomerAssignGroupMapping where userid in (952) and custAssignmentGroupId =16



   select * from UserCustomerAssignGroupMapping where userid in (952)

  -- Update UserCustomerAssignGroupMapping set AssignToWorkgroup =1 where userCustomerAssignGroupId = 12999

   --->  16

  select * from Assignmentgroup where assignmentgroupId in (
  select assignmentgroupId from CustomerAssignmentGroupMapping CA where custAssignmentGroupId In (
  select custAssignmentGroupId from UserCustomerAssignGroupMapping where userid in (1107)))

    select * from CustomerAssignmentGroupMapping CA where custAssignmentGroupId In (
  select custAssignmentGroupId from UserCustomerAssignGroupMapping where userid in (1107))



  
--Assignment Group	Enable Assignment 	Assign Workgroup 	Delete
--Ask Microland - SMC Password Reset - Queue			
--Automation - ADSS Support




    select distinct w.workgroupid, w.workgroup from Workgroup W
  inner join AssignmentGroup AG on W.workgroupId = AG.workgroupId
  inner join CustomerAssignmentGroupMapping CG on CG.assignmentgroupId = AG.assignmentgroupId
  inner join UserCustomerAssignGroupMapping  US on US.custAssignmentGroupId = CG.custAssignmentGroupId
  where cg.customerId =1 and w.workgroupId in (2, 12, 19, 9, 8, 5, 123, 136, 137, 86)
﻿


 Mohammed K:  
-- to check diff of whose replica: 
select * from UserCustomerAssignGroupMapping c where userId=507 and deleted=0  
and c.custAssignmentGroupId not in (select custAssignmentGroupId from UserCustomerAssignGroupMapping where userId=1788) 

select * from UserCustomerAssignGroupMapping c where userId=1788 and deleted=0  
and c.custAssignmentGroupId not in (select custAssignmentGroupId from UserCustomerAssignGroupMapping where userId=24269) 


 


 select * from Customer where customerId = 207
select custAssignmentGroupId from CustomerAssignmentGroupMapping where customerId = 207 --get custAssignmentGroupId 
select * from Users where userid = 24269
select * from Users where userid = 1788
select * from UserCustomerAssignGroupMapping where userId = 1036

--insert into UserCustomerAssignGroupMapping
select 1036,2720,0,0,0 ---  insert custAssignmentGroupId for the particular user as per requirement

For UserId = 25305:

        Insert into UserCustomerAssignGroupMapping
            select 25305, 2717, 0, 1, 1
			union all
			select 25305, 2718, 0, 1, 1
			union all
			select 25305, 2719, 0, 1, 1
			union all
			select 25305, 2720, 0, 1, 1
			union all
			select 25305, 2721, 0, 1, 1
			union all
			select 25305, 2722, 0, 1, 1
			union all
			select 25305, 2723, 0, 1, 1
			union all
			select 25305, 2724, 0, 1, 1
			union all
			select 25305, 2725, 0, 1, 1
			union all
			select 25305, 2726, 0, 1, 1
			union all
			select 25305, 2727, 0, 1, 1
			union all
			select 25305, 2728, 0, 1, 1
			union all
			select 25305, 2729, 0, 1, 1
			union all
			select 25305, 2730, 0, 1, 1
			union all
			select 25305, 2731, 0, 1, 1
			union all
			select 25305, 2732, 0, 1, 1






  select custAssignmentGroupId vipin from UserCustomerAssignGroupMapping c where userId=24269 and deleted=0 AND C.deleted
  select custAssignmentGroupId rashmi from UserCustomerAssignGroupMapping c where userId=1788 and deleted=0  

  [‎6/‎5/‎2020 3:48 PM]  Mohammed K:  
select * from UserCustomerAssignGroupMapping where userId =1788 and custAssignmentGroupId in (1061,
1131,
1983,
2064,
2381,
2393,
2431,
2664) 
 
Call with Mohammed K (mohammedki@microland.com) has ended. 9 minutes  

 
 UPDATE UserCustomerAssignGroupMapping  SET deleted = 1 WHERE userCustomerAssignGroupId IN (141525, 141527, 141529, 141530, 141532, 141534, 141536, 141539)

 userCustomerAssignGroupId
141525
141527
141529
141530
141532
141534
141536
141539

 SELECT * FROM Workgroup W WHERE W.displayName LIKE '%Oreta%'

 Server Support Oreta --> Oreta-->ID-->616

 select * from CustomerAssignmentGroupMapping  CAMG
 inner join 
 where CAMG.USER_ID = 1788


 What vipin has --> 260, 

 what Reshmi Has --> 1061, 1065, 1131, 1135, 1136, 1983,2064, 2213, 2381 , 2382, 2393, 2395, 2431, 2664, 2673, 2692, 2693, 2694, 2695, 2696, 2697, 2698, 2699, 2700, 2716, 2724

 
 select * from UserCustomerAssignGroupMapping where userId =1788 and deleted = 0
 


 select top 100 * from AssignmentGroup AG

 select * from UserCustomerAssignGroupMapping aa where aa.userId = 24269 and
 deleted = 0 and custAssignmentGroupId not in (select custAssignmentGroupId 
 from UserCustomerAssignGroupMapping aa where aa.userId = 1788 and deleted = 0)
 
  select * from UserCustomerAssignGroupMapping b where b.userId = 1788 and deleted = 0 and
  custAssignmentGroupId not in(select custAssignmentGroupId from UserCustomerAssignGroupMapping
  aa where aa.userId = 24269 and deleted = 0)
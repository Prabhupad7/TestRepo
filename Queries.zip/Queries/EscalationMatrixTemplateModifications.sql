
	          select�*�from�ApprovalEmailRules�where�ApprovalEntityMappingId�in�(
              select�approvalEntityMappingId�from�ApprovalEntityMapping�where�customerId=147�and�deleted=0�) and NotificationBody like '%AnanthKBK@microland.com%' 
	          and isMoreInfoTemplate = 1

			   UPDATE ApprovalEmailRules SET NotificationBody = '' WHERE ID IN ()

	        	  select�*�from�ApprovalEmailRules�where�ApprovalEntityMappingId�in�(
            select�approvalEntityMappingId�from�ApprovalEntityMapping�where�customerId=147�and�deleted=0�) and id in (4106, 4108
)
	        and isMoreInfoTemplate = 0


-- FOR isMoreInfoTemplate = 0
UPDATE ApprovalEmailRules SET NotificationBody = '  

<html style="background-color: #F0F0F0;">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Untitled Document</title>
	</head>
	<body style="background-color: #F0F0F0;">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" style="background-color: #F0F0F0;">
					<table width="900" border="0" cellspacing="0" cellpadding="0" style="border: 1px solid #656161;">
						<tr>
							<td align="left" valign="top" bgcolor="#FFFFFF" style="background-color: #FFFFFF;">
								<table width="100%" border="0" cellspacing="0" cellpadding="0">
									<tr>
										<td width="35" align="left" valign="top" />
										<td align="left" valign="top">
											<table width="100%" border="0" cellspacing="0" cellpadding="0">
												<tr>
													<td valign="top" style="font-family: Segoe UI; font-size: 20px; padding-left: 3px; font-weight: bold;padding-top: 20px;"> Pending Approval Notification </td>
												</tr>
												<tr>
													<td align="left" valign="top">
														<table style="width: 100%">
															<tr>
																<td />
															</tr>
															<tr>
																<td style="font-family: Segoe UI; padding-left: 3px;">Dear Approver </td>
															</tr>
															<tr>
																<td />
															</tr>
															<tr>
																<td style="font-family: Segoe UI; padding-left: 3px;"> This is to inform you that the following request is pending for your approval. Below are details of your Approval. 
																	
																	
																	
																	<a href="https://helpdesk.microland.com/Approval/GetApproverWithApprovalDetails?sourceId=@Model.SOURCEID&entityTypeName=TICKET&entityTypeId=2">Click Here</a> to Approve or Reject 
																
																
																
																</td>
															</tr>
															<tr>
																<td />
															</tr>
															<tr>
																<td>
																	<table style="width: 100%; font-size: 14px;">
																		<tr>
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Approval Number</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI; ">
																				<a href="https://helpdesk.microland.com/Approval/GetApproverWithApprovalDetails?sourceId=@Model.SOURCEID&entityTypeName=TICKET&entityTypeId=2">$APPROVALNO</a>
																			</td>
																		</tr>
																		<tr>
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Requestor Name</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$REQUESTORNAME </td>
																		</tr>
																		<tr>
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Requestor Department</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$REQUESTORDEPARTMENT </td>
																		</tr>
																		<tr>
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Requestor Designation</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$REQUESTORDESIGNATION </td>
																		</tr>
																		<tr>
																			<td style="font-family: Segoe UI; font-weight: bold;" width 225px;>Approval Level</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$APPROVALLEVELNAME </td>
																		</tr>
																		<tr style="border: 1px solid black">
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Category</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$CATEGORY</td>
																		</tr>
																		<tr style="border: 1px solid black">
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Sub Category</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$SUBCATEGORY</td>
																		</tr>
																		<tr style="border: 1px solid black">
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Classification</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$CLASSIFICATION</td>
																		</tr>
																		<tr style="border: 1px solid black">
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Logged Date and Time</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$LOGGEDDATEANDTIME</td>
																		</tr>
																		<tr style="border: 1px solid black">
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Description</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$DESCRIPTION</td>
																		</tr>
																	</table>
																</td>
															</tr>
															<tr>
																<td bgcolor="#ffffff" style="background-color: #ffffff; font-family: Segoe UI; padding-bottom: 20px;">
																	<table width="92%" border="1" align="center" cellspacing="0" cellpadding="0" style="font-size: 14px; font-family: Segoe UI;">
																		<tr>
																			<th colspan="4" style="font-weight: bold; background-color: gray;">Escalation Matrix </th>
																		</tr>
																		<tr>
																			<tr>
																				<th>Level </th>
																				<th>Name </th>
																				<th>Contact No </th>
																				<th>Email </th>
																			</tr>
																			<tr>
																				<td style="text-align: center;">1</td>
																				<td style="text-align: center;">MLIT Service desk</td>
																				<td style="text-align: center;">1000 /918061751003</td>
																				<td style="text-align: center;">MLITServicedesk@microland.com</td>
																			</tr>
																			<tr>
																				<td style="text-align: center;">2</td>
																				<td style="text-align: center;">Manjunath Kuntumala</td>
																				<td style="text-align: center;">919108799997</td>
																				<td style="text-align: center;">ManjunathK@microland.com</td>
																			</tr>
																			<tr>
																				<td style="text-align: center;">3</td>
																				<td style="text-align: center;">Srinivasulu Reddy E</td>
																				<td style="text-align: center;">5610/919945335479</td>
																				<td style="text-align: center;">SrinivasuluRE@microland.com</td>
																			</tr>
																		</table>
																		<br />
																	</tr>
																	<tr>
																		<td />
																	</tr>
																	<tr>
																		<td style="font-family: Segoe UI; padding-left: 3px;">
																			<br />
																			<p style="color: #000; font-size: 13px; width: 130%;"> Note: This is an automated notification, please do not reply to this mail and any response / additional information should be                                                                              
																				
																				
																				
																				<br /> sent to email ids mentioned in the signature of this email. 
																			
																			
																			
																			</p>
																		</td>
																	</tr>
																	<tr>
																		<td style="padding-top: 17px;">
																			<td />
																		</tr>
																	</table>
																</td>
															</tr>
															<tr>
																<td align="left" valign="top" style="font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #F0F0F0;" />
															</tr>
														</table>
													</td>
													<td width="35" align="left" valign="top" />
												</tr>
											</table>
										</td>
									</tr>
									<tr>
										<td bgcolor="#3C3C3A" style="background-color: #3C3C3A; height: 100px;">
											<table width="92%" border="0" align="center" cellspacing="0" cellpadding="0">
												<tr>
													<td style="width: 800px; font-family: Segoe UI; font-size: 14px; color: #f0f0f0">
														<p> Thanks & regards,                                                      
															
															
															
															<br /> For IT related issues contact helpdesk@microland.com || Internal:1000 || External: 080-61751003 (24 X 7)(For P1s - 24x7)                                                      
															
															
															
															<br /> For Non IT related issue contact askmicroland@microland.com(10:00 am to 6:00 pm Mon - Fri ) 
														
														
														
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br />
							</td>
						</tr>
					</table>
				</body>
			</html>' WHERE ID IN (4104
,4106
,4108
,4110
,4112
)


-- FOR isMoreInfoTemplate = 0


UPDATE ApprovalEmailRules SET NotificationBody = '  

<html style="background-color: #F0F0F0;">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Untitled Document</title>
	</head>
	<body style="background-color: #F0F0F0;">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" style="background-color: #F0F0F0;">
					<table width="900" border="0" cellspacing="0" cellpadding="0" style="border: 1px solid #656161;">
						<tr>
							<td align="left" valign="top" bgcolor="#FFFFFF" style="background-color: #FFFFFF;">
								<table width="100%" border="0" cellspacing="0" cellpadding="0">
									<tr>
										<td width="35" align="left" valign="top" />
										<td align="left" valign="top">
											<table width="100%" border="0" cellspacing="0" cellpadding="0">
												<tr>
													<td valign="top" style="font-family: Segoe UI; font-size: 20px; padding-left: 3px; font-weight: bold;padding-top: 20px;"> Approval Notification </td>
												</tr>
												<tr>
													<td align="left" valign="top">
														<table style="width: 100%">
															<tr>
																<td />
															</tr>
															<tr>
																<td style="font-family: Segoe UI; padding-left: 3px;">Dear $REQUESTORNAME </td>
															</tr>
															<tr>
																<td />
															</tr>
															<tr>
																<td style="font-family: Segoe UI; padding-left: 3px;"> This is to inform you that the Approval has been $STATUS by $APPROVERNAME with comments $COMMENTS. Below are details of your Approval. </td>
															</tr>
															<tr>
																<td />
															</tr>
															<tr>
																<td>
																	<table style="width: 100%; font-size: 14px;">
																		<tr>
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Approval Number</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI; ">$APPROVALNO</td>
																		</tr>
																		<tr>
																			<td style="font-family: Segoe UI; font-weight: bold;" width 225px;>Approval Level</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$APPROVALLEVELNAME </td>
																		</tr>
																		<tr style="border: 1px solid black">
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Category</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$CATEGORY</td>
																		</tr>
																		<tr style="border: 1px solid black">
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Sub Category</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$SUBCATEGORY</td>
																		</tr>
																		<tr style="border: 1px solid black">
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Classification</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$CLASSIFICATION</td>
																		</tr>
																		<tr style="border: 1px solid black">
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Logged Date and Time</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$LOGGEDDATEANDTIME</td>
																		</tr>
																		<tr style="border: 1px solid black">
																			<td style="font-family: Segoe UI; font-weight: bold; width: 225px;"> Description</td>
																			<td>:</td>
																			<td style="font-family: Segoe UI;">$DESCRIPTION</td>
																		</tr>
																	</table>
																</td>
																<tr>
																	<td bgcolor="#ffffff" style="background-color: #ffffff; font-family: Segoe UI; padding-bottom: 20px;">
																		<table width="92%" border="1" align="center" cellspacing="0" cellpadding="0" style="font-size: 14px; font-family: Segoe UI;">
																			<tr>
																				<th colspan="4" style="font-weight: bold; background-color: gray;">Escalation Matrix </th>
																			</tr>
																			<tr>
																				<tr>
																					<th>Level </th>
																					<th>Name </th>
																					<th>Contact No </th>
																					<th>Email </th>
																				</tr>
																				<tr>
																					<td style="text-align: center;">1</td>
																					<td style="text-align: center;">MLIT Service desk</td>
																					<td style="text-align: center;">1000 /918061751003</td>
																					<td style="text-align: center;">MLITServicedesk@microland.com</td>
																				</tr>
																				<tr>
																					<td style="text-align: center;">2</td>
																					<td style="text-align: center;">Manjunath Kuntumala</td>
																					<td style="text-align: center;">919108799997</td>
																					<td style="text-align: center;">ManjunathK@microland.com</td>
																				</tr>
																				<tr>
																					<td style="text-align: center;">3</td>
																					<td style="text-align: center;">Srinivasulu Reddy E</td>
																					<td style="text-align: center;">5610/919945335479</td>
																					<td style="text-align: center;">SrinivasuluRE@microland.com</td>
																				</tr>
																			</table>
																			<br />
																		</tr>
																	</tr>
																	<tr>
																		<td />
																	</tr>
																	<tr>
																		<td style="font-family: Segoe UI; padding-left: 3px;">
																			<br />
																			<p style="color: #000; font-size: 13px; width: 130%;"> Note: This is an automated notification, please do not reply to this mail and any response / additional information should be                                                                          
																				
																				
																				
																				<br /> sent to email ids mentioned in the signature of this email. 
																			
																			
																			
																			</p>
																		</td>
																	</tr>
																	<tr>
																		<td style="padding-top: 17px;">
																			<td />
																		</tr>
																	</table>
																</td>
															</tr>
															<tr>
																<td align="left" valign="top" style="font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #F0F0F0;" />
															</tr>
														</table>
													</td>
													<td width="35" align="left" valign="top" />
												</tr>
											</table>
										</td>
									</tr>
									<tr>
										<td bgcolor="#3C3C3A" style="background-color: #3C3C3A; height: 100px;">
											<table width="92%" border="0" align="center" cellspacing="0" cellpadding="0">
												<tr>
													<td style="width: 800px; font-family: Segoe UI; font-size: 14px; color: #f0f0f0">
														<p> SmartCenter Support Helpdesk                                                      
															
															
															
															<br /> Email - smartcentersupport@microland.com                                                      
															
															
															
															<br /> Support Number - 08039180715                                                      
															
															
															
															<br /> Support Hours - 8AM to 8PM Mon - Fri / P1 - 24 x 7 
														
														
														
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br />
							</td>
						</tr>
					</table>
				</body>
			</html>' WHERE ID IN (4105
,4107
,4109
,4111
,4113
,4115
,4117
,4119
,4121
)
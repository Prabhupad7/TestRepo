

 select * from Customer  where customername like 'HMCL' --->  68	Hero MotoCorp Ltd

 select * from Service where serviceName like '%End User Support%'   --->  52, 51

   select * from ServiceCustomerMapping where serviceid = 51 and customerid = 68

     Select * from ServiceCategorymapping where serviceid = 52
	 and deleted = 0 and categoryid in(1513)

   Select * from ServiceCategorymapping where categoryid in  (363,420,454)

   select * from Category where serviceid = 52

     -- Insert into Category(category,deleted,ticketTypeId,serviceId,Isdefaultcategory,isEUPVisible,icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)

	        values('Messaging', 0,1,51,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
			      ('Messaging', 0,1,52,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())
			      
    select * from Category where category like '%Messaging%'

--5742	Messaging	0	1	51
--5743	Messaging	0	1	52

   
   --   Insert into ServiceCategorymapping (serviceId, categoryId, deleted, ticketTypeId) 
	  --values 
	  --(52, 5743, 0, 1),
	  --(52, 5743, 0, 2),
	  --(52, 5743, 0, 3),
	  --(52, 5743, 0, 4)

	   -- Insert into SubCategory (subCategory,categoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)

	    select 'MDM', 5743, deleted, 0, 0, Icon, Icon_Color, Icon_BgColor, CreatedBy, 
			 GETDATE(), UpdatedBy, GETDATE() from SubCategory where subCategoryId = 1930




		 select * from SubCategory where categoryId = 5743  ---> 21942

--21943	Google Apps	5743
--21944	gControl	5743
--21945	MDM	        5743
 
		    -- Insert into Classification (classification,subCategoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)

			 --select 'Reset Password', 21942, 0, Isdefaultcategory, 0, Icon, Icon_Color, Icon_BgColor, CreatedBy, 
			 --GETDATE(), UpdatedBy, GETDATE() from Classification where classificationId = 8453
			 values 
			 ('Mobile Device Approval', 21945, 0, 0, 0, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
			 ('Mobile Device Configuration', 21943, 0, 0, 0, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),

			 select * from Classification where subcategoryid = 21943 -->  89322




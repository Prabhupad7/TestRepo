

  select * from Customer where customerName like '%jub%' -- 194

    select * from FeedbackConfig where CustId = 194 
	-- CCADDR--ShujahullaS@microland.com;FaizalM@microland.com;AbhishekSH@microland.com

--	update FeedbackConfig set CcAddr = 'ShujahullaS@microland.com'
--	where id in (318
--,316
--,319
--,320
--,321
--,322
--,317
--,323
--,324
--,325)


--update FeedbackConfig set ToAddr = 'MayaMJ@microland.com;KarthikS@microland.com;LikhithoshSK@microland.com;AjayA@microland.com'
--		where id in (318
--,316
--,319
--,320
--,321
--,322
--,317
--,323
--,324
--,325)
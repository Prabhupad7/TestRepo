

select * from notificationrules where customerid=207 and deleted=0 and ruleName like '%sla%' order by ruleName

select * from NotificationEmailTemplate where customerid=207 and templateName like '%sla%'

select * from Customer c where c.customerName like '%bio%'  --161,196




insert into NotificationEmailTemplate(templateName,template,templateSubject, customerId, isOutageNotificationTemplate, isOutageSMSNotification) 
values('Response SLA 40','<html style="background-color: #F0F0F0;">  <head>   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
<title>Untitled Document</title>  </head>  <body style="background-color: #F0F0F0;">   <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
<tr>     <td align="center" valign="top" style="background-color: #F0F0F0;">      <table width="900" border="0" cellspacing="0" cellpadding="0" style="border: 1px solid #656161;">
<tr>        <td align="left" valign="top" bgcolor="#FFFFFF" style="background-color: #FFFFFF;">         <img src="cid:HeaderImage" width="900" height="118" /> 
</td>       </tr>       <tr>        <td align="left" valign="top" bgcolor="#FFFFFF" style="background-color: #FFFFFF;">    
<table width="100%" border="0" cellspacing="0" cellpadding="0">          <tr>           <td width="35" align="left" valign="top" />   
<td align="left" valign="top">            <table width="100%" border="0" cellspacing="0" cellpadding="0">     
<tr>              <td valign="top" style="font-family: Segoe UI; font-size: 20px; padding-left: 3px; font-weight: bold;">RESPONSE SLA Notification - 40%  
</td>             </tr>             <tr>              <td align="left" valign="top">         
<table style="width: 100%;">                <tr>                 <td />                </tr>      
<tr>                 <td style="font-family: Segoe UI; padding-left: 3px;">Dear @Model.ASSIGNEDTO  </td>    
</tr>                <tr>                 <td />                </tr>                <tr>                 
<td style="font-family: Segoe UI; padding-left: 3px;">This is with reference to the Ticket @Model.TICKETNOTODISPLAY This is to inform you that the ticket has elapsed    
<b style="color:red">40%</b> of RESPONSE SLA. Please take necessary actions to resolve the ticket within target time.   The brief details of the ticket are as follows: 
</td>                </tr>                <tr>                 <td />                </tr>        
<tr>                 <td>                  <table style="width: 100%; font-size: 14px;">                   
<tr>                    <td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Service Name</td>   
<td>:</td>                    <td style="font-family: Segoe UI; ">@Model.SERVICENAME</td>                   </tr>   
<tr>                    <td style="font-family: Segoe UI; font-weight: bold; bold; width: 225px;">Ticket Number</td>   
<td>:</td>                    <td style="font-family: Segoe UI;">@Model.TICKETNOTODISPLAY </td>                   </tr>     
<tr style="border: 1px solid black">                    <td style="font-family: Segoe UI; font-weight: bold; bold; width: 225px;">Requestor Name</td>     
<td>:</td>                    <td style="font-family: Segoe UI;">@Model.REQUESTORNAME</td>                   </tr>               
<tr style="border: 1px solid black">                    <td style="font-family: Segoe UI; font-weight: bold; bold; width: 225px;">Priority:</td>                    <td>:</td>   
<td style="font-family: Segoe UI;">@Model.PRIORITYNAME</td>                   </tr>                   <tr style="border: 1px solid black">          
<td style="font-family: Segoe UI; font-weight: bold; bold; width: 225px;">Workgroup:</td>                    <td>:</td>                    
<td style="font-family: Segoe UI;">@Model.WORKGROUP</td>                   </tr>                   <tr>                  
<td style="font-family: Segoe UI; font-weight: bold; bold; width: 225px;">Ticket Title</td>                    <td>:</td>   
<td style="font-family: Segoe UI;">@Model.INFORMATION</td>                   </tr>                   <tr>                  
<td style="font-family: Segoe UI; font-weight: bold; bold; width: 225px;">Ticket Status</td>                    <td>:</td> 
<td style="font-family: Segoe UI;">@Model.STATUSNAME</td>                   </tr>                   <tr style="border: 1px solid black">  
<td style="font-family: Segoe UI; font-weight: bold; bold; width: 225px;">Logged Date and Time</td>                    <td>:</td>          
<td style="font-family: Segoe UI;">@Model.CREATEDON</td>                   </tr>                   <tr style="border: 1px solid black">       
<td style="font-family: Segoe UI; font-weight: bold; bold; width: 225px;">Due Date and Time</td>                    <td>:</td>            
<td style="font-family: Segoe UI;">@Model.DEADLINETIME</td>                   </tr>                   <tr style="border: 1px solid black">  
<td style="font-family: Segoe UI; font-weight: bold; bold; width: 225px;">Issue Description</td>                    <td>:</td>                
<td style="font-family: Segoe UI;">@Raw(Model.DESCRIPTION)</td>                   </tr>                  </table>                 </td>      
</tr>                <tr>                 <td />                </tr>                <tr>              
<td style="font-family: Segoe UI; padding-left: 3px;">                  <br />                  <p style="color: #000; font-size: 13px; width: 130%;">    
Note: This is an automated notification, please do not reply to this mail and any response / additional information should be                                                             
<br />                                                                      sent to email ids mentioned in the signature of this email.      
</p>                 </td>                </tr>                <tr>                 <td />                </tr>               </table>         
</td>             </tr>             <tr>              <td align="left" valign="top" style="font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #F0F0F0;" />             </tr>            </table>           </td>       
<td width="35" align="left" valign="top" />          </tr>         </table>        </td>       </tr>       <tr>    
<td bgcolor="#ffffff" style="background-color: #ffffff; font-family: Segoe UI; padding-bottom: 20px;">       
<table width="92%" border="1" align="center" cellspacing="0" cellpadding="0" style="font-size: 14px; font-family: Segoe UI;"> 
<tr>             <td style="width: 800px; font-family: Segoe UI; font-size: 14px; color: #f0f0f0">           
<p>Thanks and Regards               <br />UNITY BIOTECHNOLOGY               <br />Email - helpdesk@unitybiotechnology.com               <br />Support Number - 16503406737               <br />Support Hours - 8AM to 5PM Mon - Fri</p>             </td>      
</tr>         </table>       <br />      </td>     </tr>    </table>   </body>  </html>', ' $PRIORITYNAME Notification - Ticket Number: [ $TICKETNOTODISPLAY ]  has Elapsed 40% RESPONSE SLA', 207, 0,0)



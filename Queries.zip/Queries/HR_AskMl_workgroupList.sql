

select * from Workgroup where workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629,630,631,632,687,744,241,249, 238 , 207 , 772, 189,207,224,225,227,229,232,233,235,238,241,249,513,630,631,632,680,744,765,772)


select * from Service where serviceName like '%HR%' ---> 84	HR

select * from Service where serviceId = 68

    --exec deletetickets @ticketNo = '3045258'


	select * from workGroupEscalationMatrix_AskML
	where  CustomerId = 147 and Level2Email ='ManjunathK@microland.com'

	---> SR3046172

	select * from Feedback where TicketNo = 3046172 

	select * from NotificationRegistry where sourceId = 3046172 ---> 418, 583

	select * from NotificationEmailTemplate where templateId in (418, 583)

	select * from NotificationHistory where TicketNo = 3046172

	select serviceId, workgroupId,* from ticket where ticketNo = 3046172

	select * from FeedbackConfig 
	where ServiceId = 51 and workgroupId = 80 and TicketTypeId = 2 ----> 434  4


	select roleId,* from Users where firstName like '%Mahavir%'  ---> Mahavir Negi (Gurgaon Plant)94  94	753

	select * from Users where userId = 26676  ----> 

	--insert into UserCustomerAssignGroupMapping

	--select 26676, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup
	--from UserCustomerAssignGroupMapping where deleted =0  and userId = 753 and custAssignmentGroupId not in (0)

	select top 100 * from Hero_Users where emailAddress like '%priyanka.kaushal@heromotocorp.com%'

	--insert into Hero_Users

	--select 'Priyanka', 'Kaushal', 'priyanka.kaushal@heromotocorp.com','','919599488856', 'HCHO3- Horizon Office', '14053', 'Senior Manager', '', 'Sales and Marketing',
	--'', NULL, NULL,NULL,NULL, NULL

	-------------->

	select * from Service where serviceId = 84 

	select * from WorkHours where workHourId = 126

 select * from ServiceLevelobjective where serviceid = 84 and 	workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629,630,631,632,687,744,241,249, 238 , 207 , 772, 189,207,224,225,227,229,232,233,235,238,241,249,513,630,631,632,680,744,765,772)
and serviceLevelObjectiveTypeId =1


--Update ServiceLevelobjective set workHourId = 126  where serviceid = 84 and 	workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
--,629,630,631,632,687,744,241,249, 238 , 207 , 772, 189,207,224,225,227,229,232,233,235,238,241,249,513,630,631,632,680,744,765,772)
--and serviceLevelObjectiveTypeId =1

select * from Workgroup where workgroup like '%MicroVax%' ---> 238 , 207 , 772

Income tax and payroll vendor
HR compensation and benefits
MicroVax


select top 100 * from RulesForAutomationRemedial 
where CustomerId = 194 and AssignmentRule like '%deviceId=40127;%'

-----> customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39591;

--Insert into RulesForAutomationRemedial 
--values 
--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=40127;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=40127;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=40127;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=40127;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39611;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39611;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39611;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39611;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39599;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39599;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39599;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39599;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39598;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39598;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39598;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39598;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39596;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39596;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39596;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39596;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39596;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39596;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39596;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39596;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39595;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39595;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39595;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39595;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39592;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39592;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39592;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39592;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39590;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39589;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39589;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39589;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39589;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39587;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39587;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39587;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39587;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39586;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39586;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39586;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39586;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39584;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39584;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39584;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39584;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39583;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39583;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39583;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39583;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39582;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39582;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39582;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39582;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39580;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39580;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39580;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39580;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39579;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39579;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39579;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39579;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39577;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39577;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39577;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39577;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),

--('Remedial', 194, 'customerid=194;information like CPU alarm;ticketTypeId=1;deviceId=39576;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like CPU_Utilization;ticketTypeId=1;deviceId=39576;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like memory threshold alarm;ticketTypeId=1;deviceId=39576;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 194, 'customerid=194;information like disk alarm for disk;ticketTypeId=1;deviceId=39576;', 'contains', '771', 1, 26027, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL)

---> 

select Top 84 * from RulesForAutomationRemedial order by 1 desc

--Update RulesForAutomationRemedial set ApiJson = (select ApiJson from RulesForAutomationRemedial where RuleId = 4635)
--where RuleId in ()

--Update RulesForAutomationRemedial set IsDeleted = 1
--where RuleId in (
--4788,
--4787,
--4786,
--4785,
--4784,
--4783,
--4782,
--4781,
--4780,
--4779,
--4778,
--4777,
--4776,
--4775,
--4774,
--4773,
--4772,
--4771,
--4770,
--4769,
--4768,
--4767,
--4766,
--4765,
--4764,
--4763,
--4762,
--4761,
--4760,
--4759,
--4758,
--4757,
--4756,
--4755,
--4754,
--4753,
--4752,
--4751,
--4750,
--4749,
--4748,
--4747,
--4746,
--4745,
--4744,
--4743,
--4742,
--4741,
--4740,
--4739,
--4738,
--4737,
--4736,
--4735,
--4734,
--4733,
--4732,
--4731,
--4730,
--4729,
--4728,
--4727,
--4726,
--4725,
--4724,
--4723,
--4722,
--4721,
--4720,
--4719,
--4718,
--4717,
--4716,
--4715,
--4714,
--4713,
--4712,
--4711,
--4710,
--4709,
--4708,
--4707,
--4706,
--4705)
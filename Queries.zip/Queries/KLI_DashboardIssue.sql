

		 select * from Users where loginName like '%LO5145%' ---->   1142  46  1 Reference user id

		 select * from Users where email like '%kli.alan-lusbo@kotak.com%' ----->  1281

		 select * from Users where userId in (1142, 1281) ---->  
 
		 select * from UserInstanceMapping where userId in (1142, 1281)

		 select top 10 * from Admin_UserCustomerAdminMapping where userId in (1142, 1281)

		 select * from Workgroup where workgroup like '%SCOM%' --->  140  4

		 select * from CustomerAssignmentGroupMapping CM 
		 where custAssignmentGroupName like '%SCOM%'   ----> 225 205

		 select * from UserCustomerAssignGroupMapping
		 where custAssignmentGroupId =225 and userId in (1142, 1281)


		 --update Users set LevelId =1 where userId = 1281

		 select * from UserTypes

		 select * from Admin_ServiceProvider where ServiceProviderId = 4

		 select * from Admin_LevelMaster  

		  select * from Admin_CustomerServiceProviderMapping


         select * from  [dbo].[Admin_RoleServiceProviderMapping]


		 select * from MenuMaster where MenuId in 
		 (select MenuId from MenuRoleMapping where roleID = 46)


		 --update UserCustomerAssignGroupMapping set AssignToWorkgroup 


		   select * from Admin_LevelMaster

		  select * from Admin_ModuleLevelMapping

		  select * from Admin_ModuleMaster


		 ----->   priya.anjali@icicibank.com

		 ----->   Rajan 9002357777 ----> Banglore Bommanahalli.

		 ----->   



		 select deleted, * from users 
		 where email like '%Preet%'  ---->  Preetnh@microland.com


		 select deleted, * from NotificationRules 
		 where notificationCC like '%Preetnh@microland.com%'

		 select * from NotificationRules 
		 where notificationTo like '%Preetnh@microland.com%'



		select * from Requestor 
		where requestorEmail like  '%ShubhaB@microland.com%' 

		----->  9916055250
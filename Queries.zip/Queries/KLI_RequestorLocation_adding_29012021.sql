

select top 100 * from RequestorLocation where customerID =50  order by 1 desc

---->  Trichy-1- Cantonment branch option is visible and Trichy-2- GVR complex branch is not available.

select top 10 * from RequestorLocation where location like '%Trichy%'

--update RequestorLocation set location_Name ='Trichy - 2 - GVR complex' where locationID =4202

---->>  200	KLI - Trichy 1 - Cantonment

--Insert into RequestorLocation (location, Location_Name,customerID, deleted, CountryCodeId, Isdefaultlocation)
--values ('Trichy - 2 - GVR complex','Trichy - 2 - GVR complex' , 50, 0, 103, 0)

select * from Customer where customerName like '%Admin%' --->  50
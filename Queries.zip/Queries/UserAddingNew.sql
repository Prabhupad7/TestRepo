

    select roleid, * from Users where loginName like '%Nagesh%' -->  26529

    select * from Users where UserId in ( 26529, 26569)

  --	Update users set password ='SUv/GzSv2NSYGeW1YMGviQ==', SaltValue =null where userid = 26569


    select * from UserInstanceMapping where UserId in ( 26529, 26569)

  select roleid, * from Users where email like '%JosephJ@microland.com%' -->  26525

 select * from Users where email like '%BalachandranB@microland.com%'  ----> 26768

 --------> SatyajeetS


 --Insert into Users (firstName, lastName, userName, displayName,mobileNo, email, loginName, password, deleted, IsWorkgroup, isPasswordPolicyApplicable, 
 --lastUpdatedOn, isAutoAssignmentEnable, roleId, createdById, createdOn, IsEnabled, timezoneinfoId, instanceId, levelid, UserTypeId)


 --select 'Aishwarya', 'P', 'Aishwarya P', 'Aishwarya P', '123', 'AishwaryaP@microland.com', 'AishwaryaP',null, 0,0,0,
 --getdate(), 0, roleId, 6, getdate(), 1, 24, instanceId,levelid, UserTypeId from Users where userId = 26384



   select * from Users where email like '%AishwaryaP@microland.com%' ---> 26456

   select * from UserInstanceMapping where UserId = 26768

  --- insert into UserInstanceMapping (UserId, InstanceId)
   Values (26768, 1)


   ---->  26525

    select * from UserInstanceMapping where UserId = 26569

	Select * from UserCustomerAssignGroupMapping where userid = 26525

	Select * from UserCustomerAssignGroupMapping where userid = 26456

 --   Insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
	
	--select 26768, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup 
	--from UserCustomerAssignGroupMapping where userid = 26525


	--->  Asset_ProvideAssPermission 

	--->   RE: IM2761859 IM2761858 - not able to resolve


	--exec deletetickets @ticketNo = '2761859';
    --exec deletetickets @ticketNo = '2761858';

	--- 9412492888


	------>  SR2897761

	select * from ServiceLevelTracking 
	where sourceId = 2897761

	--update ServiceLevelTracking set statusId = 3 where sourceId = 2897761


	select * from Requestor where alias like '%SagarMI%'  ---> 59308	Sagar Mishra

	select * from CustomerRequestorMapping  where requestorId = 59308

	

	select * from Customer where customerName like '%Khaitan%'  ---->  199	Khaitan And Co	Khaitan And Co

	select * from Users where email like '%PremR@microland.com%'   ----->  26755	Sagar	Mishra

	select * from Users where email like '%v-Jitendra%'   -----> 25860  Itsupport1@khaitanco.com 

	select * from Requestor where requestorEmail like '%Cecil%'

	select deleted,* from Requestor where requestorEmail like '%PremR%'  ----> 14301

	select deleted,* from Requestor where requestorEmail like '%v-Jitendra%'  ----> 14301

    select * from users where userId in (26755, 25860)

	--Update Users set email ='SagarMI@khaitanco.com' where userId in (26755) 

	--Update Users set levelid =1 where userId in (26755) 


	select * from UserInstanceMapping where userId in (26755, 25860)

	select * from UserCustomerAssignGroupMapping where userId = 25860

	select * from UserCustomerAssignGroupMapping where userId = 26755

	select * from Instance ---->  15	Khaitan	Khaitan And Co	1   https://itadmin.khaitanco.com

	select * from AuthenticationType

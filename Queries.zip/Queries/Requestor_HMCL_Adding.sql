

    select * from Customer where customerName like '%mlcis%' --> 3

	select * from Customer where customerId = 147
    select * from ApiKey where customerId = 3


      select * from autoticketserviceemailconfig where apikey in (
	   select keyname from ApiKey where customerId = 147
	  )


	  select GETDATE ()
	  select top 100 createdOn , * from AutoTicketEventLog order by 1 desc

	  ---> 9978907174

	  select * from Requestor where requestorEmail like '%ashish.upadhyay@heromotocorp.com%'  ----> 

	  	--Insert into Requestor (requestorName, requestorEmail, isCriticalUser,employeeId, firstname, lastname,  alias, department, location, mobileno, 
	--createdOn, UpdatedOn, createdby, updatedby, deleted, LastLoginTime, CountryCode, failedLoginAttemptCount, isAccountLocked)

	--values ('VAAudit Scan_Corp', 'VAAuditScan_Corp@example.com', 0, '1231', 'VAAudit', 'Scan_Corp', 'VAAuditScan_Corp', 'Devops', 'Banglore' ,'121',
	--GETDATE(), GETDATE(), 6, 6, 0, GETDATE(), 61, 0, 0),


	  -->  2735487  The email was sent to rmcmicrolandgeneric@microlandsmartcenter.com  Hi Team,  Test ticket by SMC.    Thanks & Regards,  Venkat.  

	  --->  2735495   The email was sent to microlanderautoticket@microlandsmartcenter.com  Hi Team,  Test ticket by SMC, Please ignore    Thanks & Regards,  Venkat.
	  

	  select * from CustomerRequestorMapping where requestorId = 28673	--- 28694


	 select * from Requestor where requestorEmail like '%akansha.saxena@heromotocorp.com%'  -->  57636

	 --update Requestor set location='HR1 KUKAS, JAIPUR CIT' where requestorId = 57636


	 select top 1  * from hmcl_Users  order by 1 desc  

	 select top 500 * from Hero_Users where emailAddress like '%roo%'

	 select * from Hero_Users where emailAddress like '%ashish.upadhyay@heromotocorp.com%'

	 --Insert into Hero_Users (firstName, lastName, emailAddress,mobilePhone1,workAddress1,employeeId,employeeTitle,manager,department)

	 --values ('akansha', 'saxena', 'akansha.saxena@heromotocorp.com','9828775280', 'HM6C', '90121973', 'Project Support', '', 'MLH')

	 -----> Not in 

	 --Insert into hmcl_Users (ID, Users, Email, Active, Dashboard, Worklist, Reporting, changeManager, roleid)
	 --select 313,'akansha saxena', 'akansha.saxena@heromotocorp.com', Active, Dashboard, Worklist, Reporting, changeManager, roleid from hmcl_Users where id = 265

	 --delete from Hero_Users where id = 4968


----------->  Need to add Resolution Code from front End in Admin Module ---> Drop Down Values:

    select * from KLI_10022021  

	select distinct EntityType from KLI_10022021  

    select * from Asset_Status where AssetTypeId = 31
   
    select distinct EntityType from temp_KLI_10112020

    select * from KLI_12012021 where EntityType ='UPS - Standalone'    and Status = 'Spare'

	----->  

select * from customer where customerName like '%Branch%' ---->  92

select * from ResolutionCode order by 9 desc

select * from ResolutionCode  where  customerId In ( 1 ) and ticketTypeId = 2

select * from ResolutionCode  where resolutionCode = 'False Alert' and customerId In ( 1 )

--delete from ResolutionCode where resolutionCodeId = 4869

select * from ResolutionCode  where resolutionCode = 'False Alert' and customerId = 92

--Insert into ResolutionCode (resolutionCode,	ticketTypeId,	deleted,	CreatedBy,	CreatedDateTime,	UpdatedBy,	UpdatedDateTime,
--customerId)
--values ('False Alert', 2, 0, 6, GETDATE(), 6, GETDATE(), 1)

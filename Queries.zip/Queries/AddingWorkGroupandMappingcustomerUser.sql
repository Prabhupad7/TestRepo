
    
	
	
	select * from Customer where customerName like '%Channel%'

	select * from Service where serviceName like '%Channel%'

	----- 87	Channel Support

	select * from ServiceCustomerMapping where serviceId = 87 and customerId = 1

	select  * from ServiceCustomerMapping where customerId=1

	--Insert into ServiceCustomerMapping (serviceId, customerId, deleted, ticketTypeId)

	--values (87, 1, 0, 1),  (87, 1, 0, 2), (87, 1, 0, 3),(87, 1, 0, 4)

	select * from Customer

	---- 213	Nokia

 select top 1 * from Workgroup order by 1 desc

				select workgroup, workgroupEmail from Workgroup where workgroupId    in (select workgroupId from AssignmentGroup where assignmentgroupId in (

					select assignmentgroupId from customerAssignmentGroupMapping   where customerid = 213 and deleted = 0  ))




              select * from customer where customerId = 1

			        select * from customer where customerName like '%Oreta%'

					select * from customer where customerName like '%Eureka%' -- 167

					select * from customer where customerName like '%HDU%' -- 167

					 select top 1 * from Workgroup where workgroup like '%Webs%'  -- 138

		         	--	196	Oreta-MMSG VOIP	Oreta-MMSG VOIP

					--  203	Bosch � Scottsdale	Bosch � Scottsdale

					--  207	Unity Bio	Unity Bio	0
					SR2635162

 			  select * from Workgroup W where W.workgroup like '%RMC cloud%'   --- 625

			  select * from Workgroup W where W.workgroup like '%HDU%' 


			 -- Name: Amodini Singh
				--Emp ID: 21153
				--Team: RMC Collaboration team
				--Email ID: amodinisi@microland.com

					select * from customer where customerName like '%Eureka%' -- 168

					select * from customer where customerName like '%Enzen%' -- 158

			    	select * from Workgroup where workgroup like '%RMC Collaboration%'  -- 7

				    SELECT * FROM AssignmentGroup where workgroupId = 7   --- 203

				  --7
      --            634
      --            774

	    select * from CustomerAssignmentGroupMapping where customerId in ( 68)   and deleted = 0 

		and assignmentgroupId in (7, 774)  -- custAssignmentGroupId   1936

		 select * from AssignmentGroup where assignmentgroupId in ( 233 ,234)

       -- custAssignmentGroupId	custAssignmentGroupName	customerId	customerName	assignmentgroupId	deleted	UpdatedBy	UpdatedDateTime	CreatedBy	CreatedDateTime
       -- 2086	Eureka Forbes Limited - RMC Collaboration	167	Eureka Forbes Limited	7	0	6	2018-02-08 05:05:03.770	6	2018-02-08 05:05:03.770

           select * from UserCustomerAssignGroupMapping where   userid =26395 and deleted = 0 and custAssignmentGroupId = 2637



		   select * from customerAssignmentGroupMapping   where customerid in (186, 201) and deleted = 0

		 --     INSERT INTO UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
			-- VALUES 
			--(26395,2637,0,1,0)

		   --  update UserCustomerAssignGroupMapping set deleted = 1 where userCustomerAssignGroupId in (

		     select userCustomerAssignGroupId from UserCustomerAssignGroupMapping where   userid =26395 and custAssignmentGroupId not in (

			  select custAssignmentGroupId from customerAssignmentGroupMapping   where customerid in (186, 201) and deleted = 0 ))




		--   update UserCustomerAssignGroupMapping set isAssignEnabled = 1 where userCustomerAssignGroupId= 165312




			    select * from Users where email like '%Niharikad%'   --- 26222  ---42

				select * from Users where email like '%INT_MonicaS%'   --- 26384

				select * from Requestor
				--update users set RoleId = 42 where UserId =26384

				select * from Requestor where requestorEmail like '%Niharikad%'   ---- 55781	Niharika Das

				select * from Requestor where requestorEmail like '%INT_MonicaS%'   ---- 55622	Niharika Das

				select * from CustomerRequestorMapping where customerid = 147 and requestorid =55781

						select * from CustomerRequestorMapping where customerid = 147 and requestorid =55622

			  select  * from Users where lastName like '%Retheeh%'  --- 1090

			  select * from Users where loginName like '%Lo5459%'   -- 6  6	Vishal	S	VishalS	smcadmin

			  select * from users where email like '%amodinisi@microland.com%'  --- 25699

			  select * from users where email like '%GyanaranjanS@microland.com%'  --- 25409

			   select * from Workgroup W where W.displayName like '%websen%'

			    SELECT * FROM AssignmentGroup where workgroupId = 7   --- 203

			  select * from CustomerAssignmentGroupMapping where customerId in (168 )   and deleted = 0 -- custAssignmentGroupId   222



			  select distinct custAssignmentGroupId from CustomerAssignmentGroupMapping where customerId in ( 1 )   and deleted = 0 

			  select * from UserCustomerAssignGroupMapping where userId in (26222 ) 

			  select * from UserCustomerAssignGroupMapping where userId in (26384 )   

			  0
              1250
              2930


              select * from Customer where customerId = 168


             select * from customer where customername like '%ownership%'  --161

			 ---- For KLI

			 select * from customerAssignmentGroupMapping   where customerid = 213 and deleted = 0 

   -- INSERT INTO UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
			 VALUES 
			(26384,1170,0,1,1),
(26384,1188,0,1,1),
(26384,1207,0,1,1),
(26384,1208,0,1,1),







1170
1188
1207
1208
1211
1214
1218
1221
1223
1226
1231
1241
1242
1244
1246
1249
1250
1252
1255
1258
1271
1290
1994
2222
2428
2429
2477
2505
2508
2569
2583
2634
2640
2641
2701
2702
2703
2704
2705
2930










    select * from UserCustomerAssignGroupMapping where userId = 419 and custAssignmentGroupId in (
	2931
,2932
,2933
,2934
,2935
,2938)

--	update UserCustomerAssignGroupMapping set deleted = 0 where userCustomerAssignGroupId in (
--	174279
--,174280
--,174281
--,174282
--,174283
--,174284
--	)

			 --  [5:25 PM] Aravindsagar Venkatesh
    priority ID, Name, status ID, etc 



--			 UPDATE UserCustomerAssignGroupMapping SET isAssignEnabled =1 , AssignToWorkgroup = 1 WHERE userCustomerAssignGroupId IN (
--			84284
--,84280
--,84281
--,84283
--,84289
--,84282
--,84285
--,84287
--,84286
--,84288
--,84290
--)

			  --INSERT INTO UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
			  --values
			
			  --(1090, 222, 0, 1, 1)


			  --select top 3 * from UserCustomerAssignGroupMapping order by 1 desc
 
              --  update UserCustomerAssignGroupMapping set deleted = 1 where userCustomerAssignGroupId = 14053 



			  select * from Role where name like '%%'

			    select * from Role where roleid = 86

		--		update role set name = 'EFL_SPIT_Engineer' , 
				description ='EFL_SPIT_Engineer' , roleDisplayName ='EFL_SPIT_Engineer' where roleid = 86



				select  feedbackTemplate, * from FeedbackConfig where custId = 147 and serviceid =84

				--update FeedbackConfig set feedbackTemplate = '' 
				--where id in (71, 72)

				
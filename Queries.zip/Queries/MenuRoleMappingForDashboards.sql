


   select  * from MenuMaster where menuName like  '%Quarterly Enzen%'   --- 274

   -- Need not to give access for some menus 
    280  Weekly Enzen
	285  Monthly Enzen
	292  Quarterly Enzen



	   select roleId,  * from Users where email like '%NaveenCMC@microland.com%'


   select * from Users where userid = 6 ---> userId: 419, RoleId: 75

   select * from MenuMaster where menuID in (  
   274,
   275,
   276,
   277,
   278,
   279,
   280,281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293
   )

   Select * from MenuRoleMapping where roleID = 75 and menuID in (  
   274,
   275,
   276,
   277,
   278,
   279,
   280,281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293

   )

      Select * from MenuRoleMapping where roleID = 39 and menuID in (  
   274,
   275,
   276,
   277,
   278,
   279,
   280,281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293

   )
    
	select * from MenuRoleMapping where roleID in (
	58, 39
	)

	and menuID in (  
   274,
   275,
   276,
   277,
   278,
   279,
   280,281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293

   )



   				   select distinct roleid from Users where roleId in (
 3
,4
,34
,38
,39
,58
,75
,100
)

   select * from MenuroleMapping where roleId in (
 3,4,34,38,58,100)   and menuID in (  274,   275,   276,   277,   278,   279,   280,281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293   )



   select * from MenuRoleMapping where roleID =38  and
   menuID in (  274,   275,   276,   277,   278,   279, 280,  281, 282, 283, 284,285,  286, 287, 288, 289, 290, 291,292,  293   )



   --Insert into MenuRoleMapping(roleID, menuID, isdeleted)

   --select 100, menuID, isdeleted from MenuRoleMapping where roleID = 75  and 
   --menuID in (  274,   275,   276,   277,   278,   279, 280,  281, 282, 283, 284,285,  286, 287, 288, 289, 290, 291,292,  293 )


    select roleId, * from Users where UserId in ( 25259, 26103) ---> 6	25259

    select roleId, * from Users where loginName like '%SaswatA%' ---->>  38	26103


     --Update users set roleid=38  where UserId = 25259  

     --Update users set  password ='SUv/GzSv2NSYGeW1YMGviQ==', SaltValue = null where UserId = 25259  

	 38	25259	Abhishek 	Kumar
     38	26103	Saswat	Anurag

	   select * from UserInstanceMapping where UserId in ( 25259, 26103)

	   select * from UserCustomerAssignGroupMapping where userId = 26103
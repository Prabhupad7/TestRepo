

select  * from Incidentticket where ticketNo='3049680'

---> IM3083155

select top 100 * from Approval

	 select * from Asset_users where emailid like '%Pravin.patil%' ---> 28112

	 select distinct A.approvalNo, a.sourceTypeName, a.sourceDescription, a.approvalCreatedOn,A.sourceCategoryName,
	 A.sourceSubCategoryName,
	 A.sourceClassificationName, A.sourcePriorityName, A.sourceImpactName, A.sourceWorkgroupName, A.sourceRequestorName, A.sourceServiceName, 
	 A.sourceCustomerName, A.sourceAssignmentGroupName
	  from Approval A 
	 inner join ApprovalEntityMapping E on A.approvalEntityMappingId = E.approvalEntityMappingId
	 inner join ApprovalMatrixLevel L on L.approvalMatrixId = E.approvalMatrixId
	 inner join ApprovalMatrixApprover M on M.levelId = l.levelId
	 where M.approverId = 28112 and e.deleted = 0 and m.deleted = 0 and l.deleted = 0 and A.ApprovalCompletedTime is null
	 and A.approvalNo in (3083287,3083279,3083187)
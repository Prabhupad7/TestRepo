

 ---  select * from HMCL_13012021

 select * from HMCL_16032021$

  select * from HMCL_29072021$ 
  where EmailAddress = 'vaibhav.kole.ext@heromotocorp.com'

  
  select * from HMCL_21092021$ 


  select r.requestorId, r.requestorName, r.requestorEmail,  H.EmailAddress, r.mobileno, H.MobilePhone from  
  Requestor R
  inner join HMCL_21092021$ H
  on R.requestorEmail = H.EmailAddress
  where R.deleted= 0 and H.EmailAddress = 'abhishek.gautam@heromotocorp.com'

  
  select r.failedLoginAttemptCount, r.isAccountLocked,* from  
  Requestor R
  inner join HMCL_26022021$ H
  on R.requestorEmail = H.EmailAddress
  where R.deleted=0


  select r.firstName, r.emailAddress,  H.EmailAddress from  
  Hero_Users R
  inner join HMCL_08032021$ H
  on R.emailAddress = H.EmailAddress
  where R.deleted=0



  ------------->  Need to update the Requestor Table:

  ---->  3256	Anupam Kumar Mittal	anupam.mittal@heromotocorp.com	anupam.mittal@heromotocorp.com

  select * from [dbo].[HMCL_08032021$]

			  select r.requestorId, r.firstname, r.lastname, r.requestorName, r.requestorEmail,  H.EmailAddress, r.mobileno, H.MobilePhone from  
			  Requestor R
			  inner join HMCL_16032021$ H
			  on R.requestorEmail = H.EmailAddress
			  where R.deleted= 0

			  select  r.firstname, r.lastname, r.emailAddress,  H.EmailAddress, r.mobilePhone1,
			  H.MobilePhone from  
			  Hero_Users R
			  inner join HMCL_16032021$ H
			  on R.emailAddress = H.EmailAddress
			 -- where R.deleted= 0


			  ----> 09032021:   select * from [dbo].[HMCL_08032021$]

		   --ALTER TABLE  HMCL_16032021$
     --      ADD RequestorId_2 int
		  
		 ---->  STEP 1:

		  --update H set h.RequestorId = r.requestorid from HMCL_21092021$ H
		  --inner join Requestor R 
		  --on H.EmailAddress = r.requestorEmail			
		  --where r.deleted = 0 --and r.requestorid=20390

		  ----------------
		  ----------------
		  ----> STEP 2:
		  ----------------->  Updating Requestor and Hero_Users: 

		    select * from HMCL_21092021$ 

		  --	 Update  R set   R.firstname =H.FirstName, R.lastname=isnull(H.LastName, ''), R.requestorName = H.firstname +' '+ ISNULL(H.lastname, ''),R.displayname = H.firstname +' '+ ISNULL(H.lastname, ''),
		  --R.mobileno = Convert( nvarchar(100),convert(bigint, H.MobilePhone)), R.employeeId =Convert( nvarchar(100),convert(bigint, H.EmployeeID)), R.designation=ISNULL( H.EmployeeTitle,''), R.department=ISNULL( H.Department, ''), R.UpdatedOn= GETDATE(), R.updatedby = 6
		  --from Requestor R 
		  --inner join HMCL_21092021$ H
		  --on R.requestorEmail = H.EmailAddress
		  --where R.deleted= 0  and R.requestorid= 38430


		  SELECT * from Requestor where requestorid= 38430

  		--  Update  R set   R.firstname =H.FirstName, R.lastname=ISNULL( H.LastName,''), R.mobilePhone1 = Convert( nvarchar(100),convert(bigint, H.MobilePhone)),
		  --R.employeeId =Convert( nvarchar(100),convert(bigint, H.EmployeeID)), R.EmployeeTitle=ISNULL( H.EmployeeTitle,''), r.manager =ISNULL(H.ManagerEmail, ''),
		  --R.department=ISNULL( H.Department, ''), R.costCenter= ISNULL(H.CostCenter, '')
		  --from Hero_Users R 
		  --inner join HMCL_12082021$ H
		  --on R.EmailAddress = H.EmailAddress 
		  where R.Id = 3262



	   ---->  4980	Sukhbir Singh Bijarnia	sukhbir.bijarnia@heromotocorp.com	sukhbir.bijarnia@heromotocorp.com

	   ---->  57834	Mohan Sivam	mohan.sivam@heromotocorp.com	mohan.sivam@heromotocorp.com	0	919488387561

	 --Update Requestor set firstname ='', lastname='', requestorName = firstname +' '+ ISNULL(lastname, ''), displayname = firstname +' '+ ISNULL(lastname, ''),
	 --mobileno='', employeeId ='', location='', designation='',department='', UpdatedOn=GETDATE(), updatedby=6

	   select * from HMCL_26022021$ where EmailAddress ='sasi.kumar@heromotocorp.com'

	   select * from Requestor where requestorEmail ='sasi.kumar@heromotocorp.com' ---->  4177

	   select * from CustomerRequestorMapping where requestorId = 58309

	   --update Requestor set requestorName ='Sasi Kumar', firstname='Sasi', lastname='Kumar'
	   
	   --,displayname='Sasi Kumar' where requestorId = 58309

	   select * from Hero_Users where emailAddress ='sasi.kumar@heromotocorp.com'

	   Insert into Hero_Users (firstName, lastName, emailAddress, mobilePhone1, )



	   --Update Requestor set fa where requestorid = 4177

	   --Update Requestor set failedLoginAttemptCount =0 where requestorId = 4177

	   select * from Requestor where requestorId = 3262





		  --Update  R set   R.firstname =H.FirstName, R.lastname=H.LastName, R.requestorName = H.firstname +' '+ ISNULL(H.lastname, ''), R.displayname = H.firstname +' '+ ISNULL(H.lastname, ''),
		  --R.mobileno =  H.MobilePhone, R.employeeId = H.EmployeeID,     R.designation=ISNULL( H.EmployeeTitle,''), R.department=ISNULL( H.Department, ''), R.UpdatedOn= GETDATE(), R.updatedby = 6
		  --from Requestor R 
		  --inner join HMCL_13012021 H
		  --on R.requestorEmail = H.EmailAddress
		  --where R.deleted=0 and R.requestorid= 57834

		   
		  select count(*) from Hero_Users     ----->  5469
		  select count(*) from HMCL_13012021  ----->  5038


			  select * from  
			  Hero_Users R
			  inner join HMCL_12082021$ H
			  on R.emailAddress = H.EmailAddress



			  select * from HMCL_26042021$  where EmailAddress not in (select emailAddress from Hero_Users)


			  ---> where R.deleted=0

		  select * from Hero_Users where id = 252
		  select * from HMCL_13012021 where emailAddress='ankur.vats@heromotocorp.com'



		  ---> where R.deleted=0 and R.requestorid= 3262

		  select * from Hero_Users where emailAddress='rachit.srivastava@heromotocorp.com'



		  select * from HMCL_12082021$ where emailaddress not in
		  (
		     select distinct requestorEmail from Requestor where requestorEmail like '%heromotocorp.com%' and deleted =0
		  )
      

	    select H.Emailaddress,r.requestorEmail  from HMCL_13012021 H
		inner join Requestor R
		on H.Emailaddress not in (r.requestorEmail)
		where r.requestorId in (
		
		 select distinct requestorId from Requestor where requestorEmail like '%rachit.srivastava@heromotocorp.com%' and deleted =0
		)


		 select * from HMCL_13012021 

		 Alter table HMCL_13012021 
		 add RequestorId int


		 	  --ALTER TABLE KLI_23112020 
   --   ADD AssignedEnd int
		  
		  ----> UPDATING TEMP TABLE FOR REQUESTOR TABLE:

		  --update H set h.Requestorid = r.requestorid from HMCL_29072021$ H
		  --inner join Requestor R 
		  --on H.EmailAddress = r.requestorEmail			
		  --where r.deleted = 0 


		  select * from HMCL_13012021 H
		  inner join Requestor R 
		  on H.EmailAddress = r.requestorEmail
		  where r.deleted = 0 ---and r.requestorid=20390


		  select * from HMCL_26022021$ where RequestorId is null

		  select * from Requestor where requestorEmail in (
		  select EmailAddress from HMCL_13012021 where RequestorId is null
		  )

		  --Update Requestor set deleted =1, requestorEmail='deleted_eshop.orderupdate@heromotocorp.com',
		  --alias='deleted_eshop.orderupdate@heromotocorp.com'  where requestorId = 58505



		  	  select * from Hero_Users where EmailAddress in (
		  select EmailAddress from HMCL_13012021 where RequestorId is null
		  )


		  --->  rajasekhar.vardineni@heromotocorp.com

		  

		   select EmailAddress from HMCL_26022021$ where RequestorId is null and EmailAddress in (	   
		   select EmailAddress from Hero_Users
		   )

		  Alter table HMCL_26022021$ 
		 add RequestorId int

		    select EmailAddress from HMCL_13012021 where RequestorId is null\



			-----> CHECKING FOR NEW REQUESTORS

			select * from HMCL_31032021$ where RequestorId is null


---------->  Addig missing user details: 


		   --ALTER TABLE  HMCL_08032021$
     --      ADD RequestorId int

	 ---> STEP 3:

 --  	Insert into Requestor (requestorName, requestorEmail, isCriticalUser,employeeId, firstname, lastname,  alias, department, location, mobileno, 
	--createdOn, UpdatedOn, createdby, updatedby, deleted, LastLoginTime,CountryCode, failedLoginAttemptCount, isAccountLocked)

	-- select firstname +' ' + isnull (lastname,''),  EmailAddress, 0, employeeId, firstname, isnull(lastname, ''), EmailAddress, Department,WorkAddress,
	-- MobilePhone, getdate(), getdate(), 6, 6, 0, getdate(), 91, 0, 0 
	-- from HMCL_21092021$ where RequestorId is null



--	  Insert into Hero_Users (firstName, lastName, emailAddress, mobilePhone1, workAddress1, employeeId, employeeTitle, 
--   department)

--   	 select firstname , isnull(lastname, ''),  EmailAddress, MobilePhone, WorkAddress, employeeId, EmployeeTitle,Department
--	 from HMCL_12082021$ where RequestorId not in (7499,
--28251,
--91323,
--92869,
--92877,
--92878,
--92280,
--92826)
--	 where EmailAddress in (
--'nilesh.rahinj.ext@heromotocorp.com'	 )


	------>  

	 select top 26 * from Requestor order by 1 desc

	 select top 26 * from Requestor where requestorEmail like '%jeetendra.verma@heromotocorp.com%'
	 
	 ---> 58925  55891 59249 59246  59262  26719

	 select * from Requestor where requestorId in (58925,  55891 ,59249 ,59246 , 59262 , 26719)

	 select * from Hero_Users where emailAddress like '%sushantp.mhatugade@heromotocorp.com%' ---->  vishal.jain@heromotocorp.com



	--    	Insert into Requestor (requestorName, requestorEmail, isCriticalUser,employeeId, firstname, lastname,  alias, department, location, mobileno, 
	--createdOn, UpdatedOn, createdby, updatedby, deleted, LastLoginTime,CountryCode, failedLoginAttemptCount, isAccountLocked)

	--values 
	--('Business Excellence HM5V', 'hm5v.be@heromotocorp.com', 0, '', 'Business Excellence', 'HM5V', 'hm5v.be@heromotocorp.com', 'Business Excellence', 'Vadodara Plant' ,'919463633815',
	--GETDATE(), GETDATE(), 6, 6, 0, GETDATE(), 91, 0, 0),
	--('Vishal Pandey', 'vishal.pandey@heromotocorp.com', 0, '90130142', 'Vishal', 'Pandey', 'vishal.pandey@heromotocorp.com', 'Extension (Domestic Business)', 'GPC-Neemranar' ,'919314455770',
	--GETDATE(), GETDATE(), 6, 6, 0, GETDATE(), 91, 0, 0),




 ----> 	STEP: 4
	
  --Insert into Hero_Users (firstName, lastName, emailAddress, mobilePhone1, workAddress1, employeeId, employeeTitle, 
  -- department)

  -- 	 select firstname , isnull(lastname, ''),  EmailAddress, MobilePhone, WorkAddress, employeeId, EmployeeTitle,Department
	 --from HMCL_21092021$ where RequestorId is null




	 select * from CustomerRequestorMapping 
	 where customerId = 68

--	 Insert into CustomerRequestorMapping ( requestorId,	customerId,	customerName,	isLoginAllowed)
--	 values 
--(59263,68,'Hero MotoCorp Ltd',0),


	 select mobileno,* from Requestor  where requestorId in (58925,  55891 ,59249 ,59246 , 59262 , 26719)

	--Update Requestor set mobileno='917737667716' where requestorId = 59262
	 
	 --update Requestor set isAccountLocked =0, failedLoginAttemptCount = 0 where requestorId in
	 --(58925,  55891 ,59249 ,59246 , 59262 , 26719)


      select * from HMCL_16032021$ where Requestorid is null



    select top 26 * from Requestor where requestorEmail like '%anil.rao@heromotocorp.com%'


	--Update Requestor set deleted =1 , deletedOn = GETDATE() where requestorId = 59418

	select top 100 * from CustomerRequestorMapping
	where customerId = 68 and requestorId = 59417

	----->  68	Hero MotoCorp Ltd	0

	--Insert into CustomerRequestorMapping (requestorId, customerId, customerName, isLoginAllowed)
	--values (59417,68, 'Hero MotoCorp Ltd' , 0)

	select * from Hero_Users
	where emailAddress like '%anil.rao@heromotocorp.com%'

	--delete from Hero_Users  where id = 5156

	--Update Hero_Users set lastName ='Hero Green Drive' where id =5993

	select * from Hero_Users
	where emailAddress like '%anjali.rao%'

	   select * from HMCL_16032021$ where Requestorid is null

	 --Insert into Hero_Users (firstName, lastName, emailAddress, mobilePhone1, workAddress1, employeeId, employeeTitle, 
  --   department)

  -- 	 select firstname , isnull(lastname, ''),  EmailAddress, MobilePhone, WorkAddress, employeeId, EmployeeTitle,Department
	 --from HMCL_16032021$ where RequestorId is null


	  -- Insert into Hero_Users (firstName, lastName, emailAddress, mobilePhone1, workAddress1, employeeId, employeeTitle, 
   --department)

   --	 select 'Simranjit'  , 'Singh',  'simranjit.singh@heromotocorp.com', '919990902283', 'Patna Area Office', '6142', 'Deputy Manager','Global Business'

	-- from HMCL_08032021$ where RequestorId is null

   
	 --Insert into Hero_Users (firstName, lastName, emailAddress, mobilePhone1, workAddress1, employeeId, employeeTitle, 
  --   department)

  -- values 
  -- ('amit','paliwal', 'amit.paliwal@heromotocorp.com', '917838215109', 'CIT Jaipur', '14052', 'Associate Manager',''),
  -- ('manish','munjal', 'manish.munjal.ext@heromotocorp.com', '919876828019', 'CIT Jaipur', '90131192', 'Project Support',''),
  -- ('pranav','patel', 'pranav.patel@heromotocorp.com', '918140679519', 'CIT Jaipur', '90131152', 'ILS',''),
  -- ('riyanka','kaushal', 'riyanka.kaushal@heromotocorp.com', '919599488856', 'CIT Jaipur', '14053', 'Senior Manager','')


	 --> Rajbir Yadav-Business Excellence

	 select top 2 * from Hero_Users order by 1 desc



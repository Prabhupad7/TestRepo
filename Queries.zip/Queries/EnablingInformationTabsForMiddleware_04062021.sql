

	 
select GroupType,* from CustomAttributeColumnMapping where SourceId = 68

select * from AttributeGroupType   ------> 211

--Update AttributeGroupType set TabId = NULL where id = 211

select * from Asset_EntityTabConfiguration   ----> 289

--Insert into Asset_EntityTabConfiguration

--select 68, NULL, 'Information', 'Information', 'fa fa-info-circle', 1, 0, 6, getdate()

 --exec Asset_ProvideAssPermission 6,1,1

 select * from Asset_EntityTypeUserMapping where id = 1967

 select * from Asset_EntityTabAndEntityUserMapping  where entityTabId= 289  ----- 1967





select * from AssetEntityType ----->  68	Middleware	Middleware	Middleware	1	2	1

--4	Laptop	Laptop	Laptop
--5	Desktop	Desktop	Desktop

--> step 1: Enable the AssetEntityType to the isBulkuploadEnabled=1

--Update AssetEntityType set isBulkuploadEnabled =1 where id =68

select * from AssetEntityType where id in (4, 5 , 68)

---->  step: 2 Enable the coulmns:

--exec usp_assetmanagement_getcustomattributecolumnmapping

select * from CustomAttributeColumnMapping where SourceId = 68 and PageId = 3

--Update CustomAttributeColumnMapping set IsBulkUpdate = 1 
--where SourceId = 68 and PageId = 3



----> exec Asset_ProvideAssPermission 6,1,1

select top 100  * from  Asset_EntityTabAndEntityUserMapping where entityTabId =68


select * from KM_EntityTabAndEntityUserMapping

select * from Asset_EntityTabAndEntityUserMapping

select top 100  * from Asset_EntityTabConfiguration where sourceAssetTypeId = 68

select top 100  * from Asset_EntityTabConfiguration where sourceAssetTypeId = 4

----->  Step 3: AutoDiscovery

select * from Asset_AutoDiscoverConfiguration where ToolId = 3

-----> Webserver Hostname

--Insert into Asset_AutoDiscoverConfiguration (	CustomerId,	AssetEntityId,	isAutoUpdate,	isVersioning	,UniqueKeys,	isDeleted	,CreatedOn,	CreatedById	,ToolId	,isDeletedRequired	,IsInsertRequired	,IsUpdateRequired)

--select 1, 68, 1, 0, 'Webserver Hostname', 0, GETDATE(), 6, 3, 0, 1,1

--select * from Assets where SourceId = 68
-- order by 1 desc

-- 21171
--21170
--21169


--select * from VarcharCustomAttribute where PrimaryId in (21171, 21170, 21169)


select * from Asset_BulkUploadProgress

select * from CustomAttributeColumnMapping where SourceId = 68 and PageId = 2

select * from CustomAttributeColumnMapping where SourceId = 68 and PageId = 3



------>  DP-20627

select * from Assets where id = 23067   ---->   

select * from VarcharCustomAttribute where PrimaryId = 23067

select * from Asset_Assignment where assetid = 23067

select top 100 * from Log order by 1 desc    ----->  

select top 100 * from NotificationHistory order by 1 desc

---->  745003

select top 100 * from NotificationRegistry  where statusId = 2 ----> and status like '%execute%'
order by 1 desc

	

	select top 100 * from log order by 1 dec

	select * from AssetEntityType  -----> 4 

	select * from CustomAttributeColumnMapping where SourceId = 4 
	and PageId = 3 and DisplayName like '%Os%'

		select * from CustomAttributeColumnMapping where SourceId = 4 
	and PageId = 3 and DisplayName like '%Type%'

	select * from CustomAttributeColumnMapping where SourceId = 4 
	and PageId = 3 and DisplayName like '%PO%'

	select * from CustomAttributeColumnMapping where SourceId = 4 
	and PageId in ( 1,2,3) and DisplayName like '%Asset Tag%'




	---->  182 PO Number


	select * from Assets where SourceId = 4 and isDeleted =0 ----->  20722

	select * from VarcharCustomAttribute where PrimaryId = 20722  ---->  

	select * from CustomAttributeColumnMapping
	 where SourceId = 4 and AttributeName like '%Varchar51%'


	 select top 100 * from AttributeGroupType where AssetTypeId = 4
	 ----->  4	5	4	1	Software Details

	 select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName like '%Employee%'

	select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName like '%OS%' ----->   121, 122

	select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName like '%Make%' 

	select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName like '%Model%' 

	select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName like '%Location%' 

	select * from CustomAttributeColumnMapping where id in (103, 104, 105,106, 119,120, 121, 122)

	--Update CustomAttributeColumnMapping Set IsEditable=1, IsUpperCase=null, IsLowerCase =null, AllowSpecialChars =null,
	-- SCExcemption=null, MinLength =1, MaxLength =40, ValueSource =null, EnablepastDate =null, EnableFutureDate = null, 
	-- EnablecurrentDate = null, IsVersioning =0, IsBulkUpdate=0  where id in (119,120)

	select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName like '%Status%'


	select * from AssetEntityType where Id in (10, 14)   ----->  

	select * from CustomAttributeColumnMapping where SourceId in (10, 14)

	select * from AttributeGroupType where AssetTypeId = 4

	---->  Location Entity

--	 1 OS update (required 4 line in the drop down list)

--Windows 7 Professional Edition
--Windows 10 Enterprise Edition
--Windows 10 Professional Edition
--Windows XP Professional

 

--2. PO updates: Please Enable all the columns in the bulk upload

--3. Employee id and Sub Status, Locations not reflecting in the bulk upload time. (View Page)
--4. Report 



	select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName ='OS' ----->   121, 122  Varchar

	--->OsNameVarcharselect

	--Update CustomAttributeColumnMapping set FeildType ='' where id in (121, 122)

	select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName like '%Make%'  --->  103, 104

	select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName like '%Model%' 

	select * from CustomAttributeColumnMapping where id in(103, 104)

	select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName like '%Employee Code%' 

	---->  Sub Status	Varchar1

	---->  Employee code	Varchar93

	--Update CustomAttributeColumnMapping set IsBulkUpdate = 1 where id in (184, 186, 188, 190, 192, 2311)


	select LocationId, LocationName,* from Assets where id = 23068

	select Varchar1, Varchar93,* from VarcharCustomAttribute where PrimaryId = 23068  ----->  

	select * from Asset_AutoDiscoverConfiguration where ToolId = 3  ---->   Asset Tag,Serial Number

	select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName like '%Sub status%' 

	select * from CustomAttributeColumnMapping where SourceId = 4 and id in (2647,2648,2680,63,64,65)

	----> 

	--Update CustomAttributeColumnMapping set AttributeName='varchar93' where id in (2647,2648,2680)


	select varchar93,* from VarcharCustomAttribute where PrimaryId = 23070  

	--Update CustomAttributeColumnMapping set isBulkUpdateAppend =null  where id in (2648)

	SELECT * from Workgroup where deleted = 0   ---->  


	select top 100 * from vwTimeStamp where ticketno = 286335

	---->  [dbo].[usp_GetReassignedTickets_TATAAIG]

	select top 100 * from ReportMaster where name like '%Assign%'  ---->  338

	--insert into ReportMaster  (name, query, isCustomReport, isInline, deleted, createdBy, createdOn, description, ticketTypeId, ThreadId, SourceTypeId )

	--values ('GetReassignedTickets', 'usp_GetReassignedTickets_TATAAIG', 0, 0, 0, 6, GETDATE(), 'Get Reassigned Tickets', 102, 1, 2 )

	Select * from ReportParameter  where reportMasterId = 338

	--Insert into ReportParameter (reportMasterId, title, name, dataType, rowType, ordering, isMandatory)
	--values (338, 'End Date', 'Enddate', 'datetime', 'DatePicker', 2, 1),
	--       (338, 'Start Date', 'StartDate', 'datetime', 'DatePicker', 1, 1)

	select roleId, * from Users where userId = 6 ---> 2

	select roleId, * from Users where firstName like '%Amod%'  --->  38

	select top 5 * from ReportRoleMapping 

	--Insert into ReportRoleMapping
	--select 38, 338, 0

	--exec [dbo].[usp_GetReassignedTickets_TATAAIG]   '2021-04-01', '2021-04-21', 330

    select * from CustomAttributeColumnMapping where SourceId = 4 and DisplayName ='OS'

	exec usp_getAssetsDynamicropDownValues 14, 1 ,1 ,6

	select * from AssetEntityType  ---->  14	OS	OS

	--Update AssetEntityType set Name='Operating System', DisplayName='Operating System', Description='Operating System' where id = 14

	select top 100 * from AssetEntityTypeCustomerMapping where AssetEntityTypeId in (4, 14)

	--EXEC usp_getalldropdownmappedAssettypes 14,1
	     

 select a.id,name,displayname,
 b.isAutoRelationEnabled
 from assetentitytype a
join AssetEntityTypeCustomerMapping c on a.id=c.assetentitytypeid
 join asset_entityformmapping b on a.id=b.DestinationId  
where b.sourceid=4 and c.customerid= 1 order by DisplayOrder  

---------------->  

 	select * from Assets where AssetNumber like '%DP-18182%'   ---->  20446 

	select * from Assets where id in (20446, 20253, 20253) 

	select * from VarcharCustomAttribute where PrimaryId in (20446, 20253, 20253) 


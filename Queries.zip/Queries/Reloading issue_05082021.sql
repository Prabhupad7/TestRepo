

select * from Users where email like '%Suche%' ---> 24388

select * from userpreferences where userid= 24388

--delete from userpreferences where userid= 24388
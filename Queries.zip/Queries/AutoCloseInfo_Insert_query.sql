


select  statusName,serviceId,workgroupId,* from ticket 
where customerid=213 and createdOn < GETDATE()-3 and statusName like 'Resolved' order by lastUpdatedOn 

select * from AutoCloseInfo where serviceid in (516,521) and workgroupid in (688,701,691) order by serviceid,workgroupid

--insert into AutoCloseInfo 
select distinct customerid ,customerName,autocloseTime,ticketTypeID,closureCode,closureCodeText,userID,
isActive,serviceid,688 from AutoCloseInfo where serviceid in (516,521) and workgroupid in (691)
﻿
-- For Ticket: [‎6/‎12/‎2020 7:47 PM]  Vignesh Annadurai:  
SR2563637  
 
 select * from Customer C where C.customerId = 207

Select * from ReasonForResponseBreach where CustomerId = 207 -- Response / UnityBoi

--update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 207


 -- Not monitoring the ticket queue

 --For Service Request. SR
--insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
--Select 'Not monitoring the ticket queue',207,2,0
--Select 'Missed to Acknowledge ticket on time',207,2,0
--Select 'Breach Reason Undermined by Engineer',207,2,0

----For Incident Request  IM
--insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
--Select 'Bulk Tickets Logged',207,1,0
--Select 'Not monitoring the ticket queue',207,1,0
--Select 'Missed to Acknowledge ticket on time',207,1,0
--Select 'Breach Reason Undermined by Engineer',207,1,0






-- Service request SR 
select * from ResolutionPendingReasons where customerid = 207 and ticketTypeId = 2

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,207

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,207

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,207

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,207

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,207

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,207

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,207


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,207

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,207

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,207

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,207

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,207

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,207

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,207


select * from customer c where C.customerName like '%Unity Bio%'


Actifio              ----------> 168
BOSCH                ----------> 61
BOSCH DCS            --------->  189
BOSCH Scottsdale     --------->  203
Comviva              ----------> 169
Enzen-NGN            ----------> 158
FGIC                 ----------> 8
Innocent Drinks      ----------> 188
Jubilant Life Science --------> 192
Jubilant Pharma    --------> 194
MLCIS                 --------> 3
MLRMC                --------> 4
SAP GD             --------> 58
UnityBio          --------> 3
Oreta - Ownership    --------> 161     (onluy owner ship Id --> 161)
Oreta - MMSG Voip   --------> 196








  update SLAExceptionCode set isDeleted= 1 where CustomerId = 168

  select * from customer where customerId = 207


--Select 'Project Task',2,6,GETDATE(),0,207


--update ResolutionPendingReasons set deleted = 1  where customerid = 207 and ticketTypeId = 2


select t.statusName, * from ticket t
join requestor r on r.requestorId=t.requestorId
where customerId=4 and r.requestorEmail='vishalds@microland.com'


560770
1806721
2457051



  -- city std code 33337777
   

   -- Comviva Customer is pending due to no WIP tickets.
   -- Same for FGIC
  -- Innocent Drinks)


  SR2568709	
SR2569653	
SR2569668	


  [‎6/‎17/‎2020 2:23 PM]  Natarajan Gopalaswamy:  
for rmcshiftmanager, there will be a skype id RMCShiftManager@microland.com 
 

 // For hdu quality:
[‎6/‎17/‎2020 2:24 PM]  Natarajan Gopalaswamy:  
You can talk to this lady, Maya Mathew MayaMJ@microland.com 


  Ticket assigned to Aravind: --IM2570407 
 

 [‎6/‎17/‎2020 2:59 PM]  Mahesh K:  
       i will update you as the changes are done for the user, so you can connect and inform him to login
       and enroll in self help portal and he will be able to login and check his details
        


		select t.statusName,* from ticket t
join requestor r on r.requestorId=t.requestorId
where customerId=4 and r.requestorEmail='vishalds@microland.com'



    select * from customer where customerId = 189

	SELECT * FROM Customer C WHERE C.createdByName LIKE '%forbes%'



	[‎6/‎17/‎2020 7:09 PM]  Aravindsagar Venkatesh:  
2568263 this ticcket i moved to onhold customer 
please update in the sheet 
 

 IM2564080 - wip
rest are same

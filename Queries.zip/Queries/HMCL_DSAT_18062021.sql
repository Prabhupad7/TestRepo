

select * from NotificationHistory where ticketNo in (
'2983449',
'2980582',
'2991422',
'2995763',
'3001746',
'3001749',
'2985171',
'2988318',
'2988402',
'2991047',
'2993649',
'2996176',
'2998879',
'2977537',
'2986800')


select * from NotificationRegistry where sourceId in (
'2983449',
'2980582',
'2991422',
'2995763',
'3001746',
'3001749',
'2985171',
'2988318',
'2988402',
'2991047',
'2993649',
'2996176',
'2998879',
'2977537',
'2986800')

--select * from Users where firstName like '%Mahavir%'  ---> 753 itsd.csdtl@heromotocorp.com

--usp_MIS_HMCL_TicketsResolvedBySD_Realtime

--select * from Requestor where requestorId  in(7846,9547)  ---> 


select * from Customer where customerName like '%Aveva%'  ----> 220	Aveva

select * from Users where email like '%RMCshift%'  ---->  113  RMCShiftManager@microland.com


select * from Requestor where requestorEmail like '%RMCshift%'  ----> 2950,16974,34797,56326

select * from Requestor where requestorEmail like '%RMCTools%'  ----> 17519,17885,38079,90539

select * from Requestor where requestorEmail like '%Collaboration%'  ----> 2968,16955,50414

select * from CUstomer where customerName like '%Bunge%' ----> 218

select * from CustomerRequestorMapping where customerId =218 and requestorId in (
 2950,16974,34797,56326, 17519,17885,38079,90539 ,  2968,16955,50414 )

 select * from Requestor where requestorId in (
50482,
13710,
58810,
58812,
3199 ,
58893,
9517 ,
53485,
58922,
58931,
7757 ,
58941,
58987,
58988,
58302,
59035,
59062,
59097,
59131,
50758,
59185,
59188,
59189,
59190,
59198,
38267,
2752 ,
59299,
59310,
59314,
56011,
40605,
59542,
59543,
13288,
59581,
59609,
59626,
59697,
59710,
59733,
59747,
59758,
55708,
64823,
58918,
19754,
58078,
89782,
89792,
89849,
89907,
91037,
91046,
91096,
91138,
54713,
91157,
91170,
8669 ,
91200,
91234,
91348,
91444,
91478,
41014,
56324,
91705,
58795,
91726,
58155)
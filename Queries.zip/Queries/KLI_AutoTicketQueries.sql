

Select * from ApiKey where customerId=1;

select * from ApiKey where keyname ='8C5DD19C-8B3F-4948-A143-CAF98A28EB8D' --->   6

select top 100 inInformation, inDescription,createdOn, * from AutoTicketEventLog
where apikeyId =6 order by 4 desc


--1483798
--1483797
--1483796
--1484525  31-12-2020 its created



--1483798
--1483797
--1483796
--1484525



select * from AutoTicketEventLog 
where inDescription like  '%New SOC Incident INC-148885%'



select * from AutoTicketEventLog 
where inDescription like  '%148885%'



---->   gsoc.servicedesk@niiconsulting.com� 

select * from autoticketserviceemailconfig 
where apikey in (Select keyname from ApiKey where customerId=1 )

--->   mlmenabevsupport@microlandsmartcenter.com	M!cr0land@bng1

---->   kli.sc-autoticket@kotak.com   Qwerty@1234

select * from Customer where customerName like '%FGIC%' --->  8 FGIC

Select * from ApiKey where customerId=8   ----> (13, 22)

select * from AutoTicketEventLog where apikeyId in ( 22)  ---> apikeyid: 22

--->  9440825851 obulReddy: 

------->   FGIC: 

select * from autoticketserviceemailconfig 
where apikey in (Select keyname from ApiKey where customerId=8 )

select * from autoticketserviceemailconfig
where apiKey ='819FFDDB-1B8C-4A66-BA50-643DA862A988'

select * from autoticketserviceemailconfig
where apiKey ='EA99FA20-699E-4FDE-A91D-3701B1AA89B8'

select getdate()
select top 100 * from AutoTicketEventLog 
where apikeyId in ( 22)order by 1 desc
 

 select top 100 * from AutoTicketEventLog 
where  inInformation like '%10.131.127.1%' order by 1 desc


----->   RMCNetworkandSecurity@microland.com

select * from autoticketserviceemailconfig
where EmailId like '%RMCNetworkandSecurity@microland.com%'

 ---> RuleId --  104


 CHARUS@microland.com

 919560105256

 CHARU SERAIK


 select * from users where email like '%CHARUS@microland.com%' ----> 25406   26629

  select * from users where email like '%SudhirA%' ----> 26356


  select * from Users where userId in (26629,26356 )

  select * from UserCustomerAssignGroupMapping where userId in (26629)

    select * from UserCustomerAssignGroupMapping where userId in (26356)

  --update users set levelid =1 where userId = 26629
  
 --update users set email ='deleted_charus@microland.com',
 --loginName='deleted_charus@microland.com' where userId = 25406
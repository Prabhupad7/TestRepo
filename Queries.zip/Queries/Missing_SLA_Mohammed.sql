
 --->  First step : need to go the Admin--> Missing SLA and update and verify if not updated then insert sla manually.

   select * from ServiceLevelTracking where sourceId = 2763555
   --->  1883278

  -- Insert Into ServiceLevelTracking (serviceLevelObjectiveId, sourceId, serviceLevelObjectiveTypeId, startTime,
  -- expectedDuration, expectedEndTime,  actualEndTime, actualDuration, adjustedDuration, isBreached, 
  -- statusId
  -- )

  --values (1883278, 2763555, 1 ,'2020-11-30 10:07:07.000',60, '2020-11-30 11:07:07.000',  '2020-11-30 12:01:07.000' ,120, 120, 0,3)



   select serviceId, workgroupId, priorityId, * 
   from Ticket where ticketNo = 2763555

   ---> 413	375	9



   select * from ServiceLevelObjective where serviceId = 413  and priorityId = 9  and  workgroupid = 375  
--
--   Insert into ServiceLevelObjective
 --   select distinct serviceLevelAgreementId,serviceLevelObjectiveTypeId,initialStatusId,finalStatusId,responseTimeInMin,
 -- excludeStatusIds,413 serviceId,priorityId,impactId,holidayCalendarId,workHourId,is24X7Service,locationId,375 workgroupId,isDelete,isDefault
 --from ServiceLevelObjective where serviceId = 413  and priorityId = 9  and  workgroupid = 594

  -- Update ServiceLevelTracking set expectedEndTime = '2020-12-01 10:07:07.000' where serviceLevelTrackingId = 6259370

    --Update ServiceLevelTracking set isBreached =1 where  serviceLevelTrackingId = 6259455
    

	select * from Users where email like '%manjithd@microland.com%'

	--->  8700210770 sangita Rani.


	select * from ticket t
	join requestor r on r.requestorId=t.requestorId
	where customerId=4 and r.requestorEmail='vishalds@microland.com'
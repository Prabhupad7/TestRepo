

select isAutoAssignmentEnable, primaryAssignmentGroupId,* from Users where email ='TirupathiBR@microland.com'  ---> 25348 , 25348	Tirupathi

--Update Users set isAutoAssignmentEnable = null, primaryAssignmentGroupId = null where userId = 25348
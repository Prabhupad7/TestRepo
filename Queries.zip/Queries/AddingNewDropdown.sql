		   
		   
		   Non Working Faulty 
		   Non Working Dead


		   select  * from CustomAttributeColumnMapping 
		   where SourceId=18 and CustomerId=1 and DisplayName = 'Working condition'


		   select * from Asset_Entity

          --update CustomAttributeColumnMapping set ValueSource = 'Working,Not Working,Non Working Faulty, Non Working Dead' where Id in (48,49,50)

		   select top 10 * from CustomAttributeColumnMapping  where Id in (48,49,50)

		      select * from AssetEntityType where id = 32  --22

			 select * from AssetEntityType where DisplayName like '%Lenovo%'

		      select  * from CustomAttributeColumnMapping  where SourceId = 32 and DisplayName like '%Working%'

			 -- update CustomAttributeColumnMapping set ValueSource = 'Working,Not Working,Non Working Faulty, Non Working Dead' where Id in (3158,3159,3160)

		

		 ---  18	Laptop	Laptop	Laptop



		 Non Working Faulty
		 
		 Non Working Dead



		   select * from CustomAttributeSourceTypes

		   
		   select * from CustomAttributeDropdownSourceType

---> 

  select * from Users where email like '%venkataraman%' --->  26093

  select * from Users where email like '%sweta%' --->  26549

  --insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)

  Select 26549,285,GETDATE(),6,0
  
  Select * from AssetEntityType where id = 285


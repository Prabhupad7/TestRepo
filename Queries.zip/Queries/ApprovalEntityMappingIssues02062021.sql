
    

Select top 10  * from Approval order by 1 desc ----2952620

Select top 10  * from ApprovalEmail where subject like '%APR2952620%' ----76462

select top 10  * from ApprovalEntityLevelDetails where sourceId = 2952620

select top 10 * from ApproverEntityApproval where sourceId =2952620 /// after creating approval if we want to change approver name

select top 10 * from ApprovalOverrideHistory order by 1 desc /// Override approval details

select top 10 * from ApprovalTicketAttachment where ticketNo =2952620

select top 10 * from ApproverEntityApprovalHistory order by 1 desc

------------------------

     select * from Asset_users where EmailId like '%udai.joshi%'  ----> 29675 , udai.joshi@eurekaforbes.com

	  select * from Asset_users where DisplayName like '%Udai Joshi%' -----> 9820036883

	 --Update Asset_users set EmailId = 'udai.joshi@eurekaforbes.co.in' where id = 29675

	 select * from Asset_users where id =  55832   -----> SomNS@microland.com

	 select * from Asset_users where FirstName like '%Anjali%' ---> 25673 anjali@eurekaforbes.co.in



	 select top 100 * from UserDepartmentRole where userEmailId like '%udai.joshi@eurekaforbes.co.in%'  ----> userTypeId:  95

     select * from Approval where approvalNo = 3025305   ---> 3292  APR3006421   approvalEntityMappingId = 2735

	 
     Select top 10  * from ApprovalEmail where subject like '%3008676%' ----76462

	 --CategoryId = 2109 , subCate = 9155 , 45086

	 select * from Category where categoryId = 2109

	 --delete from Approval where approvalNo = 2996312  	 APR3006421 


	 select * from Ticket where ticketNo = 3025305

	 select top 100 * from ApprovalEntityMapping where approvalEntityMappingId = 2735 ---> 619

	 select top 100 * from ApprovalMatrix where approvalMatrixId = 619  ----> 531

	 select top 100 * from ApprovalMatrix where approvalMatrixName like '%EFL%'

	 select top 100 * from ApprovalMatrixLevel where approvalMatrixId = 619   -----> 1202 , 1203

	 select top 100 * from ApprovalMatrixApprover where levelId in (1202 , 1203)  ----> 54178	ML-IT Asset Management

	 ------> 103, 106, 136 for inflow:

	 select top 100  * from UserDepartmentRole where userTypeId  = 83



	  select top 100 * from ApprovalMatrixApprover where approverId = 28112

774,
1200,
1204,
1206,
1254
 
select top 100 * from Approval

Select top 10  * from ApprovalEmail where subject like '%APR2952620%'

---> Select top 10  * from ApprovalEmail where subject like '%APR2952620%'

------> 
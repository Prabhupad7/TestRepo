

--Adwait Pendse (Central Ops, KLI) adwait.pendse@kotak.com
--Madhur Dhruv (Branch Ops, KLI) Madhur.Dhruv@KOTAK.COM
--Sameera Kamath (CPC, KLI) sameera.kamath@kotak.com
--Beenoy Pereira (Central Ops, KLI) beenoy.pereira@kotak.com
--Julius Aloor (ML, IT, KLI) kli.julius-aloor@kotak.com
--Sonali Kulaye (ML, IT, KLI) kli.sonali-kulaye@kotak.com
--Amruta Chavan (ML, IT, KLI) kli.amruta-chavan@kotak.com
--Umeshwari Deshmukh (ML, IT, KLI) kli.umeshwari-deshmukh@Kotak.com
--Mangesh Jagtap (ML, IT, KLI) kli.mangesh-jagtap@kotak.com


select top 10  * from Workgroup order by 1 desc  ---> 143	POLICY SERVICING

select * from AssignmentGroup where workgroupId = 143   ----> 208	POLICY SERVICING - L1

select * from CustomerAssignmentGroupMapping where assignmentgroupId = 208   ---> 228

----> 228	Branch Operations - POLICY SERVICING - L1

select * from Users where email in (
'adwait.pendse@kotak.com',
'Madhur.Dhruv@KOTAK.COM',
'sameera.kamath@kotak.com',
'beenoy.pereira@kotak.com',
'kli.julius-aloor@kotak.com',
'kli.sonali-kulaye@kotak.com',
'kli.amruta-chavan@kotak.com',
'kli.umeshwari-deshmukh@Kotak.com',
'kli.mangesh-jagtap@kotak.com')

select * from Users where loginName in 
('LE92137',
'Madhurd',
'LO4968',
'LO3424',
'LO1572',
'LO6284'
)

402
684
823
1090
1390
1412

select * from UserCustomerAssignGroupMapping where userId in (1090) 

--Insert into UserCustomerAssignGroupMapping

--select 402, 228, 0, 1, 1
--union all
--select 684, 228, 0, 1, 1
--union all
--select 823, 228, 0, 1, 1
--union all
--select 1090, 228, 0, 1, 1
--union all
--select 1390, 228, 0, 1, 1
--union all
--select 1412, 228, 0, 1, 1

kli.mangesh-jagtap@kotak.com
kli.amruta-chavan@kotak.com
Madhur.Dhruv@KOTAK.COM
kli.julius-aloor@kotak.com
kli.umeshwari-deshmukh@Kotak.com
adwait.pendse@kotak.com
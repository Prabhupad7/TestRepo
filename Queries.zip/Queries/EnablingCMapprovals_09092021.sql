select * from ChangeType   

select * from customer where customerName like '%Aveva%' --> 220	Aveva

select * from customer where customerName like '%Bunge%' --> 218	Bunge

select * from ChangeType   where customerid in 
(3,4,8,58,59,61,158,167,168,169,182,188,189,192,194,196,201,203,207,213,214,215,217,218,219,220,221)
and changeType='Emergency'

--Update ChangeType set isCMApprovalRequired = 1
--where customerid in 
--(3,4,8,58,59,61,158,167,168,169,182,188,189,192,194,196,201,203,207,213,214,215,217,218,219,220,221)
--and changeType='Emergency'


select customerid, workgroupid,* from Ticket where Ticketno =3158116 --> 779

  select top 100 * from Users where email like '%SurendraK@microland.com%'  ----> 1776  26135

  select * from Users where userid in (47)

select * from AssignmentGroup where workgroupid = 779 ---> 914

select * from CustomerAssignmentGroupMapping where assignmentgroupId = 914  ---> 3097	BCT-Maurice - RMC-IAM-SG

select * from UserCustomerAssignGroupMapping where Userid = 47 and custAssignmentGroupId =  3097

--insert into UserCustomerAssignGroupMapping 

--select 47, 3097, 0, 1,1 


select * from ChangeType   where customerid in 
(3,4,8,58,59,61,158,167,168,169,182,188,189,192,194,196,201,203,207,213,214,215,217,218,219,220,221)

---> and changeType='Emergency'

---- =======> IM3154098 CM3159984

    -- exec deletetickets @ticketNo = '3159984' 



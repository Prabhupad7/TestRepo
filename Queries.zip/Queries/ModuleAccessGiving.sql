


-- exec Asset_ProvideAssPermission '708',1,1,null

select  * from MenuMaster

select distinct( roleid ) from Users where email  like   '%nupur_microland%' -->  76

 -- Insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)
  Values(
 967,1,GETDATE(),6,0),
( 968,1,GETDATE(),6,0),
( 976,1,GETDATE(),6,0),
( 979,1,GETDATE(),6,0),
( 989,1,GETDATE(),6,0),
( 1003,1,GETDATE(),6,0)

select * from AssetEntityType where id=1

select * from AssetEntityType where id=66 

select * from Asset_EntityTypeUserMapping where userId = 23921

select * from Asset_EntityTypeUserMapping where userId = 189
--Select 963,1,GETDATE(),6,0


[8:25 PM] Vignesh Annadurai
   -- Asset_ProvideAssPermission 
   
  -- exec Asset_ProvideAssPermission '1003',1,1,null


  select * from  Asset_EntityTypeUserMapping where entityTypeId = 1 and isDeleted = 0 and userId in (

931,
962,

1000,
1003) 



   select * from MenuMaster 

   select * from MenuMaster  where menuName like '%knowledge%' -->  202

   select distinct( roleid ) from Users where email  like   '%nupur%' -->  76

   select * from Users where email  like   '%nupur%' -->  76

   select * from MenuroleMapping where roleid = 76 and menuid = 202

      select * from MenuroleMapping where roleid = 22 and menuid = 202

      select * from MenuMaster  where menuName like '%asset%' -->  202  261

	  select roleid,* from users where userid = 6 ----> 39

	  select roleid,* from users where email like '%venkatara%' ---> 48

	  select * from MenuroleMapping where roleid = 39 and menuid in( 208, 261)

	  select * from MenuroleMapping where roleid = 48 and menuid in( 208, 261)


	  ----->  918951011224


	  select * from AutoCloseInfo where customerid = 147

	  select distinct ticketTypeID from AutoCloseInfo
	  where customerid = 147

	  select distinct ticketTypeID from AutoCloseInfo
	  where customerid = 68

	  select distinct ticketTypeID from AutoCloseInfo
	  where customerid = 12

	  select * from ClosureCode where customerId = 218  ---->  

	  -----> 1501	Auto Close   1502	Auto Close
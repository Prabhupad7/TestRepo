

select * from  Eup_commonrequesttable

Select top 100 * from EUP_CommonRequest where deleted = 0 and Serviceid= 84  ---> 29025 , 29026

--Update EUP_CommonRequest set deleted = 1 where id in (29025 , 29026)

Select top 100 * from EUP_CommonRequest where id in (29025 , 29026)

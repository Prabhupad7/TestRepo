

select * from Users where userId = 6 ---> smcadmin1

select * from Users where email like '%venkataramanaiahk%' ---> 26093	Venkataramanaiah

select * from Users where email like '%SwetaS%' ---> 26549	Sweta

select * from Users where email like '%LNN%' ---> 26952	Naveen 

select * from Users where email like '%SRN%' ---> 27151	Ramesh

select * from Users where LoginName like '%mythrah%' ---> 26846	Mythra

select * from Users where Email like '%MaheshK%' ---> 25835	mahesh

select * from UserInstanceMapping where UserId = 25835  ---> 

select * from Users where Email like '%AnandKA@microland.com%' ---> 1659	Anand 

select * from Users where Email like '%ParameswarN@microland.com%' ---> 24675	Parameswar

--------> Step1: Role ,User and LevelId

select * from Users where userId in (6, 26093)

--Update Users set roleId=39, levelid=1, UserTypeId =1, instanceId =3 where userId in( 25835, 1659, 24675)

select * from UserInstanceMapping where userId in( 25835, 1659, 24675)

--Update UserInstanceMapping set InstanceId = 3
--where userId in( 25835, 1659, 24675)

-----> Step:2 UserCustomeraccess:

select * from UserCustomerAssignGroupMapping where deleted =0 and userId = 26093

select * from UserCustomerAssignGroupMapping where deleted =0 and userId = 6


--Insert into UserCustomerAssignGroupMapping

--select 26093, custAssignmentGroupId, deleted, 0, 1 from UserCustomerAssignGroupMapping where deleted =0 and userId = 6 and custAssignmentGroupId not in (
--select custAssignmentGroupId from UserCustomerAssignGroupMapping where deleted =0 and userId = 26093
--)



select userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup from UserCustomerAssignGroupMapping where deleted =0 and userId = 6 and custAssignmentGroupId not in (
select custAssignmentGroupId from UserCustomerAssignGroupMapping where deleted =0 and userId = 26093
)



select * from Users where userId in( 26549, 26952, 27151, 26846)
---> L3 Team: userId in( 25835, 1659, 24675)

--delete from UserCustomerAssignGroupMapping  where userId in ( 25835, 1659, 24675)

select * from UserCustomerAssignGroupMapping where deleted =0 and userId = 6

--insert into UserCustomerAssignGroupMapping

--select 24675, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup
--from UserCustomerAssignGroupMapping
--where deleted =0 and userId = 26093

-------------> 

1. SmartCenter Admin Modules need to enable
2. CMDB access need to enable
3. Asset Access

---> step 3: Admin Module Access: 

---> ( 25835, 1659, 24675)

select  * from Admin_UserCustomerAdminMapping  where UserId = 26093 and Deleted = 0

select  * from Admin_UserCustomerAdminMapping  where UserId =24675 and Deleted = 0

--Insert into Admin_UserCustomerAdminMapping

--select 24675, customerid, InstanceID, GETDATE(), 6, GETDATE(), 6, 0
--from Admin_UserCustomerAdminMapping  where UserId = 6 and Deleted = 0

----> Step 4: CMDB access:

	 --Insert into Asset_EntityTypeUserMapping (userId, entityTypeId, createdOn, createdBy, isDeleted,instanceId)
	 --values 
	 --(26093, 241, GETDATE(), 6, 0, 3),
	 --(26093, 427, GETDATE(), 6, 0, 3)

	 select * from  Asset_EntityTypeUserMapping	 where entityTypeId in (143, 241, 427)  
	 and userId = 24675

	 --Update Asset_EntityTypeUserMapping set instanceId = 3 where Id = 14197

	 select * from  Asset_EntityTypeUserMapping
	 where entityTypeId in (143, 241, 427)  and userId = 6

	 --( 26549, 26952, 27151, 26846) ( 25835, 1659, 24675)

	 	-- Insert into Asset_EntityTypeUserMapping (userId, entityTypeId, createdOn, createdBy, isDeleted,instanceId)

		 --select 24675, entityTypeId, GETDATE(), createdBy, isDeleted,instanceId from  Asset_EntityTypeUserMapping	 where entityTypeId in (143, 241, 427)  and userId = 26093

----> For Normal Users:
	 --Insert into Asset_EntityTypeUserMapping (userId, entityTypeId, createdOn, createdBy, isDeleted)
	 --values 
	 --(26987, 241, GETDATE(), 6, 0)





select * from users where email like '%Tim.chitsiga@aveva.com%'


--Step 5: KM Module access: 

	 --( 26549, 26952, 27151, 26846) ( 25835, 1659, 24675)

	 select * from Asset_EntityTypeUserMapping 
	 where entityTypeId in (66, 285) and isDeleted = 0 and userId in (26093)


	 select * from Asset_EntityTypeUserMapping 
	 where entityTypeId in (66, 285) and isDeleted = 0 and userId in (24675)

	 ----delete from Asset_EntityTypeUserMapping where Id = 13225

--insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)
--Select 24675 ,66,GETDATE(),6,0
--UNION ALL
--Select 24675 ,285,GETDATE(),6,0

Step2: 

select * from customer where customerName like '%Aveva%'


---> exec KM_ProvideKnowledgePermission  26943, 220  (UserId, customerId)



exec KM_ProvideKnowledgePermission  26093, 68
exec KM_ProvideKnowledgePermission  26093, 147 
exec KM_ProvideKnowledgePermission  26093, 199 
exec KM_ProvideKnowledgePermission  26093, 50 
exec KM_ProvideKnowledgePermission  26093, 3 
exec KM_ProvideKnowledgePermission  26093, 163 
exec KM_ProvideKnowledgePermission  26093, 194 
exec KM_ProvideKnowledgePermission  26093, 182 
exec KM_ProvideKnowledgePermission  26093, 192 
exec KM_ProvideKnowledgePermission  26093, 168 
exec KM_ProvideKnowledgePermission  26093, 61 
exec KM_ProvideKnowledgePermission  26093, 169 
exec KM_ProvideKnowledgePermission  26093, 158 
exec KM_ProvideKnowledgePermission  26093, 167 
exec KM_ProvideKnowledgePermission  26093, 8 
exec KM_ProvideKnowledgePermission  26093, 188 
exec KM_ProvideKnowledgePermission  26093, 4 
exec KM_ProvideKnowledgePermission  26093, 58 
exec KM_ProvideKnowledgePermission  26093, 207 
exec KM_ProvideKnowledgePermission  26093, 217
exec KM_ProvideKnowledgePermission  26093, 216 
exec KM_ProvideKnowledgePermission  26093, 219 
exec KM_ProvideKnowledgePermission  26093, 218 
exec KM_ProvideKnowledgePermission  26093, 215 
exec KM_ProvideKnowledgePermission  26093, 213 
exec KM_ProvideKnowledgePermission  26093, 214 
exec KM_ProvideKnowledgePermission  26093, 220 




------------> 9030502836 


select distinct CustomerId from Assets where isDeleted = 0 

select * from Assets where isDeleted = 0  and CustomerId is null

------------> Asset Module access: 

  --   exec Asset_ProvideAssPermission 26137,167,1
  --   exec Asset_ProvideAssPermission 26095,167,1 
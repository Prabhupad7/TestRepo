

	select * from Workgroup where workgroupid = 3

select ServiceId, serviceName, TicketTypeid, priorityId, priorityName,
requestorId, requestedByName, * from Ticket  where ticketNo = 1606437

select * from Requestor where requestorId  = 14456 ---> 14456	Akshay Mumbaikar (CPC, KLI)

select * from CustomerRequestorMapping where requestorId = 14456

select * from serviceCategoryMapping
where ServiceiD = 2 and TicketTypeid = 2  ----> 378


select * from Category where categoryId = 378 ---> AML

select * from SubCategory where categoryId = 378  ---> 969	Access Rights

select * from Classification where SubcategoryId = 969  ---> 2783	Others-Undefined

--Update ticket set categoryId = 378, categoryName ='AML', subCategoryId = 969, subCategoryName ='Access Rights',
--classificationId = 2783, classificationName = 'Others-Undefined'
--where ticketNo = 1606437
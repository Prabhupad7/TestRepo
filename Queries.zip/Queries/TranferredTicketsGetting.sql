--Please find the query for EFL Onsite team resolved tickets:


WITH Ticket AS(
SELECT ROW_NUMBER() OVER(PARTITION BY Ticketno ORDER BY ticketno) rowno,* FROM dbo.vwTimeStamp WHERE customerid =167 AND createdon BETWEEN getdate()-65 AND getdate() and currentStatus like 'Resolved' and currentWorkgroup not like 'RMC%'
and (workgroup like 'RMC%' and statusid  in (3,14))
)
SELECT  * FROM Ticket where rowno = 1 order by ticketno

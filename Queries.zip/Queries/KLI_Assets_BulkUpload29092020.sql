   

   select top 100 A.AssetNumber, A.Model, A.SerialNumber, A.Hostname, A.Status, A.LocationId ,
   * from Assets A 

   select top 100 * from Assets 

   Select  * from KLI_29092020 

	select * from KLI_03122020

	select * from KLI_12012021

	 select * from KLI_10022021




    select * into ##temp_KLI03112020 from KLI_03112020

    select * from ##temp_KLI03112020

    select * into temp_KLI_10022021 from KLI_10022021

    select top 100 * from Assets where isDeleted = 0


   --Siva Mummidi  - SivaM@microland.com
   --Rahul Malhotra  - RahulMa@microland.com 


   --->

   Select * from KLI_12012021

   select * from KLI_10022021

   -- EntityType	AssetTag	modelno	SerialNumber	HostName	UserName	Status	LoginID	IMACDCallID	ActivityType	PartReplacementRemarks	ID	StatusIdNew	AssignedEng	DisplayName	EmailId

   ALTER TABLE KLI_12012021 
   ADD StatusIdNew int

      ALTER TABLE KLI_12012021 
      ADD EmailId nvarchar(250)

	
	  
	  --->  AssetId, AssignedEng, StatusIdNew, DisplayName, EmailId

	  --ALTER TABLE KLI_10022021 
   --   ADD EmailId nvarchar(100)

   --  DisplayName, EmailId

    --ALTER TABLE orders1
    --ADD store_code TEXT NULL 
    --CONSTRAINT store_code_d DEFAULT "store1"
    --WITH VALUES
   
   select * from KLI_23112020

   select * from KLI_07122020 

   select * from KLI_12012021

    --update KLI_01102020 set SerialNumber = 'DKN9Q13' where AssetTag = 'KLI/34953'

   select * from Assets A where A.AssetNumber ='KLI/34896' and A.SerialNumber = 'HD3MQ13'


   select * from Assets A 
   inner join KLI_12012021 K 
   on A.AssetNumber = K.AssetTag -- and A.SerialNumber = K.SerialNumber


   select * from Assets A 
   inner join temp_KLI_18112020 K 
   on A.AssetNumber = K.AssetTag 
   where A.id not in 

   (select A.Id from Assets A 
   inner join temp_KLI_18112020 K 
   on A.AssetNumber = K.AssetTag and A.SerialNumber = K.SerialNumber)



   select * from Assets where AssetNumber in (
    'KLI/20295',
	'KLI/24023',
	'KLI/24176',
	'KLI/24035',
	'KLI/24043'
   )

   ------> New Tables

   select * from Assets A 
   inner join KLI_12102020 K 
   on A.AssetNumber = K.AssetTag  --  and A.SerialNumber = K.SerialNumber

   where A.id not in 

   (select A.Id from Assets A 
   inner join KLI_12102020 K 
   on A.AssetNumber = K.AssetTag )



		   select * from KLI_29092020 where id in (
		 25263
		,25264
		,25523
		   )

		      select * from Assets A 
			  inner join KLI_06102020 K 
			  on A.AssetNumber = K.AssetTag

			     select * from Assets A 
			   inner join temp_KLI_18112020 K 
			   on A.AssetNumber = K.AssetTag and A.SerialNumber = K.SerialNumber


			   ----->  Updating the AssetID

	   --Update K set K.Id = A.Id
	   --from KLI_29092020 K
	   --inner join Assets A 
	   --on A.AssetNumber = K.AssetTag and A.SerialNumber = K.SerialNumber

	   Update K set K.AssetId = A.Id
	   from KLI_10022021 K
	   inner join Assets A 
	   on A.AssetNumber = K.AssetTag 


	   -----> Updating the Asset Status ID

	   -->  step 1
	       select * from AssetEntityType where name in (
           select distinct EntityType from KLI_12012021 )

	  --->  step 2
	    select * from Assets where AssetNumber in (
		'KLI/06791',
		'KLI/19908',
		'KLI/15337',
		'KLI/15338'
		  )

  select * from AssetEntityType wg

  select * from Asset_Status where AssetTypeId = 31
   
   select distinct EntityType from temp_KLI_10022021

    select * from KLI_12012021 where EntityType ='UPS - Standalone'    and Status = 'Spare'

	select * from KLI_07122020

	select * from KLI_10022021


	--Update KLI_12012021 set StatusIdNew = 236 where EntityType ='UPS - Standalone'   and Status = 'Spare'

	select distinct Entitytype from  ##temp_KLI30102020


	Select * from Asset_Status where AssetTypeId = 31  ----> 125	Need to Scrap

	select * from KLI_10022021  where EntityType = 'UPS - Standalone' and Status = 'Reserved'

	--Update KLI_10022021 set statusIdNew = 247 where EntityType ='UPS - Standalone' and Status = 'Reserved'

	select  * from AssetEntityType where NAme in (	'CPU', 'CRT Monitor', 'Laptop')




	select * from KLI_07122020  where EntityType ='UPS - Standalone' 

    select * from KLI_12102020  where EntityType ='UPS - Standalone' and status like '%Under allocation%'

	select * from KLI_12102020  where EntityType ='UPS - Standalone' and status ='Under allocation' 

	--Update KLI_07122020 set StatusIdNew ='238'  where EntityType ='UPS - Standalone' 

	select distinct EntityType from KLI_12102020 

	-- Update KLI_06102020 set NewAssetStatusID =125

	 --update KLI_01102020 set statusIdnew =10

  ------ Columns Need to Update StatusId, Status, Login ID, Login ID	IMACD Call ID	Activity Type	Part Replacement Remarks

  ---->  Previous User (To be add with old previous user),	New Login ID,	IMACD Call ID,	Activity Type,	Part replacement  (to be add with previous Part Replacement Remarks)

  --> 03112020
  ----->   User Name  ( to be add with previous user name)	Employee ID  ( to be add with previous Employee ID)	Previous User ( to be add with previous remarks)	Status	IMACD Call ID	Activity Type	Call ID of IT Clearance	Part Replacement Remarks ( to be add with previous remarks)

                              ---                               
  ----  A.AssignedToId, A.AssignedToName ----> Login ID, User Name

  --  DisplayName, EmailId

     ---->  step 3 Updating the AssignedEng, EmailId, DisplayName

	  select top 100 * from Asset_users

	  select * from Asset_users where EmployeeId like '%OM82588%'

	  select * from KLI_10022021

		  select * 
		  from KLI_12012021 a 
		  inner join 
		  Asset_users b on b.EmployeeID = A.EmployeeID

		   Select * 
		  from Asset_users a 
		  inner join 
		  temp_KLI_18112020 b on a.Alias =b.EmployeeID

		  ---> STEP:  Updating the EmailId, DisplayName and AssignedEng 

		  --update a set a.DisplayName = b.DisplayName, a.EmailId = b.EmailId, a.AssignedEng = b.Id  
		  --from KLI_10022021 a 
		  --inner join 
		  --Asset_users b on b.EmployeeID = A.EmployeeID

		  select top 100 * from Asset_Assignment order by 1 desc
		  
		  select * from KLI_10022021

		  --->  8381  Ms. Sonali Ghosh  ---->  Manas Paul

		  select * from Asset_Assignment where assetId = 12327  --- Mr. Sachit Mohit  --->   Shishu Jha (KA, KLI)

		  select * from Asset_users where Id in (8849) -----> 

    select * from KLI_01102020 a 

    select * from temp_KLI_18112020

    select distinct(Status) from KLI_29092020

    select distinct(Status) from KLI_01102020


  select * from Asset_users where id = 17099

  inner join Asset_users b on b.Alias =A.LoginId

  --- These users are not existing: 

    select * from Asset_users where Alias in (
'LE79847',
'LE79839',
'LE81790',
'LE79849',
'LE82825',
'LE82826'
	)

  Select top 1000 * from Asset_users


   Select A.Status, A.StatusId, A.AssignedToId, A.AssignedToName, A.AssetName, A.AssetNumber, * from Assets A 
   where A.AssetNumber ='KLI/34896' and A.SerialNumber ='HD3MQ13'


     select * from KLI_29092020 

	   Select  * from Asset_users where Id = 10941

	     select * from KLI_29092020

       select * from KLI_30102020

	   ---->  step 4 Updating the Asset Status and StatusId


				 --   update a set a.StatusId = b.NewAssetStatusID, a.status ='Need to Scrap'
					--from assets a inner join KLI_06102020 b on a.Id = b.AssetId 
					--and a.AssetNumber = b.AssetTag
					--where a.id in (select b.AssetId from KLI_06102020 )

				--update a set a.StatusId = b.StatusIdNew, a.status = b.Status
				--from assets a inner join KLI_30102020 b on a.Id = b.AssetId 
				--and a.AssetNumber = b.AssetTag
				--where a.id in (select b.AssetId from KLI_30102020 )



				--select A.AssetNumber, a.Status, k.status, a.StatusId, k.StatusIdNew from Assets A
				--inner join KLI_12102020 K
				--on a.AssetNumber = k.AssetTag
				--and a.StatusId = k.StatusIdNew

			    select A.AssetNumber, a.Status, k.status, a.StatusId, k.StatusIdNew from Assets A
				inner join temp_KLI_10112020 K
				on a.AssetNumber = k.AssetTag
				and a.StatusId = k.StatusIdNew


				select OSName, OSNameId, * from Assets where Id in ( select AssetId from KLI_12102020 ) and OSName is not null ---> 58

				select OSName, OSNameId, * from Assets where Id in ( select AssetId from KLI_12102020  where PreviousUser is not null)  ---> 58


			 --   update a set a.StatusId = b.StatusIdNew, a.status = b.Status
				--from assets a inner join KLI_10022021 b on a.Id = b.AssetId 		
				--where a.id in (select AssetId from KLI_10022021 )



		--  select * from Assets where id = 25207

		     select * from KLI_12102020 

			 select A.assetId, A.assignedToId, A.assignedToName from Asset_Assignment A
			 inner join KLI_23112020 K
			 on A.assetId = k.AssetId
			  
			  ---> 4738

			  select * from Asset_Assignment where assetId = 4738

			  select * from KLI_12102020 where assetId not in (
			  select assetId from Asset_Assignment where IsActive = 1 
			  )


			select *   from 
			Asset_Assignment a inner join KLI_07122020 b on a.assetId = b.assetId 
			where a.IsActive = 0  and a.assetId in (
			select  a.assetId from KLI_07122020 a) 

			select *   from 
			Asset_Assignment a inner join KLI_12012021 b on a.assetId = b.assetId 
			where  a.assetId in (
			select  a.assetId from KLI_12012021 a) 

			
			--Update A set A.deleted =1, IsActive =0 from
			--Asset_Assignment a inner join KLI_07122020 b on a.assetId = b.assetId 
			--where  a.assetId in (
			--select  a.assetId from KLI_07122020 a) 







			----->STEP:  Updating the Asset Assignment: 

			update Asset_Assignment set assignedToId = b.AssignedEng , assignedToName = b.DisplayName  from 
			Asset_Assignment a inner join KLI_10022021 b on a.assetId = b.assetId 
			where a.IsActive = 1  and a.assetId in (
			select  a.assetId from KLI_10022021 a) 


			
		 --   update Asset_Assignment set assignedToId = b.AssignedEnd , assignedToName = b.DisplayName  from 
			--Asset_Assignment a inner join KLI_30102020 b on a.assetId = b.assetId 
			--where a.IsActive = 1  and a.assetId in (
			--select a.assetId from KLI_30102020 a where a.AssignedEnd is  not null ) 


			select * from KLI_12102020 K
			inner join Asset_users A
			on K.AssignedEnd = A.Id



			select  A.EmailId from KLI_12102020 K
			inner join Asset_users A
			on K.NewLoginID = A.Alias

			select top 100 * from Asset_users 

			---->  step 5 Updating the Assigned_Eng
          



			select * from KLI_30102020 

			select top 1000 * from Asset_Assignment 

			select top 100 *  from Asset_users where Alias like '%Le69288%'

			
				--update JP_21072020 set assignedtoengineer =b.id  from JP_21072020 a 
				--inner join Asset_users b on a.eMail =b.EmailId


				--update KLI_30102020 set AssignedEnd = b.id, EmailId =b.EmailId,DisplayName = b.DisplayName  from KLI_30102020 a 
				--inner join Asset_users b on b.Alias = a.empcode


				select * from KLI_30102020 where AssignedEnd is null

				select top 1000 * from Asset_users order by 1 desc
				

				select * from Asset_users where Alias in (
				select empcode from KLI_30102020 where AssignedEnd is null
				)
				

			select * from Asset_Assignment a 
			inner join temp_KLI03112020 b 
			on a.assetId = b.assetId 
			where a.IsActive = 1

			--update Asset_Assignment set assignedToId = b.AssignedEng , assignedToName = b.Displayname  from 
			--Asset_Assignment a inner join temp_KLI03112020 b on a.assetId = b.assetId 
			--where a.IsActive = 1  and a.assetId in (
			--select a.assetId from temp_KLI03112020 a) 

				-----> Updating the Asset Assignment: 





		 --   update Asset_Assignment set assignedToId = b.AssignedEnd , assignedToName = b.DisplayName  from 
			--Asset_Assignment a inner join KLI_30102020 b on a.assetId = b.assetId 
			--where a.IsActive = 1  and a.assetId in (
			--select a.assetId from KLI_30102020 a where a.AssignedEnd is  not null ) 



				Select *  from Asset_users a 
				inner join KLI_30102020 b 
				on a.Alias =b.empcode

				Select * from Asset_Assignment a 
				inner join KLI_30102020 b 
				on a.assetId  = b.assetId

				Select distinct  assignedToId, assignedToName from Asset_Assignment a 
				inner join KLI_30102020 b 
				on a.assetId  = b.assetId

				--Select *  from Asset_users a 
				--inner join KLI_30102020 b 
				--on a.DisplayName like b.UserName


				select * from KLI_01102020

						select * from Asset_users where id in (
						15951
		,15955
		,15963
		,16685
		,17218
		,17217)

			select * from Asset_Assignment where assetId in (
			  6988
			)

			select * from KLI_01102020 where assetId = 25544

			--Update Asset_Assignment set assignedToId =17217 , assignedToName ='Manishkumar Pal (UW, KLI)' where Id = 38985

			select * from KLI_01102020 where assetId not  in (
			  select assetId from Asset_Assignment 
			)

  
			--update Asset_Assignment set assignedToId = b.AssignedEng , assignedToName = b.DisplayName  from 
			Asset_Assignment a inner join KLI_29092020 b on a.assetId = b.ID 
			where a.IsActive = 1  and a.assetId in (
			select a.Id from KLI_29092020 a) 


			    Select *  from Asset_Assignment a 
				inner join KLI_12102020 b 
				on a.assignedToId =b.AssignedEng
				where  a.IsActive = 1  and a.assetId in (
			    select a.assetId from KLI_12102020 a) 


		 --   Insert into Asset_Assignment (assetId, assignedToId, assignedToName, UserRelationId, Relationship, createdById, createdOn, updatedById, updatedOn, IsActive, deleted, TicketNumber)
		  
		 --  select assetId, AssignedEng, DisplayName, 3, 'Used By', 718, GETDATE(), 718, GETDATE(), 1, 0, 0 from KLI_01102020 where assetId not  in (
			--  select assetId from Asset_Assignment 
			--)

			-- exec deletetickets @ticketNo = '1418979'


			select * from PR_03082020

			select top 100 * from Asset_users where id = 25215

			select top 1000 * from VarcharCustomAttribute where PrimaryId = 25207

			---->  select * from KLI_10022021

				update VarcharCustomAttribute set Varchar17 = ISNULL( Varchar17,'' ) +' . ' + b.PartReplacementRemarks
				from VarcharCustomAttribute a inner join  [dbo].[KLI_10022021] b on a.PrimaryId = b.assetId
				where a.PrimaryId in (select   a.assetId from [dbo].[KLI_10022021] a)



				update VarcharCustomAttribute set Varchar15 =b.ActivityType
			    from VarcharCustomAttribute a inner join  [dbo].[KLI_10022021] b on a.PrimaryId = b.assetId
				where a.PrimaryId in (select   a.assetId from [dbo].[KLI_10022021] a)


				update VarcharCustomAttribute set Varchar14 = b.IMACDCallID
				from VarcharCustomAttribute a inner join  [dbo].[KLI_10022021] b on a.PrimaryId = b.assetId
				where a.PrimaryId in (select   a.assetId from [dbo].[KLI_10022021] a)


					update VarcharCustomAttribute set Varchar16 =b.CallIDofITClearance
		           from VarcharCustomAttribute a inner join  [dbo].[KLI_10022021] b on a.PrimaryId = b.assetId
				   where a.PrimaryId in (select   a.assetId from [dbo].[KLI_10022021] a)




				 ---> nedd to execute on 12012021:

				 
	     select * from CustomAttributeColumnMapping 
	     where DisplayName like '%Previous User%' and SourceId= 17  and CustomerId=1

		  select * from CustomAttributeColumnMapping 
	     where DisplayName like '%Previous User%' and SourceId= 17  and CustomerId=1

		 ----------->  Previius User Name: 

				--update VarcharCustomAttribute set varchar10 = ISNULL( varchar10,'' )  +' / ' +  b.UserName 
				--from VarcharCustomAttribute a inner join  [dbo].[KLI_10022021] b on a.PrimaryId = b.assetId
				--where a.PrimaryId in (select   a.assetId from [dbo].[KLI_10022021] a)



         select * from CustomAttributeColumnMapping 
	     where DisplayName like '%previous%' and SourceId= 17  and CustomerId=1


	 ----------->  Previius User Name: 

				--update VarcharCustomAttribute set varchar10 = ISNULL( varchar10,'' )  +' / ' +  b.UserName 
				--from VarcharCustomAttribute a inner join  [dbo].[KLI_10022021] b on a.PrimaryId = b.assetId
				--where a.PrimaryId in (select   a.assetId from [dbo].[KLI_10022021] a)


				select varchar10,  * from VarcharCustomAttribute where PrimaryId in (
				9429,21944
				)

				select * from [temp_KLI_18112020]
				
				Select varchar10, * from VarcharCustomAttribute a inner join  [dbo].[temp_KLI_18112020] b on a.PrimaryId = b.assetId
				where a.PrimaryId in (select  a.assetId from [dbo].[temp_KLI_18112020] a) --and varchar10 is null
				order by PrimaryId


					Select  PrimaryId, * from VarcharCustomAttribute a inner join  [dbo].[temp_KLI03112020] b on a.PrimaryId = b.assetId
				where a.PrimaryId in (select  a.assetId from [dbo].[temp_KLI03112020] a) and varchar10 is null



--update VarcharCustomAttribute set Varchar15 =b.ActivityType
--from VarcharCustomAttribute a inner join  [dbo].[PR_03082020] b on a.PrimaryId = b.AssetID where a.PrimaryId in (select a.AssetID from [dbo].[PR_03082020] a)


----update VarcharCustomAttribute set Varchar14 =b.IMACDCallID
----from VarcharCustomAttribute a inner join  [dbo].[PR_03082020] b on a.PrimaryId = b.AssetID where a.PrimaryId in (select a.AssetID from [dbo].[PR_03082020] a)


   select * from Users where email like '%kgi%'

   select  * from Requestor where requestorEmail like '%kgi.serv%'

   --update Requestor set failedLoginAttemptCount =0, isAccountLocked =0 where requestorId =13872

  --  ate requestor set deleted =1 where requestorId = 14387

   select * from CustomerRequestorMapping where requestorId =13872

    select * from CustomerRequestorMapping where requestorId =14387

	select * from Service where service like '%Database'

	select * from Assets where assetNumber = 'KLI/27012' ---> 19

	select * from AssetEntityType  -->  19	Thin Client	Thin Client

	Select * from Asset_Assignment where assetId = 10080 and IsActive =1  and deleted =0

	Select * from Asset_Assignment where assignedToName like '%Chatterjee Sandeep (KA, KLI)%'


	--update  Asset_Assignment set isActive =0 where id =15655

	select top 100 * from Asset_users where EmailId like '%chatterjee.sandeep@kotak.com%'  -- 5052	OM54547

	Select * from Asset_Assignment where assetId = 10080  and deleted =0



	--Varchar14 - IMACDCallID
	--Varchar15 - Activity type
	--Varchar17 - Part Replacement
	--varchar10 - Previous User
	--Varchar16 - Call ID of IT Clearance

    select * from CustomAttributeColumnMapping 
	where DisplayName like '%Previous Location%' and SourceId= 17  and CustomerId=1


	    select * from CustomAttributeColumnMapping 
	where DisplayName like '%Previous User%' and SourceId= 17  and CustomerId=1

	 select * from CustomAttributeColumnMapping where DisplayName like '%Employee%'  and CustomerId=1

    --update VarcharCustomAttribute set Varchar17 = Varchar17 + ' . ' + b.PartReplacementRemarks from KLIVandana_291020 b
	--inner join VarcharCustomAttribute a on a.PrimaryId=b.AssetId where a.PrimaryId in (select AssetId from KLIVandana_291020)

     select a.Varchar15,a.* from KLIVandana_291020 b inner join VarcharCustomAttribute a 
	 on a.PrimaryId=b.AssetId where a.PrimaryId in (select AssetId from KLIVandana_291020)


	     select * from KLI_03122020 where AssetTag in (
 'KLI/21576'
,'KLI/30950'
,'KLI/32058'
,'KLI/32061') 


-------->  select * from KLI_12012021



--------->   



select * from Asset_users where DisplayName like '%naresh mungale%' ----> 14006  OM74659	 LE74659  Naresh Mungale (Branch Ops, KLI)

select * from Asset_users where DisplayName like '%Naresh%' ---->  12255	


select * from Asset_Assignment where assignedToId = 14006        and assetId in (
21969
,21979
,21984)

select * from Asset_Assignment where assetId in (8381
,17641
,12854
,21407
,24295)


  --Insert into Asset_Assignment (assetId	,assignedToId,	assignedToName,	UserRelationId,	Relationship,	createdById,	createdOn,	updatedById	,updatedOn,	IsActive,	deleted,	TicketNumber)

  --values (15549, 12255,'Mr. Naresh Krishnakumar Mungale',3, 'Used By', 718, GETDATE(), 718, GETDATE(), 1, 0, 0),
  --       (10931, 12255,'Mr. Naresh Krishnakumar Mungale',3, 'Used By', 718, GETDATE(), 718, GETDATE(), 1, 0, 0),
		-- (20884, 12255,'Mr. Naresh Krishnakumar Mungale',3, 'Used By', 718, GETDATE(), 718, GETDATE(), 1, 0, 0),
		-- (4259,  12255,'Mr. Chandrakeerthi Jain',3, 'Used By', 718, GETDATE(), 718, GETDATE(), 1, 0, 0),
		-- (21618, 12255,'Mr. Chandrakeerthi Jain',3, 'Used By', 718, GETDATE(), 718, GETDATE(), 1, 0, 0),
		-- (21623, 12255,'Mr. Chandrakeerthi Jain',3, 'Used By', 718, GETDATE(), 718, GETDATE(), 1, 0, 0)




--Update Asset_Assignment set assignedToName ='Naresh Mungale (Branch Ops, KLI)' where id in (
-- 25257
--,25258
--,25256)





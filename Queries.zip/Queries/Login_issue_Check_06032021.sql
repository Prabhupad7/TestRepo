

       select * from Instancepasswordchangehistory where UserId = 25644

---->  update Instancepasswordchangehistory set PwdUpdatedDate = GETDATE() where Id = 1106

--[10:54 AM] Suvarna K
    
--Can you provide update on SR2875789

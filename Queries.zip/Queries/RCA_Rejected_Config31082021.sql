select * from TicketType ---> 4	Problem

select * from NotifyBasedOn where notifyBasedOn like '%Reject%'

--notifyBasedOnId	notifyBasedOn
--36	REJECTED

--37	REJECT_AND_CLOSE

--38	FIRSTLEVEL_REJECT

select * from TicketStatus where ticketTypeId = 4 

select * from Customer  ---> 147	Ask Microland

select top 100 * from NotificationRules 
where customerId = 147 and deleted = 0

select deleted,* from NotificationRules where customerId in (3,4,8,58,59,61,158,167,168,169,182,188,192,194,196,201,207,213,214,215,217,218,219,220,221) 
and ticketTypeId = 4 and notifyBasedOnId in (36,37) -- and templateId = 0
order by customerId 

----> ;;(Engineer, and workgroup should receive the email

select * from NotificationRules where customerId in (220)and ticketTypeId = 4 and notifyBasedOnId in (36,37) 

--Update NotificationRules set templateId = 2233 where ruleId in (
--2353900,
--2353901
--) 

----> $WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL

--Insert into NotificationRules (customerId, ticketTypeId, notificationMode, notificationTo, templateId, ruleName, serviceId, notifyBasedOnId, deleted)

select 221, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', 538, 36, 0 UNION ALL
select 221, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', 539, 36, 0 UNION ALL
select 221, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', 540, 36, 0 UNION ALL
select 221, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', 541, 36, 0 UNION ALL

--select 207, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', , 36, 0 UNION ALL
--select 207, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', , 36, 0 UNION ALL


select 221, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', 538, 37, 0 UNION ALL
select 221, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', 539, 37, 0 UNION ALL
select 221, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', 540, 37, 0 UNION ALL
select 221, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', 541, 37, 0 UNION ALL

--select 207, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', , 37, 0 UNION ALL
--select 207, 4, 'Email', '$WORKGROUPEMAIL;$ASSIGNEDENGINEEREMAIL', '', 'RCA_REJECTED', , 37, 0 UNION ALL

select * from Customer where customerId in (167) 

select * from NotificationRules where customerId in (167) 
and ticketTypeId = 4 and notifyBasedOnId in (36,37) -- and templateId = 0
order by customerId 

select * from NotificationEmailTemplate where customerid = 167

--Update NotificationRules set deleted  = 1 where Ruleid in (
--2353794,
--2353795,
--2353796,
--2353797,
--2353798,
--2353799,
--2353800,
--2353801,
--2353802,
--2353803,
--2353804,
--2353805,
--2353806,
--2353807,
--2353808,
--2353809,
--2353810,
--2353811,
--2353812,
--2353813,
--2353814,
--2353815,
--2353816,
--2353817,
--2353818,
--2353819,
--2353820,
--2353821,
--2353822,
--2353823
--)




select deleted,* from NotificationRules where customerId in (3,4,8,58,59,61,158,167,168,169,182,188,192,194,196,201,207,213,214,215,217,218,219,220,221) 
and ticketTypeId = 4 and notifyBasedOnId in (36,37) -- and templateId = 0
order by customerId


--Update NotificationRules set deleted =1  where customerId in (3,4,8,58,59,61,158,167,168,169,182,188,192,194,196,201,207,213,214,215,217,218,219,220,221) 
--and ticketTypeId = 4 and notifyBasedOnId in (36,37) -- and templateId = 0
order by customerId
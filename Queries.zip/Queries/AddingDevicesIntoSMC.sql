
        To add new device to the table. 

        select * from Device where devicename like '%DC1NJVM16%'

        INSERT INTO device(devicename,alternateName,ipAddress,customerId,deleted,hostName) 
        values('DC1NJVM16','DC1NJVM16','10.131.124.71', 4,0,'DC1NJVM16'); 

		

      --    After adding map the device in the service table with 4 different type (1,2,3,4)

          INSERT INTO DeviceServiceMapping (serviceId, deviceId,deleted,ticketTypeId) VALUES(1,24150,0,3)

		  select * from service where serviceName like '%RMC%'



   After inserting the device into the device table Cross check the same in the UATportal
	1. Go to request --> Click on 'Active Tickets' --> click on 'Create Ticket'
	2. Select the customer name where the device is inserted
	3. In ticket information select 'ServiceName' --> Configuration Item.

	select * from device where customerid = 4
	
	select * from customer where customername like '%rmc%' 
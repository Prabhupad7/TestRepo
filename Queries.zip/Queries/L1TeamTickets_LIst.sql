
    hi team please save the query for future reference whenever sir asks for report 

    
exec [dbo].[usp_StandardReport_getAllIM&SRCombinedTicketDump] '2020-03-01', '2020-09-30', 'resolvedTime' , 
'150,151,152,153,154,155,156,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209', 
'256,257,258,259,260,261,262,452,453,454,455,456,457,458,459,460,461,649' , 330




Select * from workgroup where workgroupId in (select workgroupid from AssignmentGroup 
where assignmentgroupId in (select assignmentgroupId from CustomerAssignmentGroupMapping 
where customerId in (150,151,152,153,154,155,156,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209) and deleted=0) and deleted=0)




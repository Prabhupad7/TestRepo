


  ---- My ID LE73272 � Use this for clone but only clone for RP002 report.

    select roleid, * from Users where loginName ='LE73272'  --->  46  , 1019

	select roleid, * from Users where loginName ='LE85453'  --->  54  , 1314

	---  update users set roleId = 54 where userid = 1314


--	Please follow the below steps

--1)	Create a user using given clone id.
--2)	Get the role id from the created user and create a new role only for that user(by taking existing role  id as reference)
--3)	Then put entry on the below table for the new created role.
  
--MenuRoleMapping
--ReportRoleMapping
--RoleAccessMapping
--UserRoleMapping

--4)	Update the newly created role to the required user,


	--insert into Users(firstName,lastName,displayName,mobileNo, email, loginName, password, deleted, IsWorkgroup, isPasswordPolicyApplicable, 
	--isAutoAssignmentEnable,roleId,createdById,createdOn,timezoneinfoId,instanceId, levelid, UserTypeId)

 --   Select 'reshma','Chougule','Reshma Chougule (IT, KLI)','1234','reshma.chougule@kotak.com','LE85453', 'SUv/GzSv2NSYGeW1YMGviQ==', 0,0,0,0, 46,6, GETDATE(), 24, 1,1,3

	select * from  UserInstanceMapping where UserId = 1019  ---- 1314

	select * from  UserInstanceMapping where UserId = 1314  ---- 1314

	Select * from Role where roleId = 46

	select top 10 * from Role order by 1 desc  --->  54

	select  * from Role

	--Update role set description ='KLI Manager - Access to Dashboard, Myworklist,report:RP002 ' where roleId = 54


    

	--  Action=Index,Controller=Dashboard,TemplateId=9

	-- Insert into Role (name, description, deleted, allowAllChangeTicketApproval, landingPageUrl, roleDisplayName)

	    values('KLI Manager', 'KLI Manager - Access to Dashboard, Myworklist,reports', 0, 0, 'Action=Index,Controller=Dashboard,TemplateId=9', 'KLI Manager')

	--Insert into UserInstanceMapping (UserId, InstanceId)
	--values (1314, 1)


	--Select * from usercustomerassigngroupmapping where userid = 25937

 --   Select * from CustomerAssignmentGroupMapping where custAssignmentGroupId  = 1101

   select * from MenuRoleMapping where roleID = 46

    select * from MenuRoleMapping where roleID = 54
  
    --  Insert into MenuRoleMapping (roleID, menuID, isdeleted)

	select 54, menuID, isdeleted from MenuRoleMapping where roleID = 46

	select * from ReportRoleMapping where RoleId = 54

	--Insert into ReportRoleMapping (RoleId, ReportMasterId, IsDeleted)
	--values (54, 46, 0)

	select * from RoleAccessMapping where roleId = 46

	select * from RoleAccessMapping where roleId = 54

	select * from UserRoleMapping where userId = 1019

	select * from UserRoleMapping where userId = 1314

	--insert into UserRoleMapping (userId, roleId)

	--select 1314, 54

	--Insert into RoleAccessMapping (roleId, roleAccessId, permission, isdeleted)

	--select 54, roleAccessId, permission, isdeleted from RoleAccessMapping where roleId = 46

	select * from ReportMaster where reportMasterID = 46  ---> 46

	select * from Role where Name like '%Aveva%'

	select * from RoleAccess

	select * from RoleAccessMapping

		 -- Action=Index,Controller=Dashboard,TemplateId = 9

	 -- Insert into Role 

	 --select name,'Aveva Engineer',viewEngineerLoad,viewTimelineTracking,	viewUnassignedTickets,	viewTickets,	viewAllIncidentTickets,	viewAllProblemTickets,
	 --viewAllChangeTickets,	viewAllServiceRequestTickets,	createTickets,	createIncidentTicket,	createProblemTicket,	createChangeTicket,
	 --createServiceRequestTicket,	updateTickets,	updateAllIncidentTickets,	updateAllProblemTickets,	updateAllChangeTickets,	1,
	 --allowIncidentAssignment,	allowIncidentForceAssignment,	allowProblemAssignment,	allowProblemForceAssignment,	allowChangeAssignment,
	 --allowChangeForceAssignment,	allowServiceRequestAssignment,	allowServiceRequestForceAssignment,	createRCA,	updateRCA,	allowRCAApproval,
	 --allowChangeTicketApproval,	allowChangeTicketCABApproval,	allowAdminRights,	receivePopUp,	deleted,	allowAllChangeTicketApproval,
	 --viewAllReleaseTickets,	allowReleaseAssignment,	createReleaseTicket	, updateAllReleaseTickets,	allowReleaseForceAssignment, allowReleaseTicketApproval,
	 --allowReleaseTicketReleaseBoardApproval,	allowAllReleaseTicketApproval,	IsSRRejectedTicketApproval,	landingPageId,	landingPageUrl,
	 --LandingPageMenuActionId,	roleDisplayName 
	 --from Role where roleId = 138   

--MenuRoleMapping
--ReportRoleMapping
--RoleAccessMapping
--UserRoleMapping

----> 
   
    select * from Role where name like '%nokia%' ---> 138	Engineer	Nokia Engineer

	select * from Role order by 1 desc  ---> 147	Engineer	Aveva Engineer

	select * from  RoleAccessMapping  
	where roleId = 138 and isdeleted = 0

	--Insert into RoleAccessMapping 

	--select 147, roleAccessId, permission, isdeleted from  RoleAccessMapping  
	--where roleId = 48 and isdeleted = 0

	select * from UserRoleMapping   where roleId = 48

	--insert into UserRoleMapping (userId, roleId)
	--values 
	--(26946, 147),
	--(26943, 147),
	--(26945, 147),
	--(26944, 147),
	--(26947, 147)


	select m.menuID, m.menuName, m.menuUrl, m.menuActionUrl from MenuRoleMapping R
	inner join MenuMaster M on M.menuID = R.menuID
	where r.roleID = 138 and isdeleted = 0 
	order by 1 

	select m.menuID, m.menuName, m.menuUrl, m.menuActionUrl from MenuRoleMapping R
	inner join MenuMaster M on M.menuID = R.menuID
	where r.roleID = 147 and isdeleted = 0 
	order by 1 
	--> 8	/ServiceRequestTicket/Index
	10	Closed Tickets

	--Update MenuRoleMapping set menuID = 8 where menuID = 10 and roleID = 147

	--Insert into MenuRoleMapping
 --  values
 --  (147,1,0),
 --  (147,2,0),
 --  (147,3,0),
 --  (147,4,0),
 --  (147,11,0),
 --  (147,12,0),
 --  (147,5,0),
 --  (147,6,0),
 --  (147,9,0),
 --  (147,10,0),
 --  (147,18,0),
 --  (147,20,0),
 --  (147,15,0),
 --  (147,16,0)


--2156	Eureka Forbes Limited - SAP - CRM1
--2157	Eureka Forbes Limited - SAP-CRM2
--2158	Eureka Forbes Limited - SAP-EV


select * from MenuMaster  where menuUrl like '%Incident%' ---> 


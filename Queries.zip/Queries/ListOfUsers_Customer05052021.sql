

	   select FirstName, lastname,EmailAddress, mobilePhone1 from Hero_Users 

	   Select distinct u.displayName, u.email, u.mobileNo 
	   from Users u join UserCustomerAssignGroupMapping m on u.userId = m.userId 
	   join CustomerAssignmentGroupMapping c on c.custAssignmentGroupId= m.custAssignmentGroupId
	   where c.customerId=68 and c.deleted=0 and u.deleted=0 and m.deleted=0
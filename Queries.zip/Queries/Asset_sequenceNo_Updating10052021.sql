    

--EXEC Usp_AssetDeletetionByAssetId  20386

--select * from Asset_AssetNumberConfiguration where CustomerId = 1 and AssetTypeId = 18

--update Asset_AssetNumberConfiguration set SequenceNumber = 1481 where CustomerId = 1 and AssetTypeId = 18


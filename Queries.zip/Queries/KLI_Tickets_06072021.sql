

select * from Customer where customerName like '%Aveva%' ---> 220	Aveva

select * from Organization where customerId = 220

--Update Organization set deleted = 1 where organizationId in (7123,7124)

--Insert into Organization

--select 'Expereo','Expereo',0,0,1,0,0,0,'Expereo', NULL,NULL,NULL,NULL,NULL,NULL,220
--UNION ALL
--select 'Equinix','Equinix',0,0,1,0,0,0,'Equinix', NULL,NULL,NULL,NULL,NULL,NULL,220
--UNION ALL
--select 'Cisco SmartNet','Cisco SmartNet',0,0,1,0,0,0,'Cisco SmartNet', NULL,NULL,NULL,NULL,NULL,NULL,220
--UNION ALL
--select 'Centrics IT','Centrics IT',0,0,1,0,0,0,'Centrics IT', NULL,NULL,NULL,NULL,NULL,NULL,220

select * from Requestor 
where requestorEmail like  '%pratibha@heromotocorp.com%' ---> 91879 pratibha@heromotocorp.com

--Update Requestor set lastname ='' where requestorId = 91879

select top 100 * from Hero_Users where emailAddress = 'pratibha@heromotocorp.com'

--Insert into Hero_Users

--select 'Pratibha', '', 'pratibha@heromotocorp.com', '', '', 'HP3N-Neemrana GPC', '', '', '', '','','', '', '', '',''

select * from users where userId = 26808  -----> RashadK@microland.com

select top 100 * from CustomerAssignmentGroupMapping where custAssignmentGroupId in (
select custAssignmentGroupId from UserCustomerAssignGroupMapping where userId = 26808 and deleted = 0 )


--------------> Admin Access Providing: 

 ----> 220	Aveva

 select * from Users where email = 'amitdik@microland.com' ----> 26360  2

 select * from UserTypes

 select top 100 * from Admin_UserCustomerAdminMapping where Deleted = 0 and UserId = 26360

 --Insert into Admin_UserCustomerAdminMapping

 --select 26360, 220, 2, GETDATE(), 6, GETDATE(), 6, 0
 ------------------------------------------------------->

 select * from Service where serviceId =  84  ---> 84	HR	HR

 select * from NotificationRules 
 where deleted = 0 and customerId = 147 and serviceId = 84 and workgroupid = 632 

 ----> Enzen SGN account.

select * from customer where customerName like '%Enzen SGN%'  ---> 221	Enzen SGN

select * from workGroupEscalationMatrix_AskML
where Level3Email='SrinivasuluRE@microland.com'

select * from workGroupEscalationMatrix_AskML
where workGroupId in (200, 216)

----delete from workGroupEscalationMatrix_AskML where id in (9, 10)

----------->

  select * from customer where customerName like '%Actifio%'   --> 168	Actifio-Apotex

  select * from ApiKey where customerId = 168  ----> 74 

  select top 100 * from AutoTicketEventLog where apikeyId = 74 and inDescription like '%SmartCopy failed with an unknown error code%'
  order by 1 desc

  --------------------> 



  select * from [dbo].[MIS_HMCL_EmailSend_Weekly]


  select roleId,* from Users where firstName like '%Mandar%' ----> 48	25804

  select top 100 * from ReportMaster where reportMasterID = 499

  Select * from ReportRoleMapping where RoleId = 48 and ReportMasterId = 499

  -----------> 

  select * from MenuMaster ---> 281	/Dashboard/99

  select * from MenuRoleMapping where roleID = 48 and menuID = 281

  ----------------------->

  select * from Customer where customerName like '%mott%' ---> 220 , 147,  214	Mott MacDonald

  select * from Users where userId = 26945   ----> 

  select distinct u.userId, u.firstName, u.lastName, u.mobileNo, u.email from Users U 
  inner join UserCustomerAssignGroupMapping UC
  on U.userId = UC.userId
  inner join CustomerAssignmentGroupMapping C on c.custAssignmentGroupId = uc.custAssignmentGroupId
  where u.deleted = 0 and uc.deleted = 0 and c.customerId= 220 and c.deleted = 0

  ----> Pradeep Bharadwaj T S

  select * from ApiKey where customerId = 214  ---> 130	BEF3CF70-8741-4E7C-A3FE-683A1D114CAE

select * from autoticketserviceemailconfig
where apikey in (Select keyname from ApiKey where customerId=214)

-----> mottmacdonalds@microlandsmartcenter.com  M!cr0land@bng1

select roleId,* from Users where loginName ='sukeshsg'  ----> 75

select top 100  roleId,* from users where userId in (26986 , 26987)

--Update Users Set roleId = 75 where userId in (26986 , 26987)

select * from Requestor where requestorEmail like '%parikshit.tyagi@heromotocorp.com%'  ---> 91807

------------------>

select * from Assets where AssetNumber = 'KLI/31532' ---> 21664

--Update Assets set LastUpdatedOn= GETDATE() where id = 21664

select * from Asset_users where EmployeeId ='OM113133' ---> 27631  'Devendra  Kumar (KA, KLI)'

select top 100 * from Asset_Assignment where assetId = 21664

--Insert into Asset_Assignment
--select 21664, 27631, 'Devendra  Kumar (KA, KLI)', 3, 'Used By', 6, GETDATE(), 6, GETDATE(), 1, 0, NULL


select * from Workgroup where workgroup like '%security management%'  ----> 15	Security Management

select * from Workgroup where workgroup like '%Infra security%'  ---->144	Infra Security device Management

select * from AssignmentGroup where  workgroupId in (15 ,144 ) ----> 28	Security Management-Queue

---> 209	Infra Security device Management - L3

--assignmentgroupId	assignmentgroupName
--28	Security Management-Queue
--209	Infra Security device Management - L3

select * from Service where ServiceId = 15 ----> 15	Security Management

select distinct categoryId from ServiceCategoryMapping where serviceId = 15 and deleted = 0

select * from Category where categoryId in (916,926)

----> 875,876,877,878,879,880,881,916,926

select top 100 * from RulesForPriority  where PriorityRule like '%categoryId=875;%'


select * from RulesForAssignment where PrimaryAssignmentGroupId = 28

select * from RulesForAssignment where PrimaryAssignmentGroupId = 209

----> 3056354

select * from ServiceLevelTracking where SourceId = 3056354

select   * from serviceLevelObjective where serviceLevelObjectiveId in (
816450,
816446,
404333,
760069
)

--Update serviceLevelObjective set responseTimeInMin = 1440 where serviceLevelObjectiveId in (
--760069
--)


select distinct responseTimeInMin from ServiceLevelObjective where serviceId = 84 and workgroupId in 
( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628,629,630,631,632,687,744,241,249,
189,207,224,225,227,229,232,233,235,238,241,249,513,630,631,632,680,744,765,772,527,238) 
and serviceLevelObjectiveTypeId = 2

select * from ServiceLevelObjective where serviceId = 84 and workgroupId in 
( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628,629,630,631,632,687,744,241,249,
189,207,224,225,227,229,232,233,235,238,241,249,513,630,631,632,680,744,765,772,527,238) 
and serviceLevelObjectiveTypeId = 2

select * from ServiceLevelObjective where serviceId = 84 and workgroupId in 
( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628,629,630,631,632,687,744,241,249,
189,207,224,225,227,229,232,233,235,238,241,249,513,630,631,632,680,744,765,772) 
and serviceLevelObjectiveTypeId = 2 and workhourid in (126)

--Update ServiceLevelObjective set responseTimeInMin = 1440  from ServiceLevelObjective where serviceId = 84 and workgroupId in 
--( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628,629,630,631,632,687,744,241,249,
--189,207,224,225,227,229,232,233,235,238,241,249,513,630,631,632,680,744,765,772,527,238) 
--and serviceLevelObjectiveTypeId = 2

select * from WorkHours where workHourId = 14 ----> 38

----> 126	9:30am to 6:30pm Mon to Fri	9:30am to 6:30pm Mon to Fri	India Standard Time

--Insert into WorkHours

--select '9:30am to 6:30pm Mon to Fri', '9:30am to 6:30pm Mon to Fri', 'India Standard Time'


select * from WorkHoursDetail  where workHourId = 126

select * from WorkHoursDetail   order by 1 desc

--insert into WorkHoursDetail (workHourId, dayNumber, dayName, startTime, endTime)

--values 
--( 126,1, 'Monday', '2012-08-24 09:30:00.000', '2012-08-24 18:30:00.000'),
--( 126,2, 'Tuesday', '2012-08-24 09:30:00.000', '2012-08-24 18:30:00.000'),
--( 126,3, 'Wednesday', '2012-08-24 09:30:00.000', '2012-08-24 18:30:00.000'),
--( 126,4, 'Thursday', '2012-08-24 09:30:00.000', '2012-08-24 18:30:00.000'),
--( 126,5, 'Friday', '2012-08-24 09:30:00.000', '2012-08-24 18:30:00.000')


select 126, dayNumber, dayName,'2012-08-24 09:30:00.000', endTime, durationInSec from WorkHoursDetail  where workHourId = 14



----> 14	9:00am to 6:30pm Mon to Fri	9:00am to 6:30pm Mon to Fri	India Standard Time



select * from WorkHours where name like '%9:30am%' ----> 38

--select * from WorkHoursDetailTime

---> 14	9:00am to 6:30pm Mon to Fri	9:00am to 6:30pm Mon to Fri	India Standard Time

---> 38	9:30am to 6:30pm	9:30am to 6:30pm	India Standard Time

--Update ServiceLevelObjective set responseTimeInMin = 1440 
--where serviceLevelObjectiveId in (1885321,
--1885323,
--1885320,
--1885331,
--1885324,
--1885326,
--1885333,
--1885330,
--1885301,
--1885334,
--1885300,
--1885302,
--1885304,
--1885322,
--1885328,
--1885327,
--1885303,
--1885325,
--1885332,
--1885329)


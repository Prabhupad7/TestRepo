

 select * from Customer where customerName like '%Men%'  --->   217

 select  * from ChangeAdvisoryBoard where customerid = 217 and deleted =0

 --Insert into ChangeAdvisoryBoard (memberName, displayName, emailId, customerId, customerName, isdeleted, deleted)
 --values 
 --('Borhan Hassan', ' Borhan Hassan', 'hassan.borhan@menabev.com', 217, 'MenaBev', 0, 0),
 --('Yarkandi Hanan', ' Yarkandi Hanan', 'Hanan.Yarkandi@menabev.com', 217, 'MenaBev', 0, 0),
 --('Syed Zeeshan Ali', 'Syed Zeeshan Ali', 'Syed.Zeeshan@menabev.com', 217, 'MenaBev', 0, 0),
 --('Hamed Mohammed', 'Hamed Mohammed', 'Mohammed.Hamed@menabev.com', 217, 'MenaBev', 0, 0),
 --('AlSharif Abdullah', 'AlSharif Abdullah', 'Abdullah.Alsharif@menabev.com', 217, 'MenaBev', 0, 0)




 --Update ChangeAdvisoryBoard set isdeleted =1 , deleted =1 where customerId = 217



AlSharif Abdullah 
Abdullah.Alsharif@menabev.com
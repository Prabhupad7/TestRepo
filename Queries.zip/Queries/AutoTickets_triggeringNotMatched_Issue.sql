
   select * from Customer where customerId = 8 --> FGIC

   select * from Customer where customerName like '%Menabev%' --> 217	MenaBev



   select customerId,deleted, * from Device where deviceName like '%SW01NJ%'

   select * from DeviceServiceMapping where deviceId = 4338

   Select top 100 * from AutoTicketEventLog order by 1 desc

   Select top 100 * from AutoTicketEventLog where inInformation like '%SW01NJ%'
   order by 1 desc




      select getdate()
      Select top 100 * from AutoTicketEventLog where
	  inInformation like '%isolated network%' and apikeyId = 134 order by 1 desc

	   --  2793163
    --     2793163

	  select * from ApiKey where customerId =217 ---->  keyId (134)

	  select getdate()

      select top 100 createdOn,* from AutoTicketEventLog where
	  apikeyId = 134 order by 1 desc

	  -->  select top 100 createdOn,* from AutoTicketEventLog where  id in (1215671,1215670)

   
Select * from ApiKey where customerId=8 ; 

Select * from ApiKey where customerId=1 ;

select * from ApiKey where keyname ='8C5DD19C-8B3F-4948-A143-CAF98A28EB8D' --->   6

select top 100 * from AutoTicketEventLog
where apikeyId =6 order by 1 desc


select * from Customer where customerId = 8 --> FGIC

Select * from ApiKey where customerId=8  ---->  13, 22

select * from autoticketserviceemailconfig 
where apikey in (Select keyname from ApiKey where customerId=8 )

select top 100 * from AutoTicketEventLog
where apikeyId = 22 order by 1 desc


select top 10  * from AutoTicketServiceRule where id =104

select top 10 * from AutoTicketServiceRuleDetails where autoTicketServiceRuleId = 104


select top 100 * from AutoTicketEventLog
where apikeyId = 22 and inInformation like '%FGIC Cisco Router/Critical: Fan 3 Status%'
order by 1 desc


select top 100 * from AutoTicketEventLog
where apikeyId = 22 and inInformation like '%Fan 3 Status%'   ---ruleId =  104
order by 1 desc


select top 100 * from AutoTicketEventLog
where apikeyId = 22 and inInformation like '%Fan 4 Status%'
order by 1 desc


select top 100 * from AutoTicketEventLog
where apikeyId = 22 and inInformation like '%FGIC-NY521-LAS01%'
order by 1 desc



--->   mlmenabevsupport@microlandsmartcenter.com	M!cr0land@bng1

---->   kli.sc-autoticket@kotak.com   Qwerty@1234

select * from autoticketserviceemailconfig where apikey='819FFDDB-1B8C-4A66-BA50-643DA862A988'

select top 10 * from autoticketserviceemailconfig where apikey='EA99FA20-699E-4FDE-A91D-3701B1AA89B8'


   Select top 100 * from AutoTicketEventLog where inInformation like '%SW01NJ%'
   order by 1 desc



   --->   Agent Uptime 




      Select top 100 * from AutoTicketEventLog where inInformation like '%SNMP Agent Uptime%'
      order by 1 desc



   	    Subject: [Traverse] SW01NJCritical: SNMP Agent Uptime 
 
		Status Change Notification from Traverse:

		TCUSTOMERNAME:FGIC
		CATEGORY: RMC 
		TCOMPONENT: E 
		TSEVERITY: None 
		TPRIORITY: None 
		TDEVICENAME: SW01NJ
		TIPADDRESS: 10.131.127.11
		TALERTDESCRIPTION: SW01NJ  10.131.127.11   SNMP Agent Uptime  none  Polled Result: 529    Warning: 7200  Critical: 1800  Time In State: 00:05 TEND: End 


		------>   919560044987


		select * from ReportMaster where reportMasterID = 150 

		----->   usp_StandardReport_ASKML_getChangeClosedTicketDump_RP002



		select top 100  * from AutoTicketServiceRule where apikeyid = 134 and deviceid = 31180   ----->   1030675

---------------> 03-05-2021: 

select * from Customer where customerId = 3 --->  MLCIS

select * from AutoTicketEventLog
where ticketNo in (2868363, 2869219) ---->  RuleId: 351

select deviceId, ServiceId, PriorityId, CategoryId, SubCategoryId, ClassificationId,
* from AutoTicketServiceRule where id = 351  ---->  DeviceiD: 7

select * from Device where deviceName like  '%BLRBTPAVAADS101%'   --->  31308 

select * from AutoTicketServiceRule where deviceId = 31308  ---->  


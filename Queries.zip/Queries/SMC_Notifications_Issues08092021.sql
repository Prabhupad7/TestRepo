

select * from NotificationEmailTemplate where templateid in (461, 417)

select top 100 * from SMSnotificationLogs

------> SLA Percentage: 98


select top 100 * from SMSnotificationLogs S

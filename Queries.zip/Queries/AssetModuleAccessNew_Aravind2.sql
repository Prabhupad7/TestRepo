
    ----->  Asset_ProvideAssPermission

    --  exec Asset_ProvideAssPermission 26543,216,1


   select * from users where email like '%MunirajaK@microland.com%'  ---->  25652   roled: 42

   select * from ReportMaster where reportMasterID = 326 

   select * from ReportRoleMapping where RoleId = 42 and ReportMasterId =326

   --update ReportRoleMapping set IsDeleted =0 where id = 3406



   select c.customerId from UserCustomerAssignGroupMapping U
   inner join CustomerAssignmentGroupMapping C on C.custAssignmentGroupId = u.custAssignmentGroupId
   where U.userId= 26674 and u.deleted =0 and c.deleted= 0


      select c.customerId from UserCustomerAssignGroupMapping U
   inner join CustomerAssignmentGroupMapping C on C.custAssignmentGroupId = u.custAssignmentGroupId
   where U.userId= 23854 and u.deleted =0 and c.deleted= 0

     select * from Asset_EntityTypeUserMapping where userId =26674 

	 
  select * from Asset_EntityTypeUserMapping where userId =23854 

  select * from Asset_EntityTypeUserMapping where userId =26674 

  select top 100 * from  AssetEntityTypeCustomerMapping  order by 1 desc ---->  

  select * from users where email like '%MayaMJ@microland.com%'  ---->  419

        --exec Asset_ProvideAssPermission 26093,147,1

		--exec Asset_ProvideAssPermission 26676,147,1

	select * from Workgroup where workgroup like '%Neemrana%' --	from Neemrana GPC location 

	select * from AssetEntityType where Name like '%CMDB%'  ---->  143, 241, 427

	 Asset_EntityTypeUserMapping

	 AssetEntityTypeCustomerMapping

	 Asset_EntityTabAndEntityUserMapping

	 select top 100 * from  Asset_EntityTypeUserMapping  ---> 

	 select top 1000 * from  AssetEntityTypeCustomerMapping  ---> 

	 select top 1000 * from  Asset_EntityTabAndEntityUserMapping  where entityUserMappingId in (14202
,14201
,14200
,14199
,14198
,8811)

	 select top 100 * from  Asset_EntityTypeUserMapping
	 where entityTypeId in (143, 241, 427)  and userId = 26676
	 order by 1 desc


	 --Insert into Asset_EntityTypeUserMapping (userId, entityTypeId, createdOn, createdBy, isDeleted)
	 --values 
	 --(26676, 143, GETDATE(), 6, 0),
	 --(26676, 241, GETDATE(), 6, 0),
	 --(26676, 427, GETDATE(), 6, 0)

	 --update Asset_EntityTypeUserMapping set isDeleted = 0 where id in ( 17760)
    
	---> 17760	26676	241	2021-05-05 12:34:15.213	6	0	NULL

	 select top 100 * from  Asset_EntityTypeUserMapping
	 where entityTypeId in (143, 241, 427)  and userId = 6
	 order by 1 desc



	 	 select top 100 * from  Asset_EntityTypeUserMapping
	 where entityTypeId in (143, 241, 427)  and userId = 26093
	 order by 1 desc

	 select * from Users where userId in (26832, 25644, 26093) ---> 25644	Ashokkumar  9916944948


	 -------------------> Enabling information Tab for TATAAIG middleware: 

	 
select GroupType,* from CustomAttributeColumnMapping where SourceId = 68

select * from AttributeGroupType   ------> 211

--Update AttributeGroupType set TabId = NULL where id = 211

select * from Asset_EntityTabConfiguration   ----> 289

--Insert into Asset_EntityTabConfiguration

--select 68, NULL, 'Information', 'Information', 'fa fa-info-circle', 1, 0, 6, getdate()

 --exec Asset_ProvideAssPermission 6,1,1

 select * from Asset_EntityTypeUserMapping where id = 1967

 select * from Asset_EntityTabAndEntityUserMapping  where entityTabId= 289  ----- 1967



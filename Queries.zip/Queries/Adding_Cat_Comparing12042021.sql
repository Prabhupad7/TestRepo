

select * from Service where serviceName like '%NTTA - DCS%' ---->   500

select * from ServiceCategoryMapping where serviceId = 500 and deleted = 0 

select * from Category where categoryId in (
select categoryId from ServiceCategoryMapping
where serviceId = 500 and deleted = 0 )

select * from ServiceCategoryMapping 
where serviceId = 500 and deleted = 0  and categoryId = 5854

select * from Category where categoryid = 5854

select * from SubCategory where categoryId = 5854 and deleted =0

select * from Category where Category like 'Security' and deleted = 0

select * from ServiceCategoryMapping where serviceId = 500 and categoryId in (

select categoryId from Category where Category like 'Security' and deleted = 0)

select * from Category 
where Category like 'Security' 
and deleted = 0 and serviceId = 500  
---->  5866  ticketTypeId: 1
---->  5867  ticketTypeId: 2

       --   Insert into Category(category,deleted,ticketTypeId,serviceId,Isdefaultcategory,isEUPVisible,icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)
	      --values('Security',0,2,500,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())

		 --insert into ServiceCategoryMapping (serviceId, categoryId, deleted, ticketTypeId)
		 --values 
		 --(500, 5866, 0, 1),
		 --(500, 5867, 0, 2)

		 select * from SubCategory where categoryId = 43 and deleted =0

		 --   Insert into SubCategory (subCategory,categoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)
			--values 
			--('Access Changes', 5867, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			--('Security Incident', 5867, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			--('Security Event', 5867, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			--('Firewall Change', 5867, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			--('Security Consultation', 5867, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			--('Information Security Systems', 5867, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE())

  
        select * from SubCategory where categoryId = 5867 and deleted =0



	--Insert into Classification (classification,subCategoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)
	--values 
	--('Access Changes', 22695, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
	--('Security Incident', 22696, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
	--('Security Event', 22697, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
	--('Firewall Change', 22698, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
	--('Security Consultation', 22699, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
	--('Information Security Systems', 22700, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE())

	 select * from Classification where subCategoryId in (
	 22695,22696,22697,22698,22699,22700)

	 select top 100  * from RulesForPriority order by 1 desc

	 --Insert into RulesForPriority (RuleDescr, PriorityRule, PriorityId, ImpactId, RulePriority, Deleted, RuleTemplateId, customerid)
	 --values 
	 --('Rule', '{customerid=210;serviceid=500;categoryid=5867;subcategoryid=22695;classificationid=90920;ticketTypeId=2;}', 15, 5, 1, 0, 1890, 210),
	 --('Rule', '{customerid=210;serviceid=500;categoryid=5867;subcategoryid=22696;classificationid=90921;ticketTypeId=2;}', 15, 5, 1, 0, 1890, 210),
	 --('Rule', '{customerid=210;serviceid=500;categoryid=5867;subcategoryid=22697;classificationid=90922;ticketTypeId=2;}', 15, 5, 1, 0, 1890, 210),
	 --('Rule', '{customerid=210;serviceid=500;categoryid=5867;subcategoryid=22698;classificationid=90923;ticketTypeId=2;}', 15, 5, 1, 0, 1890, 210),
	 --('Rule', '{customerid=210;serviceid=500;categoryid=5867;subcategoryid=22699;classificationid=90924;ticketTypeId=2;}', 15, 5, 1, 0, 1890, 210),
	 --('Rule', '{customerid=210;serviceid=500;categoryid=5867;subcategoryid=22700;classificationid=90925;ticketTypeId=2;}', 15, 5, 1, 0, 1890, 210)


   select * from ServiceLevelTracking where sourceId = 2733429

   --update ServiceLevelTracking set statusId = 3 where sourceId = 2733429

select serviceid, workgroupid, Priorityid,customerId from ticket where ticketNo=2000326

select * from ServiceLevelAgreement where customerId=147

select * from Priority where ticketTypeId=1 and deleted=0

select top 100 * from ServiceLevelObjective where serviceLevelObjectiveId=641976

select top 100 * from ServiceLevelObjective where  serviceId=322 and serviceLevelObjectiveTypeId=1 and isDelete=0 and priorityId=5

--select * from ServiceLevelTracking where sourceId=2000326
--update ServiceLevelTracking set expectedEndTime='2019-05-07 05:52:47.000' where serviceLevelTrackingId=4243044

--insert into ServiceLevelObjective(serviceLevelAgreementId,	serviceLevelObjectiveTypeId,	initialStatusId,	finalStatusId,	responseTimeInMin,	serviceId,	priorityId	,impactId	,holidayCalendarId	,workHourId	,is24X7Service	,locationId,isDelete,	isDefault) values 
--(73,1,1,3,60,322,9,1,59,14,0,0,0,0),(73,1,1,3,60,322,9,5,59,14,0,0,0,0),(73,1,1,3,60,322,9,6,59,14,0,0,0,0),(73,1,1,3,60,322,9,7,59,14,0,0,0,0),
--(73,1,1,3,60,322,27,1,59,14,0,0,0,0),(73,1,1,3,60,322,27,5,59,14,0,0,0,0),(73,1,1,3,60,322,27,6,59,14,0,0,0,0),(73,1,1,3,60,322,27,7,59,14,0,0,0,0)
--(73,1,1,3,60,322,5,1,59,14,0,0,0,0),(73,1,1,3,60,322,5,5,59,14,0,0,0,0),(73,1,1,3,60,322,5,6,59,14,0,0,0,0),(73,1,1,3,60,322,5,7,59,14,0,0,0,0)
--(73,1,1,3,60,322,5,1,59,14,0,0,0,0),(73,1,1,3,60,322,5,5,59,14,0,0,0,0),(73,1,1,3,60,322,5,6,59,14,0,0,0,0),(73,1,1,3,60,322,5,7,59,14,0,0,0,0)

 
    
	select * from Workgroup where workgroup like '%Application Management%'   -- 131 and others are (3, 130, 131)

	select * from Service S where ServiceName like '%Application Management%'

	select * from workGroupEscalationMatrix where  workGroupId = 131 -- where ServiceId = 2 and Level3Name like '%suni%'
   
     Select * from workGroupEscalationMatrix where Level3 like '%kli.portalsupport@kotak.com%' -- workGroupId = 131 and deleted = 0

	 

	-- workGroupEscalationMatrix

�--workGroupEscalationMatrix_AskML 

--update workGroupEscalationMatrix set Level1Name = 'MLIT Service desk', 
--Level1Email = 'MLITServicedesk@microland.com',Level1Extension = '1000/918061751003' ,
--Level2Name = 'Ananth Kumar',Level2Email = 'AnanthKBK@microland.com',Level2Extension = '5716/919845392898',Level3Name = 'Srinivasulu Reddy E',Level3Extension = '5610/919945335479', Level3Email = 'SrinivasuluRE@microland.com' where Id = 980

--Select * from workGroupEscalationMatrix_AskML where workGroupId = 200

--update workGroupEscalationMatrix_AskML set Level1Name = 'MLIT Service desk',
--Level1Email = 'MLITServicedesk@microland.com',Level1Extension = '1000/918061751003',
--Level2Name = 'Ananth Kumar',Level2Email = 'AnanthKBK@microland.com',Level2Extension = '5716/919845392898',
--Level3Name = 'Srinivasulu Reddy E', Level3Extension = '5610/919945335479', Level3Email = 'SrinivasuluRE@microland.com' where Id = 9



Select * from workGroupEscalationMatrix where CustomerId = 1
select * from Customer where CustomerId = 1
select distinct (serviceId)from ServiceCustomerMapping where CustomerId = 1

select * from CustomerAssignmentGroupMapping where customerId = 1

--select * from AssignmentGroup where assignmentgroupId in(140,141,142,143,144,145,146,147,152,153)
--select * from Workgroup where workgroupId in(70,71,72,73,74,75,76,77,82,83)

--insert into workGroupEscalationMatri(CustomerId,ServiceId,TicketTypeId,WorkgroupName,Level1Name,Level2Name,workGroupId,createdBy,createdOn,updatedBy,updatedOn,deleted)
--values(54,NULL,1,'Gift Cards','Raghvendra Shukla','Vishwas Choube',70,6,GETDATE(),6,GETDATE(),0),
--(54,NULL,1,'Vouchers and Bills','Raghvendra Shukla','Vishwas Choube',71,6,GETDATE(),6,GETDATE(),0),
--(54,NULL,1,'Reward','Raghvendra Shukla','Vishwas Choube',72,6,GETDATE(),6,GETDATE(),0),
--(54,NULL,1,'Qualification','Raghvendra Shukla','Vishwas Choube',73,6,GETDATE(),6,GETDATE(),0),
--(54,NULL,1,'Data Query','Raghvendra Shukla','Vishwas Choube',74,6,GETDATE(),6,GETDATE(),0),
--(54,NULL,1,'LP,BO,TB','Raghvendra Shukla','Vishwas Choube',75,6,GETDATE(),6,GETDATE(),0),
--(54,NULL,1,'Data Query TIED','Raghvendra Shukla','Vishwas Choube',76,6,GETDATE(),6,GETDATE(),0),
--(54,NULL,1,'Data Query APC','Raghvendra Shukla','Vishwas Choube',77,6,GETDATE(),6,GETDATE(),0),
--(54,NULL,1,'Pragati','Raghvendra Shukla','Vishwas Choube',82,6,GETDATE(),6,GETDATE(),0),
--(54,NULL,1,'Power club','Raghvendra Shukla','Vishwas Choube',83,6,GETDATE(),6,GETDATE(),0)




--WITH cte AS ( select n.ruleId,n.templateId,serviceId, ROW_NUMBER() OVER (PARTITION BY serviceid,templateid order by serviceid,templateid ) rn from NotificationRules n where n.customerId=204 and n.deleted=0) select ruleId from cte where rn>1

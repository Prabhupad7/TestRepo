



--workflowmaster,workflowstatus,workflow

select top 50 * from workflowmaster

select  * from workflowstatus  ----> 36	Cancelled , 34	WaitingForThirdParty

select  * from workflow

    select  * from workflow where workflowMasterId = 6 and deleted = 0

--activityid possible activities that could be done on current status

--nextstatusid next status to which ticket could be moved from current status

Select top 50 * from Log order by 1 desc

select top 50 * from workflowmaster 

---> 6	Default - Incident
---> 14	Jubliant Life Sciences - Incident

--14	Jubliant Life Sciences - Incident
--15	Jubliant Life Sciences - Request

select  * from workflow where workflowMasterId = 7
and deleted  = 0 and nextStatusId= 36

select  * from workflow where workflowMasterId = 7
and deleted  = 0 and nextStatusId= 36

select  * from workflow where workflowMasterId = 7
and deleted  = 0 and currentStatusId= 36

select  * from workflow where workflowMasterId = 14
and deleted  = 0 and nextStatusId= 36

select  * from workflow where workflowMasterId = 15
and deleted  = 0 and nextStatusId= 36

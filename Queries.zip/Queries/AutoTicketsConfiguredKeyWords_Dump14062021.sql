

select * from Customer where customerName like '%Bosch%' --- 61	BOSCH

select * from Apikey where customerid = 61 

select top 50 * from AutoTicketEventLog where apikeyid= 27
order by 1 desc

--------------> Query to get keywords for AutoTickets configured:


select distinct (d.criteriaValue) as Keyword,serviceName,c.category,sub.subCategory,cl.classification,i.impact,p.priority
from AutoTicketServiceRule a join service s on a.serviceId = s.serviceId
join Category c on a.categoryId = c.categoryId
join SubCategory sub on a.subCategoryId = sub.subCategoryId
join Classification cl on a.ClassificationId = cl.classificationId
join Impact i on a.ImpactId = i.impactId
join Priority p on a.PriorityId = p.priorityId
join AutoTicketServiceRuleDetails d on  a.Id = d.autoTicketServiceRuleId
where a.apiKeyId in (27) and a.isDeleted = 0





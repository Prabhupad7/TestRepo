

  select * from Requestor where alias like '%helpdesk%'  --->  13872	Shital Naik

  select * from Requestor where deleted =0 


  select * from CustomerRequestorMapping where requestorId in (
    select requestorId from Requestor where deleted =0 
  ) and isLoginAllowed =1

  select * from CustomerRequestorMapping where requestorId = 13872

  --   Update CustomerRequestorMapping set isLoginAllowed = 0 where requestorId = 13872

  select * from EUP_Instancepasswordchangehistory

  select * from Instancepasswordchangehistory

  select * from EUP_Instance

  select * from AuthenticationType
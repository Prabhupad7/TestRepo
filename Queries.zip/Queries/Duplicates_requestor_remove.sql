


select * from Workgroup where  workgroupId = 628  ---->  628	General L&D

select * from AssignmentGroup where workgroupId = 628         ---->  759	General L&D - Queue

--Update AssignmentGroup set assignmentgroupName ='Learning & Development - Queue' where assignmentgroupId = 759 

select * from CustomerAssignmentGroupMapping where assignmentgroupId = 759   ------->  2701	Ask Microland - L&D - Queue

--->  Update CustomerAssignmentGroupMapping set custAssignmentGroupName = 'Ask Microland - L&D - Queue' where assignmentgroupId = 759 

--Update Workgroup set Workgroup = 'Learning & Development', displayName='Learning & Development' where workgroupId = 628 

---->  

select * from Users where email like '%charlotte.crawley@fujitsu.com%'   ---->  26695

select * from Users where email like '%bartlomiej.nocon@fujitsu.com%'   ---->  26857

select * from Users where email like '%milena.biernat@fujitsu.com%'   ---->  26858

select * from UserInstanceMapping where userid = 26695
select * from UserInstanceMapping where userid = 26857
select * from UserInstanceMapping where userid = 26858

--Insert into UserInstanceMapping (UserId, InstanceId)
--Values 
--(26857, 1),
--(26858, 1)

select * from UserCustomerAssignGroupMapping 
where userId = 26695 ---->  and custAssignmentGroupId = 1218 

select * from UserCustomerAssignGroupMapping where userid = 26695
select * from UserCustomerAssignGroupMapping where userid = 26857
select * from UserCustomerAssignGroupMapping where userid = 26858

--insert into UserCustomerAssignGroupMapping (Userid, custAssignmentGroupId, deleted,	isAssignEnabled,	AssignToWorkgroup)

--select 26858, custAssignmentGroupId, deleted,	isAssignEnabled,	AssignToWorkgroup from UserCustomerAssignGroupMapping 
--where userId = 26695


select * from Users where userid = 26695   ---->   


select * from Users where userid = 26695  

select * from UserType




--Insert into Users(firstName,	lastName,	userName,	displayName	,mobileNo,	email,	loginName	,password,
--custAssignmentGroupId,	deleted,	IsWorkgroup,	isPasswordPolicyApplicable,	lastUpdatedOn,	isAutoAssignmentEnable,	roleId	,createdById,
--updatedById,	createdOn,	updatedOn,	IsEnabled,	timezoneinfoId,	AboutMe,	instanceId,	ProfilePicture,	PasswordPolicyId,	SaltValue,
--primaryAssignmentGroupId,	deletedOn,	levelid	,UserTypeId)


----select 'Bartlomiej',	'Nocon','Bartlomiej Nocon',	'Bartlomiej Nocon'	,'123',	'bartlomiej.nocon@fujitsu.com',	'bartlomiej.nocon'	,password,
----0,	deleted,	0,	isPasswordPolicyApplicable,	GETDATE(),	isAutoAssignmentEnable,	roleId	,createdById,
----updatedById,	GETDATE(),	GETDATE(),	IsEnabled,	timezoneinfoId,	AboutMe,	instanceId,	ProfilePicture,	PasswordPolicyId,	null,
----primaryAssignmentGroupId,	deletedOn,	1	,4 from users where userId = 26695


--select 'milena',	'biernat','milena biernat',	'milena biernat'	,'123',	'milena.biernat@fujitsu.com',	'milena.biernat'	,password,
--0,	deleted,	0,	isPasswordPolicyApplicable,	GETDATE(),	isAutoAssignmentEnable,	roleId	,createdById,
--updatedById,	GETDATE(),	GETDATE(),	IsEnabled,	timezoneinfoId,	AboutMe,	instanceId,	ProfilePicture,	PasswordPolicyId,	null,
--primaryAssignmentGroupId,	deletedOn,	1	,4 from users where userId = 26695



select * from Requestor where 


SELECT 
    RequestorEmail, 
    Alias, 
    COUNT(*) occurrences
FROM Requestor where deleted = 0
GROUP BY
    RequestorEmail, Alias
HAVING    COUNT(*) > 1;

select * from Requestor 

select * from Requestor where deleted =0 and Alias =NULL

select * from Requestor where  Alias = NULL

select * from Requestor where deleted =0 and alias like  '%rmcshiftmanager%'


--Update Requestor set deleted = 1 where Requestorid in (
--9520
--,9583
--,9656
--,9853
--,15677
--,15982
--,16240
--,16244
--,16253
--,16321
--,16337
--,16441
--,16596
--,16621
--,16669
--,16682
--,16751
--,16767
--,16812
--,17518
--,17520
--,17536
--,17557
--,17591
--,17593
--,18059
--,18087
--,18579
--,18788
--,18885
--,19594
--,19688
--,19697
--,40894
--,48504
--,48519
--,48906
--,54216
--,54218
--,56938
--,57047
--,58448
--)

select * from Requestor where deleted =0 and alias IS NULL

select * from Requestor where deleted =0 and requestorEmail IS NULL

--Update Requestor set deleted =1 where RequestorId in (
-- 29112
--,20628
--,59238
--,22043
--,21642
--,40434
--,59239
--,40424
--,40448
--,59086
--,21404
--,20644
--,20800
--,20946
--,25057
--,20619
--,20632
--,20673
--,20691
--,20697
--,20806
--,36373
--,45364
--,24789
--,22343
--,27955
--,22382
--,44815
--,37130
--,3038
--,21141
--,22656
--,27510
--,20864
--,19935
--,20533
--,20703
--,20853
--,20985
--,22965
--,57733
--,57732
--,28142
--,59241
--,22348
--,28139
--,28166
--,23050
--,22622
--,20344
--,20515
--,20517
--,20519
--,20520
--,20523
--,20524
--,20849
--,20850
--,20857
--,20858
--,20861
--,20869
--,20870
--,20872
--,20873
--,20896
--,20897
--,20903
--,20906
--,20908
--,20916
--,20918
--,20919
--,20921
--,20922
--,20925
--,20926
--,20927
--,20928
--,20934
--,20938
--,20955
--,20956
--,20991
--,20992
--,21013
--,21014
--,21027
--,21028
--,21046
--,21047
--,23685
--,57731
--,35431
--,22231
--,25166
--,59244
--,26878
--,59245
--,20981
--,24627
--,22685
--,57734
--,20097
--,20509
--,20512
--,20563
--,20564
--,20565
--,20566
--,20574
--,20575
--,20576
--,20579
--,20584
--,20586
--,20588
--,20589
--,20592
--,20593
--,20596
--,20597
--,20615
--,20616
--,20618
--,20621
--,20626
--,20627
--,20633
--,20636
--,20637
--,20645
--,20651
--,20653
--,20654
--,20658
--,20659
--,20661
--,20663
--,20664
--,20665
--,20666
--,20669
--,20671
--,20674
--,20679
--,20682
--,20683
--,20685
--,20738
--,20739
--,20740
--,20741
--,20745
--,20748
--,20750
--,20754
--,20762
--,20771
--,20773
--,20790
--,20804
--,20813
--,20818
--,20824
--,20828
--,20883
--,20884
--,20886
--,20887
--,20891
--,20893
--,20894
--,20900
--,20902
--,20913
--,20914
--,20929
--,20930
--,20931
--,20944
--,20948
--,20959
--,20972
--,20973
--,21009
--,21010
--,21016
--,21023
--,21037
--,21038
--,21042
--,21050
--,21051
--,56325
--,20759
--,38147
--,28137
--,20871
--,21353
--,35638
--,20638
--,20678
--,20839
--,34408
--,20954
--,20960
--,34368
--,34352
--,40703
--,20726
--,34342
--,34214
--,34346
--,57735
--,34509
--,25025
--,34323
--,34403
--,57730
--,34345
--,34246
--,34377
--,34316
--,20528
--,20634
--,20940
--,20941
--,20949
--,20607
--,21004
--,21005
--,21006
--,21007
--,21008
--,21011
--,21012
--,21015
--,21020
--,21025
--,21029
--,21033
--,20526
--,20534
--,20693
--,20700
--,20701
--,20805
--,20809
--,20812
--,20821
--,20829
--,20846
--,20848
--,20980
--,21059
--,18484
--,19938
--,20536
--,20710
--,20859
--,34255
--,20971
--,20975
--,34545
--,20945
--,34468
--,34275
--,25278
--,59251
--,59253
--,59252
--,23247
--,34314
--,27701
--,27699
--,24012
--,40438
--,56332
--,20609
--,28660
--,59254
--,20827
--,20841
--,20843
--,20932
--,20942
--,22562
--,59255
--,34260
--,56329
--,34406
--,27836
--,59077
--,9882
--,20546
--,20602
--,20604
--,20605
--,20606
--,20765
--,20767
--,20768
--,20769
--,20770
--,20777
--,20779
--,20792
--,20794
--,20795
--,20796
--,20797
--,20799
--,20801
--,20802
--,20803
--,20905
--,20907
--,20909
--,20910
--,20912
--,21017
--,21018
--,21019
--,21022
--,21024
--,21030
--,40435
--,20610
--,20611
--,20814
--,20594
--,28141
--,34313
--,20239
--,20635
--,19993
--,20022
--,20532
--,20547
--,20570
--,20598
--,20763
--,20764
--,20778
--,20780
--,20781
--,20782
--,20783
--,20819
--,20901
--,20911
--,20950
--,21026
--,21031
--,21032
--,55289
--,55290
--,57737
--,20622
--,20625
--,20630
--,20646
--,20649
--,20655
--,20831
--,27381
--,59258
--,34404
--,20761
--,20766
--,20775
--,20789
--,20807
--,35587
--,44312
--,55985
--,34521
--,34379
--,20101
--,20510
--,20516
--,20518
--,20522
--,20527
--,20529
--,20530
--,20535
--,20537
--,20538
--,20540
--,20541
--,20542
--,20543
--,20545
--,20548
--,20549
--,20550
--,20551
--,20553
--,20554
--,20555
--,20556
--,20557
--,20558
--,20559
--,20560
--,20562
--,20567
--,20568
--,20569
--,20572
--,20582
--,20583
--,20587
--,20590
--,20591
--,20608
--,20614
--,20624
--,20629
--,20631
--,20641
--,20643
--,20652
--,20656
--,20657
--,20660
--,20662
--,20672
--,20675
--,20680
--,20681
--,20687
--,20688
--,20689
--,20692
--,20694
--,20695
--,20696
--,20698
--,20699
--,20702
--,20704
--,20705
--,20706
--,20707
--,20708
--,20709
--,20711
--,20712
--,20713
--,20714
--,20715
--,20716
--,20717
--,20718
--,20719
--,20720
--,20721
--,20722
--,20724
--,20725
--,20729
--,20730
--,20731
--,20732
--,20733
--,20734
--,20735
--,20736
--,20737
--,20742
--,20744
--,20747
--,20749
--,20751
--,20755
--,20760
--,20772
--,20774
--,20776
--,20784
--,20785
--,20786
--,20788
--,20791
--,20793
--,20798
--,20810
--,20822
--,20823
--,20825
--,20826
--,20830
--,20832
--,20833
--,20834
--,20835
--,20836
--,20837
--,20838
--,20840
--,20842
--,20845
--,20847
--,20851
--,20852
--,20854
--,20855
--,20856
--,20860
--,20862
--,20863
--,20865
--,20866
--,20867
--,20868
--,20874
--,20875
--,20876
--,20877
--,20878
--,20879
--,20880
--,20881
--,20882
--,20885
--,20888
--,20889
--,20890
--,20895
--,20899
--,20904
--,20923
--,20924
--,20935
--,20937
--,20939
--,20943
--,20952
--,20953
--,20957
--,20976
--,20977
--,20978
--,20979
--,20982
--,20983
--,20984
--,20986
--,20988
--,20989
--,20990
--,20993
--,20994
--,20995
--,20996
--,20997
--,20998
--,20999
--,21000
--,21001
--,21002
--,21003
--,21021
--,21034
--,21035
--,21036
--,21039
--,21043
--,21044
--,21048
--,21049
--,21052
--,21053
--,21054
--,21055
--,21056
--,21057
--,21058
--,21060
--,21061
--,21062
--,21063
--,21064
--,21065
--,21066
--,21067
--,21068
--,21069
--,21070
--,21071
--,21072
--,21073
--,37665
--,58155
--,57736
--,34218
--,20539
--,20642
--,20756
--,27567
--,59261
--,59090
--,40436
--,34513
--,29165
--,22654
--)
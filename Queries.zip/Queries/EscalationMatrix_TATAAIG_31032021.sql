

 select * into Backup_NotificationEmailTemplate31032021 from NotificationEmailTemplate where customerId = 1


 
select * from NotificationEmailTemplate where customerId = 1

---->  templateid = 3
--->  Sanjay.Microland@tataaig.com
--UPDATE [CMS_DB_test].[dbo].[cms_HtmlText] 
--SET Content = CAST(REPLACE(CAST(Content as NVarchar(MAX)),'ABC','DEF') AS NText)


 --Update NotificationEmailTemplate set template = CAST(REPLACE(CAST(template as NVarchar(MAX)), '<td style="text-align: center;">N/A</td>',
 -- '<td style="text-align: center;">Sanjay.Microland@tataaig.com</td>')  AS NText)
 --where templateid = 3

 select * into Backup_NotificationEmailTemplate31032021 from NotificationEmailTemplate where customerId = 1

 -- Update NotificationEmailTemplate set template = CAST(REPLACE(CAST(template as NVarchar(MAX)), '<td style="text-align: center;">N/A</td>',
 -- '<td style="text-align: center;">Sanjay.Microland@tataaig.com</td>')  AS NText)
 --where templateid in (
 --1,
 --2,
 --3,
 --4,
 --6,
 --7,
 --8,
 --9,
 --10,
 --16,
 --17,
 --18,
 --19,
 --77,
 --79,
 --80,
 --81,
 --87,
 --88,
 --89,
 --94
 --)

 ---->  Test ticket: SR736063


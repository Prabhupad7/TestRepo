

  select * from NotificationRegistry where sourceId= 2744486 

  Select * from NotificationRules where ruleId in (
  select ruleId from NotificationRegistry where sourceId= 2744486 )
  and notificationMode = 'AWSSMS' and duePercent = 50

    select * from NotificationRules where notificationTo like '%%'


--    update NotificationRules set entryStateId = null where ruleId in (
	
--	2254713
--,2254785
--,2254857
--,2254929)

		--  Update NotificationRules set notificationTo = '918904641816,919620191402,919000309621' where ruleid in (
		--  2254713
		--,2254785
		--,2254857
		--,2254929
		--  )

		--->  For Email we need to user ';' for separation and for mobile number we need to user ','

		select * from NotificationRules where customerId = 8 and serviceId = 1 and ticketTypeId =2
		and notificationMode like '%AWSSMS%'

		select * from TicketStatus

		select * from Requestor where requestorEmail like '%venkataramana%' -->  54539


		Select * from AssetEntityType 

		select ruleId from NotificationRegistry where sourceId=2760066 and notificationMode not like '%Email%'

		select * from NotificationRegistry where sourceId=2760066 and notificationMode not like '%Email%'

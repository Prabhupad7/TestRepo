

         select * from NotificationEmailTemplate  where customerId = 147 and templateName like '%SMS%'

		 select distinct workgroupid from NotificationRules where customerId = 147 and deleted = 0 and notificationMode like '%AWSSMS%' and notificationTo like '%$REQUESTORPHONENO%'

		and workgroupid in (
 203
,214
,224
,225
,227
,229
,232
,233
,235
,238
,241
,249
,495
,496
,512
,513
,515
,525
,595
,596
,628
,629
,630
,631
,632
,687)


    select * from Workgroup where workgroupId in (203
,214
,224
,225
,227
,229
,232
,233
,235
,238
,241)


		 ----  SR2659134

		 ---- SR2659174


		 -- For Escalation Matrix Reference: customerid --147
		-- 455	RESPONSE SLA 50



--       select * from NotificationEmailTemplate where templateId in ( 484, 488, 489, 1459, 460, 1958) ---- 459 feed back 


        --  select top 10 * from Requestor where requestorEmail like '%rajesh.bangera%'


		 select * from NotificationEmailTemplate where template like '%HIGHLY DISSATI%' AND 


		 select * from NotificationRules 

		 SELECT (SELECT COUNT(*) FROM t1) - (SELECT COUNT(*) FROM t2)




		 select * from NotificationRegistry where sourceId = 2600993 , 2608151


  -- New 1459:

--update NotificationEmailTemplate set template = '' where templateId = 492


select top 1000 * from NotificationRules where templateId = 492 and deleted =0


     select * from Users where  firstName like '%Jacob%'   ---- 25965   917259208324

	 select * from NotificationRules where deleted = 0 and notificationCC like '%917259208324%' and customerId in (
	 
	 168, 61, 189, 203, 169, 158, 167, 8, 188, 192, 194, 3, 4, 58, 207
	 )


	  select * from NotificationRules where deleted = 0 and notificationMode = 'AWSSMS' and notificationTo like '%917259208324%' and customerId in (
	 
	 168, 61, 189, 203, 169, 158, 167, 8, 188, 192, 194, 3, 4, 58, 207
	 )


	-- update NotificationRules set notificationTo = REPLACE(notificationTo, ',917259208324', '')


	select * from ticket where ticketNo = 2659368

	select * from TicketStatus


	select * from ReportMaster  where reportMasterId = 149             ----------  usp_StandardReport_TimeSpentonTicket_TimeStampBreakup

	select * from ReportMaster where reportMasterID = 499



	select * from ReportMaster where reportMasterID = 25

	--Insert ReportMaster (name, query, isCustomReport, isInline, deleted, createdBy, createdOn, description, ticketTypeId, ThreadId, SourceTypeId)
	
	values ()




-->   RE: SC - Location name to be Change
RE: Escalation contact details to be changed in AskML APP // SR2701303 //
FW: IMPORTANT|| Mid Year Check-In Cascade Session for Managers
RE: 103+110 HP and Dell Bulk Upload
RE: SR3 Notification - Ticket Number: SR2673314 has been assigned to you.


select * from Assets 


Hi Venkataramanaiah/Aravind,

Could you please respond on this, we are unable to access smart center and its been a day since we reported it.

As I pointed out yesterday, this coincides with the attached change that you did on admin account.

Please have it fixed ASAP.

Regards,
Naveen



RE: IMP_log a ticket 

RE: Request to integrate approvers

  select * from ReportMaster where reportMasterID = 153
  
  select * from ReportParameter where reportMasterId = 153

  select * from ReportRoleMapping

  --->   33	- Time Spent On Ticket	usp_report_GetTotalTimeSpentInTicket_KLI

     --> 153	TotalTimeSpentExcludingOnHold	usp_StandardReport_TotalTimeSpentExcludingOnHold	0	0	0	6	2020-08-14 15:16:34.950	TotalTimeSpentExcludingOnHold	
    -->  153	TotalTimeSpentExcludingOnHold	usp_StandardReport_TotalTimeSpentExcludingOnHold	0	0	0	6	2020-08-14 15:16:34.950	TotalTimeSpentExcludingOnHold	1	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	1	2
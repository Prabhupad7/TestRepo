

select customerId,serviceId,workgroupId,TicketTypeid,* from Ticket where ticketno ='1560769'   ---->  

--exec deletetickets @ticketNo = '1560772'

IM1560769
IM1560788
IM1560775

select * from NotificationRegistry where sourceId = '1560769'  --->  IM1560769 

select * from NotificationHistory where TicketNo = '1560769' 
select * from NotificationHistory where TicketNo = '1560788' 
select * from NotificationHistory where TicketNo = '1560775'


select * from NotificationRegistry where sourceId in (
'1560769',
'1560788',
'1560775'
)


select * from NotificationRules where ruleId in (
select ruleId from NotificationRegistry where sourceId in (
'1560769',
'1560788',
'1560775'
))

select * from NotificationRules where ruleId in (
select ruleId from NotificationRegistry where sourceId in (
'1560788'
))

  select E.stateEntryId, e.ticketNo, e.statusId, t.status, e.entryTime, e.exitTime, e.activePhase from ServiceLevelStateEntry E
  inner join TicketStatus T on T.statusId = E.statusId
  where ticketNo = 1560769

  select E.stateEntryId, e.ticketNo, e.statusId, t.status, e.entryTime, e.exitTime, e.activePhase from ServiceLevelStateEntry E
  inner join TicketStatus T on T.statusId = E.statusId
  where ticketNo = 1560788

  select E.stateEntryId, e.ticketNo, e.statusId, t.status, e.entryTime, e.exitTime, e.activePhase from ServiceLevelStateEntry E
  inner join TicketStatus T on T.statusId = E.statusId
  where ticketNo = 1560775

---->  473	On Hold Customer

---->  5

select * from TicketStatus where ticketTypeId =1 and deleted =0 

---->  5	On Hold (Customer)
----->   6	On Hold (3rd Party)	0	1


select * from NotificationRules where ruleId in (
select ruleId from NotificationRegistry where sourceId in (
'1560769',
'1560788',
'1560775'
))

---> ServiceId : 1, 14

---->  OHT template Id: 475	NULL

select * from NotificationRules
where customerId = 1 and serviceId in (1, 14) and ticketTypeId =1 and deleted = 0 and entryStateId = 6


--insert into NotificationRules (customerId,ticketTypeId,notificationMode,notificationTo,	notificationCC,	templateId,	ruleName,workgroupid,serviceId,
--notifyBasedOnId,	entryStateId,	deleted)
--values 
--(1, 1, 'mlmail', '$REQUESTOREMAIL', '$ASSIGNEDENGINEEREMAIL', 475, 'On Hold Vendor', 2, 1, 1, 6, 0),
--(1, 1, 'mlmail', '$REQUESTOREMAIL', '$ASSIGNEDENGINEEREMAIL', 475, 'On Hold Vendor', 12, 1, 1, 6, 0),
--(1, 1, 'mlmail', '$REQUESTOREMAIL', '$ASSIGNEDENGINEEREMAIL', 475, 'On Hold Vendor', 19, 1, 1, 6, 0),
--(1, 1, 'mlmail', '$REQUESTOREMAIL', '$ASSIGNEDENGINEEREMAIL', 475, 'On Hold Vendor', 19, 14, 1, 6, 0)

select * from NotificationEmailTemplate where templateId in (
473,475
,477
,478
,483
,643
,649
,650
,652
,653
,654
,655
,656
,659
)

 select * from NotificationHistory 
 where TicketNo = 1561215 and NotificationId = 22298299
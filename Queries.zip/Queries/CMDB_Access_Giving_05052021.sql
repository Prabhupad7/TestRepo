

    select * from users where email like '%srinivasulum@microland.com%'  ---->  26987  75

 	select * from Workgroup where workgroup like '%Neemrana%' --	from Neemrana GPC location 

	select * from AssetEntityType where Name like '%CMDB%'  ---->  143, 241, 427

	select * from AssetEntityType where Name like '%CMDB%'  ---->   241

	select * from AssetEntityType where Name like '%Event%'  ---->   241

	select *  from MenuMaster where menuName like '%Event%'  ---> 242	/EventManagement/Index

	select * from MenuRoleMapping where RoleId= 75 and MenuId = 242

	--Insert into MenuRoleMapping

	--select 75, 242, 0

	 --Asset_EntityTypeUserMapping

	 --AssetEntityTypeCustomerMapping

	 --Asset_EntityTabAndEntityUserMapping

	 select top 100 * from  Asset_EntityTypeUserMapping  ---> 

	 select top 1000 * from  AssetEntityTypeCustomerMapping  ---> 

	 select top 1000 * from  Asset_EntityTabAndEntityUserMapping  where entityUserMappingId in (14202
,14201
,14200
,14199
,14198
,8811)



	 select * from Users

	 ----> CMDB ACCESS:

	 --Insert into Asset_EntityTypeUserMapping (userId, entityTypeId, createdOn, createdBy, isDeleted)
	 --values 
	 --(26987, 241, GETDATE(), 6, 0)

	 --update Asset_EntityTypeUserMapping set isDeleted = 0 where id in ( 17760)
    
	---> 17760	26676	241	2021-05-05 12:34:15.213	6	0	NULL


	 select * from Users where userId in (26832, 25644, 26093) ---> 25644	Ashokkumar  9916944948



	 select * from Approval where approvalNo = '2735905' 

	 --delete from Approval where approvalNo = '2735905' 

	 select * from Customer where customerName like '%SMC%'  ---> 179	SMC New Unilever	SMC New Unilever


	 --select * from Users where email in (
	 --'PavanR@microland.com',
	 --'VigneshS12@microland.com'
	 --)

	 select * from Requestor where Requestoremail like '%PavanR@microland.com%' ----> 48750

	 select * from Requestor where Requestoremail like '%VigneshS12@microland.com%' ----> 89720



	 --Update Requestor set isAccountLocked =0 , failedLoginAttemptCount =0 
	 --where requestorId in (48750, 89720)

	 select * from CustomerRequestorMapping where requestorId = 48750

	 select * from CustomerRequestorMapping where requestorId = 89720



select * from Asset_users where EmailId like '%SriramN@microland.com%' ---->  id= 99826,  managerId= 98929

select * from Asset_users where EmailId like '%BharathKu@microland.com%' ---->  id= 22949,  managerId= 98929

--->  VijethaKR@microland.com

select * from Asset_users where EmailId like '%VijethaKR@microland.com%' ---->  id= 98929,  managerId= 63152

select * from Customer where customerName like '%Unile%'  -----> 179	SMC New Unilever

select * from Instance  

select * from EUP_Instance  


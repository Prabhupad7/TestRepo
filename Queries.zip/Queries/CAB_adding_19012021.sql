

--[3:50 PM] Aravindsagar Venkatesh


    select top 100 * from ChangeAdvisoryBoard

	Chandramohan R / Arun Kumar AK sir name / Suraj R V R name for different customer


	---->  ChandramohanR@microland.com    ArunKA@microland.com  SurajR@microland.com

	select * from Customer where customerid in (167, 3, 4, 169, 168, 192, 215, 213, 188, 158, 
    214, 58, 59, 196, 194, 8, 207, 61, 189, 203, 217)

	select * from Customer where customerid in (59,196,213,214,215,217)

	--Insert into ChangeAdvisoryBoard (memberName, displayName, emailId, customerId, customerName, isdeleted, deleted)
	--values 
	--('Suraj Rvr','Suraj Rvr', 'SurajR@microland.com',218 , 'Bunge', 0, 0),
	----('Arun  KA','Arun  KA', 'ArunKA@microland.com',218 , 'Bunge', 0, 0),
	--('Chandramohan R','Chandramohan R', 'ChandramohanR@microland.com',218 , 'Bunge', 0, 0)

	select * from  ChangeAdvisoryBoard where customerid = 218 and deleted =0


	--('Suraj Rvr','Suraj Rvr', 'SurajR@microland.com',214, 'Mott MacDonald', 0, 0),
	--('Suraj Rvr','Suraj Rvr', 'SurajR@microland.com',215 , 'GCC ABInBev', 0, 0)


	--('Arun Kumar A K','Arun Kumar A K', 'arunka@microland.com',217 , 'MenaBev', 0, 0)


	select * from ChangeAdvisoryBoard where emailId in ('SurajR@microland.com') 
	and customerId in (167, 3, 4, 169, 168, 192, 215, 213, 188, 158, 
    214, 58, 59, 196, 194, 8, 207, 61, 189, 203, 217)
	order by 7


	--update ChangeAdvisoryBoard set isdeleted =0, deleted =0 where memberId in (835)

--	select * from CustomerAssignmentGroupMapping 
--	where customerId = 3 and deleted = 0

----custAssignmentGroupName	customerId	customerName	assignmentgroupId
----MLCIS - RMC VoIP	3	MLCIS	9

--select top 10000 * from RulesForAssignment where customerId = 3 
--order by 1 desc

--select top 100 * from RulesForAssignment where customerId = 3 
--and  AssignmentRule like '%categoryId=124;%'

select * from AssignmentGroup where assignmentgroupId = 9  -----> workgroupId = 9

----Insert into RulesForAssignment

----select 'Rules', '{customerId=3;priorityId=1;deviceId=31307;}', 9,9,1,0, 80,3,1,0,3


select * from ChangeAdvisoryBoard where customerId = 192

--Update ChangeAdvisoryBoard set customerName ='Jubilant Pharma'
--where memberId in (996, 997)

--insert into ChangeAdvisoryBoard 

--select 'Saswat Anurag','Saswat Anurag',NULL,'saswata@microland.com',NULL,192,'Jubilant Pharma',0,GETDATE(),6,GETDATE(),6,0
--UNION ALL
--select 'Naveen Chandra MC','Naveen Chandra MC',NULL,'NaveenCMC@microland.com',NULL,192,'Jubilant Pharma',0,GETDATE(),6,GETDATE(),6,0

 

 

--insert into ChangeAdvisoryBoard 
--select 'Saswat Anurag','Saswat Anurag',NULL,'saswata@microland.com',NULL,192,'Jubilant Life Sciences',0,GETDATE(),6,GETDATE(),6,0
--UNION ALL
--select 'Naveen Chandra MC','Naveen Chandra MC',NULL,'NaveenCMC@microland.com',NULL,192,'Jubilant Life Sciences',0,GETDATE(),6,GETDATE(),6,0
 






   �IM2625492�   IM2625492
	
	select * from Customer where customername like '%SMC RMC%' -- 154	SMC RMC

	select * from Customer where customername like '%SMC TAGIC%' -- 157	SMC TAGIC

	select * from Users where email like '%AsmitaK@microland.com%'  ---->  25720	asmita	kanungo	NULL	asmita kanungo		asmitak@microland.com


    select * from CustomerAssignmentGroupMapping where customerId in (154, 157) and deleted = 0

	select * from UserCustomerAssignGroupMapping where custAssignmentGroupId in (
	 select custAssignmentGroupId from CustomerAssignmentGroupMapping where customerId in (154, 157) and deleted = 0
	) and userId = 25720




		    -- Insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
			values
			(25720, 2780,0,1,1),
			(25720, 2781,0,1,1),
			(25720, 2782,0,1,1),
			(25720, 2783,0,1,1),
			(25720, 2784,0,1,1),
			(25720, 2785,0,1,1),
			(25720, 2786,0,1,1),
			(25720, 2787,0,1,1),
			(25720, 2788,0,1,1),
			(25720, 2789,0,1,1),
			(25720, 2790,0,1,1),
			(25720, 2802,0,1,1),
			(25720, 2803,0,1,1),
			(25720, 2804,0,1,1),
			(25720, 2805,0,1,1),
			(25720, 2806,0,1,1),
			(25720, 2807,0,1,1),
			(25720, 2808,0,1,1),
			(25720, 2809,0,1,1),
			(25720, 2810,0,1,1),
			(25720, 2811,0,1,1),
			(25720, 2812,0,1,1)
			






	select * from Customer where customerId= 147





	    select * from CustomerAssignmentGroupMapping where customerId = 199, 212


		select  * from users  where Email like '%KarthikSh1@microland.com%'  -- 25793  KarthikSh1@microland.com

		select * from Customer where customerName like '%MLCIS%'  -- 3

	    select * from users where Email like '%BooraPo@microland.com%'  -- 25744  

	select U.roleId, U.instanceId ,* from users U where userid In (1728, 25744)  -- 25275

	update users set instanceId = 1 where userid = 25434
	--need to update in userInstanceMapping  -->only when changes made for instance
	--need to update in Admin_UserCustomerAdminMapping -->only for admin access.

	--- changing Role Id and instanceId 


		select U.roleId, U.instanceId ,* from users U where userid In (665,25275, 25434)  -- 25275

		select * from Role where roleId in (39, 111)

          	    update users set instanceId = 1 where userid = 25434
          		  --update UserRoleMapping set roleId = 39 where userid=665 
          
           select * from role where roleId = 39
          
           select * from UserRoleMapping where userid = 665

		   select * from UserRoleMapping where userid In (25275, 25434)

		   INSERT INTO UserRoleMapping (userId, roleId) VALUES (25434, 111)
          
           select * from Customer where customerName like '%EY%'
          
           select * from device where customerid = EY

        --   F:\Services\KLI\AUTOTICKET\Log\LogBackup

		---- SR2670417

	-------------
		select  * from users  where Email like '%NavyaKS@microland.com%'  -- 1728  

	    select * from users where Email like '%BooraPo@microland.com%'  -- 25744  

		  select * from users where email like '%kli.dlp%'

--		  User Name - DLP Admin Hitachi IT KLI
--Login id - Lo5459
--Email id - kli.dlp-admin@kotak.com.

 

		select top 1 * from Workgroup where workgroup like '%Webs%'  -- 138

		
		select  * from users  where Email like '%GoutamK@microland.com%' and deleted = 0 --  23852  

		select  * from users  where Email like '%nikhildab@microland.com%' and deleted = 0 --  26328   

	    select custAssignmentGroupId, * from UserCustomerAssignGroupMapping where userid = 23852 and deleted = 0

	    select custAssignmentGroupId, * from UserCustomerAssignGroupMapping where userid = 26328 and deleted = 0

		--update UserCustomerAssignGroupMapping set isAssignEnabled =1 , AssignToWorkgroup =0 where userId = 26328 and custAssignmentGroupId  in (
		--2919
		--)







		select * from users where userName like '%DLP Admin Hitachi IT KLI%' and deleted = 0

		select  * from users  where loginId like '%Sarag%'  -- 25793  KarthikSh1@microland.com

		select * from Customer where customerName like '%MLCIS%'  -- 3

		select * from Customer where customerName like '%ML SOC%' --- 211

	    select custAssignmentGroupId, * from UserCustomerAssignGroupMapping where userid = 25971 and deleted = 0

		select custAssignmentGroupId, * from UserCustomerAssignGroupMapping where userid = 71556 and deleted = 0
	
	    select custAssignmentGroupId, * from UserCustomerAssignGroupMapping where userid = 25744 and deleted = 0

	    select custAssignmentGroupId, * from UserCustomerAssignGroupMapping where userid = 23852 and deleted = 0













		select * from users where email like '%DineshReddyC%' and deleted = 0 ---  26330

		select * from users where email like '%AjayKumarA%' and deleted = 0 ---  26331


		select * from users where email like '%NikhilDaB%' and deleted = 0 ---  26328




		 select custAssignmentGroupId, * from UserCustomerAssignGroupMapping where userid = 26328  and custAssignmentGroupId in (

		select custAssignmentGroupId from CustomerAssignmentGroupMapping where customerId =211  )


			-- Insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
			values
			(26331, 2923,0,1,1),
			(26331, 2924,0,1,1),
			(26331, 2925,0,1,1),
			(26331, 2919,0,1,1),
			(26331, 2926,0,1,1)


	--	UPDATE UserCustomerAssignGroupMapping SET  isAssignEnabled =0, AssignToWorkgroup = 0 
		where userCustomerAssignGroupId in 
		(
174724
,174725
,174726
,174727
,174728)	

	
	
	UPDATE UserCustomerAssignGroupMapping SET deleted = 1 WHERE userid = 25744 AND  custAssignmentGroupId NOT in (
0
,10
,23
,1303
,1937
,1975
,2036
,2070
,2095
,2212
,2394
,2405
,2416
,2438
,2528
,2556)

SR2623149


	select distinct custAssignmentGroupId from UserCustomerAssignGroupMapping where custAssignmentGroupId not in (

	select custAssignmentGroupId  from UserCustomerAssignGroupMapping where userid = 71556 and deleted = 0
	)
	
	and userid = 1728  and deleted = 0


	select * from customer where customerName like '%Unity Bio%'   -- 207

	select * from customer where customerName like '%LO5182%'   -- 203

		select  * from users  where loginName like '%LO5182%'  -- 25793  KarthikSh1@microland.com

		select  * from users  where firstName like '%Sneha%'

		

		select * from Customer where customerName like '%MLCIS%'  -- 3

		  select * from Users where loginName like '%LO5182%'  ---  Sneha Kamath 

	select * from CustomerAssignmentGroupMapping where customerId =211   and custAssignmentGroupId not in 
	
	 (select custAssignmentGroupId  from UserCustomerAssignGroupMapping where userid = 25793 )

	 select * from UserCustomerAssignGroupMapping where custAssignmentGroupId IN (14
,15
,16
) and userId = 25793
	
--	custAssignmentGroupId  in (
--14
--,15


    select *  from UserCustomerAssignGroupMapping where userid = 25744 and custAssignmentGroupId in ( 2556 ,1303,  2070, 2394, 2405)  --and deleted = 0

    select distinct custAssignmentGroupId from UserCustomerAssignGroupMapping where  custAssignmentGroupId not in (

	select custAssignmentGroupId  from UserCustomerAssignGroupMapping where userid = 25744 and deleted = 0) and userid = 1728  and deleted = 0
	

	Insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
	values
(25793, 21 ,0,1,1),
(25793, 27 ,0,1,1),
(25793, 164,0,1,1),
(25793, 165,0,1,1)


    select * from Users where userId in (1021, 910)


    select distinct custAssignmentGroupId from CustomerAssignmentGroupMapping where custAssignmentGroupId  in (

      	select custAssignmentGroupId  from UserCustomerAssignGroupMapping where userid = 1021 and deleted = 0
	)


	  select distinct custAssignmentGroupId from CustomerAssignmentGroupMapping where custAssignmentGroupId  in (

      	select custAssignmentGroupId  from UserCustomerAssignGroupMapping where userid = 910 and deleted = 0
	)

   -- (25744,2556,0,1,1)

   Update UserCustomerAssignGroupMapping set deleted = 0  where userCustomerAssignGroupId = 169048
    


	select * from 


	--  68 user need to map.
    --  96 user deleted.

	  select * from Customer



-- FOR CUSTOMERID=207  (Unity Bio)
--  
   Select * from ReasonForResponseBreach where CustomerId = 207 and isDeleted =0 

 --For Service Request. SR
--insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
--Select 'Not monitoring the ticket queue',207,2,0
--Select 'Missed to Acknowledge ticket on time',207,2,0
--Select 'Breach Reason Undermined by Engineer',207,2,0

----For Incident Request  IM



--insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
--Select 'Bulk Tickets Logged',207,1,0
--Select 'Not monitoring the ticket queue',207,1,0
--Select 'Missed to Acknowledge ticket on time',207,1,0
--Select 'Breach Reason Undermined by Engineer',207,1,0






---- Service request SR 
--select * from ResolutionPendingReasons where customerid = 207 and ticketTypeId = 2

  SELECT * FROM SLAExceptionCode WHERE customerId = 207 and ticketTypeId = 2

  update SLAExceptionCode set isDeleted= 1 where CustomerId = 168

--insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

--Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,207

--Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,207

--Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,207

--Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,207

--Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,207

--Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,207

--Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,207


----For Incident Request  IM


--insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

--Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,207

--Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,207

--Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,207

--Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,207

--Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,207

--Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,207

--Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,207



-- FOR CUSTOMERID = 168  (Actifio)

 --select * from Customer C where C.customerId = 168

--Select * from ReasonForResponseBreach where CustomerId = 168 -- Response / Actifio

--update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 168

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',168,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',168,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',168,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',168,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',168,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',168,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',168,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',168,1,0


-- select * from ResolutionPendingReasons where customerid = 168

--update ResolutionPendingReasons set deleted= 1 where CustomerId = 168


--insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

--Select 'Project Task',2,6,GETDATE(),0,168

--insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

--Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,168

--insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

--Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,168
--insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

--Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,168
--insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)
--Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,168
--insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

--Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,168
--insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

--Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,168
--insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

--Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,168


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,168

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,168

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,168

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,168

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,168

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,168

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,168


-- FOR CUSTOMERID = 61  (BOSCH)

 -- select * from Customer C where C.customerId = 61

--Select * from ReasonForResponseBreach where CustomerId = 61 -- Response / BOSCH

update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 61

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',61,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',61,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',61,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',61,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',61,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',61,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',61,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',61,1,0



--select * from ResolutionPendingReasons where customerid = 61

update ResolutionPendingReasons set deleted= 1 where CustomerId = 61


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Project Task',2,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,61


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,61

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,61




-- FOR CUSTOMERID = 189 (BOSCH DCS)

 --select * from Customer C where C.customerId = 189

--Select * from ReasonForResponseBreach where CustomerId = 189 -- Response / BOSCH

update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 189

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',189,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',189,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',189,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',189,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',189,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',189,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',189,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',189,1,0



-- select * from ResolutionPendingReasons where customerid = 189 

update ResolutionPendingReasons set deleted= 1 where CustomerId = 189 


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Project Task',2,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,189


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,189

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,189






-- FOR CUSTOMERID = 203 (BOSCH Scottsdale)

 -- select * from Customer C where C.customerId = 203

-- Select * from ReasonForResponseBreach where CustomerId = 203 

update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 203

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',203,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',203,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',203,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',203,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',203,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',203,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',203,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',203,1,0



-- select * from ResolutionPendingReasons where customerid = 203 

update ResolutionPendingReasons set deleted= 1 where CustomerId = 203 


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Project Task',2,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,203


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,203

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,203


-- FOR CUSTOMERID = 169 (Comviva)

 -- select * from Customer C where C.customerId = 169

-- Select * from ReasonForResponseBreach where CustomerId = 169 

update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 169

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',169,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',169,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',169,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',169,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',169,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',169,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',169,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',169,1,0



-- select * from ResolutionPendingReasons where customerid = 169 

update ResolutionPendingReasons set deleted= 1 where CustomerId = 169 


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Project Task',2,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,169


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,169

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,169



-- FOR CUSTOMERID = 158 (Enzen-NGN)

 -- select * from Customer C where C.customerId = 158

-- Select * from ReasonForResponseBreach where CustomerId = 158 

update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 158

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',158,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',158,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',158,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',158,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',158,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',158,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',158,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',158,1,0



-- select * from ResolutionPendingReasons where customerid = 158 

update ResolutionPendingReasons set deleted= 1 where CustomerId = 158 


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Project Task',2,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,158


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,158

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,158


-- FOR CUSTOMERID = 8 (FGIC)

 -- select * from Customer C where C.customerId = 8

-- Select * from ReasonForResponseBreach where CustomerId = 8 

   update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 8

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',8,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',8,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',8,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',8,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',8,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',8,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',8,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',8,1,0



-- select * from ResolutionPendingReasons where customerid = 8 

update ResolutionPendingReasons set deleted= 1 where CustomerId = 8 


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Project Task',2,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,8


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,8

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,8




-- FOR CUSTOMERID = 188 (Innocent Drinks)

 -- select * from Customer C where C.customerId = 188

-- Select * from ReasonForResponseBreach where CustomerId = 188 

   update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 188

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',188,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',188,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',188,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',188,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',188,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',188,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',188,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',188,1,0



-- select * from ResolutionPendingReasons where customerid = 188 

update ResolutionPendingReasons set deleted= 1 where CustomerId = 188 


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Project Task',2,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,188


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,188

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,188




-- FOR CUSTOMERID = 192 (Jubilant Life Sciences)

 -- select * from Customer C where C.customerId = 192

-- Select * from ReasonForResponseBreach where CustomerId = 192 

   update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 192

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',192,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',192,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',192,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',192,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',192,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',192,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',192,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',192,1,0



-- select * from ResolutionPendingReasons where customerid = 188 

update ResolutionPendingReasons set deleted= 1 where CustomerId = 192 


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Project Task',2,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,192


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,192

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,192






-- FOR CUSTOMERID = 194 (Jubilant Pharma)

 -- select * from Customer C where C.customerId = 194

-- Select * from ReasonForResponseBreach where CustomerId = 194 

   update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 194

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',194,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',194,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',194,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',194,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',194,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',194,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',194,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',194,1,0



-- select * from ResolutionPendingReasons where customerid = 194 

update ResolutionPendingReasons set deleted= 1 where CustomerId = 194 


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Project Task',2,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,194


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,194

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,194



-- FOR CUSTOMERID = 3 (MLCIS)

 -- select * from Customer C where C.customerId = 3

-- Select * from ReasonForResponseBreach where CustomerId = 3 

   update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 3

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',3,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',3,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',3,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',3,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',3,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',3,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',3,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',3,1,0



-- select * from ResolutionPendingReasons where customerid = 3 

update ResolutionPendingReasons set deleted= 1 where CustomerId = 3 


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --Resolution /Unityboi

Select 'Project Task',2,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,3


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,3

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,3




-- FOR CUSTOMERID = 4 (MLRMC)

 -- select * from Customer C where C.customerId = 4

-- Select * from ReasonForResponseBreach where CustomerId = 4

   update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 4

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',4,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',4,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',4,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',4,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',4,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',4,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',4,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',4,1,0



-- select * from ResolutionPendingReasons where customerid = 4

update ResolutionPendingReasons set deleted= 1 where CustomerId = 4 


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) --

Select 'Project Task',2,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,4


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,4

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,4





-- FOR CUSTOMERID = 58 (SAP GD)

 -- select * from Customer C where C.customerId = 58

-- Select * from ReasonForResponseBreach where CustomerId = 58

   update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 58

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',58,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',58,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',58,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',58,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',58,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',58,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',58,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',58,1,0



-- select * from ResolutionPendingReasons where customerid = 58

update ResolutionPendingReasons set deleted= 1 where CustomerId = 58


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Project Task',2,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,58


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,58

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,58




-- FOR CUSTOMERID = 161 (Ownership)

 -- select * from Customer C where C.customerId = 161

-- Select * from ReasonForResponseBreach where CustomerId = 161

   update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 161

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',161,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',161,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',161,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',161,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',161,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',161,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',161,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',161,1,0



-- select * from ResolutionPendingReasons where customerid = 58

update ResolutionPendingReasons set deleted= 1 where CustomerId = 161


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Project Task',2,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,161


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,161

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,161






-- FOR CUSTOMERID = 196 (Oreta-MMSG VOIP)

 -- select * from Customer C where C.customerId = 196

-- Select * from ReasonForResponseBreach where CustomerId = 196

   update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 196

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',196,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',196,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',196,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',196,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',196,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',196,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',196,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',196,1,0



-- select * from ResolutionPendingReasons where customerid = 196

update ResolutionPendingReasons set deleted= 1 where CustomerId = 196


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Project Task',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,196


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,196





-- FOR CUSTOMERID = 196 (Oreta-MMSG VOIP)

 -- select * from Customer C where C.customerId = 196

-- Select * from ReasonForResponseBreach where CustomerId = 196

   update ReasonForResponseBreach set isDeleted= 1 where CustomerId = 196

 --For Service Request. SR
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)  
Select 'Bulk Tickets Logged',196,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',196,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',196,2,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',196,2,0

--For Incident Request  IM
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Bulk Tickets Logged',196,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Not monitoring the ticket queue',196,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Missed to Acknowledge ticket on time',196,1,0
insert into ReasonForResponseBreach(ReasonForResponseBreachName,CustomerId,TicketTypeId,isDeleted)
Select 'Breach Reason Undermined by Engineer',196,1,0



-- select * from ResolutionPendingReasons where customerid = 196

update ResolutionPendingReasons set deleted= 1 where CustomerId = 196


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Project Task',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Initial Engineer Delay',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Breached before assignment',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Assignment Delay-Hopping Between Workgroups',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Request fulfillment took longer time due to Dependency',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Breach Reason Undermined by Engineer',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Vendor',2,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid)

Select 'Ticket not put on-hold Customer/User',2,6,GETDATE(),0,196


--For Incident Request  IM


insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Initial Engineer Delay',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Breached before assignment',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Assignment Delay-Hopping Between Workgroups',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Resolution Diagnosis took longer time',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Breach Reason Undermined by Engineer',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Vendor',1,6,GETDATE(),0,196

insert into ResolutionPendingReasons(ResolutionPendingReasonName,ticketTypeId,CreatedBy,CreatedDateTime,deleted,customerid) 

Select 'Ticket not put on-hold Customer/User',1,6,GETDATE(),0,196


To delete ticket � There is one SP in the name DeleteTickets with ticketno as a parameter.

Please find the sample query for your reference.

select * from ticket t
join requestor r on r.requestorId=t.requestorId
where customerId=4 and r.requestorEmail='vishalds@microland.com'

select T.statusName, * from ticket t
join requestor r on r.requestorId=t.requestorId
where customerId=4 and r.requestorEmail='vishalds@microland.com' 

select * from ticket t
join requestor r on r.requestorId=t.requestorId
where customerId=4 and r.requestorEmail='vishalds@microland.com' 

select * from ticket t
join requestor r on r.requestorId=t.requestorId
where customerId=4 and r.requestorEmail='vishalds@microland.com'

select * from ticket t
join requestor r on r.requestorId=t.requestorId
where customerId=4 and r.requestorEmail='vishalds@microland'

--> SR2556232

exec deletetickets @ticketNo = '560770';
exec deletetickets @ticketNo = '1806721';
exec deletetickets @ticketNo = '2457051';
exec deletetickets @ticketNo = '2608098';
exec deletetickets @ticketNo = '2611865';
exec deletetickets @ticketNo = '2614526';
exec deletetickets @ticketNo = '2614543';
exec deletetickets @ticketNo = '2615177';
exec deletetickets @ticketNo = '2615187';
exec deletetickets @ticketNo = '2615192';
exec deletetickets @ticketNo = '2615198';
exec deletetickets @ticketNo = '2622093';
exec deletetickets @ticketNo = '2622551';
exec deletetickets @ticketNo = '2622596';

PM2616732

exec deletetickets @ticketNo = '2616732';   























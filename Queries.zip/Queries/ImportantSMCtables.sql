

select * from customer
select * from service where iseupvisible=1
select * from servicecustomermapping where customerid=147 and deleted=0 and tickettypeid=1
select * from tickettype
select * from category
select * from servicecategorymapping 
select * from subcategory
select * from classification
select  * from rulesforpriority where customerid=190 and deleted=0
select * from ruletemplates
select * from priority where tickettypeid=1
select * from impact

select  * from rulesforassignment where customerid=190 and deleted=0
select * from ruletemplates
select * from assignemntgroup

select * from workgroup
select * from assignmentgroup
select * from customerassignmentgroupmapping where customerid=4
select * from usercustomerassigngroupmapping where userid=6
select * from users where userid=6
SELECT * FROM USERINSTANCEMAPPING 
1 --DB
2 --AD
select * from instance
SELECT * FROM [dbo].[CustomerPriorityMapping] WHERE CUSTOMERID=190
SELECT * FROM [dbo].[servicePriorityMapping] WHERE SERVICEID=196
SELECT * FROM [dbo].[ImpactTicketTypeMapping]

SELECT * FROM [dbo].[ResolutionCategories]
SELECT * FROM [dbo].[ResolutionCode] WHERE CUSTOMERID=147 AND DELETED=0 AND TICKETTYPEID=1
SELECT * FROM [dbo].[ResolutionPendingReasons]
SELECT * FROM [dbo].[SLAExceptionCode]
SELECT * FROM [dbo].[ClosureCode]
SELECT * FROM REQUESTORLOCATION WHERE CUSTOMERID=147 AND DELETED=0
SELECT * FROM HOLIDAYCALENDAR WHERE NAME LIKE '%EFL%'
SELECT * FROM HOLIDAYCALENDARDETAIL WHERE HOLIDAYCALENDARID=78
select * from servicelevelagreement where customerid=190
select * from servicelevelobjective where servicelevelagreementid in (230,231,232,233)
select * from servicelevelobjectivetype
select * from ticketstatus where tickettypeid=1
select * from workhours
select * from workhoursdetail where workhourid=5
select top 10 * from servicelevelobjective where servicelevelagreementid in (230) and serviceid=306 and priorityid=1 and impactid=1 and locationid=1152 and workgroupid=506
select * from servicelevelagreement where customerid=200
select serviceid,priorityid,impactid,workgroupid,currentlocationid,customerid,tickettypeid,* from ticket where ticketno=2299152
select * from servicelevelobjective where servicelevelagreementid in (264) and serviceid=391 and priorityid=9 and impactid=5 
select * from serviceleveltracking where sourceid=2299152

===============================================================
select * from notificationemailtemplate where customerid=190
select * from notificationimages
select * from notifybasedon
select * from ticketstatus 
select * from notificationrules where customerid=190
select * from notificationserviceemailconfig where customerid=190
select * from notificationregistry where sourceid=2299152
===============
select * from requestor
select * from customerrequestormapping where customerid=147
===========
select * from vendor where customerid=147

select vendorId, * from device where customerid=147

select * from deviceservicemapping where deviceid=4194
====================
select * from apikey where customerid=190
select * from creationtype
select * from autoticketserviceemailconfig where apikey='8C4D8A04-1FB9-472A-8277-1D3A816C9BC4'
select * from autoticketservicerule where apikeyid=84
select * from autoticketservicerulecolumn
select top 10 * from autoticketserviceruledetails
select * from apikeyactionmapping

===============================
select * from [dbo].[ClosureCode] where customerid=147 and deleted=0 and closureCode='Auto Close'
select * from [dbo].[AutoCloseInfo] where customerid=147

select * from [dbo].[PendingReasons] where customerid=147
select * from [dbo].[PendingReasonDependentMapping]

select * from role
select * from roleaccess
select * from roleaccessmapping
select * from [dbo].[ChangeAdvisoryBoard] where customerid=147
select  * from users where roleid=3
select * from rcareviewer

select * from menumaster where menuurl like '%dashboard%'
select * from menurolemapping where roleid=3


select * from templateconfig where id=71

select * from reportmaster where reportmasterid=102
select * from  [dbo].[ReportColumnMapping] where reportmasterid=102
select * from [dbo].[ReportParameter] where  reportmasterid=102

select * from reportrolemapping where roleid=3

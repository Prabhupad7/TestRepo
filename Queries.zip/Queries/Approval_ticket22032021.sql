

select sourceCategoryId, sourceCategoryName, sourceSubCategoryId, sourceSubCategoryName, 
sourceClassificationId, sourceClassificationName,sourceServiceId, sourceServiceName, sourceDeviceId, sourceDeviceName, 
* from Approval where approvalno= '2904435'  

--sourceCategoryId	sourceCategoryName	sourceSubCategoryId	sourceSubCategoryName	sourceClassificationId
--4248	                  IT Onboarding	   18114	          Replacement Joiner	 78300

   Select * from ApprovalEntityMapping  where approvalMappingRule like '%categoryId=4248;%'  ---->  3288

   select * from ApprovalEntityMapping where approvalEntityMappingId = 3288  --->  531 ---->  54178  54178	ML-IT Asset Management
   
   select * from ApprovalMatrixLevel where approvalMatrixId = 531  ---->  1018  issue is here 

   --Update ApprovalMatrixLevel set deleted = 0 where levelId = 1018 and approvalMatrixId = 531

   select top 10 * from ApprovalMatrixApprover where levelId = 1018

   select * from Asset_users where id = 54178

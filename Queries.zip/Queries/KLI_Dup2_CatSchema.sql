
    select * from KLI_24102020

    select * from KLI_24102020 where TicketType like '%Change Ticket%'

	select * from TicketType 

	--1	Incident	IM	NULL
	--2	Service Request	SR	NULL
 --   3	Change	CM	NULL

      select * from KLI_24102020 where TicketType = 'Change Ticket'

	 select * from KLI_24102020 

	 select distinct TicketType   from KLI_24102020

	 select *  from KLI_24102020 where TicketType is null

	 select * from Service where serviceName in( 
	 select distinct Servicename  from KLI_24102020 
	 )

	    select * from KLI_24102020 where serviceName ='Virtual Desktop Management'

	    --  update KLI_24102020 set ServiceId = 31 where serviceName ='Virtual Desktop Management'

		DECLARE @servicename NVARCHAR(MAX) ,@category NVARCHAR(MAX) ,@subcategory NVARCHAR(MAX) ,@clasification NVARCHAR(MAX),@customerid INT,@TicketType INT
SET @customerid=1
SET @TicketType=1
DECLARE Category_CURSOR CURSOR
LOCAL FORWARD_ONLY FOR
select * from KLI_24102020
OPEN Category_CURSOR
FETCH NEXT FROM Category_CURSOR INTO @servicename,@category,@subcategory,@clasification
WHILE @@FETCH_STATUS = 0
BEGIN

FETCH NEXT FROM Category_CURSOR INTO @servicename,@category,@subcategory,@clasification
END
CLOSE Category_CURSOR
DEALLOCATE Category_CURSOR



	select * from SubCategory where categoryId = 548

    and subCategory like '%data issue%'  -- 45

	Update SubCategory set subCategory = 'Information Required' where subCategoryId = 4489


	4489	data issue
    4490	data update
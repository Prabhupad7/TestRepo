

  select * from ReportMaster where reportMasterID in (300, 303)
  
   

---->  300	Asset Inventory	usp_Asset_Inventory

---->  303	Asset Storage Dump	usp_Asset_StorageDump

  --  execute usp_Asset_Inventory 1, 5

    select * from AssetEntityType  where id = 1 --->  1	Asset	Assets	Asset Management

    select * from AssetEntityType  where id = 35 --->  35	Database	Database

	 select * from AssetEntityType  where name like '%server%' ----> 17  displayorder 4

	 	 select * from AssetEntityType  where name like '%Admini%' ----> 23 ---> 5

		  select * from AssetEntityType  where name like '%Middleware%' ---->68

		  --update AssetEntityType set DisplayOrder =2 where id =68

		  select * from AssetEntityType where id = 67

		 select * from AssetEntityType  where id in(2,3, 35, 17, 23)

	 --   Insert into AssetEntityType (Name,DisplayName,Description,ParentId,DisplayOrder,AllowAssetCreation,	FaIcon,	EnableForleftMenu,CreatedById,CreatedOn,UpdatedById,UpdatedOn,
		--Deleted,SourceTypeId, IsActive, isAutoDiscoverEnabled,isBulkuploadEnabled)

		--Values ('Middleware', 'Middleware', 'Middleware', 1,11 , 1, 'fa fa-server', 1, 6, getdate(), 6, GETDATE(), 0, 1, 1, 0,0)


		select * from AssetEntityTypeCustomerMapping where AssetEntityTypeId In (2, 68)

		select * from AssetEntityTypeCustomerMapping where AssetEntityTypeId =2

		--Insert into AssetEntityTypeCustomerMapping(
		--	AssetEntityTypeId,	CustomerId	,	IsDeleted,	IsAutoTicket,		isKMSearchEnabledSMC,	isEUPEnabled,	isEnabledToNewTab,	isGridEnabled)		

		--	values (68, 1, 0, 1, 0, 0, 0, 0) 


		select top 10  * from Asset_EntityTypeUserMapping order by 1 desc  --- 1967

		--Insert into Asset_EntityTypeUserMapping (userId, entityTypeId, createdOn, createdBy, isDeleted, instanceId)

		--values (6, 68, getdate(), 6, 0, 1)



	    select * from AssetEntityType  where id = 67  ---->   67	IBM DB2	IBM DB2

		select * from AssetEntityType  where name like '%middle%'  ---->   67	IBM DB2	IBM DB2


        select * from Users where loginName like '%ajkumar10%'

        --update Users set password='SUv/GzSv2NSYGeW1YMGviQ==' , SaltValue=null where userId=989

        select * from UserInstanceMapping where userId=989



---->   instancepasswordchange 

  select * from Instancepasswordchangehistory where UserId = 989

 --- update Instancepasswordchangehistory set PwdUpdatedDate = GETDATE () where id = 511

  --->  UpdatedOn =getdate(), CreatedOn= GETDATE()

select * from Users where loginName like '%AJKUMAR10%' ---> 



select * from TAAGIC_15122020

select top 100 * from AttributeGroupType where AssetTypeId =68 --->   211

--Insert into AttributeGroupType(AssetTypeId	,CustomerId	,Groupname	,GroupTitle	,Displayorder,	deleted	,Createdon,	CreatedBy,	UpdatedBy	,Updatedon,	faIcon	,TabId	)

--values (68, 1, 'General', 'General Information', 1,0, getdate(), 6, 6, getdate(), 'fa fa-indent', 1)

select top 10 * from CustomAttributeColumnMapping order by 1 desc


--insert into CustomAttributeColumnMapping(CustomerId,SourceId,SourceTypeId,PageId,DisplayName,AttributeName,CustomerAttributeTablename,DataType,IsEditable,
--IsMandatory,IsVisible,FeildType,GroupType,Displayorder,  CreatedBy,CreatedOn,isAutoDiscoverEnabled,
--IsEUPRelationEnabled,IsAdvanceSearch,Deleted)

--select 1, 68, 1, 1, 'Remarks', 'Varchar15', 'VarcharCustomAttribute', 'Varchar', 1, 1, 1, 'text', 211, 15 ,   6, getdate(),0 , 0, 0, 0
--union all																										   
--select 1, 68, 1, 2, 'Remarks', 'Varchar15', 'VarcharCustomAttribute', 'Varchar', 1, 1, 1, 'text', 211, 15 ,   6, getdate(),0 , 0, 0, 0
--union all																										   
--select 1, 68, 1, 3, 'Remarks', 'Varchar15', 'VarcharCustomAttribute', 'Varchar', 1, 1, 1, 'text', 211, 15 ,   6, getdate(),0 , 0, 0, 0


  

--Select CustomerId,13,SourceTypeId,PageId,'Oracle Code','Varchar101',CustomerAttributeTablename,DataType,IsEditable,IsMandatory,IsVisible,FeildType,ValueSourceId,ValueSource,
--73,14
--,CreatedBy,GETDATE(),IsVersioning,isAutoDiscoverEnabled,IsAutogeneration,IsEUPRelationEnabled,IsAdvanceSearch,Deleted from CustomAttributeColumnMapping
--where SourceId = 18 and DisplayName = 'Location Code'




 select top 100 * from  Asset_ButtonAndEntityUserMapping where userid = 6 and entityUserMappingId = 1967
  order by 1 desc


  -- insert into Asset_ButtonAndEntityUserMapping (buttonName, isEnabled, isDeleted, pageId, userId, entityUserMappingId)   ---->  1967

  -- select buttonName, isEnabled, isDeleted, pageId, userId, 1967 from Asset_ButtonAndEntityUserMapping  where userid = 6 and entityUserMappingId = 1966
  --order by 1 desc

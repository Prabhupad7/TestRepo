

		select * from Workgroup where workgroup like '%HR Tech LD%'  ---->    652

		select * from AssignmentGroup where workgroupId = 652  ----->   786


		select * from CustomerAssignmentGroupMapping
		where assignmentgroupId = 786                           ----->   2844

		select top 100 * from Rulesforassignment 
		where PrimaryAssignmentGroupId = 786        ------>   79473    ---> AssigntoId:  24406

		--update Rulesforassignment set deleted = 1 where ruleid = 79473

		select * from Users where userid = 24406

		--update Workgroup set deleted = 1 where workgroupId = 652

		--update AssignmentGroup set deleted =1 where assignmentgroupId  =786

		--update CustomerAssignmentGroupMapping set deleted =1 where custAssignmentGroupId  =2844 
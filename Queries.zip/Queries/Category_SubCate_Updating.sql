

Select * from category where Category like '%Life Asia%'

Select * from category where Category like '%Life%'  

  -- Update category set deleted = 0 where categoryId = 946

  select * from ServiceCategoryMapping where categoryId in (946)


  select * from SubCategory where categoryId in ( 388, 412, 991)

    select * from SubCategory where categoryId in ( 946)

	-- Update SubCategory set deleted = 0 where  categoryId in ( 388)

	select * from Classification where subCategoryId in (
4544
,4545
	)

	-- Update Classification set deleted = 0, classification ='Others-Undefined' where classificationId in (
	8003
	)

  select * from SubCategory where categoryId in ( 388, 991)


 --- update ServiceCategoryMapping set deleted =0 where categoryId = 946
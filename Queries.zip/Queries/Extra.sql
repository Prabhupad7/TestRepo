﻿

       select * from Customer where customerName like '%Ask%'  --- 147	Ask Microland	Ask Microland	0

	   select * from Customer where customerName like '%MLCIS%'  ---- 3	MLCIS	MLCIS	0	NULL
     
	   select * from CustomerAssignmentGroupMapping where customerId = 147 and deleted = 0


       select distinct (userId) from UserCustomerAssignGroupMapping where  
	   custAssignmentGroupId in( select custAssignmentGroupId from CustomerAssignmentGroupMapping where customerId = 147)    
	   and  custAssignmentGroupId not in( select custAssignmentGroupId from CustomerAssignmentGroupMapping where customerId !=147) 
	   order by userId asc



	   select * from CustomerAssignmentGroupMapping where customerid ! = 147 and deleted = 0


	   select * from UserCustomerAssignGroupMapping where userId = 3 and deleted = 0 and custAssignmentGroupId in (
	   
	   select custAssignmentGroupId from CustomerAssignmentGroupMapping where customerid  = 147 and deleted = 0
	   )

	   --192	Jubilant Life Sciences	Jubilant Life Sciences	0
    --   194	Jubilant Pharma	Jubilant Pharma 	0

	   select * from Customer where customerName like '%Jub%'


	   select * from NotificationRules where customerId in (192, 194) and priorityId = 9 and deleted = 0 


	    select  * from NotificationRules where customerId in (192, 194) and deleted = 0 and tickettypeid = 1 and priorityid = 9



		select * from NotificationRules where customerId in (192) and duePercent is not null and deleted = 0 and tickettypeid = 1 and  priorityid = 1       ---  594

		
		select * from NotificationRules where customerId in (194) and duePercent is not null and deleted = 0 and tickettypeid = 1 and  priorityid = 1       ---  219

		select * from NotificationRules where customerId in (194) and duePercent is not null and deleted = 0 and tickettypeid = 1 and priorityid is null    --- 1212 rows


		select serviceid,  * from NotificationRules where customerId in (194) and duePercent is not null and deleted = 0 and tickettypeid = 1 and priorityid is null  and serviceid not in (
		select serviceid from NotificationRules where customerId in (194) and duePercent is not null and deleted = 0 and tickettypeid = 1 and  priorityid = 1 
		)


	 --   Insert into NotificationRules(CustomerId,	ticketTypeId,	priorityId	, duePercent	, notificationMode	,notificationTo	, notificationCC,	templateId,	ruleName,	workgroupid	, supportgroupid,	serviceId,	notifyBasedOnId,	entryStateId,	deleted	)

		select  194, 1, 1, duePercent, notificationMode, notificationTo	, notificationCC,	templateId,	ruleName,	workgroupid	, supportgroupid,	serviceId,	notifyBasedOnId,	entryStateId,	0	
		
		select * from NotificationRules where customerId in (194) and duePercent is not null and deleted = 0 and tickettypeid = 1 and priorityid is null    and Serviceid not in (
		
		select  Serviceid from NotificationRules where customerId in (194) and duePercent is not null and deleted = 0 and tickettypeid = 1 and  priorityid = 1   
		) 


		select * from Priority where deleted =0 and ticketTypeid =1

		---- 5	P2	240
		---- 27	P4	1440



		select   * from NotificationRules where customerId in (194) and duePercent is not null and deleted = 0 and tickettypeid = 1 and priorityid= 5    ---    

update NotificationRules set priorityId = 5 where ruleID in (

		) 




				select  Serviceid, * from NotificationRules where customerId in (192) and duePercent is not null and deleted = 0 and tickettypeid = 1 and  priorityid = 1       ---  594



       -- Insert into NotificationRules(CustomerId,	ticketTypeId,	priorityId	, duePercent	, notificationMode	,notificationTo	, notificationCC,	templateId,	ruleName,	workgroupid	, supportgroupid,	serviceId,	notifyBasedOnId,	entryStateId,	deleted	)

		select  192, 1, 1, duePercent, notificationMode, notificationTo	, notificationCC,	templateId,	ruleName,	workgroupid	, supportgroupid,	serviceId,	notifyBasedOnId,	entryStateId,	0	
		
		from NotificationRules where customerId in (192) and duePercent is not null and deleted = 0 and tickettypeid = 1 and priorityid is null    and Serviceid not in (
		
		select  Serviceid from NotificationRules where customerId in (192) and duePercent is not null and deleted = 0 and tickettypeid = 1 and  priorityid = 1   
		) 



       -- Insert into NotificationRules(CustomerId,	ticketTypeId,	priorityId	, duePercent	, notificationMode	,notificationTo	, notificationCC,	templateId,	ruleName,	workgroupid	, supportgroupid,	serviceId,	notifyBasedOnId,	entryStateId,	deleted	)

		select   194,	1,	27	, duePercent	, notificationMode	,notificationTo	, notificationCC,	templateId,	ruleName,	workgroupid	, supportgroupid,	serviceId,	notifyBasedOnId,	entryStateId,	0
		from NotificationRules where customerId in (194) and duePercent is not null and deleted = 0 and tickettypeid = 1 and priorityid= 5  





		select  * from NotificationRules where customerId in (192, 194) and  deleted = 0 and notificationTo like '%PrabhuKR@microland.com%'

		-- select  * from servicePriorityMapping where customerId in (192, 194) and deleted =0 and PriorityId = null



		--update servicePriorityMapping set deleted = 0 where servicePriorityMappingId in (
		4697
,4698
,4699
,4700
,4701
,4702
,4703
,4704
,4705
,4706
,4707
,4708
,4709
,4710
,4711
,4712
,4713
,4714
,9978
,9995
,10012
,10029
,10046
,10063
,10080
,10097
,10114
,10131
,10148
,10525
,10542
,13508
,13520
,13542
,13553
,13576
		)

	   -- update NotificationRules set deleted =1 where ruleId In (2086506,)   -- done for 2220 rows

	   select  * from rulesforassignment where customerId in (192, 194) and deleted=0 and AssignmentRule like '%priority%'

					--	   i)	RulesForAssignment
					--ii)	AutoTicketServiceRuleDetails
					--iii)	AutoTicketServiceRule
					--iv)	AutoTicketEventLog

					select top 100 * from AutoTicketServiceRuleDetails

					select top 100 * from AutoTicketEventLog

					select distinct (D.deviceId) from Device  D
					inner join DeviceServiceMapping DS
					on D.deviceId = DS.deviceId 
					where D.customerId in (192, 194) and d.deleted = 0 and ds.deleted = 0 


					
					---- Query to disable auto ticket notifications , query to review:

					select  * from AutoTicketServiceRule where TicketTypeId = 1 and PriorityId = 9 and isDeleted = 0 and deviceId in 
					(
					select distinct (D.deviceId) from Device  D
					inner join DeviceServiceMapping DS
					on D.deviceId = DS.deviceId 
					where D.customerId in (192, 194) and d.deleted = 0 and ds.deleted = 0 
					)

					[‎8/‎21/‎2020 12:44 PM]  Mahesh K:  
                     select * from autoticketservicemailconfig 
                     SELECT * FROM AUTOTICKETSERVICERULE
                     SELECT * FROM AUTOTICKETSERVICERULEDETAILS
                     SELECT * FROM AUTOTICKETSERVICERULECOLUMN
                     SELECT * FROM APIKEYACTIONMAPPING 
                      
                     



	   select top 100 * from AutoTicketEmailLogs 

	   select top 100 * from AutoTicketLogs

	   select * from Autom

	   AutoticketConfig

	   AutoTicketEmailconfig

	   select * from Priority

select top 100 * from TS_AutoTicketSchedular
where title like '%Point 2 Point connectivity Moor side and Low Thornely servers%' ---> 274

--Update TS_AutoTicketSchedular set deleted = 1 where id = 274

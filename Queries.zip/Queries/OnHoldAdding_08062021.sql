


---> 72 OnHold other TicketTypeId: 1
---> 73	OnHold other TicketTypeId: 2

---> 74	OnHold other TicketTypeId: 4

select * from ServiceLevelAgreement where customerId = 196

select Count(*) from ServiceLevelObjective 
where serviceLevelAgreementId in (254, 335)
and serviceLevelObjectiveTypeId = 2
and isDelete = 0 and finalStatusId = 39 and excludeStatusIds is not null

select * from ServiceLevelObjective where serviceLevelAgreementId in (254, 335)
and serviceLevelObjectiveTypeId = 2
and isDelete = 0 and finalStatusId = 39 and excludeStatusIds is not null


--Update ServiceLevelObjective set excludeStatusIds = excludeStatusIds+',74' 
--where serviceLevelAgreementId in (254, 335)
--and serviceLevelObjectiveTypeId = 2
--and isDelete = 0 and finalStatusId = 39 and excludeStatusIds is not null


----------------------------->

select * from NotificationRules where deleted = 0 
and customerid = 147 and serviceid= 84

select * from customer where customerName like '%ASK%' ----> 147	Ask Microland

select * from Service where deleted = 0 and serviceName like '%HR%'  ---> 84	HR

select * from TicketType ------> 2	Service Request
--ticketTypeId	ticketType
--1	Incident
--2	Service Request

select * from Priority where deleted = 0 and ticketTypeId = 1

select * from Priority where deleted = 0 and ticketTypeId = 2  ----> 14	SR3

select * from NotificationEmailTemplate where customerId = 147  ---> 449

-----> Respose 

select * from TicketStatus
where ticketTypeId = 2 and deleted = 0  ----> 
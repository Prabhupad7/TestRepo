



select * from customer where customerName like '%Kotak%'   ---  163

select * from customer where customerName like '%Eureka%'   ---  167

select top 10 * from Category where customerid= 194

select top 100 * from ServiceCategoryMapping 



 select distinct 
case scm.tickettypeid when 1 then 'Incident'  when 2 then 'Service Request' when 3 then 'Change Ticket' when 4 then 'Problem Ticket' end 'Ticket Type',
 s.serviceName, c.category, sc.subcategory, cl.classification, case when scm.deleted = 0 and c.deleted = 0 and sc.deleted = 0 and cl.deleted = 0 and scc.deleted=0 then 'Active' else 'Inactive' end as Active 
 from ServiceCategoryMapping scm
join servicecustomermapping scc on scc.serviceid= scm.serviceid
join service s on s.serviceid = scm.serviceid
join category c on scm.categoryid = c.categoryId
join subcategory sc on sc.categoryId = c.categoryId
join Classification cl on cl.subCategoryId = sc.subCategoryId
where scc.customerid= 1  and c.deleted = 0 and sc.deleted = 0 and cl.deleted =0
and scm.tickettypeid in (1, 2,3,4)

--------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------



select distinct s.serviceName as 'Service Name',
case slag.subTypeId when 1 then 'Incident' when 2 then 'Service' when 3 then 'Change' when 4 then 'Problem' end 'Ticket Type'
,CASE slo.serviceLevelObjectiveTypeId when 1 then 'Response' WHEN 2 then 'Resolution'end 'Service Type',p.priority as 'Priority',i.impact as 'Impact',
CASE WHEN wg.workgroup is null THEN 'Default' ELSE wg.workgroup END AS 'Work Group',
slo.responseTimeInMin as 'SLA Duration Time(min)',
CASE slo.is24X7Service when 0 then 'No' WHEN 1 then 'Yes'end 'is24X7Service',
case  when slo.workHourId=0 then '12:00am to 11:59pm Mon to Sun'  else wh.description end as 'Service Window'
,CASE WHEN SLO.isDefault=1 THEN 'Yes' else 'No' end as 'Is Default',rl.location
from servicelevelobjective slo
join service s on s.serviceId=slo.serviceId
join Priority p on p.priorityId = slo.priorityId
join Impact i on i.impactId = slo.impactId
left join Workgroup wg on wg.workgroupId=slo.workgroupId
left join WorkHours wh on wh.workHourId = slo.workHourId
join ServiceLevelAgreement slag on slag.serviceLevelId = slo.serviceLevelAgreementId
left join RequestorLocation rl on rl.customerID=slag.customerid and rl.locationID=slo.locationId
where slo.isDelete=0 and s.deleted=0 and p.deleted=0 and i.deleted=0 and slag.customerid= 3

--------->

select top 1000 * from RulesForPriority

select * from NotificationRules where customerId = 68 and notificationMode ='AWSSMS'  


select * from Customer where customerid in (
3,4,8,58,59,61,158,167,168,169,188,189,192,194,196,201,203,207,213,214,215,217,218,219,220,221
) and deleted = 0

    select * from Customer where customerName like '%Jubilant Life Sciences%'  --  192	Jubilant Life Sciences

    select TicketType, customer, Device, service, category, subcategory, classification, impact, priority, requestoremail, Title, Description, startDate, expirydate, assignmentGroupName
	from TS_AutoTicketSchedular 
	where customer like '%Jubilant Life Sciences%' and deleted = 0

	select * from Customer where customerId = 3 


﻿

--[2/16 6:40 PM] Mahesh K

--    EUP PI Call summary - usp_MIS_HMCL_REP_ResolvedTicketDump_Daily_EUP


--​[2/16 6:41 PM] Mahesh K
--    Daily Ageing report - MIS_HMCL_REP_ageingTicketDump_NonML  and MIS_HMCL_REP_ageingTicketDump_ML


select * from MIS_HMCL_NewEmailReport where id in (1, 5)

 --Update MIS_HMCL_NewEmailReport set body ='<p>Dear Harish Sir,<br/><br/>Please find below snapshot of Daily Ageing Report as on @date and refer attached summary.<br/><br/><b><U>Synopsis:</b></U><br/><br/>1. 18 Tickets having more than 7 days ageing for ML account.<br/><br/>@Image0<br/><br/>2. 25 Tickets having more than 7 days ageing for NON-ML account.<br/><br/>@Image1<br/><br/>Regards,<br/> Microland Team </p>'

 --where id in (5)
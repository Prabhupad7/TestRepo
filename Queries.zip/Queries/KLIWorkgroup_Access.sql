
select * from workgroup where workgroup like '%Oncall Support%'

2	Desktop-Laptop Management
12	Remote Support Management
19	Service Desk
9	IMACD
5	Server Management
123	2 Strike Tickets
135	Airwatch management
8	ID Management
136	Branch Support Management
14	AIU  Management
15	Security Management
86	Oncall Support


  Select * from Workgroup where workgroupId in (
  2, 12,19, 9,5,123,135,8,136,14,15,86)

  select Ag.assignmentgroupId, ag.assignmentgroupName from  Workgroup W 
  inner join AssignmentGroup Ag on Ag.workgroupId = w.workgroupId
  inner join CustomerAssignmentGroupMapping ca on ca.assignmentgroupId = ag.assignmentgroupId
  inner join UserCustomerAssignGroupMapping cm on cm.custAssignmentGroupId = ca.custAssignmentGroupId
  where cm.userId in (
  73	
  ,516	
  ,635	
  ,1047
  ,1107
  ) and w.workgroupId in (2, 12,19, 9,5,123,135,8,136,14,15,86)

--Shishir � LO3556
--Sandhya �  LO4772
--Mayuri --  LO4997
--Pradeep -- LO1880
--Omkar --   LO3201


  select * from users where loginName in (
  'LO3556',
  'LO4772',
  'LO4997',
  'LO1880',
  'LO3201'
  )

73	Shishir	Bodane
516	Pradeep	Thotapalli
635	Omkar	Chavan
1047	Sandhya	Chauhan
1107	Mayuri	Wakchowre 


  select Ag.assignmentgroupId, ag.assignmentgroupName, ca.custAssignmentGroupId from  Workgroup W 
  inner join AssignmentGroup Ag on Ag.workgroupId = w.workgroupId
  inner join CustomerAssignmentGroupMapping ca on ca.assignmentgroupId = ag.assignmentgroupId
  where w.workgroupId in (2, 12,19, 9,5,123,135,8,136,14,15,86)

15
18
21
22
25
27
28
84
175
206
219
220

  select * from UserCustomerAssignGroupMapping where userId in (
  73 ,516 ,635,1047,1107) and custAssignmentGroupId in (
 15
,18
,21
,22
,25
,27
,28
,84
,175
,206
,219
,220
  )

  --->  userid 73	custAss 28

    Insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)

	values 
	(73, 15, 0, 0, 0),
	(73, 18, 0, 0, 0),
	(73, 21, 0, 0, 0),
	(73, 22, 0, 0, 0),
	(73, 25, 0, 0, 0),
	(73, 27, 0, 0, 0),
	--(73, 28, 0, 0, 0),
	(73, 84, 0, 0, 0),
	(73, 175, 0, 0, 0),
	(73, 206, 0, 0, 0),
	(73, 219, 0, 0, 0),
	(73, 220, 0, 0, 0)
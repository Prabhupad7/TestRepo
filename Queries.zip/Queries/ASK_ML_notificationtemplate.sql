

   select * from NotificationEmailTemplate
   where customerid = 147 and templateName like '%Assigned Template%'

   --448

   select *  from notificationRules where customerid =147 
   and deleted =0 and serviceid =68 and templateId = 448

   select * from Service where serviceId = 68

   select * from NotificationEmailTemplate where templateid = 448

   --insert into NotificationEmailTemplate (templateName, template, templateSubject, customerId,ImageIds, 
   --isOutageNotificationTemplate, oldtemplateid, isOutageSMSNotification)


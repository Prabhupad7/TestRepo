

select * from VarcharCustomAttribute where PrimaryId = 765918

----> Convert( nvarchar(100),convert(bigint, H.MobilePhone))

--Insert into Assets (CustomerId,SourceId,SourceTypeId,AssetNumber,SerialNumber,Createdbyid,CreatedOn,StatusId,Status,Model,
--ModelId,ManufacturerId,Manufacturer,LastUpdatedOn,LastUpdatedBy,Department,Project)

------> 772714

--values (147, 370, 1, 'INSU-16138', '5063900083', 6, GETDATE(), 823, 'Active', 'Kotak Mahindra Life Insurance Ltd','772714', 80420, 'Mediassist',
--GETDATE(), 6, 'NETWORK & CYBER SECURITY', ''),

--(147, 370, 1, 'INSU-16139', '5067987013', 6, GETDATE(), 823, 'Active', 'Kotak Mahindra Life Insurance Ltd','772714', 80420, 'Mediassist',
--GETDATE(), 6, 'HUMAN RESOURCES', ''),



--select 147, 370, 1,  'INSU-'+ Cast(assetNumber as varchar),Convert( nvarchar(100),convert(bigint, TPANumber))   , 6, GETDATE() , 823, 'Active', Model, '80417', '80420', Manufacturer,UpdatedOn,
--6, DepartmentName, ProjectName  from Insurance_08072021$ where TPANumber not in (
--select SerialNumber from Assets where customerid = 147 and SourceId = 370) 
--order by assetnumber 

select id, CustomerId, SourceId, SourceTypeId, AssetNumber, SerialNumber, Createdbyid, CreatedOn,StatusId, Status, Model, ModelId, 
ManufacturerId, Manufacturer, LastUpdatedOn, LastUpdatedBy, Department, Project	 from Assets 
where SourceId = 370 order by 1 desc  




select * from  Insurance_08072021$ order by assetNumber


--declare @Id int
--Set @Id  = 015865
--Update Insurance_08072021$ set @Id = AssetNumber = @Id + 1
--Go


select top 272 * from Assets 
where SourceId = 370 order by 1 desc



select * from Assets where id in (80420, 80417)

select * from VarcharCustomAttribute where PrimaryId in (
762922,762921,762920,762919,762918,762917,762916,762915,762914,762913,762912,762911,762910,762909,762908,762907,762906,762905,762904,762903,762902,762901,
762900,762899,762898,762897,762896,762895,762894,762893,762892,762891,762890,762889,762888,762887,762886,762885,762884,762883,762882,762881,762880,762879,
762878,762877,762876,762875,762874,762873,762872,762871,762870,762869,762868,762867,762866,762865,762864,762863,762862,762861,762860,762859,762858,762857,
762856,762855,762854,762853,762852,762851,762850,762849,762848,762847,762846,762845,762844,762843)

select  CustomerId, SourceId, SourceType, PrimaryId, Varchar99, Varchar100
from VarcharCustomAttribute where SourceId = 370 and CustomerId = 147

select * from CustomAttributeColumnMapping where SourceId = 370 
and PageId in (2,3) and DisplayName ='Business Function' --> DateTimeCustomAttribute --> Asset Issued On	Datetime18

select top 100  * from DateTimeCustomAttribute where SourceId = 370

--Insert into DateTimeCustomAttribute (CustomerId, SourceId, SourceType, PrimaryId, Datetime18)

--select 147, 370,1,Id, AssetIssuedOn from Insurance_08072021$

--Insert into VarcharCustomAttribute (PrimaryId, CustomerId, SourceId, SourceType, Varchar99, Varchar100)

--select distinct A.Id, A.CustomerId, A.SourceId,A.SourceTypeId, 'Beneficiary - '+ I.AssetAssignedto , 'HR Asset' from Insurance_08072021$ I
--inner join Assets A on I.TPANumber = A.SerialNumber
--where A.CustomerId = 147 and SourceId = 370

--id: 772716	147	370	1	INSU-16139	NULL	5067987013
--id: 772715	147	370	1	INSU-16138	NULL	5063900083


select id, auid ,* from Insurance_08072021$ where employeeid ='23046'  ---> AJAYSIK@microland.com

select * from Asset_users where EmailId =''

select * from Assets where id in (772716, 772715)

select * from Asset_users where EmployeeId = '23046'  ---> 100218

select * from Asset_Assignment where assignedToId = 100218

select distinct A.Id, I.ID, I.EmailId from Insurance_08072021$ I 
inner join Assets A on A.SerialNumber = I.TPANumber
where a.CustomerId = 147 and SourceId =  370

select isDeleted, * from Assets where id in (766503,766504) 

--Update Assets set isDeleted = 1 where id = 766504

 select A.*from Insurance_08072021$ I 
inner join Asset_Users A on A.EmailId = I.EmailId

--where a.CustomerId = 147 and SourceId =  370



--Update i set I.auid = a.id from Insurance_08072021$ I 
--inner join Asset_Users A on A.EmailId = I.EmailId

select id, auid ,* from Insurance_08072021$ where id in (766355, 766354, 766353) 

---> 766243	100075	Sowmya Mb

select top 100 * from Asset_Assignment 

--Insert into Asset_Assignment

--select i.id, i.auid, a.DisplayName, 3, 'Used By', 6, GETDATE(), 6, GETDATE(), 1, 0, NULL from  Insurance_08072021$ I 
--inner join Asset_Users A on A.EmailId = I.EmailId
--where a.IsDeleted = 0


select * from Customer where displayName like '%Empire%'  

---> 766355, 766354, 766353




select * from users where loginName like '%Manjunath%' ---> 25644 , 1712

select roleId,* from Users where userId in (25644 , 1712, 25872)  ----> 58

--Update Users set roleId = 75 where userId in (25644 , 1712) 

select * from Role where roleId in (58,75) 

select * from Service where serviceName like '%SAP%'

select * from Users where email like '%srijith.ravindran@westernacher.com%'

select * from Users where email like '%sudharson.narayanan@westernacher.com%'

select * from Asset_Assignment where assetId in (762917,762916,762915,762914,762913)

---------------------------->

select PrimaryId, CustomerId, SourceId, SourceType, Varchar99, Varchar100, * from VarcharCustomAttribute where PrimaryId in (762922,762921,762920,762919,762918,762917,762916,762915,762914)

--Insert into VarcharCustomAttribute (PrimaryId, CustomerId, SourceId, SourceType, Varchar99, Varchar100)

--select '772715', 147, 370, 1, 'Beneficiary - Syed Ahamad', 'HR Asset' UNION ALL

--select '772716', 147, 370, 1, 'Beneficiary - M Keerthana', 'HR Asset' 


    select top 1  * from Requestor where deleted = 0 and requestorEmail like '%imam.sagar%' order by 1 desc


	select top 200* from Hero_Users order by 1 desc

	select   * from Requestor where deleted = 0  and lastname like '%.%'

	 select EmployeeId, MobilePhone, LastName, * from HMCL_22092020 where  lastname like '%.%'

	 	 select  * from HMCL_2_22092020$ 


	  --   select FirstName, LastName, EmailAddress,WorkPhone, MobilePhone, WorkAddress, EmployeeID, EmployeeType, EmployeeTitle, ManagerEmail, Department
		 --CostCenter into #HMupdate  from HMCL_UserData05092019

		 -- drop table #HMupdate

	--	C1 --- requestorId	requestorName	requestorPhoneNumber	requestorEmail	isCriticalUser	requestorOtherInfo	employeeId	firstname	lastname	displayname	alias	designation	department	location	mobileno	businessphone	createdOn	UpdatedOn	createdby	updatedby	deleted	profilePicture	AboutMe	Password	deletedBy	deletedOn	LastLoginTime	CountryCode	failedLoginAttemptCount	isAccountLocked


		 select EmployeeId ,MobilePhone, * from #HMupdate

		 select * from Requestor where requestorEmail like '%@heromotocorp.com%' and deleted =


		 select  newmobileNo, * from HMCL_UserData05092019

		 select newmobileNo, [Mobile Phone],  * from HMCL_UserData05092019 where newmobileNo is null and [Mobile Phone] is not null

		  select newmobileNo, [Mobile Phone],  * from HMCL_UserData05092019 where newmobileNo is null 

		  select newmobileNo, [Mobile Phone],  * from HMCL_UserData05092019 where EmailAddress ='abhay.thakur@heromotocorp.com'


		 --  Select R.employeeId, R.mobileno, H.EmployeeID, H.MobilePhone,

		   	select   * from Requestor where deleted = 0  and lastname like '%.%'

			select EmployeeId , MobilePhone,  * from #HMupdateq

			 select EmployeeId, mobileno, LastName, * from Requestor
			 where deleted = 0 and requestorEmail like '%heromotocorp.com%' 

			--- update Requestor set lastname ='' where requestorId in ()
			
			---- avinash.upadhyay@heromotocorp.com


			

		 
		 --UPDATE R
		 --SET  R.mobileno =  H.newmobileNo
		 --from Requestor R
		 --inner join HMCL_UserData05092019 H
		 --on R.requestorEmail = H.EmailAddress
		 --WHERE R.requestorEmail = H.EmailAddress and H.newmobileNo is not null
		 

		 --UPDATE R
		 --SET  R.mobileno =  H.newmobileNo
		 --from Requestor R
		 --inner join HMCL_UserData05092019 H
		 --on R.requestorEmail = H.EmailAddress
		 --WHERE R.requestorEmail = H.EmailAddress and H.newmobileNo is not null




		 select R.mobileno, H.newmobileNo
		 from Requestor R
		 inner join HMCL_UserData05092019 H
		 on R.requestorEmail = H.EmailAddress
		 WHERE R.requestorEmail = H.EmailAddress


		 SELECT  * from Requestor R
		 inner join #HMupdate H
		 on R.requestorEmail = H.EmailAddress




		 SELECT  R.mobileno, H.MobilePhone, * from Hero_Users H2
		 inner join #HMupdate H
		 on H2.EmailAddress = H.EmailAddress


		 select * from Requestor r join HMCL_22092020 h on r.alias = h.EmailAddress


	--  MERGE INTO [dbo].[Requestor] c1
      USING #HMupdate c2
      ON c1.requestorEmail = c2.EmailAddress
      When MATCHED THEN 

		Update set c1.employeeId=c2.EmployeeID, C1.mobileno=C2.MobilePhone, c1.lastname=c2.LastName	
		WHEN NOT MATCHED THEN

   INSERT(
 requestorName,	requestorPhoneNumber,	requestorEmail,	isCriticalUser,	requestorOtherInfo,	employeeId,	firstname,	lastname,	displayname,	alias,	designation,	department	location	mobileno	businessphone	createdOn	UpdatedOn	createdby	updatedby	deleted	profilePicture	AboutMe	Password	deletedBy	deletedOn	LastLoginTime	CountryCode	failedLoginAttemptCount	isAccountLocked

 ) VALUES(
 
   c2.[id],
	c2.[EmployeeId]  ,
	c2.[FirstName] ,
	c2.[LastName] ,
	c2.[DisplayName] ,
	c2.[RoleId]  ,
	c2.[ManagerId]  ,
	c2.[EmailId] ,
	c2.[Alias] ,
	c2.[Address]  ,
	c2.[City]  ,
	c2.[State]  ,
	c2.[Country]  ,
	c2.[ZipCode] ,
	c2.[JobTitle] ,
	c2.[Company] ,
	c2.[Department]  ,
	c2.[Project] ,
	c2.[BusinessPhone1]  ,
	c2.[BusinessPhone2]  ,
	c2.[HomePhone1] ,
	c2.[HomePhone2] ,
	c2.[Mobile] ,
	c2.[Fax] ,
	c2.[Pager]  ,
	c2.[Assistant] ,
	c2.[IsEnrolled],
	c2.[IsDisabled],
	c2.[TimeZoneId]  ,
	c2.[PhotoImage] ,
	--c2.[CreatedOn] ,
	c2.[CreatedBy],
	--c2.[LastUpdatedOn] ,
	c2.[LastUpdatedBy],
    c2.[IsDeleted] ,
	c2.[maxassetcount] ,
	c2.[CustomerId],
	c2.[MgrEmpId]

	  );


	   select newmobileNo, [Mobile Phone],  * from HMCL_UserData05092019 where newmobileNo is null and [Mobile Phone] is not null

	  select * from Users where email like '%LikhithoshSK@microland.com%'

	  select top 220 * from Hero_Users  order by 1 desc 


	  select top 300 * from Requestor where requestorEmail like '%heromotocorp.com%' order by  1 desc

	  gadde.venkataprudhviraj@heromotocorp.com

	    select  * from Requestor where requestorEmail like '%md.nawaj@heromotocorp.com%' --- 56733

		-- update Requestor set mobileno ='8436055783' where requestorId = 56542

	    select top 1 * from Hero_Users where emailAddress = 'gadde.venkataprudhviraj@heromotocorp.com'

		select top 1 * from Hero_Users order by 1 desc

		select top 1 * from Hero_Users where id=5189

	   -- Insert into Hero_Users (  firstName	, lastName	, emailAddress	, workPhone1	, mobilePhone1	, workAddress1	, employeeId	,
		employeeTitle,	manager, 	department	, costCenter)

		Values ( 'Mrinal', 'Vaibhav', 'MRINAL.VAIBHAV@HEROMOTOCORP.COM', null, 919176738709, 'HEAD Office', 13719,

		'Graduate Engineer Trainee', 'kamal.jeet@heromotocorp.com', 'Sales&Marketing', 'Parts Business')









	  	 --UPDATE R
		 SET  R.mobileno =  H.newmobileNo
		 from Requestor R
		 inner join HMCL_UserData05092019 H
		 on R.requestorEmail = H.EmailAddress
		 WHERE R.requestorEmail = H.EmailAddress and H.newmobileNo is not null



		 select * from Requestor where requestorEmail like '%abhay.thakur@heromotocorp.com%'


	 -- Insert into Hero_Users (  firstName	, lastName	, emailAddress	, workPhone1	, mobilePhone1	, workAddress1	, employeeId	,
		employeeTitle,	manager, 	department	, costCenter)
		Values ( 'Mrinal', 'Vaibhav', 'MRINAL.VAIBHAV@HEROMOTOCORP.COM', null, 919176738709, 'HEAD Office', 13719,

		'Graduate Engineer Trainee', 'kamal.jeet@heromotocorp.com', 'Sales&Marketing', 'Parts Business')





		-- Insert into Hero_Users (  firstName	, lastName	, emailAddress	, workPhone1	, mobilePhone1	, workAddress1	, employeeId	,
		employeeTitle,	manager, 	department	, costCenter)
		


		   select [First Name], [Last Name], EmailAddress, [Work Phone], NewMobilenum, [Work Address], NewEmpiD, [Employee Title], [Manager Email], Department, [Cost Center]  from HMCL_23092020 where EmailAddress
           not in (select EmailAddress from Hero_Users ) -- and EmailAddress ='abhay.thakur@heromotocorp.com'


		   --				MobilePhone		EmployeeID	Employee Type			Department		NewMobilenum	NewEmpiD	(No column name)

		 		--select top 1 *, cast(CAST(MobilePhone AS bigint) AS varchar(50)) from HMCL_23092020 where EmailAddress
     --                  not in (select EmailAddress from Hero_Users )


					   select *, cast(CAST(MobilePhone AS bigint) AS varchar(50)) from HMCL_23092020 where EmailAddress
                    not in (select EmailAddress from Hero_Users )


					--update Hero_Users set LastName ='' where Id in (
					5399
                   ,5328
                   ,5317
                   ,5308
                   ,5302
                   ,5237
                   ,5236
                   )
                   

				    select top 500 * from Requestor where requestorEmail like '%heromotocorp.com%' order by 1 desc

					--select * from HMCL_23092020 where EmailAddress
     --                  not in (select requestorEmail from Requestor )
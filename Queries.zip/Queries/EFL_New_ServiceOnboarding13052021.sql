
select * from Customer where customerName like '%Eureka%'  ---> 167	Eureka Forbes Limited

select * from Service where serviceName like '%TAXILLA%' --->  543

select * from ServiceCustomerMapping where customerId= 167

select * from Service where serviceId = 194  ---> 194

--Insert into Service (serviceName,alternateName,	description	,createdDate,typeId,contactId,createdById,modifiedById,	deleted,isEUPVisible,
--Icon, Icon_Color, Icon_BgColor)

--values ('TAXILLA', 'TAXILLA', 'TAXILLA', GETDATE(), 4, 1,1, 1,0,1, 'fa fa-2x fa-shield', '#F5CF87','#C75C5C')

-- select * from servicePriorityMapping where serviceId =543 194  543

select * from Priority where deleted = 0 and TicketTypeId = 1  ----> 5	P2

--Insert into servicePriorityMapping (customerPriorityMappingId,	serviceId,	deleted,	customerId,	PriorityId)

--select customerPriorityMappingId,	543,	deleted,	customerId,	PriorityId
--from servicePriorityMapping where serviceId = 194


select * from ServiceCustomerMapping where serviceid= 194  ---> 51

--Insert into ServiceCustomerMapping (serviceId, customerId, deleted, ticketTypeId)
--values 
--(543, 167, 0, 1),
--(543, 167, 0, 2)

    select * from Impact

    select * from ImpactTicketTypeMapping where serviceId = 194

	--Insert into ImpactTicketTypeMapping (impactId, ticketTypeid, deleted,serviceid)
	--select impactId, ticketTypeid, deleted,543 from ImpactTicketTypeMapping where serviceId = 194


select d.deviceId, d.deviceName from DeviceServiceMapping DS 
inner join Device D on d.deviceId = ds.deviceId
where ds.serviceId = 543 and d.deleted = 0 and ds.deleted = 0

--Insert into DeviceServiceMapping

--select 543, deviceId, deleted, ticketTypeId from DeviceServiceMapping where serviceId =  194

select * from Workgroup where workgroup like '%Taxilla%'  ---> 767 Taxilla

select * from AssignmentGroup where workgroupId = 767 -----> 902

select * from CustomerAssignmentGroupMapping where assignmentgroupId = 902  ---> 3065

select top 100 * from AutoCloseInfo  where serviceId = 543 and WorkgroupId = 2

--insert into AutoCloseInfo (customerid,	customerName,	autocloseTime,	ticketTypeID,	closureCode,	closureCodeText,	userID,
--isActive,	serviceid,	workgroupid)

--values (167, 'Eureka Forbes Limited', 2880,	1,	1031,	'Auto Close',	5,	'Active',543,767),
--       (167, 'Eureka Forbes Limited', 2880,	2,	1032,	'Auto Close',	5,	'Active',543,767)

select * from Users where email like '%rshah.x@taxilla.com%'  ---> 6

--brijesh.shah@eurekaforbes.com
--rshah.x@taxilla.com


--insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
--values (6, 3065, 0,1, 1)

-----> Rules For Priority: 
-----> Rules For Assignment:

 select * from RulesForPriority where customerid = 167 and Deleted = 0

 select * from Priority where ticketTypeId = 2 ---> P2 5 , 14	SR3

-- 5	Low (1 Person Affected)
--6	Medium (Department Effected)
--7	High (Organization Effected)

select * from Category C
inner join ServiceCategoryMapping CM on C.categoryId = CM.categoryId
where CM.serviceId = 543  and  -----> 



select c.categoryId, c.category, s.subCategoryId, s.subCategory, cc.classificationId, cc.classification from Category C
inner join SubCategory S on c.categoryId = s.categoryId
inner join Classification CC on cc.subCategoryId = s.subCategoryId
where c.deleted = 0 and s.deleted = 0 and cc.deleted =0 and c.categoryId in (
 5892
,5893
,5894
,5895
,5896
,5897
,5898
,5899
,5900
)


select * from Impact


-- Insert into RulesForPriority (RuleDescr, PriorityRule, PriorityId, ImpactId, RulePriority, Deleted, RuleTemplateId, customerid)
-- values 
--('Eureka Forbes Limited', '{customerid=167;serviceid=543;categoryid=5892;subcategoryid=22777;classificationid=91089;tickettypeid=1;}',5, 7,1,0,1890,167),
--('Eureka Forbes Limited', '{customerid=167;serviceid=543;categoryid=5892;subcategoryid=22777;classificationid=91090;tickettypeid=1;}',5, 7,1,0,1890,167),
--('Eureka Forbes Limited', '{customerid=167;serviceid=543;categoryid=5893;subcategoryid=22778;classificationid=91091;tickettypeid=1;}',5, 7,1,0,1890,167),
--('Eureka Forbes Limited', '{customerid=167;serviceid=543;categoryid=5894;subcategoryid=22779;classificationid=91092;tickettypeid=1;}',5, 7,1,0,1890,167),
--('Eureka Forbes Limited', '{customerid=167;serviceid=543;categoryid=5895;subcategoryid=22780;classificationid=91093;tickettypeid=1;}',5, 7,1,0,1890,167),
--('Eureka Forbes Limited', '{customerid=167;serviceid=543;categoryid=5896;subcategoryid=22781;classificationid=91094;tickettypeid=1;}',5, 7,1,0,1890,167),
--('Eureka Forbes Limited', '{customerid=167;serviceid=543;categoryid=5897;subcategoryid=22782;classificationid=91095;tickettypeid=1;}',5, 7,1,0,1890,167),
--('Eureka Forbes Limited', '{customerid=167;serviceid=543;categoryid=5898;subcategoryid=22783;classificationid=91096;tickettypeid=1;}',5, 7,1,0,1890,167),

--('Eureka Forbes Limited', '{customerid=167;serviceid=543;categoryid=5899;subcategoryid=22784;classificationid=91097;tickettypeid=2;}',14, 6,1,0,1890,167),
--('Eureka Forbes Limited', '{customerid=167;serviceid=543;categoryid=5900;subcategoryid=22785;classificationid=91098;tickettypeid=2;}',14, 6,1,0,1890,167)


select top 100 * from RulesForAssignment where customerId = 167
order by 1 desc

--Insert into RulesForAssignment (RuleDescr, AssignmentRule, PrimaryAssignmentGroupId, SecondaryAssignmentGroupId, RulePriority, Deleted, RuleTemplateId,
--customerId, AssignmentType, AssignToId, NoOfParams)
--values 
--('Rule','{customerId=167;serviceId=543;categoryId=5892;}', 902, 902, 1, 0, 91, 167, 1, 0, 3 ),
--('Rule','{customerId=167;serviceId=543;categoryId=5893;}', 902, 902, 1, 0, 91, 167, 1, 0, 3 ),
--('Rule','{customerId=167;serviceId=543;categoryId=5894;}', 902, 902, 1, 0, 91, 167, 1, 0, 3 ),
--('Rule','{customerId=167;serviceId=543;categoryId=5895;}', 902, 902, 1, 0, 91, 167, 1, 0, 3 ),
--('Rule','{customerId=167;serviceId=543;categoryId=5896;}', 902, 902, 1, 0, 91, 167, 1, 0, 3 ),
--('Rule','{customerId=167;serviceId=543;categoryId=5897;}', 902, 902, 1, 0, 91, 167, 1, 0, 3 ),
--('Rule','{customerId=167;serviceId=543;categoryId=5898;}', 902, 902, 1, 0, 91, 167, 1, 0, 3 ),
--('Rule','{customerId=167;serviceId=543;categoryId=5899;}', 902, 902, 1, 0, 91, 167, 1, 0, 3 ),
--('Rule','{customerId=167;serviceId=543;categoryId=5900;}', 902, 902, 1, 0, 91, 167, 1, 0, 3 )


-----> SLA Configurations: 

select  * from ServiceLevelObjective  where serviceId = 92 and serviceLevelAgreementId = 23 
select  * from ServiceLevelObjective  where serviceId = 93 -- and serviceLevelAgreementId = 23 

select * from ServiceLevelAgreement where customerId = 167  -----> 139 IM, 140 SR

select * from ServiceCustomerMapping where serviceid= 194 

----> 9am to 6pm	Monday to Friday  ---> 28	9:00am to 6:00pm Mon to Fri	9:00am to 6:00pm Mon to Fri	India Standard Time


select * from ServiceLevelObjective where serviceId = 194 
and serviceLevelAgreementId = 140  and workgroupId = 338  and holidayCalendarId = 83 -- and priorityId = 5
and serviceLevelObjectiveTypeId = 2

select distinct workhourId from ServiceLevelObjective where serviceId = 194 
and serviceLevelAgreementId = 139 ---> and workgroupId = 338 and priorityId = 5 -- and holidayCalendarId = 0
and serviceLevelObjectiveTypeId = 2

select * from WorkHours where workHourId = 14

--Insert into ServiceLevelObjective 

select distinct  serviceLevelAgreementId , serviceLevelObjectiveTypeId,initialStatusId,finalStatusId, responseTimeInMin,excludeStatusIds,543 serviceId,priorityId
,impactId,83 holidayCalendarId,28 workHourId,0 is24X7Service,locationId,767 workgroupId,isDelete,isDefault from ServiceLevelObjective
where serviceId = 194 and serviceLevelAgreementId = 139  and isDelete = 0   and serviceLevelObjectiveTypeId = 1

---> 4,5,6,7

--and impactId = 7
--and holidayCalendarId = 0

--Insert into ServiceLevelObjective (serviceLevelAgreementId , serviceLevelObjectiveTypeId,initialStatusId,finalStatusId, responseTimeInMin,excludeStatusIds,
--serviceId,priorityId,impactId, holidayCalendarId, workHourId, is24X7Service,locationId, workgroupId,isDelete,isDefault)
--values
--(140, 2, 64, 19, 30, '15,16,17,18', 543, 6, 1, 83, 28, 0, 0, 767, 0, 0),
--(140, 2, 64, 19, 30, '15,16,17,18', 543, 6, 5, 83, 28, 0, 0, 767, 0, 0),
--(140, 2, 64, 19, 30, '15,16,17,18', 543, 6, 6, 83, 28, 0, 0, 767, 0, 0),
--(140, 2, 64, 19, 30, '15,16,17,18', 543, 6, 7, 83, 28, 0, 0, 767, 0, 0),
			
--(140, 2, 64, 19, 240, '15,16,17,18', 543, 10, 1, 83, 28, 0, 0, 767, 0, 0),
--(140, 2, 64, 19, 240, '15,16,17,18', 543, 10, 5, 83, 28, 0, 0, 767, 0, 0),
--(140, 2, 64, 19, 240, '15,16,17,18', 543, 10, 6, 83, 28, 0, 0, 767, 0, 0),
--(140, 2, 64, 19, 240, '15,16,17,18', 543, 10, 7, 83, 28, 0, 0, 767, 0, 0),
			
--(140, 2, 64, 19, 240,'15,16,17,18', 543, 14, 1, 83, 28, 0, 0, 767, 0, 1),
--(140, 2, 64, 19, 240,'15,16,17,18', 543, 14, 5, 83, 28, 0, 0, 767, 0, 1),
--(140, 2, 64, 19, 240,'15,16,17,18', 543, 14, 6, 83, 28, 0, 0, 767, 0, 1),
--(140, 2, 64, 19, 240,'15,16,17,18', 543, 14, 7, 83, 28, 0, 0, 767, 0, 1),
			
--(140, 2, 64, 19, 480,'15,16,17,18', 543, 15, 1, 83, 28, 0, 0, 767, 0, 0),
--(140, 2, 64, 19, 480,'15,16,17,18', 543, 15, 5, 83, 28, 0, 0, 767, 0, 0),
--(140, 2, 64, 19, 480,'15,16,17,18', 543, 15, 6, 83, 28, 0, 0, 767, 0, 0),
--(140, 2, 64, 19, 480,'15,16,17,18', 543, 15, 7, 83, 28, 0, 0, 767, 0, 0)


----> 
----> Need to configure the NotificationRules: 

select * from Service where ServiceId = 194   ----> 194

--Insert into NotificationRules

--select customerId,2	ticketTypeId, null	priorityId,	duePercent,	notificationMode,	notificationTo,'brijesh.shah@eurekaforbes.com;rshah.x@taxilla.com'	notificationCC,	templateId,	ruleName,767	workgroupid,	supportgroupid,
--543 serviceId,	notifyBasedOnId,	entryStateId,	deleted,	categoryId,	interval,	numberOfOccurence

--from NotificationRules 
--where customerId = 167 and deleted = 0 and serviceId = 194 and duePercent is null and priorityId =14
--and workgroupid is null

select * from NotificationRules 
where customerId = 167 and deleted = 0 and serviceId = 543 and duePercent is null and priorityId = 14
and workgroupid is null


------------------> SR Approvals:

select * from Asset_users where EmailId like  '%raja.roy@eurekaforbes.com%'  ---

select ID, * from Asset_users where EmailId ='raja.roy@eurekaforbes.com'  --->   100196   raja.roy@eurekaforbes.com

select * from Asset_users where EmailId like  '%brijesh.shah@eurekaforbes.com%'  ----> 84396  brijesh.shah@eurekaforbes.com

select  * from UserDepartmentRole where userEmailId like  '%raja.roy@eurekaforbes.com%'   ----> 235 raja.roy@eurekaforbes.com

select  * from UserDepartmentRole where userEmailId like  '%brijesh.shah@eurekaforbes.com%'   ----> 232  brijesh.shah@eurekaforbes.com

--Insert into Asset_users (FirstName, LastName, DisplayName, EmailId, Alias, isdeleted, customerId, id)
--values ('raja', 'roy', 'raja roy', 'raja.roy@eurekaforbes.com', 'raja.roy', 0, 167, 100196)


select top 100 * from Approval order by 1 desc  ----> 2990062  4463

--delete from Approval  where approvalNo = 2990062




	 ---------------> New configurations for SR Approvals:
	 
	 --step 1:

	  select top 100 * from ApprovalMatrix order by 1 desc  ----> 804

	  --Insert into ApprovalMatrix 

	  --select 'EFL_Taxilla', 'EFL_Taxilla', 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, NULL

	  ----> Step 2:

	  select top 100 * from ApprovalEntityMapping 
	  where customerId = 167 and deleted = 0 and approvalEntityMappingId = 2832

	  --Insert into ApprovalEntityMapping

	  --select 2, 'TICKET', 167, 'Eurekaforbes Limited', '{customerid=167;serviceid=543;categoryid=5899;subcategoryid=22784;classificationid=91097;tickettypeid=2;}',
	  --NULL, 1, 804, 1890, NULL, 0, 0, null, 1

	  --union all

	  --select 2, 'TICKET', 167, 'Eurekaforbes Limited', '{customerid=167;serviceid=543;categoryid=5900;subcategoryid=22785;classificationid=91098;tickettypeid=2;}',
	  --NULL, 1, 804, 1890, NULL, 0, 0, null, 1

	  ---> step 3

	  select top 100 * from ApprovalMatrixLevel order by 1 desc

	  --Insert into ApprovalMatrixLevel 

	  ----select 804, 'Level 1', 'EFL_Taxilla', NULL, 1, 0, 0, NULL, 1, 6, 'smcAdmin', getdate(), 6, 'smcAdmin', getdate(), 0, 0, 1

	  ----UNION ALL

	  --select 804, 'Level 1', 'EFL_Taxilla', 1444, 1, 0, 0, NULL, 1, 6, 'smcAdmin', getdate(), 6, 'smcAdmin', getdate(), 0, 1, 1
	   
	  --Update ApprovalMatrixLevel set levelName = 'Level 2' where levelId = 1445

--levelId	approvalMatrixId	levelName	levelDescription
--1445	804	Level 2	EFL_Taxilla
--1444	804	Level 1	EFL_Taxilla

	  ---> Step 4:


	   select top 100 * from ApprovalMatrixApprover where levelId = 1018

	   select top 100 * from ApprovalMatrixApprover order by 1 desc


	   --insert into ApprovalMatrixApprover 

	   --select 235, 100196, 'Raja Roy', 1444, 'Level 1', 1, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 1, 1, 1, NULL, 1
	   --UNION ALL
	   --select 232, 84396, 'Brijesh Shah', 1445, 'Level 2', 1, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 1, 1, 1, NULL, 1

	   --  INSU-010855  

	  
select * from Role  --111,110


select * from MenuMaster where menuName like '%Asset%'
261
262

select * from MenuMaster where menuID in (
select menuID from MenuRoleMapping where roleID in (111,110) and menuID in (261,262))

select * from MenuRoleMapping where roleID in (111,110) and menuID in (261,262)

--update MenuRoleMapping set isdeleted = 1 where id in (4148
--,4149
--,4151
--,4152)

select * from customer where customerName like '%Khai%'  --199
select * from AssetEntityTypeCustomerMapping where CustomerId = 199

--update AssetEntityTypeCustomerMapping set IsDeleted = 1 where CustomerId = 199

select * from Assets where CustomerId = 199 and (isDeleted is Null or isDeleted = 0);

--update Assets set isDeleted = 1  where CustomerId = 199 and (isDeleted is Null or isDeleted = 0);


--Select * INTO Asset_EntityTypeUserMapping_23122020
--from Asset_EntityTypeUserMapping where userId in (select userId from users where roleId in (111,110));


select * from [dbo].[Asset_EntityTypeUserMapping] where userId in (select userId from users where roleId in (111,110))

--update [Asset_EntityTypeUserMapping] set isDeleted = 1 where userId in (select userId from users where roleId in (111,110))


select  * from [dbo].[Asset_AutoDiscoverConfiguration] where CustomerId = 199

--update [Asset_AutoDiscoverConfiguration] set isDeleted = 1  where CustomerId = 199


select top 10 * from [dbo].[Asset_UserTypeMapping]


select top 10 * from   where AssetuserId  = 6

select * from Asset_users where DisplayName like '%Jayesh%'


select * from users where roleId in (111,110)

select * from users where displayName like '%Jayesh%'

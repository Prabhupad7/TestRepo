

    select * from Service where serviceName like '%Database Management%' --->  2
   
    select * from Category where   category like '%Software%'

		select * from ServiceCategoryMapping where serviceId =15
    and  categoryId in (
    select categoryId from Category where   category like '%Vendor Onboarding%'
    )

	select * from ServiceCategoryMapping where serviceId =47
    and  categoryId in ()

   ---> 780, 782

	select * from Category where category like '%Auto Ticket%'
	
	select * from Category where category ='Access'

	select * from ServiceCategoryMapping where serviceId = 2 and 
	categoryId in ( select categoryId from Category where category ='Wso2')


	select * from ServiceCategoryMapping where serviceId = 14 and categoryId = 55




	select * from SubCategory where categoryId in ( 633)
    and subCategory like '%AV Defin not%'  -- 45



	select * from SubCategory where categoryId in( 880
,878
,878
,881
 ) and subCategory in (
	'New Business')

	Update SubCategory set subCategory = 'Data Update - Claims' where subCategoryId = 4473

	
	select * from Classification where subCategoryId in (
	4261
,4262
,4265
,4266) 
	and classification in (
	'Others-Undefined'
	) 

	Update Classification set classification = 'Others-Undefined' where classificationId in (
	7735) 

	Update Classification set deleted = 0 where classificationId = 1976

	order by classification


    --'%keyboard  Undefined%' -->  45

	-- update Classification set deleted =1 where classificationId in (
 	976
	  )
 

	-->  55	Asset -Missing  

	delete q
  from classification q
  where exists
  (
    select *
      from classification q2
      where q2.[specimen id] = q.[specimen id] and
        q2.quicklabdumpID > q.quicklabdumpID
  )


  WITH cte AS
( SELECT  deviceId,deviceName,ipAddress,  ROW_NUMBER() OVER ( PARTITION BY deviceName,ipAddress ORDER BY deviceName,ipAddress)
row_num  FROM  device where customerId=167 and deleted=0  )
SELECT * FROM cte WHERE row_num > 1;
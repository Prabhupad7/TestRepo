


    select * from Ticket where ticketNo ='800656'

    select top 100 ApprovalCompletedTime,* from Approval
	order by 1 desc

    select ApprovalCompletedTime,* from Approval where approvalNo in(747729 , 800656, 788309  )

  --Update Approval set

  --isSourceCreated = 1, ApprovalCompletedTime = getdate()

  --where approvalNo = 788309



select * from PendingReasons where customerId = 167 and ticketTypeid = 3

	 select * from Asset_users where EmailId like '%RahulRA3@microland.com%'  ---> 21062

	 select * from Asset_users where EmailId like '%SuvarnaKR@microland.com%'  ---> 100773

	 select * from Asset_users where id = 100773  ---> 

	 select * from Asset_users where FirstName like '%Pravin.patil@eurekaforbes.com%' ---> 25673 anjali@eurekaforbes.co.in

	 select * from Asset_users where id in ( 29071, 25673 ) ---> 29071 shailendra@eurekaforbes.co.in

	 select top 100 * from UserDepartmentRole where userEmailId like '%anjali@eurekaforbes.co.in%'  ----> userTypeId:  270 anjali@eurekaforbes.co.in

	 select top 100 * from UserDepartmentRole where userEmailId like '%shailendra@eurekaforbes.co.in%'  ----> userTypeId:  90 Shailendra@eurekaforbes.co.in

	 select top 100 * from UserDepartmentRole where userEmailId like '%Pravin.patil@eurekaforbes.com%'

	 select top 100 * from UserDepartmentRole where  userTypeid in (90, 270,83)


Step 1: 

	 select top 100 * from ApprovalMatrix where approvalMatrixId = 619  ----> 531

	 select top 1000 * from ApprovalMatrix where approvalMatrixName like '%EFL%' ---> 804	EFL_Taxilla

	 --Insert into ApprovalMatrix 

	 --select 'EFL SAP EUROPLAN', 'EFL SAP EUROPLAN', 6, 'smcadmin', GETDATE(), 6,'smcadmin', GETDATE(), 0, NULL

	 ---> 805	EFL SAP EUROPLAN

Step2: 

        select top 100 * from ApprovalMatrixLevel where approvalMatrixId in ( 804,805 )

		select top 100 * from ApprovalMatrixLevel ORDER by 1 desc

--		Insert into ApprovalMatrixLevel 

--values (805, 'Level 2', 'EFL SAP EUROPLAN', 1446, 1, 0, 0, NULL, 1, 6, 'smcAdmin', GETDATE(), 6, 'smcAdmin', GETDATE(), 0 , 1, 1)

Step 3: 

	 select top 100 * from ApprovalMatrixApprover where levelId in (1444,1445) 

	 select top 100 * from ApprovalMatrixApprover where levelId in (1446,1447) 

	 --Insert into ApprovalMatrixApprover 

	 --select 270, 25673, 'Anjali Murthy',1446,'Level 1', 1, 6, 'smcadmin', getdate(), 6, 'smcadmin', getdate(), 0, 1,1,1,NULL, 1
	 --UNION ALL
	 --select 90, 29071, 'Shailendra Kulkarni',1447,'Level 2', 1, 6, 'smcadmin', getdate(), 6, 'smcadmin', getdate(), 0, 1,1,1,NULL, 1

Step 4: 

	 select top 1000 * from ApprovalEntityMapping 
	 where customerid = 167 and approvalEntityMappingId in (4462, 4463, 4464)

	 --Insert into ApprovalEntityMapping 

	 --select 2, 'TICKET', 167, 'Eurekaforbes Limited', '{customerid=167;serviceid=550;categoryid=6029;subcategoryid=23013;classificationid=91476;tickettypeid=2;}',
	 --NULL, 1, 805, 1890, NULL, 0, 0, NULL, 1

	 --------------> Approval Tickets pending with others: 

	 	 select distinct A.approvalNo, a.sourceTypeName, a.sourceDescription, a.approvalCreatedOn,A.
	  from Approval A 
	 inner join ApprovalEntityMapping E on A.approvalEntityMappingId = E.approvalEntityMappingId
	 inner join ApprovalMatrixLevel L on L.approvalMatrixId = E.approvalMatrixId
	 inner join ApprovalMatrixApprover M on M.levelId = l.levelId
	 where M.approverId = 28112 and e.deleted = 0 and m.deleted = 0 and l.deleted = 0 and A.ApprovalCompletedTime is null
	 and A.approvalNo in (3083287,


select * from (select distinct a.*  from ApprovalEntityLevelDetails a
join ApproverEntityApproval aea on aea.sourceId = a.sourceId and a.levelId = aea.approverLevelId
join approval app on app.approvalNo=a.sourceId and app.sourceTypeId = a.entityTypeId and app.sourceTypeName = a.entityTypeName
join (select aus.ManagerId,ap.approvalNo from approval ap
join Requestor r on r.requestorId = ap.sourceRequestorId
join Asset_users aus on LTRIM(rtrim(lower(aus.EmailId))) = LTRIM(rtrim(lower(r.requestorEmail)))
where ap.isApprovalInitiated = 1 ) manager on manager.approvalNo = a.sourceId
 join Asset_users au on au.id = manager.ManagerId
Where  aea.approverName is null and app.ApprovalCompletedTime is null and aea.approvalDateTime is null and a.isFullyApproved=0
and  LTRIM(rtrim(lower(au.EmailId))) = 'pravin.patil@eurekaforbes.co.in' and app.sourceCustomerId= 167


union 


select distinct a.* from ApprovalEntityLevelDetails a
join ApproverEntityApproval aea on aea.approverLevelId = a.levelId and aea.sourceId = a.sourceId
join Asset_users au on au.id = aea.approverId
join approval ap on ap.approvalNo = a.sourceid and ap.sourceTypeId = a.entityTypeId and ap.sourceTypeName = a.entityTypeName
Where LTRIM(rtrim(lower(au.EmailId))) = 'pravin.patil@eurekaforbes.co.in'
and ap.ApprovalCompletedTime is null and aea.approvalDateTime is null 
and ap.isApprovalInitiated = 1 and ap.sourceCustomerId= 167 and a.isFullyApproved=0
) as result ORDER by result.sourceId DESC 
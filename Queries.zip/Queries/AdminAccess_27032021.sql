

select top 10 * from Admin_UserCustomerAdminMapping  order by 1  ---->  221

--->  PramodPK@microland.com

select instanceId,* from Users where email like '%PramodPK@microland.com%' ---->  1669

select instanceId,* from Users where email like '%i_raviprakashk@microland.com%' ---->  26459

select * from Admin_UserCustomerAdminMapping  where UserId = 25872  ---->  

select  * from Admin_UserCustomerAdminMapping  where UserId in(   26710)
order by 1 

select distinct C.customerid from CustomerAssignmentGroupMapping C
inner join    UserCustomerAssignGroupMapping U 
on U.custAssignmentGroupId = C.custAssignmentGroupId
where userId = 26710 and c.deleted = 0 and u.deleted = 0



select * from Admin_UserCustomerAdminMapping  where UserId = 26660  ---->  

---> Step 1 : Set level ID =1 
---> Step 2 : Configure in Admin_UserCustomerAdminMapping

--Update Users set levelId  =1 where userid in (25872, 26753,26660)

--Insert into Admin_UserCustomerAdminMapping (UserId, CustomerID, InstanceID, CreatedOn, CreatedBy, UpdatedOn, updatedby, Deleted)

--select 26459, CustomerID, InstanceID, GETDATE(), CreatedBy, GETDATE(), updatedby, Deleted 
--from Admin_UserCustomerAdminMapping  where UserId = 6  and Deleted = 0


select * from MenuMaster  where menuUrl like '%Admin%'  ---->  220

select * from MenuRoleMapping where roleID = 75 and menuID = 220 ---->  

--Insert into Admin_UserCustomerAdminMapping (UserId, CustomerID, InstanceID, CreatedOn, CreatedBy, UpdatedOn, updatedby, Deleted)
--values 
--(26660, 3,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 4,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 8,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 61,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 147,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 158,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 160,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 167,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 168,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 169,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 188,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 189,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 192,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 194,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 203,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 207,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 214,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 215,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 217,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 218,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 219,0, GETDATE(), 6, GETDATE(), 6, 0),
--(26660, 221,0, GETDATE(), 6, GETDATE(), 6, 0)

--update Admin_UserCustomerAdminMapping set Deleted =1 where UCAMID in (
--1187
--,1188
--,1189
--,1190
--,1191
--,1192)



﻿


select * from Users where email like '%AbhishaiBV@microland.com%' ----->   1814

select * from Users where loginName like '%smcadmin%' ----->   6

select * from Workgroup where workgroup like '%Infosec%' --->  206


select  * from Admin_UserCustomerAdminMapping  where UserId in(   26710)
order by 1 

select distinct C.customerid from CustomerAssignmentGroupMapping C
inner join    UserCustomerAssignGroupMapping U 
on U.custAssignmentGroupId = C.custAssignmentGroupId
where userId = 26710 and c.deleted = 0 and u.deleted = 0


select * from AssignmentGroup where workgroupId = 206   ---->   322

select * from CustomerAssignmentGroupMapping where assignmentgroupId = 322 --- 2926	ML SOC - InfoSec	211	ML SOC	322

select * from UserCustomerAssignGroupMapping 
where userId = 1527 and custAssignmentGroupId = 2926

select * from Workgroup where workgroup like '%Servicedesk%'  --->   200	ML IT Servicedesk	ML IT Servicedesk	helpdesk@microland.com

select * from AssignmentGroup where workgroupId = 200   ---->   317

select * from CustomerAssignmentGroupMapping where assignmentgroupId = 317  

select * from Customer where customerName like '%ML%' ---->   211	ML SOC

select * from CustomerAssignmentGroupMapping where customerId = 211

---->  Ask ML - ML IT Servicedesk

select * from UserCustomerAssignGroupMapping 
where userId = 6 and custAssignmentGroupId = 1218


select * from UserCustomerAssignGroupMapping 
where userId = 5 and custAssignmentGroupId = 1218

--update UserCustomerAssignGroupMapping set isAssignEnabled = 1  where userCustomerAssignGroupId = 54390


  select workgroupId,* from ticket where ticketNo = 2809475 ---->   247

  select * from Workgroup where workgroupId = 247  

  select * from workGroupEscalationMatrix_AskML where workGroupId = 247

  --Insert into workGroupEscalationMatrix_AskML (CustomerId, WorkgroupName, Level1Name, Level1Extension, Level1Email, 
  --Level2Name, Level2Extension, Level2Email,Level3Name, Level3Extension, Level3Email, workGroupId)

  --select CustomerId, 'Remote Resolution Group', Level1Name, Level1Extension, Level1Email, 
  --Level2Name, Level2Extension, Level2Email,Level3Name, Level3Extension, Level3Email, 247
  --from workGroupEscalationMatrix_AskML where workGroupId = 200 and CustomerId = 147

  ---->  5318 4910 2449 1901

--  https://itsupport.microland.com

--  [2:30 PM] Manuchandan C
--    https://itsupport.microland.com
--​[2:30 PM] Manuchandan C
--    manuchandancv@microland.com
--​[2:31 PM] Manuchandan C
    
--  YuvarajS@Microland.com
------------------------------->


  select * from users where email like '%manuchandancv@microland.com%' ---->  25695	Manuchandan


  YuvarajS@microland.com      918431778745
   

   select * from users where loginName = 'LikhithoshSk' ------> 4 LikhithoshSK@microland.com likhithoshsk  25469

   select * from ReportMaster where  24



   select * from ReportRoleMapping where roleid = 4 and reportMasterID = 24

   --Insert into ReportRoleMapping (Roleid, reportMasterID, IsDeleted)

   --select 4, 24, 0

    select w.workgroupId, w.workgroup from CustomerAssignmentGroupMapping CA
 inner join AssignmentGroup AG on AG.assignmentgroupId = CA.assignmentgroupId
 inner join Workgroup W on W.workgroupId = Ag.workgroupId
 where CA.customerId = 68 and ca.deleted =0 and w.deleted=0 --- and W.workgroupId in ( 2,3,4,5,9,10,13,47,104,169,442,490,492,523,541,556,609 )

 

 select * from UserCustomerAssignGroupMapping 
 where deleted =0 and userid = 1814


 select * from CustomerAssignmentGroupMapping where custAssignmentGroupId in (
  select custAssignmentGroupId from UserCustomerAssignGroupMapping 
 where deleted =0 and userid = 1814)

 select * from customer where customerid = 218 



  select * from CustomerAssignmentGroupMapping where customerid = 218

  ---->  2988	Bunge - RMC Database	218	RMC Database

--  Update UserCustomerAssignGroupMapping set deleted = 0 where userid = 1814 and   custAssignmentGroupId in (
--  2988
--)

  select * from UserCustomerAssignGroupMapping 
 where  userid = 1814

     select w.workgroupId, w.workgroup from CustomerAssignmentGroupMapping CA
 inner join AssignmentGroup AG on AG.assignmentgroupId = CA.assignmentgroupId
 inner join Workgroup W on W.workgroupId = Ag.workgroupId
 where CA.customerId = 218 and ca.deleted =0 and w.deleted=0 
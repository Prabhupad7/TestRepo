

select createdOn,sr.resolvedTime ,* from Ticket T
inner join ServiceRequestTicket SR on Sr.ticketno = T.ticketno
---> incidentTicket
where T.ticketno = 2842408

select * from servicelevelTracking where sourceid = 2842408

--update ticket set createdOn= select startTime from servicelevelTracking where 
--where ticketno = 2842408

--update ticket set createdOn= ''
--where ticketno = 2842408



--Timing in Ticket              Timings in Excel Sheet:
--Feb 1, 2021 21:12:44          2/2/2021  2:12:44 AM      
--Feb 1, 2021 21:58:50          2/1/2021  9:58:50 PM


select distinct (t.ticketNo),t.createdOn,sl.startTime  from ticket t inner join ServiceLevelTracking sl
on t.ticketNo = sl.sourceId where sl.serviceLevelObjectiveTypeId = 1 and  t.createdOn > sl.startTime 
and sl.startTime between '2020-12-01' and '2021-03-16' and t.customerid = 194
 

 select distinct (t.ticketNo),t.createdOn,sl.startTime  from ticket t inner join ServiceLevelTracking sl
on t.ticketNo = sl.sourceId where sl.serviceLevelObjectiveTypeId = 1 and  t.createdOn > sl.startTime 
and sl.startTime between '2021-03-09' and '2021-03-16' and t.customerid = 194
 
 

--update ticket set createdon = sl.startTime  from ticket t inner join ServiceLevelTracking sl
--on t.ticketNo = sl.sourceId where sl.serviceLevelObjectiveTypeId = 1 and  t.createdOn > sl.startTime
-- and sl.startTime between '2020-12-01' and '2020-12-10' and t.customerid = 194
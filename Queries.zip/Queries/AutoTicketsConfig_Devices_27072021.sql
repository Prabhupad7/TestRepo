

select * from Customer where customerId = 220   ----> 220	Aveva

select * from Customer where customerName like '%Bunge%' 218	Bunge

select * from Customer where customerId = 167   ----> 167	Eureka Forbes Limited

select * from Device where customerId =  220 and deleted = 0

select * from DeviceServiceMapping where deviceId in (34062,34063,34064)  ----> serviceId: 537

--     INSERT INTO device(devicename, alternateName, ipAddress, customerId, deleted, hostName) 
--	  values 
--('AEDBXHFW001','AEDBXHFW001','10.84.127.20',220,0,'AEDBXHFW001'),
--('AUBRIHFW001','AUBRIHFW001','10.96.111.20',220,0,'AUBRIHFW001'),
--('AUPERHFW001','AUPERHFW001','10.96.191.20',220,0,'AUPERHFW001'),

--     INSERT INTO device(devicename, alternateName, ipAddress, customerId, deleted, hostName) 
--	  values 
--('MININT-7A1CVVN','MININT-7A1CVVN','10.63.143.6',218,0,'MININT-7A1CVVN'),
--('MININT-8QIRJ8G','MININT-8QIRJ8G','10.63.143.8',218,0,'MININT-8QIRJ8G'),
--('MININT-9AUTARG','MININT-9AUTARG','10.63.143.11',218,0,'MININT-9AUTARG'),
--('MININT-EGVE5BK','MININT-EGVE5BK','10.63.143.9',218,0,'MININT-EGVE5BK'),
--('MININT-N789ALP','MININT-N789ALP','10.63.143.18',218,0,'MININT-N789ALP'),
--('MININT-R30Q7IK','MININT-R30Q7IK','10.63.143.12',218,0,'MININT-R30Q7IK'),
--('MININT-RBUCQTT','MININT-RBUCQTT','10.63.143.10',218,0,'MININT-RBUCQTT'),
--('MOH-NT-DB1','MOH-NT-DB1','10.63.100.171',218,0,'MOH-NT-DB1'),
--('MOH-NT-TRVS01','MOH-NT-TRVS01','10.63.129.14',218,0,'MOH-NT-TRVS01')





select top 9 * from Device 
where customerId  = 218 order by 1 desc

40916
40915
40914
40913
40912
40911
40910
40909
40908


          select * from DeviceServiceMapping where deviceid = 40319


		   --   INSERT INTO DeviceServiceMapping (serviceId, deviceId , deleted, ticketTypeId)
			  VALUES (532, 40916, 0,4),
			         (532, 40915, 0,4),
					 (532, 40914, 0,4),
					 (532, 40913, 0,4),
					 (532, 40912, 0,4),
					 (532, 40911, 0,4),
					 (532, 40910, 0,4),
					 (532, 40909, 0,4),
					 (532, 40908, 0,4)



select * from RulesForAssignment where customerId = 220

select * from ApiKey where customerId = 220  ---> 139

select * from ApiKey where customerId = 167  ---> 67	DE7D749D-F506-49A2-BDF4-18B496BF4C7E

select * from AutoTicketServiceRule where apiKeyId = 67  ---> and deviceId in (10823) 

select * from Apikey where customerid = 194

select * from AutoTicketServiceRule
where deviceId in (10823,10428)

select top 31 id, deviceId, * from AutoTicketServiceRule where apiKeyId = 139 order by 1 desc

select * from Classification where classificationId = 78775

select top 100 * from AutoTicketServiceRuleDetails 
where autoTicketServiceRuleId in ( select Id from AutoTicketServiceRule where apiKeyId = 67 )


select top 100 * from AutoTicketServiceRuleDetails  

--Insert into AutoTicketServiceRule (Name, IsDefault, TicketTypeId, RequestorId, ServiceId, CategoryId, SubCategoryId, ClassificationId, ImpactId, 
--PriorityId, CreatedById, CreatedOn, apiKeyId, deviceId, requesorLocationId, isDeleted)

--values 
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40902, 4386, 0),


--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40754, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40753, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40752, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40751, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40750, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40749, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40748, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40747, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40746, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40745, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40744, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40743, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40742, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40741, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40740, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40739, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40738, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40737, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40736, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40735, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40734, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40733, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40732, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40731, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40730, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40729, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40728, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40727, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40726, 4386, 0),
--('Device Rule', 0, 1, 58155, 537, 5797, 22183, 90254, 5, 9, 6, GETDATE(), 139, 40725, 4386, 0)

select top 31 * from AutoTicketServiceRule -- where id in (1031464, 1031465)
where apiKeyId = 139 order by 1 desc

--select distinct M.Id, M.deviceId, d.deviceId, d.deviceName, S.autoTicketServiceRuleId 
--from AutoTicketServiceRule M
--inner join Device D on M.deviceId =  D.deviceId
--inner join AutoTicketServiceRuleDetails S on S.autoTicketServiceRuleId in (
--1031463,1031462,1031461,1031460,1031459,1031458,1031457,1031456,1031455,1031454,1031453,1031452,1031451,1031450,
--1031449,1031448,1031447,1031446,1031445,1031444,1031443,1031442,1031441,1031440,1031439,1031438,1031437,1031436,1031435,
--1031434,1031433)
--where d.deviceId in
--(40725,40726,40727,40728,40729,40730,40731,40732,40733,40734,40735,40736,40737,40738,40739,40740,40741,40742,
--40743,40744,40745,40746,40747,40748,40749,40750,40751,40752,40753,40754,40755)


--insert into AutoTicketServiceRuleDetails 
--values 
--(5, 'contains', 'AUSYDHFW001', 0, 'contains', 1031466),
--(4, 'contains', 'AUSYDHFW001', 0, 'contains', 1031466),


--(5, 'contains', 'NLAMQA001.aveva.com', 0, 'contains', 1031461),
--(5, 'contains', 'NLAMQA001.aveva.com', 0, 'contains', 1031460),
--(5, 'contains', 'NLAMQA001.aveva.com', 0, 'contains', 1031459),
--(5, 'contains', 'NLAMQA001.aveva.com', 0, 'contains', 1031458),


--(4, 'contains', 'NLAMQA001.aveva.com', 0, 'contains', 1031463),
--(4, 'contains', 'NLAMQA001.aveva.com', 0, 'contains', 1031462),
--(4, 'contains', 'NLAMQA001.aveva.com', 0, 'contains', 1031461),
--(4, 'contains', 'NLAMQA001.aveva.com', 0, 'contains', 1031460),
--(4, 'contains', 'NLAMQA001.aveva.com', 0, 'contains', 1031459),
--(4, 'contains', 'NLAMQA001.aveva.com', 0, 'contains', 1031458),

select * from AutoTicketServiceRuleDetails where autoTicketServiceRuleId in (
1031463,1031462,1031461,1031460,1031459,1031458,1031457,1031456,1031455,1031454,1031453,1031452,1031451,1031450,
1031449,1031448,1031447,1031446,1031445,1031444,1031443,1031442,1031441,1031440,1031439,1031438,1031437,1031436,1031435,
1031434,1031433
) 

    select * from Customer  where customerName like '%Nokia%'  --->   213

	select * from customer where customerid = 68  ----> 68

	select top 100 * from Users

--	mobileNo
--+919902066973

	select distinct u.userId, u.loginName, u.firstName, u.lastName, u.email, u.mobileNo, r.roleDisplayName, u.deleted   --, u.createdOn, u.createdById, u.lastUpdatedOn
	from UserCustomerAssignGroupMapping UC
	inner join Users U on u.userId = uc.userId 
	inner join Role R on R.roleId = U.roleid
	inner join CustomerAssignmentGroupMapping C
	on UC.custAssignmentGroupId = c.custAssignmentGroupId
	where c.customerId = 68 and c.deleted = 0  and uc.deleted = 0 


	select * from Users where userId = 26366

    select * from users where firstName like '%css.engr4@heromotocorp.com%'
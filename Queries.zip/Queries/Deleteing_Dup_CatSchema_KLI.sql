

DECLARE @servicename NVARCHAR(MAX) ,@category NVARCHAR(MAX) ,@subcategory NVARCHAR(MAX) ,@clasification NVARCHAR(MAX), @customerid INT,@TicketType INT, @update nvarchar(max), @classificationId INT
SET @customerid=1
SET @TicketType=3
DECLARE Category_CURSOR CURSOR
LOCAL FORWARD_ONLY FOR
select serviceName, category, subcategory, classification, [update]   from KLI_24102020
OPEN Category_CURSOR
FETCH NEXT FROM Category_CURSOR INTO @servicename, @category, @subcategory, @clasification, @update
WHILE @@FETCH_STATUS = 0
BEGIN

select @classificationId = cc.classificationId  from ServiceCategoryMapping SCM
inner join Category C on SCM.categoryId = C.categoryId and category = @category
inner join SubCategory SC on c.categoryId = sc.categoryId and subCategory = @subcategory
inner join Classification CC on CC.subCategoryId = sc.subCategoryId 
inner join Service S on S.serviceId = SCM.serviceId and S.serviceName = @servicename
inner join ServiceCustomerMapping SCC on SCC.serviceId = SCM.serviceId 
where SCC.customerId = 1 and scm.ticketTypeId = 3 and cc.classification = @clasification
IF (@update is null)
  begin
  Update Classification set classification ='Others-Undefined' where classificationId = @classificationId
  end
else
begin
 Update Classification set deleted =1  where classificationId = @classificationId
end

FETCH NEXT FROM Category_CURSOR INTO @servicename, @category, @subcategory, @clasification, @update
END
CLOSE Category_CURSOR
DEALLOCATE Category_CURSOR
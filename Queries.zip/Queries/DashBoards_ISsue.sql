﻿
--->  For real time dashboard need to refresh the cache.


select * from Templateconfig where Id = 14

select * from Viewpoint where Id in (select ViewpointId from Templatelayoutdetails where LayoutId in (
Select id from Templatelayout where TemplateConfigId = 9))

select * from Templatelayoutdetails where LayoutId in (
Select id from Templatelayout where TemplateConfigId = 9)



---->   TemplateConfigId = 22)  get the dashboard id


select * from Viewpoint where Id in (select ViewpointId from Templatelayoutdetails where LayoutId in (
Select id from Templatelayout where TemplateConfigId = 7))  --->  25	Tickets Assigned to Me	Tickets Assigned to Me

---> usp_Dashboard_TicketsAssignedToMe

    usp_Dashboard_KLI_MyWorkList

    usp_Dashboard_KLI_MyWorkList_TicketData


--->  8793510233   

----->  nikhildab@microland.com - NikhilDaB




SR2792169 
 
SR2792143 

SR2792224 --->  notifications has triggered.

      select * from NotificationRegistry where sourceId = 2792169

      select * from NotificationRegistry where sourceId = 2792143 

	  select * from NotificationRules where ruleId in (
	   select distinct ruleId from NotificationRegistry where sourceId = 2792143 
	  ) and duePercent is null

	   select * from NotificationRules where ruleId in (
	   select distinct ruleId from NotificationRegistry where sourceId = 2792224   and templateId = 937
	  ) and duePercent is null

	  select * from NotificationRules where customerId = 180 and deleted = 0 and workgroupid = 452
	  and serviceId = 241


	  select * from NotificationHistory where TicketNo = 2792143 

	 --   2028432
		--2028482

		--2028397
  --      2028447

      select * from NotificationRegistry where sourceId = 2792224   and templateId = 937

	  select * from NotificationEmailTemplate where templateId in (
	  select distinct templateId from NotificationRegistry where sourceId = 2792224  
	  )

	  asset Mana

	  ---->  937	SMC New CIS-Resolved notication
	  ---->  937	SMC New CIS-Resolved notication

  --https://microuniv.microland.com/
  --https://microuniv.microland.com/


  {"Settings": {          "multiGraph": "false",        "GraphCount": "1",     
  "rtime":"Ticket",          "spinfo": {              "spname": "usp_Dashboard_KLI_MyWorkList",    
  "params": [               {"pname": "customerId","pvalue": "0","pvaluemap": "gCustomers"},    
  {"pname": "workGroupId","pvalue": "0","pvaluemap": "gWorkgroup"},      {"pname": "userId","pvalue": "0","pvaluemap": "userid"},
  {"pname":"timeZoneOffset","pvalue":"0","pvaluemap":"ofset"},          
  {"pname":"Permissions","pvalue":"0","pvaluemap":"myprmsn"}                ]          },     
  "Graphs":[              {                  "GraphType": "HTML",              
  "GraphTitle": "MyWork List",                  "IsHeaderEnable": "0",   
  "TemplateName":"MyWorkListKLI",      "headers":[        {         "dvalue":"Requestor",
  "IsTrimNeeded":"1",         "TrimLength":10         },         {         "dvalue":"work group", 
  "IsTrimNeeded":"1",         "TrimLength":10         },         {         "dvalue":"Last Manual Update", 
  "IsTrimNeeded":"1",         "TrimLength":15         },        {         "dvalue":"Description",   
  "IsTrimNeeded":"1",         "TrimLength":16         }       ],    
  "ddSource": {  "spname": "usp_Dashboard_KLI_MyWorkList_TicketData", 
  "params": [                        {"pname": "customerId","pvalue": "0","pvaluemap": "gCustomers"}, 
  {"pname": "workGroupIds","pvalue": "0","pvaluemap": "gWorkgroup"},  
  {    "pname": "param",    "pctrlmap": {"clsname":{"n":true,"class":".tclickval"},"propname":"html"}   }, 
  {"pname": "userId","pvalue": "0","pvaluemap": "userid"},   {"pname":"timeZoneOffset","pvalue":"0","pvaluemap":"ofset"}, 
  {"pname":"Permissions","pvalue":"0","pvaluemap":"myprmsn"}       ]  }}]}}

  ---->  

  select * from WorkGroup where workgroup like '%SCOM%'

  --exec  usp_Dashboard_KLI_MyWorkList_TicketData 'Assigned to me', 1,140 ,1281 , 0,0

  --exec  usp_Dashboard_KLI_MyWorkList  1,140 ,1281 , 0,0


 select * from Users where loginName like '%LO5803%'

  --  LO5803
  --  Email ID : kli.alan-lusbo@kotak.com


  select * from Users where username like '%Sankar %' --->  SankarR@microland.com

      --exec deletetickets @ticketNo = '2761859';
    --exec deletetickets @ticketNo = '2761858';

	--IM2794312
	
	--nikhildab@microland.com

	--abhishekku123456@microland.com - AbhishekKu123456



	select top 100  * from hero_users order by 1 desc  ----->  

	select top 100  * from hero_users where emailAddress like '%sakshi.khode@heromotocorp.com%'


	--insert into hero_users (firstName,lastName,emailAddress,mobilePhone1,workAddress1,employeeId,manager,
	--department, employeeTitle)

	--values ('Sakshi Sanjay', 'Khode', 'sakshi.khode@heromotocorp.com', '9545006897', 'HM3H-Haridwar Plant', '13889',
	--'amit.handa@heromotocorp.com', 'Q.A', 'Graduate Engineer Trainee')



	Hi Mahesh,

Need a help for the below mentioned tickets, few of the tickets are continuously followed up by customer. 

1.	SR2758938
2.	IM2750933
3.	SR2682551
4.	SR2776860


Select * from Templatelayoutdetails where LayoutId in (483,484,485,486,487,488,489,490,491,492)

 

Select * from Viewpoint where Id in (76,62,63,64,65,68,67,74,69,66,698,699,81,77,80)

--    usp_MIS_HR_Filter_GetWorkGroupByUser         ----->  Done 
--    usp_MIS_HR_getTotalTicketCount           
--    usp_MIS_HR_getTotalTicketCount_TicketData

    usp_MIS_HR_getTotalTicketCount

    usp_MIS_HR_getTotalTicketCount_TicketData


--hliC9bJRUiFx0HfHdXvQkg

select * from users where email like '%itsd.areaoffice@heromotocorp.com%'   ---->   

select * from Requestor where Requestoremail like '%itsd.areaoffice@heromotocorp.com%'  ---->  919950822609

select * from Customer where customerName like '%Eureka%'   ------>  167 

select * from Service where serviceName like '%End User Service%'  ---->  194,307,313,475

select * from ServiceCustomerMapping 
where customerId = 167 and serviceid in (194,307,313,475)  ----> 194

select * from NotificationRules where deleted = 0 
and customerId = 167 and serviceId = 194 and ticketTypeId = 1 and priorityId = 1 and ruleName='Assigned'


    -- usp_MIS_HR_getTotalTicketCount

    -- usp_MIS_HR_getTotalTicketCount_TicketData







select distinct c.Value, u.EmployeeId,am.approverName, am.levelId, am.levelName,u.EmailId from
ApprovalMatrixCriteria c join ApprovalEntityMapping m on m.approvalCriteriaId = c. ApprovalMatrixCriteriaId join 
ApprovalMatrixLevel l on l.approvalMatrixId = m.approvalMatrixId join ApprovalMatrixApprover am on am.levelId= l.levelId 
join Asset_users u on u.id = am.approverId where m.customerId = 147 
and m.deleted = 0 and am.deleted = 0 and am.levelName like '%Level%'
order by c.Value , am.levelName
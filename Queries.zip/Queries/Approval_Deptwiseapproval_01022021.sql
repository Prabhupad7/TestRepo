---Query for Dept wise approval


select * from ApprovalMatrixCriteria order by ApprovalMatrixCriteriaId desc


--insert into ApprovalMatrixCriteria(ApprovalMatrixCriteriaId,ClauseId,AndOr,TableName,ColumnName,Operator,Value) --162

--select 162,1,'AND','Asset_Users','Department','=','''SERCO SUNGARD''' 


select top 10 * from ApprovalEntityMapping  order by 1 desc

insert into ApprovalEntityMapping (entityTypeId,entityTypeName,customerId,customerName,approvalMappingRule,rulePriority,approvalMatrixId,ruleTemplateId,
deleted,isSourceFirst,showApprovalDetailsEUP,approvalCriteriaId)

select entityTypeId,entityTypeName,customerId,customerName,approvalMappingRule,rulePriority,approvalMatrixId,ruleTemplateId,
deleted,isSourceFirst,showApprovalDetailsEUP,162  from   ApprovalEntityMapping where approvalEntityMappingId = 3747



select top 25 * from ApprovalMatrix order by 1  desc ---677

--insert into ApprovalMatrix (approvalMatrixName,approvalMatrixDescription,createdById,createdByName,createdOn,updatedById,updatedByName,updatedOn,deleted)

--Select 'SERCO SUNGARD','SERCO SUNGARD',6,'smcadmin',GETDATE(),6,'smcadmin',GETDATE(),0




select * from ApprovalMatrixLevel where approvalMatrixId = 677 --level - 1 1310 , level 2 - 1311

--insert into ApprovalMatrixLevel(approvalMatrixId,levelName,createSource,levelDescription,parentLevelId,isLoginRequired,canApproveByEmail,approvalCount,
-- displayOrder,createdById,createdByName,createdOn,updatedById,updatedByName,updatedOn,deleted,isEmailToBeSent)

--Select 677,'Level 1',0,'SERCO SUNGARD',null,1,0,0,1,6,'smcAdmin',GETDATE(),6,'smcAdmin',GETDATE(),0,1

--union all 

--Select 677,'Level 2',1,'SERCO SUNGARD',1310,1,0,0,1,6,'smcAdmin',GETDATE(),6,'smcAdmin',GETDATE(),0,1



--insert into ApprovalMatrixApprover (approverTypeId,approverId,approverName,levelId,levelName,mustApprove,createdById,createdByName,createdOn,updatedById,updatedByName,updatedOn,deleted,canApprove,canReject,canRejectAndClose,isEmailToBeSent)
--select 374,54361,'NagarajaKG@microland.com',1310,'Level 1',1,6,'Vignesh',GETDATE(),6,'Vignesh',GETDATE(),0,1,1,1,1
--union all 
--select 375,52590,'Ashish Garg',1311,'Level 2',1,6,'Vignesh',GETDATE(),6,'Vignesh',GETDATE(),0,1,1,1,1
--union all 
--select 376,61474,'Divya Agarwal',1311,'Level 2',1,6,'Vignesh',GETDATE(),6,'Vignesh',GETDATE(),0,1,1,1,1

-Vignesh.

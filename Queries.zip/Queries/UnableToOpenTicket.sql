	 -- SR2647175

	 SELECT customerId, serviceId, * FROM Ticket WHERE ticketNo = 2636902  -- 314

	-- UPDATE Ticket SET subCategoryId = 16905 , subCategoryName ='SAP', classificationId= 73293, classificationName= 'SAP-ABAP' where ticketNo = 2636902

	  SELECT * FROM Classification WHERE classificationId = 32590

	  SELECT * FROM ServiceCustomerMapping WHERE customerId = 190 AND serviceId = 314

	  SELECT * FROM Customer WHERE customerId = 190


	  SELECT * FROM Classification where subCategoryId = 16905  --- 73293	SAP-ABAP



	  SELECT  * FROM Category WHERE categoryId = 3970

	  SELECT * FROM SubCategory WHERE categoryId = 3970 AND subCategory LIKE '%sap%'  --- 16905	SAP	3970



	 SR2636902 
     SR2636902 


	 SELECT * FROM Classification WHERE classificationId = 32590
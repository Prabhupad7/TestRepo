

    select * from Customer where customerName like  '%kotak%'  --- 163	Kotak Mahindra Asset Management Co. Ltd

	select distinct serviceId from ServiceCustomerMapping where deleted=0 and customerId = 194

	select * from ServiceCustomerMapping where deleted=0 and customerId = 163 and serviceId = 174

	select top 100 * from Category where serviceId = 329

	select  * from Category where deleted =0 and  category like '%Desktop/Laptop Management%'  ---->  2077	Desktop/Laptop Management

	select * from ServiceCategoryMapping where categoryId = 2077

	select * from Service where serviceId = 174 ----> 

	select * from Service where serviceName like '%Desktop / Laptop Management%'

	select top 10 * from Category where category like '%De-Commission%'
	
         -- Insert into Category(category,deleted,ticketTypeId,serviceId,Isdefaultcategory,isEUPVisible,icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)

	      values('Commission',   0,1,6,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
          ('De-Commission',0,1,6,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())


		   select * from SubCategory where deleted = 0 and categoryId = 1756 and subCategory like '%Arcos Access - Arcos Reports %' -->  22699

			 --Insert into SubCategory (subCategory,categoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)

			 --select 'Seclore DRM - File Access Issue', categoryId, deleted, Isdefaultcategory, 1, Icon, Icon_Color, Icon_BgColor, CreatedBy, 
			 --GETDATE(), UpdatedBy, GETDATE() from SubCategory where subCategoryId = 5199

			 --Update SubCategory set subCategory ='Arcos Access - Arcos Reports' where subCategoryId = 5211

			 select * from Classification where subCategoryId = 20119

			  select * from Classification where subCategoryId = 22699

			 --Insert into Classification (classification,subCategoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)

			 --select 'Others - Undefined', 5213, 0, Isdefaultcategory, 1, Icon, Icon_Color, Icon_BgColor, CreatedBy, 
			 --GETDATE(), UpdatedBy, GETDATE() from Classification where classificationId = 9333


			 --Update Classification set classification = 'Avamar related issues' where classificationId = 90948


			 select * from Customer where customerName like '%Technologent%' ---->   210

			 select * from Impact  ----->  7	High (Organization Effected)	1, 5	Low (1 Person Affected)

			 select * from Priority where ticketTypeId =2  ---->  9	P3   , 15	SR4








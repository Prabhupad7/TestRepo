
             
			 
			 select TicketTypeid,priorityId, priorityName, serviceId,requestedById, CurrentlocationName, requestorLocationID,impactId, workgroupId,  * from Ticket where ticketNo = 1433126

			 select * from ServiceLevelObjective where priorityId = 16 and impactId = 7 and serviceLevelAgreementId =1
			 and serviceId = 4 and serviceLevelObjectiveTypeId = 2 and locationId = 118 and isDelete  = 0

			 select * from ServiceLevelAgreement where subTypeId = 2  
			 --> 1433126
		     select * from ServiceLevelTracking where sourceId = 1439525

			 select * from ServiceLevelTracking where sourceId = 1433126

		--   update ServiceLevelTracking set statusId = 3 where serviceLevelTrackingId = 6152401


		-- Insert into ServiceLevelTracking( serviceLevelObjectiveId,sourceId, serviceLevelObjectiveTypeId, startTime,expectedEndTime,expectedDuration,statusId)

		select 2097064, 1433126, 2, '2020-10-23 17:26:29.000', '2020-10-24 10:26:29.000' , 960,3


		select * from ServiceLevelObjective where serviceLevelObjectiveId = 2324872
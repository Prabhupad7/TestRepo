

  select * from Service where servicename like '%CIS%'  ---->  68

  select * from Service where serviceName like '%Eurometrics%' ---->  498

  select * from SubCategory where subCategory like '%Eurometrics%' ----->   20976  20977

  --->  5349  5350

 ---->  Step: 1  ---->  614

  Select top 10  * from ApprovalEntityMapping 
  where customerId = 167 and approvalMappingRule like
 '%customerid=167;serviceid=498;%'   ---->  3616

 ---> step 2:
 
 select top 10 * from ApprovalMatrixLevel where approvalMatrixId =  614  ----> Level1:  1191 , Level2: 1192

 Step3: 

 select * from ApprovalMatrixApprover where levelId in (1191, 1192) and levelName like '%2%'

 --Update ApprovalMatrixApprover set approverTypeId = 93, approverId = 27013, approverName ='Jagruti Kesaria'
 --where approvalMatrixApproverId = 1743

 select * from Asset_users where DisplayName like '%Jagruti%'
 and CustomerId = 167 and IsDeleted  = 0  ---->   keshav.gupta@eurekaforbes.com   27203  , ---->  27013


 select * from UserDepartmentRole where userEmailId like '%jagruti.kesaria@eurekaforbes.com%' ---> 93 userTypeid



  ----->  2104

  select * from Subcategory where categoryid = 2104 ----> 9135	Peripherals

  select * from classification where subcategoryid = 9135 ---->  78891	New Monitor
 
  select * from Category where category like '%Accessories%' and deleted = 0

2089
2104
3058

select * from Servicecategorymapping where categoryid in (
2089
,2104
,3058
)  and serviceid = 68   ---->  2104
 

 Select * from ApprovalEntityMapping 
 where approvalMappingRule like
 '%{customerId=3;categoryId=2104;subCategoryId=9135;classificationId=78891;ticketTypeId=2;}%' --> 3629


  Select * from ApprovalEntityMapping 
 where customerid = 3 and  approvalMappingRule like
 '%{customerId=4;}%'


  Select * from ApprovalEntityMapping 
 where approvalMappingRule like
 '%{customerId=3;categoryId=2111;subCategoryId=18667;classificationId=79306;ticketTypeId=2;}%'

-- approvalEntityMappingId
-- 3629

--approvalMatrixId
--623  SR2774120

 Select * from ApprovalEntityMapping 
 where approvalMappingRule like
 '%{customerId=147;categoryId=2111;subCategoryId=18667;classificationId=79306;ticketTypeId=2;}%' --> 3629

---2

Select * from ApprovalMatrix where approvalMatrixId = 623

--->  Lakshmi Annapurna Mahidhara

-- 3

Select * from ApprovalMatrixLevel where approvalMatrixId = 623 ----> 1209

Select  top 100 * from ApprovalMatrixApprover where levelId = 1209 ---->  Benjamin John Abraham

Select * from ApprovalMatrixApprover where levelId in (1,2) and deleted = 0

Select top 100 * from ApprovalMatrixApprover where approverName like '%Benji%'

Select * from ApprovalMatrixApprover where approverName like '%RM%'



----->  steps to verify the approvers: 

    select categoryId, subCategoryId, classificationId,* from Ticket where ticketNo = 2776533 


 Select * from ApprovalEntityMapping 
 where approvalMappingRule like
 '%{customerId=147;categoryId=2111;subCategoryId=18667;classificationId=79306;ticketTypeId=2;}%' --> 3629

 Select * from ApprovalMatrix where approvalMatrixId = 623 --->  Skip this

 Select * from ApprovalMatrixLevel where approvalMatrixId = 623 ----> 1209

Select  top 100 * from ApprovalMatrixApprover where levelId = 1209 ---->  Benjamin John Abraham

---->  SR2781614

  

     select top 10 * from Asset_users where EmailId like '%thejasb%' ---  98625


     select * from Asset_users where id = 52726  ----->   22380	Sandeep	Gupta	Sandeep Gupta



	 select * from  ApproverEntityApproval where sourceId = 2774120  --->  52726

      --update ApproverEntityApproval set approverName = 'Benjamin John Abraham' where ApproverEntityHistoryId = 65700

	 
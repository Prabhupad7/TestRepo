

     select * from Jp_28072020  --where AssetId is null  --AssetTag ='KLI/07579'

    select * from Jp_28072020  where AssetId is null 

   Select A.StatusId, A.Status, * from Assets A  where assetNumber ='KLI/14843'

   --ALTER TABLE Jp_28072020	
   --ADD AssetID nvarchar(500), AssignedToEngineer nvarchar(250), StatusId float


   --update Jp_28072020 set AssetID = b.Id from Jp_28072020 a 
   --inner join Assets b on a.SerialNumber = b.SerialNumber and a.AssetTag = b.AssetNumber


   --update Jp_28072020 set AssignedToEngineer = b.id  from Jp_28072020 a 
   inner join Asset_users b on a.eMail = b.EmailId

   select top 100 * from Asset_users


   select distinct NewStatus from   Jp_28072020

   select * from Asset_Status  -- 1 In USe, 8	Need to Scrap

    select * from Asset

 --   update Jp_28072020 set StatusId = 1 where NewStatus = 'In USe' 

	--update Jp_28072020 set StatusId = 8 where NewStatus = 'Need to Scrap' 
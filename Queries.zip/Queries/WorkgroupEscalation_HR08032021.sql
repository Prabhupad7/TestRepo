

select * from workGroupEscalationMatrix 
where CustomerId = 147 and deleted = 0 and Level2Name like '%nagamani%' ---->  931

select * from workGroupEscalationMatrix 
where CustomerId = 147 and deleted = 0 and Level2Name like '%sahana%'  

----> 933 , 934, 936, 947, 965, 974, 935, 937, 938, 942, 944, 949, 972, 943, 

----> 931, 933,  934, 936, 947, 965, 935, 937, 938, 942, 944, 949, 972, 941, 948, 943, 945, 946, 964, 950, 951, 952
----> 953, 954, 967, 975, 955, 970, 956, 969, 971, 973, 957, 958, 959, 960, 961, 962, 963, 966, 968, 976


select * from workGroupEscalationMatrix 
where CustomerId = 147 and deleted = 0 and Level2Name like '%Parthajith Shenoy%'  


select * from workGroupEscalationMatrix 
where CustomerId = 147 and deleted = 0 and id in (
 931, 933,  934, 936, 947, 965, 935, 937, 938, 942, 944, 949, 972, 941, 948, 943, 945, 946, 964, 950, 951, 952,
 953, 954, 967, 975, 955, 970, 956, 969, 971, 973, 957, 958, 959, 960, 961, 962, 963, 966, 968, 976)



	 select * from workGroupEscalationMatrix 
	where CustomerId = 147 and deleted = 0 and id in (
	 931, 933,  934, 936, 947, 965, 935, 937, 938, 942, 944, 949, 972, 941, 948, 943, 945, 946, 964, 950, 951, 952,
	 953, 954, 967, 975, 955, 970, 956, 969, 971, 973, 957, 958, 959, 960, 961, 962, 963, 966, 968, 976)


	 --	update workGroupEscalationMatrix set deleted =1 where id in (
	 --931, 933,  934, 936, 947, 965, 935, 937, 938, 942, 944, 949, 972, 941, 948, 943, 945, 946, 964, 950, 951, 952,
	 --953, 954, 967, 975, 955, 970, 956, 969, 971, 973, 957, 958, 959, 960, 961, 962, 963, 966, 968, 976, 974)




    select CustomerId, 'HR Workgroups', 'India - Bengaluru - Ecospace1B', 'HR Workgroups', Level1Email, 'Monica S', 'MonicaS@microland.com', Level2Email, 
   Level3Name, Level3Extension, Level3Email,'' , 5,24689, GETDATE(), 24689, GETDATE(), 0 from workGroupEscalationMatrix where id = 931



 Update workGroupEscalationMatrix set WorkgroupName ='HR Workgroups',Level1Name='India - Bengaluru - Micropolis',	Level1Extension	Level1Email	Level2Name	Level2Extension	Level2Email	Level3Name	Level3Extension	Level3Email	workGroupId
 where id = 931

 
   -- Insert into workGroupEscalationMatrix(CustomerId, WorkgroupName, Level1Name, Level1Extension, Level1Email, Level2Name, Level2Extension, Level2Email, 
   --Level3Name, Level3Extension, Level3Email, workGroupId, InstanceId, createdBy, createdOn, updatedBy, updatedOn, deleted)

   --select CustomerId, 'HR Workgroups', 'India - Bengaluru - Ecospace1B', 'HR Workgroups', Level1Email, 'Purna Mahidhara', 'lakshmiannapurnam@microland.com', Level2Email, 
   --Level3Name, Level3Extension, Level3Email,'' , 5,24689, GETDATE(), 24689, GETDATE(), 0 from workGroupEscalationMatrix where id = 964

   select top 3 * from workGroupEscalationMatrix order by 1 desc

--   Update workGroupEscalationMatrix set Level2Email = Level2Extension ,  Level2Extension = Level2Email where id in (
--   1038
--,1037
--,1036
--   )
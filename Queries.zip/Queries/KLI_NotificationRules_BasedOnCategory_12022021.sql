

    select * from customer where customerName like '%channel support%' ----->  

    select * from Service where servicename like '%Application Management%' ---->  2

	select * from Category where category like '%Digital Library%'   ---


	--categoryId	category	deleted	ticketTypeId
 --   1031	Digital Library  	0	      1
 --   1032	Digital Library	    0	      2


 select * from NotificationRules where categoryId is not null and ticketTypeId = 2

--  update NotificationRules set priorityId = 16 where ruleId in (
--3101292
--,3101293
--,3101294
--,3101295
--,3101296
--  )




  --  Insert into NotificationRules (customerId,	ticketTypeId,	priorityId,	duePercent,	notificationMode,	notificationTo,
 	--templateId,	ruleName,	workgroupid,	serviceId,	notifyBasedOnId	,entryStateId	,deleted,	categoryId)

  --  select customerId,	ticketTypeId,	priorityId,	duePercent,	notificationMode,	'kli.anup-saha@pwc.com',
 	--templateId,	ruleName,	null,	2,	notifyBasedOnId	,entryStateId	,deleted,	1032 from NotificationRules where categoryId is not null and ticketTypeId = 2


 select top 100  * from NotificationHistory 

  select * from NotificationRules where categoryId is not null

  select * from NotificationRegistry where ruleId in ()

  select * from Priority where ticketTypeId = 1 --->  1, 5, 9
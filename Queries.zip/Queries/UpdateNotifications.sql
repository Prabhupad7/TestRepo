﻿


   select top 100 * from NotificationRules where notificationCC like '%IrfanAV@microland.com%'  and Customerid= 167

    select * from Workgroup where workgroupEmail like '%karthikv@microland.com%'  and Customerid= 167


   --UPDATE NotificationRules SET notificationTo =REPLACE(notificationTo,'IrfanAV@microland.com', ''), notificationCC = REPLACE(notificationCC,'IrfanAV@microland.com', '') 
   
   -- where Customerid= 167 and notificationCC like '%IrfanAV@microland.com%'

--   select top 10 * from Customer where Customerid in (161, 167)

   select top 10 * from Customer where Customerid = 167



   --For Oreta:


    // select top 10 * from Customer where Customerid in (70, 145)

	select * from Customer where customerId = 145


    --select top 100 * from NotificationRules where notificationTo like '%karthikv@microland.com%' 

    select top 100 * from NotificationRules where notificationCC like '%karthikv@microland.com%'  and Customerid= 145

    --UPDATE NotificationRules SET notificationTo =REPLACE(notificationTo,'karthikv@microland.com', ''), 
    notificationCC =REPLACE(notificationCC,'karthikv@microland.com', '')
	where notificationCC like '%karthikv@microland.com%' and Customerid= 145

	-- for mobile number stop notifications:
   -- update notificationrules set notificationTo = Replace(notificationTo, '919739886229 ', '')
	where notificationto like '%919739886229%' and customerId = 145



	 select  * from NotificationRules where notificationTo like '%9739886229%'
	  
	 -- in --(Select customerId from Customer where customerName like '%oreta%') and notificationMode = 'AWSSMS' and priorityId = 1 
	 --update notificationrules set notificationCC = Replace(notificationto,'917829472443','')  where notificationto like '%917829472443%' 

	 --update notificationrules set notificationCC = Replace(notificationto,'917829472443','')  where notificationto like '%917829472443%' 


	 ---
	 [‎5/‎26/‎2020 4:45 PM]  Mohammed K:  
	 -- while Modifying the Notifications we need to check the Work Group also.

select * from Workgroup u where u.workgroupEmail like '%sumitbj@microland.com%' and u.
select * from Workgroup u where workgroupId=206 
 
 -- update Workgroup set workgroupEmail = REPLACE ( workgroupEmail, 'sumitbj@microland.com', 
 --'Anandvk@microland.com;Manikandanc@microland.com;Sankarr@microland.com;SasikumarN@microland.com' )
 -- where workgroupId=206 



select  * from AutoTicketEventLog where ticketNo = 2606137

select distinct ServiceId, * from AutoTicketServiceRule where apiKeyId = 67



select customerId, * from Device where deviceName like '%EFL_Jaipur_Kota_Airtel_2Mbps%'  -- 167, 27155

   select customerId, * from Device where deviceName like '%Fortigate-Firewall_192.168.9.14%'   

   --Fortigate-Firewall_192.168.9.14   Fortigate-Firewall_192.168.9.14

select * from Customer where customerName like '%Eure%'  -- 167

select * from Service S
inner join ServiceCustomerMapping SCM
on  S.serviceId = scm.serviceId
where customerId = 167


select  D.deviceId, deviceName, D.ipAddress, D.hostName, DSM.serviceId, S.serviceName  from Device D 
inner join DeviceServiceMapping DSM
on D.deviceId =dsm.deviceId
inner join Service S on DSM.serviceId = s.serviceId
where customerId = 4 and d.deleted = 0 and DSM.deleted = 0 


   select D.deviceId, D.deviceName, D.ipAddress  from Device D where customerId = 4 and deleted = 0



select * from device where customerId = 167 and deleted = 0 and deviceId not in (

select deviceId  from DeviceServiceMapping DSM where serviceId in (196) and customerId = 167 and deleted =0)



select * from device where customerId = 167 and deleted = 0 and deviceId not in (

select deviceId  from DeviceServiceMapping DSM where serviceId in (198) and customerId = 167 and deleted =0)




select * from DeviceServiceMapping where 
deviceId = 27155 and serviceId = 196    --14118, 27184

	  INSERT INTO DeviceServiceMapping (serviceId, deviceId,deleted,ticketTypeId) 
	  VALUES
    (196,27155,0,1),
	(196,27155,0,2),
	(196,27155,0,3),
	(196,27155,0,4),

	(196,27184,0,1),
	(196,27184,0,2),
	(196,27184,0,3),
	(196,27184,0,4)


	 INSERT INTO DeviceServiceMapping (serviceId, deviceId,deleted,ticketTypeId) 
	  VALUES
    (198,27155,0,1),
	(198,27155,0,2),
	(198,27155,0,3),
	(198,27155,0,4),

	(198,27184,0,1),
	(198,27184,0,2),
	(198,27184,0,3),
	(198,27184,0,4)
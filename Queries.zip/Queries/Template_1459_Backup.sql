<html style="background-color:#F0F0F0;">     <head>        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>  
<title>Untitled Document</title>     </head>     <body style="background-color:#F0F0F0;">        <table width="100%" border="0" cellspacing="0" cellpadding="0">  
<tr>              <td align="center" valign="top" style="background-color: #F0F0F0;">               
<table width="900" border="0" cellspacing="0" cellpadding="0" style="border: 1px solid #656161;">         
<tr> <td align="left" valign="top" bgcolor="#ffffff" style="background-color:="ffffff";"> <img src="cid:HeaderImage" width="900" height="118"/> </td></tr>  
<tr>                       <td align="left" valign="top" bgcolor="#ffffff" style="background-color:="ffffff";">                
<table width="100%" border="0" cellspacing="0" cellpadding="0" >                          <tr>                        
<td width="35" align="left" valign="top"/>                              <td align="left" valign="top">                
<table width="100%" border="0" cellspacing="0" cellpadding="0" >                                   <tr>              
<td align="left" valign="top" style="color: black; font-family: Calibri, Times, serif; font-size: 25px;"> How did we do ? </td>       
</tr>                                   <tr style="font-size:12px;">                                      <td align="left" valign="top">   
<table style="width: 100%;">                                            <tr>                                               <td/>           
</tr>                                            <tr>                                              
<td style="font- family: Calibri; padding-left: 3px;">Dear @Model.REQUESTORNAME </td>                  
</tr>                                            <tr>                                               <td/>     
</tr>                                            <tr>                                     
<td style="font-family: Calibri; padding- left: 3px;"> Thank you for contacting Helpdesk. We hope we were able to resolve your issue with ticket number
@Model.TICKETNO logged on @Model.CREATEDON EST. We are constantly striving to provide excellent services and would love to get your feedback. Please rate our 
quality of services by selecting your rating below. </td>                                            </tr>                                            <tr>  
<td/>                                             </tr>                                            <table style="width: 100%;">                          
<tr>                                                  <td style="width:20%;"><a href="https://itsurvey.microland.com/FeedbackUrl?strReq=@Model.GOLDENCRYPTEDDATA">
<img src="cid:HighlySatisfiedNew" width="60" height="60"></a></td>                                               
<td style="width:20%;"><a href="https://itsurvey.microland.com/FeedbackUrl?strReq=@Model.GREENENCRYPTEDDATA"> 
<img src="cid:imageSatisfiedNew1" width="60" height="60"></a></td>                                               
<td style="width:20%;"><a href="https://itsurvey.microland.com/FeedbackUrl?strReq=@Model.AMBERENCRYPTEDDATA"> 
<img src="cid:NeutralNew" width="60" height="60"></a></td>                                                 
<td style="width:20%;"><a href="https://itsurvey.microland.com/FeedbackUrl?strReq=@Model.REDENCRYPTEDDATA"> 
<img src="cid:DisSatisfiedNewImage2" width="60" height="60"></a></td>                                        
<td style="width:20%;"><a href="https://itsurvey.microland.com/FeedbackUrl?strReq=@Model.ORANGEENCRYPTEDDATA"> 
<img src="cid:HighlyDisSatisfiedNew" width="60" height="60"></a></td>                                               </tr>       
<!--<tr>                                                  <td>FABULOUS</td>                                               
<td>GOOD</td>                                                  <td>OK</td>                                               
<td>POOR</td>                                                  <td>VERY POOR</td>                                             
</tr>-->                                            </table>                                            <tr>        
<td>                                                  <table style="width: 60%; padding-top:20px;">                   
<tr>                                                        <td style="font-family: Calibri;font-weight:bold;">Your Issue and Resolution Details:</td>
</tr>                                                     <tr>                                                        
<td style="font-family: Calibri;font-weight:bold;">Service Line</td>                                                        <td>:</td>     
<td style="font-family: Calibri;">@Model.SERVICELINE</td>                                                     </tr>                      
<tr>                                                        <td style="font-family: Calibri;font-weight:bold;">Issue Description</td>   
<td>:</td>                                                        <td style="font-family: Calibri;">@Raw(Model.DESCRIPTION) </td>       
</tr>                                                     <tr>                                                       
<td style="font-family: Calibri;font-weight:bold;">Resolution Summary</td>                                                        <td>:</td>  
<td style="font- family: Calibri;">@Model.RESOLUTIONSUMMARY</td>                                                     </tr>               
</table>                                               </td>                                            </tr>                          
<tr>                                               <td/>                                             </tr>                                
<tr>                                               <td style="font-family: Calibri; padding-left: 3px;">                                 
<br/>                                                   <p style="color: #000; font-size:13px; width: 130%; "> Assuring you of best services all the time,
if you would like to raise new query please visit our helpdesk portal here. </p>                                               </td>                   
</tr>                                            <tr>                                               <td/>                                            
</tr>                                         </table>                                      </td>                                   </tr>            
<tr>                                      <td align="left" valign="top" style="font- family: Arial, Helvetica, sans-serif; font-size: 12px; color: #F0F0F0;"/>    
</tr>                                </table>                             </td>                             <td width="35" align="left" valign="top"/>           
</tr>                       </table>                       </td>                    </tr>                    <tr>                       <td align="center" valign="top">  
<table bgcolor="#3C3C3A" style="background-color: #3C3C3A; height: 80px; width :900px">                             <tr>                                
<td width="5%" style="margin-top:7px"">  <img src="cid:ClientLogo" width="80" height="80" style="margin-left:20px;" /></td>                                
<td width="55%"  height="50%" valign="middle" style="color: #ED8F0C; font-size: 14px; font-family: Calibri;">                               
<p style="color: #ED8F0C; font-size: 14px; font-family: Calibri;">  Thanks and Regards,<br />  HR Team                              </tr>      
</table>                       </td>                    </tr>                 </table>            

<br/>               </td>           </tr>        </table>     </body>  </html>


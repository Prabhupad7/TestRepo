


--1
Select * from ApprovalEntityMapping where approvalMappingRule like '%serviceid=2%'

---2

Select * from ApprovalMatrix where approvalMatrixId = 1
-- 3

Select * from ApprovalMatrixLevel where approvalMatrixId = 1

Select * from ApprovalMatrixApprover where levelId in (1,2) and deleted = 0

     Select * from ApprovalEntityMapping  where approvalEntityMappingId in ( 6, 7)
	 select * from Service where serviceName ='Datacenter Service'  --> 2

	 select * from Category where category like '%N/W Security Management%'

	 select * from SubCategory where categoryId in (30, 38, 46) and subCategory like '%Firewall%' --> 215

	 --> 30 --1
	 ---, 38  --2   
	 --->, 46  --3

	 select * from Classification where subCategoryId = 215
	 --> 819	Port Opening

	 select * from ServiceCategoryMapping where serviceId =2 and categoryId in (30, 38, 46)

	 --Insert into ApprovalEntityMapping (entityTypeId, entityTypeName, customerId,customerName,  approvalMappingRule, approvalCriteriaId, rulePriority, approvalMatrixId, 
	 --ruleTemplateId, firstLevelId, deleted, isSourceFirst, formId, showApprovalDetailsEUP)
	 --values (2, 'TICKET', 1, 'TATA AIG', '{customerId=1;categoryId=38;subCategoryId=215;classificationId=819;ticketTypeId=2;}', null, null, 1, 1092, null,0, 0, null, 1)

	 	 Select * from ApprovalEntityMapping  where approvalEntityMappingId in ( 6, 7, 8)





select * from Service where serviceName like '%Data%'  --->   2

select * from Category where Category like '%Server%'

    ---   32,40,49,78

	select * from ServiceCategoryMapping where serviceId =2 and ticketTypeId = 2 and categoryId in (32,40,49,78 )  ---40

	select * from SubCategory where categoryId =40 and subCategory like '%linux%'  --  318

	select * from Classification where subCategoryId = 318  ---  1352, 1353

	--1352	Commission
	--1353	Decommission


	--1
Select * from ApprovalEntityMapping where approvalMappingRule like '%serviceid=2%'

 insert

---2

Select * from ApprovalMatrix where approvalMatrixId = 1
-- 3

Select * from ApprovalMatrixLevel where approvalMatrixId = 1

Select * from ApprovalMatrixApprover where levelId in (1,2) and deleted = 0


  ---> For adding approvers:

	 select * from Asset_users  

	 select * from UserDepartmentRole 

	 ---->

	 [2:16 PM] Mohammed K
    hi tagic notifications are not triggering, which folder can i check the logs.. as its comings in registry table but not to histry table
?[2:17 PM] Mahesh K
    The notifications are an console app, check the producation_consoleapp folder in path D:/SmartCenterNew and take IN_1 and IN_1_Copy service logs for Notification


	


  select * from Asset_users  

 select * from UserDepartmentRole 

  select * from UserDepartmentRole  where userEmailId in (
'Adarsh.Verma@tataaig.com',
'Amrish.thakkar@tataaig.com',
'Amol.Bhuvad@tataaig.com'
  )

   select EmailId, * from Asset_users 

    select * from Asset_users where EmailId in (
   'Adarsh.Verma@tataaig.com',
'Amrish.thakkar@tataaig.com',
'Amol.Bhuvad@tataaig.com',
'Anurag.Deb@tataaig.com',
'Akash3.Basu@tataaig.com',
'sanjay.Pai@tataaig.com'

  )

  
   select * from UserDepartmentRole where deleted = 0 order by userEmailId

   select *  from Asset_users where EmailId like '%Ankita3.Agrawal@tataaig.com%'

   select  top 13 * from Asset_users order by 1 desc

   -- Insert into Asset_users (FirstName, LastName, DisplayName, RoleId, EmailId, Alias, IsEnrolled, IsDisabled, CreatedOn, CreatedBy, LastUpdatedOn, LastUpdatedBy, IsDeleted, CustomerId)
   --values  
   --('Ashutosh', 'Dubey', 'Ashutosh Dubey',1, 'Ashutosh.Dubey@tataaig.com', 'Ashutosh.Dubey', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Aditya1', 'Kumar', 'Aditya1 Kumar',1, 'Aditya1.Kumar@tataaig.com', 'Aditya1.Kumar', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Sheili', 'Desaigwalia', 'Sheili Desaigwalia',1, 'Sheili.Desaigwalia@tataaig.com', 'Sheili.Desaigwalia', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Biprojit', 'Chakraborty', 'Biprojit Chakraborty',1, 'Biprojit.Chakraborty@tataaig.com', 'Biprojit.Chakraborty', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Urvi', 'Shah', 'Urvi Shah',1, 'Urvi.Shah@tataaig.com', 'Urvi.Shah', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Neha', 'Gupta', 'Neha Gupta',1, 'Neha.Gupta@tataaig.com', 'Neha.Gupta', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Mayuri', 'Panchal', 'Mayuri Panchal',1, 'Mayuri.Panchal@tataaig.com', 'Mayuri.Panchal', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Deepak', 'Mittal', 'Deepak Mittal',1, 'Deepak.Mittal@tataaig.com', 'Deepak.Mittal', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Siddhi', 'Kharkia', 'Siddhi Kharkia',1, 'Siddhi.Kharkia@tataaig.com', 'Siddhi.Kharkia', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Aniket4', 'Chakraborty', 'Aniket4 Chakraborty',1, 'Aniket4.Chakraborty@tataaig.com', 'Aniket4.Chakraborty', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Nitin1', 'Toraskar', 'Nitin1 Toraskar',1, 'Nitin1.Toraskar@tataaig.com', 'Nitin1.Toraskar', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Tony', 'Gomes', 'Tony Gomes',1, 'Tony.Gomes@tataaig.com', 'Tony.Gomes', 0, 0, getdate(), 6, getdate(), 6, 0, 1),
   --('Vinod', 'Kumar', 'Vinod Kumar',1, 'Vinod.Kumar@tataaig.com', 'Vinod.Kumar', 0, 0, getdate(), 6, getdate(), 6, 0, 1)


   select * from ##TTemp_Asset_users

    select * from UserDepartmentRole where userEmailId like '%Vinod.Kumar@tataaig.com%'

	select top 13 * from UserDepartmentRole order by 1 desc

	--insert into UserDepartmentRole (userDepartment,userRole, userEmailId, isImmediateManager, isManagerOfPreviousApprover, createdById, createdByName, createdOn, updatedById, updatedByName, updatedOn, deleted, IsDynamicApprover)
	--values (NULL,'', 'Ashutosh.Dubey@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--       (NULL,'', 'Aditya1.Kumar@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--	   (NULL,'', 'Sheili.Desaigwalia@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--	   (NULL,'', 'Biprojit.Chakraborty@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--	   (NULL,'', 'Urvi.Shah@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--	   (NULL,'', 'Neha.Gupta@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--	   (NULL,'', 'Mayuri.Panchal@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--	   (NULL,'', 'Deepak.Mittal@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--	   (NULL,'', 'Siddhi.Kharkia@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--	   (NULL,'', 'Aniket4.Chakraborty@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--	   (NULL,'', 'Nitin1.Toraskar@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--	   (NULL,'', 'Tony.Gomes@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0),
	--	   (NULL,'', 'Vinod.Kumar@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0)


   select * from ##TTemp_Asset_users T
   inner join Asset_users A on T.EmailId = A.EmailId
   where A.IsDeleted = 0

   select * from ##TTemp_Asset_users T
   inner join UserDepartmentRole A on T.EmailId = A.userEmailId
   -- where A.IsDeleted = 0

     select * from ##TTemp_Asset_users where emailid  in (
	 select userEmailId from UserDepartmentRole
	 )

	   select * from ##TTemp_Asset_users where emailid not in (
	   select EmailId from UserDepartmentRole )

	   select * from ##TTemp_Asset_users

	   select * from UserDepartmentRole where userEmailId not in (
	    select EmailId from ##TTemp_Asset_users
	   )

	 select * from UserDepartmentRole where useremailId = 'Aditya1.Kumar@tataaig.com'

  --   Create table ##TTemp_Asset_users (
	 --userId_new Int,
	 --EmailId nvarchar(250)
	 --)

	 Select * from ApprovalEntityMapping  where approvalEntityMappingId in ( 6, 7)

	 select * from Service where serviceName ='Datacenter Service'  --> 2

	 select * from Category where category like '%N/W Security Management%'

	 select * from SubCategory where categoryId in (30, 38, 46) and subCategory like '%Firewall%' --> 215

	 --> 30 --1
	 ---, 38  --2   
	 --->, 46  --3

	 select * from Classification where subCategoryId = 215
	 --> 819	Port Opening

	 select * from ServiceCategoryMapping where serviceId =2 and categoryId in (30, 38, 46)

	 --Insert into ApprovalEntityMapping (entityTypeId, entityTypeName, customerId,customerName,  approvalMappingRule, approvalCriteriaId, rulePriority, approvalMatrixId, 
	 --ruleTemplateId, firstLevelId, deleted, isSourceFirst, formId, showApprovalDetailsEUP)
	 --values (2, 'TICKET', 1, 'TATA AIG', '{customerId=1;categoryId=38;subCategoryId=215;classificationId=819;ticketTypeId=2;}', null, null, 1, 1092, null,0, 0, null, 1)

	 	 Select * from ApprovalEntityMapping  where approvalEntityMappingId in ( 6, 7, 8)


		 Select * from ApprovalMatrix where approvalMatrixId = 1

		 	--1
Select * from ApprovalEntityMapping where approvalMappingRule like '%serviceid=2%'


---2

Select * from ApprovalMatrix where approvalMatrixId = 1
-- 3

Select * from ApprovalMatrixLevel where approvalMatrixId = 1

Select * from ApprovalMatrixApprover where levelId in (1,2) and deleted = 0

Select * from ApprovalMatrixApprover where levelId in (1,2) and deleted = 0   -->  Amrish.thakkar@tataaig.com

Select * from ApprovalMatrixApprover where levelId in (1,2) and approverName like '%Hemant Deshmukh%'

Select * from ApprovalMatrixApprover where levelId in (1,2) and approverName like '%Bhushan Patil%'

Select * from ApprovalMatrixApprover where levelId in (1,2) and approverName like '%Vike%'

 --UPDATE ApprovalMatrixApprover SET canReject=1, canRejectAndClose =2 WHERE approvalMatrixApproverId in(66, 67)

-- Viken Seth	Viken.Sheth@tataaig.com		IT	Level - 2	Optional



    select * from UserDepartmentRole where userEmailId like '%viken.Sheth@tataaig.com%'

	select top 1 * from UserDepartmentRole order by 1 desc  -->  65

	 --  insert into UserDepartmentRole (userDepartment,userRole, userEmailId, isImmediateManager, isManagerOfPreviousApprover, createdById, createdByName, createdOn, updatedById, updatedByName, updatedOn, deleted, IsDynamicApprover)
	 --values (NULL,'', 'viken.Sheth@tataaig.com', 0, 0, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 0)

   
   select *  from Asset_users where EmailId like '%viken.Sheth@tataaig.com%'

   select  top 1 * from Asset_users order by 1 desc  ---55
   select  top 1 * from Asset_users --1

   -- Insert into Asset_users (FirstName, LastName, DisplayName, RoleId, EmailId, Alias, IsEnrolled, IsDisabled, CreatedOn, CreatedBy, LastUpdatedOn, LastUpdatedBy, IsDeleted, CustomerId)
   --values  
   --('viken', 'Sheth', 'viken Sheth',1, 'viken.Sheth@tataaig.com', 'viken.Sheth', 0, 0, getdate(), 6, getdate(), 6, 0, 1)


   Select * from ApprovalMatrixApprover where levelId in (1,2) and approverName like '%viken Sheth%'

   --Insert into ApprovalMatrixApprover (approverTypeId, approverId, approverName, levelId, levelName, mustApprove, createdById, createdByName, createdOn, 
   --updatedById, updatedByName, updatedOn, deleted, canApprove, canReject, approverCriteriaId, isEmailToBeSent)

   --Select  65, 55, 'viken Sheth', levelId, levelName, mustApprove, createdById, createdByName, getdate(), 
   --updatedById, updatedByName, getdate(), 0, canApprove, canReject, approverCriteriaId, isEmailToBeSent

   --from ApprovalMatrixApprover where levelId in (1,2) and approverName like '%Hemant Deshmukh%'




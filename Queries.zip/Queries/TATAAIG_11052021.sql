

select * from AutoTicketEventLog where ticketNo = 715182

select top 10 * from AutoTicketEventLog order by createdOn desc

select * from ticket where ticketNo = 749981


select * from Assets where AssetNumber in (
'17448',
'17669',
'17595',
'17664',
'17525',
'17681',
'17528',
'18231',
'18075',
'17661',
'18208',
'18098',
'17554',
'18092',
'18347',
'17421'
)


select * from Assets where AssetNumber like '%17448%'  --->

select * from Assets where AssetName like '%18182%'  --->


SELECT  AssetNumber, SerialNumber, 
 COUNT(*) occurrences
FROM Assets  where sourceid = 4
GROUP BY
    AssetNumber, SerialNumber
HAVING    COUNT(*) > 1;


Select * from Users ---> smartcenter

--update users set password='SUv/GzSv2NSYGeW1YMGviQ==', SaltValue = null where userId = 6

select * from Instancepasswordchangehistory where UserId = 6

select * from Assets where AssetNumber like '%DP-18182%'   ----> 20253

select * from Assets where Id =  20253  -----> AssetName: 20253

SELECT  AssetNumber, SerialNumber, 
 COUNT(*) occurrences
FROM Assets  where sourceid = 4
GROUP BY
    AssetNumber, SerialNumber
HAVING    COUNT(*) > 1;

select isDeleted,* from Assets where  AssetNumber ='6368'  -----> 

select isDeleted,* from Assets where  SerialNumber ='5CG03805Q2'  -----> 
select isDeleted,* from Assets where  SerialNumber ='76M7503'  -----> 
select isDeleted,* from Assets where  SerialNumber ='a'  -----> 

--> 6354 , 6368

--update Assets set isDeleted = 1 where id = 20432

select * from VarcharCustomAttribute where PrimaryId  in (20254 )

--delete from VarcharCustomAttribute where id in (14502)

select * from Assets where AssetName in
(
'DP-17448',
'DP-17669',
'DP-17595',
'DP-17664',
'DP-17525',
'DP-17681',
'DP-17528',
'DP-18231',
'DP-18075',
'DP-17661',
'DP-18208',
'DP-18098',
'DP-17554',
'DP-18092',
'DP-18347',
'DP-17421'
)

--AssetIds: duplicates:

--20413
--20480
--20494
--20504
--20565
--20614
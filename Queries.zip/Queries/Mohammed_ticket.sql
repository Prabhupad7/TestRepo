

  select * from Assets


  select * from KLI_05102020


    --  ALTER TABLE KLI_05102020
    --ADD AssetId int


	select * from EntityType

	select * from AssetEntityType

	select * from 

    select A.Id, A.isDeleted, A.AssetNumber, A.SerialNumber from Assets A 
   inner join KLI_05102020 K 
   on A.AssetNumber = K.AssetTag and A.SerialNumber = K.SerialNumber


   select * from Assets A 
   inner join KLI_05102020 K 
   on A.AssetNumber = K.AssetTag -- and A.SerialNumber = K.SerialNumber


   select A.Id , K.AssetId, A.isDeleted from Assets A 
   inner join KLI_05102020 K 
   on A.AssetNumber = K.AssetTag and A.SerialNumber = K.SerialNumber


   --Update Assets set isDeleted = null  from Assets A 
   --inner join KLI_05102020 K 
   --on A.AssetNumber = K.AssetTag -- and A.SerialNumber = K.SerialNumber
   --where A.Id in (
   --select A.AssetId from KLI_05102020 A
   --)



   --update KLI_05102020 set AssetId = A.Id  from Assets A 
   --inner join KLI_05102020 K 
   --on A.AssetNumber = K.AssetTag and A.SerialNumber = K.SerialNumber



	 select * from Users where loginName like '%aravind%' -->  6 , 25971
	 
	 select * from Users where email like '%pawan9.kumar@heromotocorp%' -->  6 , 23876

   -- Insert into Asset_EntityTypeUserMapping(userId, entityTypeId, createdOn, createdBy, isDeleted, instanceId)

	  --values (23876, 66, getdate(), 6, 0,1),
   --          (23876, 285, getdate(), 6, 0, 1)

      Select * from Asset_EntityTypeUserMapping where entityTypeId in (66 , 285) and userid = 6

	  Select * from Asset_EntityTypeUserMapping where entityTypeId in (66 , 285) and userid in (6,23876)

      Select * from Asset_EntityTypeUserMapping where entityTypeId in (66 , 285) and userid = 26093



	  --->   update Asset_EntityTypeUserMapping set instanceId = null where id = 15974

     --->  KM � entitytype 285 or 66 

	 select * from MenuMaster where menuID in (66, 285)

	 Select * from Asset_EntityTypeUserMapping where entityTypeId = 285

	 ----->  GeethaKr@microland.com

	 select * from Users where email like '%GeethaKr@microland.com%' ---->  26753

	 select * from Users where email like '%ManjunathKS@microland.com%' --->  25872


	     select * from AssetEntityType where id in (66, 285)

	 	 select * from AssetEntityType where Name like '%CMDB%' ---->  143  241 427

		  --  Insert into Asset_EntityTypeUserMapping(userId, entityTypeId, createdOn, createdBy, isDeleted, instanceId)

		  --Select 26753 ,entityTypeId, GETDATE(), 6, isDeleted, instanceId from Asset_EntityTypeUserMapping where userId = 25872 and entityTypeId in (
		  --66, 285, 143,  241 , 427
		  --)


		  	  Select * from Asset_EntityTypeUserMapping where userId = 26753 and entityTypeId in (
		  66, 285, 143,  241 , 427
		  )

   select * from Requestor where requestorEmail like '%SriramN@microland.com%' ---->  59642  SriramN@microland.com

   select * from CustomerRequestorMapping where requestorId = 59642  ---->  

	   select * from Asset_users where EmailId = 'SriramN@microland.com'  ---->  ManagerId: 63926

	   select * from Requestor where requestorEmail like '%SriramN@microland.com%'

	   select * from Asset_users where id = 63926 ----> Val�rie Beaulieu  vbeaulieu@jhs.jubl.com


	   select * from ApiKey where customerId = 3  ----> 4

	   select top 100 * from AutoTicketEventLog where apikeyId = 4
	   order by 1 desc

	   select top 10 * from AutoTicketEventLog where apikeyId =4  order by createdOn desc

	   select * from Users where email like '%MayaMJ@microland.com%'  ---> 419

	   select * from Users where displayName like '%SMC%'  --->  26676  smcdashboard 

	   select * from MenuMaster where menuUrl like '%CMDB%'  --->  

	   select * from AssetEntityType where name like '%CMDB%' --->  143 241 427

	



<html style="background-color: #F0F0F0;">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Untitled Document</title>
  </head>
  <body style="background-color: #F0F0F0;">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center" valign="top" style="background-color: #F0F0F0;">
          <table width="900" border="0" cellspacing="0" cellpadding="0" style="border: 1px solid #656161;">
            <tr>
              <td align="left" valign="top" bgcolor="#FFFFFF" style="background-color: #FFFFFF;">
                <img src="cid:HeaderImage" width="900" height="118" />
              </td>
            </tr>
            <tr>
              <td align="left" valign="top" bgcolor="#FFFFFF" style="background-color: #FFFFFF;">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="35" align="left" valign="top" />
                    <td align="left" valign="top">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td valign="top" style="font-family: Segoe UI; font-size: 20px; padding-left: 3px; font-weight: bold;">@Model.STATUSNAME Notification </td>
                        </tr>
                        <tr>
                          <td align="left" valign="top">
                            <table style="width: 100%">
                              <tr>
                                <td />
                              </tr>
                              <tr>
                                <td style="font-family: Segoe UI; padding-left: 3px;">Dear @Model.ASSIGNEDTO </td>
                              </tr>
                              <tr>
                                <td />
                              </tr>
                              <tr>
                                <td style="font-family: Segoe UI; padding-left: 3px;">RCA is rejected for the ticket TICKETNOTODISPLAY </td>
                              </tr>
                              <tr>
                                <td />
                                <br />
                                <br /> Below are the details of your ticket
                              </tr>
                              <tr>
                                <td>
                                  <table style="width: 100%; font-size: 14px;">
                                    <tr>
                                      <td style="font-family: Segoe UI; font-weight: bold;" width: 225px;>Ticket Number</td>
                                      <td>:</td>
                                      <td style="font-family: Segoe UI;">@Model.TICKETNOTODISPLAY </td>
                                    </tr>
                              </tr>
                              <tr></tr>
                              <tr></tr>
                              <tr style="border: 1px solid black">
                                <td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Issue Description</td>
                                <td>:</td>
                                <td style="font-family: Segoe UI;">@Raw(Model.DESCRIPTION)</td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                        <tr>
                          <td> Click here to open the ticket:@Model.TICKETNOTODISPLAY and take the required action. </td>
                          <td />
                        </tr>
                        <tr>
                          <td style="font-family: Segoe UI; padding-left: 3px;">
                            <br />
                            <p style="color: #000; font-size: 13px; width: 130%;"> Note: This is an automated notification, please do not reply to this mail and any response / additional information should be <br /> sent to email ids mentioned in the signature of this email. </p>
                          </td>
                        </tr>
                        <tr>
                          <td />
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td align="left" valign="top" style="font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #F0F0F0;" />
                  </tr>
                </table>
              </td>
              <td width="35" align="left" valign="top" />
            </tr>
          </table>
        </td>
      </tr>
      <!--<tr><td bgcolor="#ffffff" style="background-color: #ffffff; font-family: Segoe UI; padding-bottom: 20px;"><table width="92%" border="1" align="center" cellspacing="0" cellpadding="0" style="font-size: 14px; font-family: Segoe UI;"><tr><th colspan="4" style="font-weight: bold; background-color: gray;">Escalation Matrix </th></tr><tr><tr><th>Level </th><th>Name </th><th>Contact No </th><th>Email </th></tr><tr><td style="text-align: center;">1</td><td style="text-align: center;">@Model.LEVEL1NAME</td><td style="text-align: center;">@Model.LEVEL1EXTENSION</td><td style="text-align: center;">@Model.LEVEL1EMAIL</td></tr><tr><td style="text-align: center;">2</td><td style="text-align: center;">@Model.LEVEL2NAME</td><td style="text-align: center;">@Model.LEVEL2EXTENSION</td><td style="text-align: center;">@Model.LEVEL2EMAIL</td></tr><tr><td style="text-align: center;">3</td><td style="text-align: center;">@Model.LEVEL3NAME</td><td style="text-align: center;">@Model.LEVEL3EXTENSION</td><td style="text-align: center;">@Model.LEVEL3EMAIL</td></tr></table><br /></tr>-->
      <tr>
        <td bgcolor="#3C3C3A" style="background-color: #3C3C3A; height: 100px;">
          <table width="92%" border="0" align="center" cellspacing="0" cellpadding="0">
            <tr>
              <td>
                <img src="cid:microland.png" />
              </td>
              <td style="width: 800px; font-family: Segoe UI; font-size: 14px; color: #f0f0f0">
                <p> Thanks and Regards, <br />
                  <b> Microland RMC Helpdesk </b>
                  <br />
                  <a style="color:white;" http: //www.microland.net">https://www.microland.com</a> | <b>E-mail:</b>rmc@microland.com <br>
                  <b>Direct Tel: </b> +91 8043280006| <b>US Tel:</b> +1-646-259-0397 <br />
                </p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <br />
    </td>
    </tr>
    </table>
  </body>
</html>


------------------------------->

<html style="background-color: #F0F0F0;">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Untitled Document</title>
  </head>
  <body style="background-color: #F0F0F0;">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center" valign="top" style="background-color: #F0F0F0;">
          <table width="900" border="0" cellspacing="0" cellpadding="0" style="border: 1px solid #656161;">
            <tr>
              <td align="left" valign="top" bgcolor="#FFFFFF" style="background-color: #FFFFFF;">
                <img src="cid:HeaderImage" width="900" height="118" />
              </td>
            </tr>
            <tr>
              <td align="left" valign="top" bgcolor="#FFFFFF" style="background-color: #FFFFFF;">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="35" align="left" valign="top" />
                    <td align="left" valign="top">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td valign="top" style="font-family: Segoe UI; font-size: 20px; padding-left: 3px; font-weight: bold;">@Model.STATUSNAME Notification </td>
                        </tr>
                        <tr>
                          <td align="left" valign="top">
                            <table style="width: 100%">
                              <tr>
                                <td />
                              </tr>
                              <tr>
                                <td style="font-family: Segoe UI; padding-left: 3px;">Dear @Model.ASSIGNEDTO </td>
                              </tr>
                              <tr>
                                <td />
                              </tr>
                              <tr>
                                <td style="font-family: Segoe UI; padding-left: 3px;">RCA is rejected for the ticket @Model.TICKETNOTODISPLAY</td>
                              </tr>
                              <tr>
                                <td />
                                <br />
                                <br /> Below are the details of your ticket
                              </tr>
                              <tr>
                                <td>
                                  <table style="width: 100%; font-size: 14px;">
                                    <tr>
                                      <td style="font-family: Segoe UI; font-weight: bold;" width: 225px;>Ticket Number</td>
                                      <td>:</td>
                                      <td style="font-family: Segoe UI;">@Model.TICKETNOTODISPLAY </td>
                                    </tr>
                              </tr>
                              <tr></tr>
                              <tr></tr>
                              <tr style="border: 1px solid black">
                                <td style="font-family: Segoe UI; font-weight: bold; width: 225px;">Issue Description</td>
                                <td>:</td>
                                <td style="font-family: Segoe UI;">@Raw(Model.DESCRIPTION)</td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                        <tr>
                          <td />
                        </tr>
                        <tr>
                          <td style="font-family: Segoe UI; padding-left: 3px;">
                            <br />
                            <p style="color: #000; font-size: 13px; width: 130%;"> Note: This is an automated notification, please do not reply to this mail and any response / additional information should be <br /> sent to email ids mentioned in the signature of this email. </p>
                          </td>
                        </tr>
                        <tr>
                          <td />
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td align="left" valign="top" style="font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #F0F0F0;" />
                  </tr>
                </table>
              </td>
              <td width="35" align="left" valign="top" />
            </tr>
          </table>
        </td>
      </tr>
      <!--<tr><td bgcolor="#ffffff" style="background-color: #ffffff; font-family: Segoe UI; padding-bottom: 20px;"><table width="92%" border="1" align="center" cellspacing="0" cellpadding="0" style="font-size: 14px; font-family: Segoe UI;"><tr><th colspan="4" style="font-weight: bold; background-color: gray;">Escalation Matrix </th></tr><tr><tr><th>Level </th><th>Name </th><th>Contact No </th><th>Email </th></tr><tr><td style="text-align: center;">1</td><td style="text-align: center;">@Model.LEVEL1NAME</td><td style="text-align: center;">@Model.LEVEL1EXTENSION</td><td style="text-align: center;">@Model.LEVEL1EMAIL</td></tr><tr><td style="text-align: center;">2</td><td style="text-align: center;">@Model.LEVEL2NAME</td><td style="text-align: center;">@Model.LEVEL2EXTENSION</td><td style="text-align: center;">@Model.LEVEL2EMAIL</td></tr><tr><td style="text-align: center;">3</td><td style="text-align: center;">@Model.LEVEL3NAME</td><td style="text-align: center;">@Model.LEVEL3EXTENSION</td><td style="text-align: center;">@Model.LEVEL3EMAIL</td></tr></table><br /></tr>-->
      <tr>
        <td bgcolor="#3C3C3A" style="background-color: #3C3C3A; height: 100px;">
          <table width="92%" border="0" align="center" cellspacing="0" cellpadding="0">
            <tr>
              <td>
                <img src="cid:microland.png" />
              </td>
              <td style="width: 800px; font-family: Segoe UI; font-size: 14px; color: #f0f0f0">
                <p> Thanks and Regards, <br />
                  <b> Microland RMC Helpdesk </b>
                  <br />
                  <a style="color:white;" http: //www.microland.net">https://www.microland.com</a> | <b>E-mail:</b>rmc@microland.com <br>
                  <b>Direct Tel: </b> +91 8043280006| <b>US Tel:</b> +1-646-259-0397 <br />
                </p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <br />
    </td>
    </tr>
    </table>
  </body>
</html>


   select * from Customer where CustomerName like '%SMC RMC%' --  167	Eureka Forbes Limited	Eureka Forbes Limited	0

   --- 154	SMC RMC	SMC RMC

            select * from Customer where customerId = 4 --- 3	MLCIS	MLCIS


                    select * from Device where customerId = 3 and  devicename like '%CIS Extn 2%'

					select * from Device where deviceName like '%HDUECO-AUTO01%' and customerId = 4   ----26093

					select * from Device where deviceName like '%HDUECOANS101%' and customerId = 4   --- 29851

			     ---  update Device set deleted = 0, description = 'Windows Server' where deviceid =26093


				 select * from DeviceServiceMapping where deviceId in ( 26093, 29851) and serviceId =1

				            -- Insert into DeviceServiceMapping (serviceId, deviceId, deleted, ticketTypeId)
							 values (1,29851,0,1),
							 (1,29851,0,2),
							 (1,29851,0,3),
							 (1,29851,0,4)


							 select * from Service where serviceid = 1


         -- Insert into Device (deviceName, alternateName, ipAddress, description, createdDate, modifiedDate, customerId, hostName, deleted )

	      values 
		 -- ('HDUECO-AUTO01','HDUECO-AUTO01','203.31.9.81','Windows Server',getdate(),getdate(),4,'HDUECO-AUTO01', 0),
          ('HDUECOANS101','HDUECOANS101','203.90.5.189 ','Unix Server',getdate(),getdate(),4,'HDUECOANS101', 0)

          

		  select top 4 * from Device order by 1 desc

		  29839
29838
29837
29836

                    select * from DeviceServiceMapping where deviceId in (29839
,29838
,29837
,29836)


            -- insert into DeviceServiceMapping (serviceId, deviceId, deleted, ticketTypeId)

values
(1,29839,0,1),
(1,29838,0,1),
(1,29837,0,1),
(1,29836,0,1),

(1,29839,0,2),
(1,29838,0,2),
(1,29837,0,2),
(1,29836,0,2),

(1,29839,0,3),
(1,29838,0,3),
(1,29837,0,3),
(1,29836,0,3),

(1,29839,0,4),
(1,29838,0,4),
(1,29837,0,4),
(1,29836,0,4)

                    

   select * from Service where serviceId in (Select distinct serviceId from ServiceCustomerMapping where customerId = 3 and deleted = 0 )

   ---- 196	DCS	DCS	NULL	DCS
   ---- 198	NCS	NCS	NULL

   select * from DeviceServiceMapping where deviceId in ( select deviceId from Device where customerId = 167 
   and deleted = 0) and serviceId in (196, 198) and deleted=0 order by 2 

   ---- 5570	Generic	Generic	NULL
   select * from DeviceServiceMapping where deviceId= 5570 and serviceId in (196, 198)

     select * from Device where Deviceid in ( select deviceId from DeviceServiceMapping where serviceId in (196, 198) and deleted=0 ) 

	  select * from Device where deviceId in (27100
,27099
,27098
,27097
,27096)

	  ---     ---- 196	DCS	DCS	NULL	DCS

     --  Insert into Device (deviceName, alternateName, ipAddress, description, createdDate, modifiedDate, customerId, deleted, hostName)

	  values 
('ADFS-EFL','ADFS-EFL','10.1.0.8','Windows Server',GETDATE(),GETDATE(),167,0,'ADFS-EFL')
,('ADFS-WAP','ADFS-WAP','10.1.2.4','Windows Server',GETDATE(),GETDATE(),167,0,'ADFS-WAP')
,('AMS-UAT-APP','AMS-UAT-APP','192.168.9.130','Linux',GETDATE(),GETDATE(),167,0,'AMS-UAT-APP')
,('AMS-UAT-DB','AMS-UAT-DB','192.168.9.131','Linux',GETDATE(),GETDATE(),167,0,'AMS-UAT-DB')
,('AMSAPP','AMSAPP','192.168.9.122','Linux',GETDATE(),GETDATE(),167,0,'AMSAPP')
,('AMSAPP1','AMSAPP1','192.168.9.128','Linux',GETDATE(),GETDATE(),167,0,'AMSAPP1')
,('AMSBATCH','AMSBATCH','192.168.9.127','Linux',GETDATE(),GETDATE(),167,0,'AMSBATCH')
,('AMSDB','AMSDB','192.168.9.121','Linux',GETDATE(),GETDATE(),167,0,'AMSDB')
,('AMSPROXY','AMSPROXY','192.168.9.129','Linux',GETDATE(),GETDATE(),167,0,'AMSPROXY')
,('Andes-app','Andes-app','192.168.3.228','Windows Server',GETDATE(),GETDATE(),167,0,'Andes-app')
,('Database','Database','10.100.27.230','Windows Server',GETDATE(),GETDATE(),167,0,'Database')
,('EF-BDI-TRACE02','EF-BDI-TRACE02','10.100.27.160','Windows Server',GETDATE(),GETDATE(),167,0,'EF-BDI-TRACE02')
,('Ef-BLR-FS01','Ef-BLR-FS01','10.101.137.23','Windows Server',GETDATE(),GETDATE(),167,0,'Ef-BLR-FS01')
,('EF-DC-INSTACM','EF-DC-INSTACM','192.168.9.111','Windows Server',GETDATE(),GETDATE(),167,0,'EF-DC-INSTACM')
,('EF-DC-InstaRS','EF-DC-InstaRS','192.168.9.112','Windows Server',GETDATE(),GETDATE(),167,0,'EF-DC-InstaRS')
,('EF-DDR-FS02','EF-DDR-FS02','10.101.19.8','Windows Server',GETDATE(),GETDATE(),167,0,'EF-DDR-FS02')
,('EF-DHD-TRACE03','EF-DHD-TRACE03','10.100.46.217','Windows Server',GETDATE(),GETDATE(),167,0,'EF-DHD-TRACE03')
,('EF-HO-TC01','EF-HO-TC01','10.101.201.4','Linux',GETDATE(),GETDATE(),167,0,'EF-HO-TC01')
,('EF-HO-TC02','EF-HO-TC02','10.101.201.5','Linux',GETDATE(),GETDATE(),167,0,'EF-HO-TC02')
,('EFL URL','EFL URL','192.168.9.132','Linux',GETDATE(),GETDATE(),167,0,'EFL URL')
,('Efl-dc-bigfix','Efl-dc-bigfix','10.98.0.124','Linux',GETDATE(),GETDATE(),167,0,'Efl-dc-bigfix')
,('EFL-DC-CCPROD','EFL-DC-CCPROD','192.168.9.13','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-DC-CCPROD')
,('EFL-DC-DLR01','EFL-DC-DLR01','10.98.0.49','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-DLR01')
,('EFL-DC-JOSAPP01','EFL-DC-JOSAPP01','10.98.0.111','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-JOSAPP01')
,('EFL-DC-JOSAPP02','EFL-DC-JOSAPP02','10.98.0.112','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-JOSAPP02')
,('EFL-DC-JOSAPP04','EFL-DC-JOSAPP04','10.98.0.24','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-JOSAPP04')
,('EFL-DC-JOSDB','EFL-DC-JOSDB','10.98.0.54','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-JOSDB')
,('EFL-DC-JOSDBFO','EFL-DC-JOSDBFO','10.98.0.53','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-JOSDBFO')
,('EFL-DC-JOSDBFO_MySQL','EFL-DC-JOSDBFO_MySQL','10.98.0.58','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-JOSDBFO_MySQL')
,('EFL-DC-JOSDEV','EFL-DC-JOSDEV','192.168.9.153','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-JOSDEV')
,('EFL-DC-JOSGWFO','EFL-DC-JOSGWFO','192.168.3.52','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-JOSGWFO')
,('EFL-DC-JOSQA','EFL-DC-JOSQA','192.168.9.154','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-JOSQA')
,('EFL-DC-PLR01','EFL-DC-PLR01','10.98.0.45','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-PLR01')
,('EFL-DC-SAPCC','EFL-DC-SAPCC','192.168.9.90','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-DC-SAPCC')
,('EFL-DC-SAPPS','EFL-DC-SAPPS','192.168.3.68','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-DC-SAPPS')
,('EFL-DC-SFTP','EFL-DC-SFTP','192.168.9.45','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-SFTP')
,('EFL-DC-SLDWorks','EFL-DC-SLDWorks','192.168.9.126','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-DC-SLDWorks')
,('EFL-DC-SM','EFL-DC-SM','192.168.9.164','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-DC-SM')
,('EFL-DC-SYSLOG','EFL-DC-SYSLOG','192.168.9.73','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-SYSLOG')
,('EFL-DC-TCN01','EFL-DC-TCN01','10.98.0.47','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-TCN01')
,('EFL-DC-TECHDEV','EFL-DC-TECHDEV','192.168.9.178','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-TECHDEV')
,('EFL-DC-TECHQA','EFL-DC-TECHQA','192.168.9.179','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-TECHQA')
,('EFL-DC-TECHQA1','EFL-DC-TECHQA1','192.168.9.180','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-TECHQA1')
,('EFL-DC-TECHQAGW','EFL-DC-TECHQAGW','192.168.9.186','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-TECHQAGW')
,('EFL-DC-TGW','EFL-DC-TGW','192.168.3.49','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-TGW')
,('EFL-DC-TGWFO','EFL-DC-TGWFO','192.168.3.51','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-TGWFO')
,('EFL-DC-TGWFO-MySQL','EFL-DC-TGWFO-MySQL','192.168.3.50','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-TGWFO-MySQL')
,('EFL-DC-TSAFO','EFL-DC-TSAFO','10.98.0.46','Linux',GETDATE(),GETDATE(),167,0,'EFL-DC-TSAFO')
,('EFL-DC-WDBIW','EFL-DC-WDBIW','192.168.9.108','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-DC-WDBIW')
,('EFL-DC-WDCRM','EFL-DC-WDCRM','192.168.9.106','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-DC-WDCRM')
,('EFL-DC-WDECC','EFL-DC-WDECC','192.168.9.107','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-DC-WDECC')
,('EFL-HO-DHCP02','EFL-HO-DHCP02','10.101.200.154','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-HO-DHCP02')
,('EFL-HO-FS01','EFL-HO-FS01','10.101.200.211','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-HO-FS01')
,('efl-mail-cas1','efl-mail-cas1','192.168.3.224','Windows Server',GETDATE(),GETDATE(),167,0,'efl-mail-cas1')
,('efl-mail-cas2','efl-mail-cas2','192.168.3.222','Windows Server',GETDATE(),GETDATE(),167,0,'efl-mail-cas2')
,('EFL-SEPM','EFL-SEPM','192.168.9.166','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-SEPM')
,('EFL-SW1','EFL-SW1','10.98.0.147','Storage Array',GETDATE(),GETDATE(),167,0,'EFL-SW1')
,('EFL-SW2','EFL-SW2','10.98.0.148','Storage Array',GETDATE(),GETDATE(),167,0,'EFL-SW2')
,('EFL-VCS-SRV','EFL-VCS-SRV','192.168.9.244','Windows Server',GETDATE(),GETDATE(),167,0,'EFL-VCS-SRV')
,('EFL_monitoring server','EFL_monitoring server','192.168.9.132','Linux',GETDATE(),GETDATE(),167,0,'EFL_monitoring server')
,('EFLAD6','EFLAD6','10.98.0.99','Windows Server',GETDATE(),GETDATE(),167,0,'EFLAD6')
,('EFLAD8','EFLAD8','10.98.0.98','Windows Server',GETDATE(),GETDATE(),167,0,'EFLAD8')
,('EFLAD9','EFLAD9','10.98.0.94','Windows Server',GETDATE(),GETDATE(),167,0,'EFLAD9')
,('eflbrightmail1.eurekaforbes.co.in','eflbrightmail1.eurekaforbes.co.in','192.168.3.71','Linux',GETDATE(),GETDATE(),167,0,'eflbrightmail1.eurekaforbes.co.in')
,('EFLBRIGHTMAIL2','EFLBRIGHTMAIL2','192.168.9.103','Linux',GETDATE(),GETDATE(),167,0,'EFLBRIGHTMAIL2')
,('EFLDEHRADUN','EFLDEHRADUN','10.100.46.101','Windows Server',GETDATE(),GETDATE(),167,0,'EFLDEHRADUN')
,('EFLHUB','EFLHUB','10.98.0.119','Linux',GETDATE(),GETDATE(),167,0,'EFLHUB')
,('EFLSYM','EFLSYM','192.168.9.30','Windows Server',GETDATE(),GETDATE(),167,0,'EFLSYM')
,('EFLSYM2','EFLSYM2','192.168.9.101','Windows Server',GETDATE(),GETDATE(),167,0,'EFLSYM2')
,('EFLVCENTER','EFLVCENTER','192.168.9.251','Windows Server',GETDATE(),GETDATE(),167,0,'EFLVCENTER')
,('eurekarouter','eurekarouter','192.168.9.235','Linux',GETDATE(),GETDATE(),167,0,'eurekarouter')
,('EURO-HPDP','EURO-HPDP','10.98.0.105','Windows Server',GETDATE(),GETDATE(),167,0,'EURO-HPDP')
,('EURODB','EURODB','10.98.0.118','Windows Server',GETDATE(),GETDATE(),167,0,'EURODB')
,('EUROIIS','EUROIIS','192.168.9.60','Windows Server',GETDATE(),GETDATE(),167,0,'EUROIIS')
,('HP Chassis','HP Chassis','192.168.3.31','Vmware/Xen/Hyper-V',GETDATE(),GETDATE(),167,0,'HP Chassis')
,('HP MSL 2024 Tape Library_7','HP MSL 2024 Tape Library_7','192.168.9.137','Tape Library',GETDATE(),GETDATE(),167,0,'HP MSL 2024 Tape Library_7')
,('HP MSL 4048 Tape Library_6','HP MSL 4048 Tape Library_6','192.168.9.228','Tape Library',GETDATE(),GETDATE(),167,0,'HP MSL 4048 Tape Library_6')
,('HRMS-PROD-APP01','HRMS-PROD-APP01','192.168.9.24','Windows Server',GETDATE(),GETDATE(),167,0,'HRMS-PROD-APP01')
,('IBM Chassis','IBM Chassis','192.168.3.32','Vmware/Xen/Hyper-V',GETDATE(),GETDATE(),167,0,'IBM Chassis')
,('IBM System Stroage TS3200 Tape library_2','IBM System Stroage TS3200 Tape library_2','192.168.9.184','Storage Array',GETDATE(),GETDATE(),167,0,'IBM System Stroage TS3200 Tape library_2')
,('IBM System Stroage TS3200 Tape library_4','IBM System Stroage TS3200 Tape library_4','10.98.0.5','Storage Array',GETDATE(),GETDATE(),167,0,'IBM System Stroage TS3200 Tape library_4')
,('IBM System Stroage TS3200 Tape library_8','IBM System Stroage TS3200 Tape library_8','192.168.9.109','Storage Array',GETDATE(),GETDATE(),167,0,'IBM System Stroage TS3200 Tape library_8')
,('Main_Test','Main_Test','192.168.9.132','Linux',GETDATE(),GETDATE(),167,0,'Main_Test')
,('MITHI1','MITHI1','192.168.3.40','Linux',GETDATE(),GETDATE(),167,0,'MITHI1')
,('MITHI2','MITHI2','192.168.3.39','Linux',GETDATE(),GETDATE(),167,0,'MITHI2')
,('QLIKVIEW-DEVL','QLIKVIEW-DEVL','10.98.0.125','Windows Server',GETDATE(),GETDATE(),167,0,'QLIKVIEW-DEVL')
,('QLIKVIEW-PROD','QLIKVIEW-PROD','192.168.9.120','Windows Server',GETDATE(),GETDATE(),167,0,'QLIKVIEW-PROD')
,('SAPROUTER','SAPROUTER','192.168.9.110','Linux',GETDATE(),GETDATE(),167,0,'SAPROUTER')
,('Shivane - FS','Shivane - FS','10.101.52.135','Windows Server',GETDATE(),GETDATE(),167,0,'Shivane - FS')
,('SMTP','SMTP','192.168.9.86','Linux',GETDATE(),GETDATE(),167,0,'SMTP')
,('TrustE Server','TrustE Server','192.168.9.70','Windows Server',GETDATE(),GETDATE(),167,0,'TrustE Server')
,('V5030','V5030','10.98.0.140','Storage Array',GETDATE(),GETDATE(),167,0,'V5030')
,('VSPHERE1','VSPHERE1','10.98.0.16','Vmware/Xen/Hyper-V',GETDATE(),GETDATE(),167,0,'VSPHERE1')
,('VSPHERE10','VSPHERE10','192.168.9.253','Vmware/Xen/Hyper-V',GETDATE(),GETDATE(),167,0,'VSPHERE10')
,('VSPHERE16','VSPHERE16','192.168.9.95','Vmware/Xen/Hyper-V',GETDATE(),GETDATE(),167,0,'VSPHERE16')
,('VSPHERE3','VSPHERE3','192.168.9.114','Vmware/Xen/Hyper-V',GETDATE(),GETDATE(),167,0,'VSPHERE3')
,('VSPHERE5','VSPHERE5','10.98.0.10','Vmware/Xen/Hyper-V',GETDATE(),GETDATE(),167,0,'VSPHERE5')
,('VSPHERE6','VSPHERE6','192.168.9.44','Vmware/Xen/Hyper-V',GETDATE(),GETDATE(),167,0,'VSPHERE6')
,('VSPHERE7','VSPHERE7','192.168.9.138','Vmware/Xen/Hyper-V',GETDATE(),GETDATE(),167,0,'VSPHERE7')
,('VSPHERE8','VSPHERE8','192.168.9.252','Vmware/Xen/Hyper-V',GETDATE(),GETDATE(),167,0,'VSPHERE8')
,('VSPHERE9','VSPHERE9','192.168.9.249','Vmware/Xen/Hyper-V',GETDATE(),GETDATE(),167,0,'VSPHERE9')
,('WEBDISPATCHER1','WEBDISPATCHER1','192.168.9.55','Windows Server',GETDATE(),GETDATE(),167,0,'WEBDISPATCHER1')
,('WEBDISPATCHER5','WEBDISPATCHER5','192.168.9.61','Windows Server',GETDATE(),GETDATE(),167,0,'WEBDISPATCHER5')
,('WEBDISPATCHER7','WEBDISPATCHER7','192.168.9.50','Windows Server',GETDATE(),GETDATE(),167,0,'WEBDISPATCHER7')
,('WSUS server','WSUS server','10.98.0.19','Windows Server',GETDATE(),GETDATE(),167,0,'WSUS server')


  select * from DeviceServiceMapping where deviceId= 5570 and serviceId in (196, 198)

  select top 105 * from device order by 1 desc


  --  insert into DeviceServiceMapping (serviceId, deviceId, deleted, ticketTypeId)

values
(198,29307,0,4),
(198,29306,0,4),
(198,29305,0,4),
(198,29304,0,4),
(198,29303,0,4),
(198,29302,0,4),
(198,29301,0,4),
(198,29300,0,4),
(198,29299,0,4),
(198,29298,0,4),
(198,29297,0,4),
(198,29296,0,4),
(198,29295,0,4),
(198,29294,0,4),
(198,29293,0,4),
(198,29292,0,4),
(198,29291,0,4),
(198,29290,0,4),
(198,29289,0,4),
(198,29288,0,4),
(198,29287,0,4),
(198,29286,0,4),
(198,29285,0,4),
(198,29284,0,4),
(198,29283,0,4),
(198,29282,0,4),
(198,29281,0,4),
(198,29280,0,4),
(198,29279,0,4),
(198,29278,0,4),
(198,29277,0,4),
(198,29276,0,4),
(198,29275,0,4),
(198,29274,0,4),
(198,29273,0,4),
(198,29272,0,4),
(198,29271,0,4),
(198,29270,0,4),
(198,29269,0,4),
(198,29268,0,4),
(198,29267,0,4),
(198,29266,0,4),
(198,29265,0,4),
(198,29264,0,4),
(198,29263,0,4),
(198,29262,0,4),
(198,29261,0,4),
(198,29260,0,4),
(198,29259,0,4),
(198,29258,0,4),
(198,29257,0,4),
(198,29256,0,4),
(198,29255,0,4),
(198,29254,0,4),
(198,29253,0,4),
(198,29252,0,4),
(198,29251,0,4),
(198,29250,0,4),
(198,29249,0,4),
(198,29248,0,4),
(198,29247,0,4),
(198,29246,0,4),
(198,29245,0,4),
(198,29244,0,4),
(198,29243,0,4),
(198,29242,0,4),
(198,29241,0,4),
(198,29240,0,4),
(198,29239,0,4),
(198,29238,0,4),
(198,29237,0,4),
(198,29236,0,4),
(198,29235,0,4),
(198,29234,0,4),
(198,29233,0,4),
(198,29232,0,4),
(198,29231,0,4),
(198,29230,0,4),
(198,29229,0,4),
(198,29228,0,4),
(198,29227,0,4),
(198,29226,0,4),
(198,29225,0,4),
(198,29224,0,4),
(198,29223,0,4),
(198,29222,0,4),
(198,29221,0,4),
(198,29220,0,4),
(198,29219,0,4),
(198,29218,0,4),
(198,29217,0,4),
(198,29216,0,4),
(198,29215,0,4),
(198,29214,0,4),
(198,29213,0,4),
(198,29212,0,4)





--Insert into Device (deviceName, alternateName, ipAddress, description, createdDate, modifiedDate, customerId, deleted, hostName)
values 
('Aruba- HO 1 - Controller -Virtual IP','Aruba- HO 1 - Controller -Virtual IP','10.101.205.9','Wireless Access Point',getdate(),getdate(),167,0,'Aruba- HO 1 - Controller -Virtual IP'),
('Aruba- HO AP12','Aruba- HO AP12','10.101.205.20','Wireless Access Point',getdate(),getdate(),167,0,'Aruba- HO AP12'),
('Dadar Virtual controller','Dadar Virtual controller','10.100.19.21','Wireless Access Point',getdate(),getdate(),167,0,'Dadar Virtual controller'),
('EFL-Dadar-L3-SWITCH','EFL-Dadar-L3-SWITCH','10.101.19.5','Network Switch',getdate(),getdate(),167,0,'EFL-Dadar-L3-SWITCH'),
('EFL-DMZ-SWITCH-STACK-1','EFL-DMZ-SWITCH-STACK-1','192.168.3.4','Network Switch',getdate(),getdate(),167,0,'EFL-DMZ-SWITCH-STACK-1'),
('EFL-DMZ-SWITCH-STACK-2','EFL-DMZ-SWITCH-STACK-2','192.168.3.5','Network Switch',getdate(),getdate(),167,0,'EFL-DMZ-SWITCH-STACK-2'),
('EFL-PROD-SWITCH-STACK','EFL-PROD-SWITCH-STACK','10.98.0.2','Network Switch',getdate(),getdate(),167,0,'EFL-PROD-SWITCH-STACK'),
('EFL_DADAR_10MB_ILL_AIRTEL_MPLS','EFL_DADAR_10MB_ILL_AIRTEL_MPLS','172.40.181.74','IP Router',getdate(),getdate(),167,0,'EFL_DADAR_10MB_ILL_AIRTEL_MPLS'),
('EFL_DC_Router','EFL_DC_Router','10.101.108.1','IP Router',getdate(),getdate(),167,0,'EFL_DC_Router'),
('EFL_Firewall','EFL_Firewall','192.168.9.14','Firewall Appliance',getdate(),getdate(),167,0,'EFL_Firewall'),
('EFL_HO_AP1','EFL_HO_AP1','10.101.205.10','Wireless Access Point',getdate(),getdate(),167,0,'EFL_HO_AP1'),
('EFL_HO_AP10','EFL_HO_AP10','10.101.205.19','Wireless Access Point',getdate(),getdate(),167,0,'EFL_HO_AP10'),
('EFL_HO_AP2','EFL_HO_AP2','10.101.205.11','Wireless Access Point',getdate(),getdate(),167,0,'EFL_HO_AP2'),
('EFL_HO_AP3','EFL_HO_AP3','10.101.205.12','Wireless Access Point',getdate(),getdate(),167,0,'EFL_HO_AP3'),
('EFL_HO_AP4','EFL_HO_AP4','10.101.205.13','Wireless Access Point',getdate(),getdate(),167,0,'EFL_HO_AP4'),
('EFL_HO_AP5','EFL_HO_AP5','10.101.205.14','Wireless Access Point',getdate(),getdate(),167,0,'EFL_HO_AP5'),
('EFL_HO_AP6','EFL_HO_AP6','10.101.205.15','Wireless Access Point',getdate(),getdate(),167,0,'EFL_HO_AP6'),
('EFL_HO_AP7','EFL_HO_AP7','10.101.205.16','Wireless Access Point',getdate(),getdate(),167,0,'EFL_HO_AP7'),
('EFL_HO_AP8','EFL_HO_AP8','10.101.205.17','Wireless Access Point',getdate(),getdate(),167,0,'EFL_HO_AP8'),
('EFL_HO_AP9','EFL_HO_AP9','10.101.205.18','Wireless Access Point',getdate(),getdate(),167,0,'EFL_HO_AP9'),
('EFL_HO_BOARD-ROOM_58','EFL_HO_BOARD-ROOM_58','10.101.204.1','IP Router',getdate(),getdate(),167,0,'EFL_HO_BOARD-ROOM_58'),
('EFL_MARATHON_HP_ALS09_SWITCH','EFL_MARATHON_HP_ALS09_SWITCH','10.101.200.19','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_HP_ALS09_SWITCH'),
('EFL_MARATHON_HP_ALS10_SWITCH','EFL_MARATHON_HP_ALS10_SWITCH','10.101.200.20','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_HP_ALS10_SWITCH'),
('EFL_MARATHON_HP_ALS1_SWITCH','EFL_MARATHON_HP_ALS1_SWITCH','10.101.200.11','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_HP_ALS1_SWITCH'),
('EFL_MARATHON_HP_ALS2_SWITCH','EFL_MARATHON_HP_ALS2_SWITCH','10.101.200.12','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_HP_ALS2_SWITCH'),
('EFL_MARATHON_HP_ALS3_SWITCH','EFL_MARATHON_HP_ALS3_SWITCH','10.101.200.13','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_HP_ALS3_SWITCH'),
('EFL_MARATHON_HP_ALS4_SWITCH','EFL_MARATHON_HP_ALS4_SWITCH','10.101.200.14','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_HP_ALS4_SWITCH'),
('EFL_MARATHON_HP_ALS5_SWITCH','EFL_MARATHON_HP_ALS5_SWITCH','10.101.200.15','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_HP_ALS5_SWITCH'),
('EFL_MARATHON_HP_ALS6_SWITCH','EFL_MARATHON_HP_ALS6_SWITCH','10.101.200.16','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_HP_ALS6_SWITCH'),
('EFL_MARATHON_HP_ALS7_SWITCH','EFL_MARATHON_HP_ALS7_SWITCH','10.101.200.17','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_HP_ALS7_SWITCH'),
('EFL_MARATHON_HP_ALS8_SWITCH','EFL_MARATHON_HP_ALS8_SWITCH','10.101.200.18','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_HP_ALS8_SWITCH'),
('EFL_MARATHON_HP_L3_SWITCH','EFL_MARATHON_HP_L3_SWITCH','10.101.200.2','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_HP_L3_SWITCH'),
('EFL_MARATHON_ROUTER','EFL_MARATHON_ROUTER','10.101.200.1','IP Router',getdate(),getdate(),167,0,'EFL_MARATHON_ROUTER'),
('EFL_MARATHON_WIFI_SWITCH','EFL_MARATHON_WIFI_SWITCH','10.101.200.21','Network Switch',getdate(),getdate(),167,0,'EFL_MARATHON_WIFI_SWITCH'),
('EFL_MUM_CHEMBUR_RO_TATA_ROUTER','EFL_MUM_CHEMBUR_RO_TATA_ROUTER','10.100.79.129','IP Router',getdate(),getdate(),167,0,'EFL_MUM_CHEMBUR_RO_TATA_ROUTER'),
('EFL_NASIK_32','EFL_NASIK_32','97.0.16.118','IP Router',getdate(),getdate(),167,0,'EFL_NASIK_32'),
('EFL_SANJAYNAGAR_AIRTEL_Internet','EFL_SANJAYNAGAR_AIRTEL_Internet','172.40.171.22','IP Router',getdate(),getdate(),167,0,'EFL_SANJAYNAGAR_AIRTEL_Internet'),
('EFL_VIKROLI_DC_HP_L3_SWITCH','EFL_VIKROLI_DC_HP_L3_SWITCH','10.98.12.1','Network Switch',getdate(),getdate(),167,0,'EFL_VIKROLI_DC_HP_L3_SWITCH'),
('EFL_VIKROLI_DC_INTERNET_NETMAGIC_ROUTER','EFL_VIKROLI_DC_INTERNET_NETMAGIC_ROUTER','124.153.91.193','IP Router',getdate(),getdate(),167,0,'EFL_VIKROLI_DC_INTERNET_NETMAGIC_ROUTER'),
('FortiAnalyzer','FortiAnalyzer','10.98.12.6','Firewall Appliance',getdate(),getdate(),167,0,'FortiAnalyzer'),
('Fortigate-Firewall_192.168.9.14','Fortigate-Firewall_192.168.9.14','10.98.0.1','Firewall Appliance',getdate(),getdate(),167,0,'Fortigate-Firewall_192.168.9.14'),
('INBAG---RA001','INBAG---RA001','10.77.190.218','IP Router',getdate(),getdate(),167,0,'INBAG---RA001'),
('INBDD---RA001','INBDD---RA001','10.100.27.129','IP Router',getdate(),getdate(),167,0,'INBDD---RA001'),
('INBOM---RA001','INBOM---RA001','10.101.137.1','IP Router',getdate(),getdate(),167,0,'INBOM---RA001'),
('INCHB---AP001','INCHB---AP001','10.100.9.18','Wireless Access Point',getdate(),getdate(),167,0,'INCHB---AP001'),
('INCHB---AP002','INCHB---AP002','10.100.9.13','Wireless Access Point',getdate(),getdate(),167,0,'INCHB---AP002'),
('INCHB---AP003','INCHB---AP003','10.100.9.14','Wireless Access Point',getdate(),getdate(),167,0,'INCHB---AP003'),
('INCHB---AP004','INCHB---AP004','10.100.9.15','Wireless Access Point',getdate(),getdate(),167,0,'INCHB---AP004'),
('INCHB---AP005','INCHB---AP005','10.100.9.16','Wireless Access Point',getdate(),getdate(),167,0,'INCHB---AP005'),
('INCHB---AP006','INCHB---AP006','10.100.9.17','Wireless Access Point',getdate(),getdate(),167,0,'INCHB---AP006'),
('INCHB---AP007','INCHB---AP007','10.100.9.12','Wireless Access Point',getdate(),getdate(),167,0,'INCHB---AP007'),
('INCHB---RA001','INCHB---RA001','10.102.11.1','IP Router',getdate(),getdate(),167,0,'INCHB---RA001'),
('INCHB---RA002','INCHB---RA002','10.100.9.1','IP Router',getdate(),getdate(),167,0,'INCHB---RA002'),
('INCHB---SA001','INCHB---SA001','10.102.11.37','Network Switch',getdate(),getdate(),167,0,'INCHB---SA001'),
('INCHB---SA002','INCHB---SA002','10.102.11.38','IP Router',getdate(),getdate(),167,0,'INCHB---SA002'),
('INCHB---SA003','INCHB---SA003','10.102.11.34','Network Switch',getdate(),getdate(),167,0,'INCHB---SA003'),
('INCHB---SA004','INCHB---SA004','10.100.9.11','Network Switch',getdate(),getdate(),167,0,'INCHB---SA004'),
('INCHB---SA005','INCHB---SA005','10.100.9.19','Network Switch',getdate(),getdate(),167,0,'INCHB---SA005'),
('INCHB---SA006','INCHB---SA006','10.100.9.20','Network Switch',getdate(),getdate(),167,0,'INCHB---SA006'),
('INCHB---SA007','INCHB---SA007','10.100.9.21','Network Switch',getdate(),getdate(),167,0,'INCHB---SA007'),
('INCHB---SA008','INCHB---SA008','10.100.9.22','Network Switch',getdate(),getdate(),167,0,'INCHB---SA008'),
('INCHB---SA009','INCHB---SA009','10.100.9.23','Network Switch',getdate(),getdate(),167,0,'INCHB---SA009'),
('INCHB---SA010','INCHB---SA010','10.100.9.24','Network Switch',getdate(),getdate(),167,0,'INCHB---SA010'),
('INCHB---SD001','INCHB---SD001','10.102.11.35','IP Router',getdate(),getdate(),167,0,'INCHB---SD001'),
('INCHB---SD002','INCHB---SD002','10.102.11.36','Network Switch',getdate(),getdate(),167,0,'INCHB---SD002'),
('INCHB---SD003','INCHB---SD003','10.100.9.2','IP Router',getdate(),getdate(),167,0,'INCHB---SD003'),
('INCHK---RA001','INCHK---RA001','10.100.11.129','IP Router',getdate(),getdate(),167,0,'INCHK---RA001'),
('INCMS---FW001','INCMS---FW001','10.101.80.1','Firewall Appliance',getdate(),getdate(),167,0,'INCMS---FW001'),
('INCMS---RA002','INCMS---RA002','10.101.80.2','IP Router',getdate(),getdate(),167,0,'INCMS---RA002'),
('INCMS---SA001','INCMS---SA001','10.101.80.3','Network Switch',getdate(),getdate(),167,0,'INCMS---SA001'),
('INCMS---SA002','INCMS---SA002','10.101.80.4','Network Switch',getdate(),getdate(),167,0,'INCMS---SA002'),
('INDDR---RA001','INDDR---RA001','10.100.78.2','IP Router',getdate(),getdate(),167,0,'INDDR---RA001'),
('INDDR---SA002','INDDR---SA002','10.100.19.26','Network Switch',getdate(),getdate(),167,0,'INDDR---SA002'),
('INDDR---SA003','INDDR---SA003','10.100.19.27','Network Switch',getdate(),getdate(),167,0,'INDDR---SA003'),
('INDDR---SA004','INDDR---SA004','10.100.19.28','Network Switch',getdate(),getdate(),167,0,'INDDR---SA004'),
('INDDR---SA005','INDDR---SA005','10.100.19.29','Network Switch',getdate(),getdate(),167,0,'INDDR---SA005'),
('INDDR---SA006','INDDR---SA006','10.100.19.30','Network Switch',getdate(),getdate(),167,0,'INDDR---SA006'),
('INDHD---RA001','INDHD---RA001','10.100.46.1','IP Router',getdate(),getdate(),167,0,'INDHD---RA001'),
('INENT---RA001','INENT---RA001','10.101.158.1','IP Router',getdate(),getdate(),167,0,'INENT---RA001'),
('INFRT---AP001','INFRT---AP001','10.100.10.16','Wireless Access Point',getdate(),getdate(),167,0,'INFRT---AP001'),
('INFRT---AP002','INFRT---AP002','10.100.10.17','Wireless Access Point',getdate(),getdate(),167,0,'INFRT---AP002'),
('INFRT---AP003','INFRT---AP003','10.100.10.18','Wireless Access Point',getdate(),getdate(),167,0,'INFRT---AP003'),
('INFRT---AP004','INFRT---AP004','10.100.10.19','Wireless Access Point',getdate(),getdate(),167,0,'INFRT---AP004'),
('INFRT---RA001','INFRT---RA001','10.100.10.1','IP Router',getdate(),getdate(),167,0,'INFRT---RA001'),
('INFRT---SA001','INFRT---SA001','10.100.10.2','Network Switch',getdate(),getdate(),167,0,'INFRT---SA001'),
('INFRT---SA002','INFRT---SA002','10.100.10.3','Network Switch',getdate(),getdate(),167,0,'INFRT---SA002'),
('INGUW---RA001','INGUW---RA001','10.100.62.1','IP Router',getdate(),getdate(),167,0,'INGUW---RA001'),
('INHGH---RA001','INHGH---RA001','172.40.156.186','IP Router',getdate(),getdate(),167,0,'INHGH---RA001'),
('INJAI---RA001','INJAI---RA001','172.40.171.66','IP Router',getdate(),getdate(),167,0,'INJAI---RA001'),
('INKAG---RA001','INKAG---RA001','10.150.114.92','IP Router',getdate(),getdate(),167,0,'INKAG---RA001'),
('INKAS---RA001','INKAS---RA001','10.70.98.82','IP Router',getdate(),getdate(),167,0,'INKAS---RA001'),
('INKOR---RA001','INKOR---RA001','10.101.52.129','IP Router',getdate(),getdate(),167,0,'INKOR---RA001'),
('INKOT---RA001','INKOT---RA001','10.101.155.1','IP Router',getdate(),getdate(),167,0,'INKOT---RA001'),
('INNAV---RA001','INNAV---RA001','10.99.23.1','IP Router',getdate(),getdate(),167,0,'INNAV---RA001'),
('INRJD---RA001','INRJD---RA001','10.100.12.129','IP Router',getdate(),getdate(),167,0,'INRJD---RA001'),
('INRJK---RA001','INRJK---RA001','10.100.18.1','IP Router',getdate(),getdate(),167,0,'INRJK---RA001')



  select top 96  * from device order by 1 desc

  
  Insert into Device (deviceName, alternateName, ipAddress, description, createdDate, modifiedDate, customerId, deleted, hostName) values

('INDDR---SD001','INDDR---SD001','10.100.19.5','Network Switch',getdate(),getdate(),167,0,'INDDR---SD001'),
('INDDR---SA001','INDDR---SA001','10.100.19.31','Network Switch',getdate(),getdate(),167,0,'INDDR---SA001'),
('INDDR---AP001','INDDR---AP001','10.100.19.32','Wireless Access Point',getdate(),getdate(),167,0,'INDDR---AP001'),
('INDDR---AP002','INDDR---AP002','10.100.19.33','Wireless Access Point',getdate(),getdate(),167,0,'INDDR---AP002'),
('INDDR---AP003','INDDR---AP003','10.100.19.34','Wireless Access Point',getdate(),getdate(),167,0,'INDDR---AP003'),
('INDDR---AP004','INDDR---AP004','10.100.19.35','Wireless Access Point',getdate(),getdate(),167,0,'INDDR---AP004'),
('INDDR---AP005','INDDR---AP005','10.100.19.36','Wireless Access Point',getdate(),getdate(),167,0,'INDDR---AP005'),
('INDDR---AP006','INDDR---AP006','10.100.19.37','Wireless Access Point',getdate(),getdate(),167,0,'INDDR---AP006'),
('INDDR---AP007','INDDR---AP007','10.100.19.38','Wireless Access Point',getdate(),getdate(),167,0,'INDDR---AP007'),
('INDDR---AP008','INDDR---AP008','10.100.19.39','Wireless Access Point',getdate(),getdate(),167,0,'INDDR---AP008'),
('INDDR---AP009','INDDR---AP009','10.100.19.40','Wireless Access Point',getdate(),getdate(),167,0,'INDDR---AP009')


  select top 11  * from device order by 1 desc


  -- insert into DeviceServiceMapping (serviceId, deviceId, deleted, ticketTypeId)

values
(198,29318,0,4),
(198,29317,0,4),
(198,29316,0,4),
(198,29315,0,4),
(198,29314,0,4),
(198,29313,0,4),
(198,29312,0,4),
(198,29311,0,4),
(198,29310,0,4),
(198,29309,0,4),
(198,29308,0,4)

   

select * from role where name like '%EFL%'  ---  86	EFL_Quinnox_Engineer	EFL Quinnox Engineer

                 -- INSERT INTO ROLE (name, description, deleted, allowAllChangeTicketApproval, landingPageUrl, roleDisplayName)
				 Values ('EFL_SPIT_Engineer', 'EFL_SPIT_Engineer', 0, 0, 'Action=Index,Controller=Dashboard,TemplateId=10', 'EFL_SPIT_Engineer')

select * from roleaccess

select * from roleaccessmapping where roleId = 86

   --INSERT INTO RoleAccessMapping (roleId, roleAccessId, permission, isdeleted)

   SELECT 00, roleAccessId,  permission, isdeleted, from roleaccessmapping where roleId = 86



select * from [dbo].[ChangeAdvisoryBoard] where customerid=147

select  * from users where roleid=3

select * from rcareviewer
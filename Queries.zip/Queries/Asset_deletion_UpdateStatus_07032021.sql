﻿[10:37 AM] Vignesh Annadurai
    select * from Asset_AssetNumberConfiguration where CustomerId = 147 and AssetTypeId = 14

--update Asset_AssetNumberConfiguration set SequenceNumber= 102419 where CustomerId = 147 and AssetTypeId = 14
​[10:37 AM] Vignesh Annadurai
    

--EXEC Usp_AssetDeletetionByAssetId 751170


--EXEC Usp_AssetDeletetionByAssetId 20594


----> Link to watch Video:
https://web.microsoftstream.com/video/19aae217-45f6-4456-b6b6-8adefa3b8de9
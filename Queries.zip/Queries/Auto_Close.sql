       
	   
	      //       select * from TicketStatus s where s.ticketTypeId in (1,2) and s.deleted=0 and s.status like '%resol%'  

          select distinct(t.serviceId),t.workgroupId, * from ticket t where customerId = 182 and t.statusId in (9,19) and t.createdOn < '2020-05-08' order by 1,2,3 desc 

          select * from ClosureCode where customerId = 182 and closureCode='Auto Close'

	   --   1006	Auto Close	1
       --   1017	Auto Close	2
 

		     
			-- Insert into ClosureCode values ('Auto Close', 1, 0, 6, getdate(), 6, getdate(), 209)
			-- Insert into ClosureCode values ('Auto Close', 2, 0, 6, getdate(), 6, getdate(), 209)

          select * from AutoCloseInfo where customerid = 191 and serviceid = 489 and workgroupid in (459) order by serviceid,workgroupid, ticketTypeID


		 -- need to check for customer--> 204 is 463, 464

          insert into AutoCloseInfo (customerid,customerName,autocloseTime,ticketTypeID,closureCode,closureCodeText,userID,isActive,serviceid,workgroupid) values
	      (191,'Oreta-Kings Transport',2880,1,980,'Auto Close',5,'Active', 318,3),
	      (191,'Oreta-Kings Transport',2880,2,985,'Auto Close',5,'Active', 318,3),
			
		  (191,'Oreta-Kings Transport',2880,1,980,'Auto Close',5,'Active', 318,611),
	      (191,'Oreta-Kings Transport',2880,2,985,'Auto Close',5,'Active', 318,611),
				
		  (191,'Oreta-Kings Transport',2880,1,980,'Auto Close',5,'Active', 319,3),
	      (191,'Oreta-Kings Transport',2880,2,985,'Auto Close',5,'Active', 319,3),
				
		  (191,'Oreta-Kings Transport',2880,1,980,'Auto Close',5,'Active', 319,491),
	      (191,'Oreta-Kings Transport',2880,2,985,'Auto Close',5,'Active', 319,491),

		  (191,'Oreta-Kings Transport',2880,1,980,'Auto Close',5,'Active', 319,611),
	      (191,'Oreta-Kings Transport',2880,2,985,'Auto Close',5,'Active', 319,611)



				
		  (207,'Unity Bio',2880,1,1330,'Auto Close',5,'Active', 477,643),
	      (207,'Unity Bio',2880,2,1341,'Auto Close',5,'Active', 477,643),
				
		  (207,'Unity Bio',2880,1,1330,'Auto Close',5,'Active', 478,643),
	      (207,'Unity Bio',2880,2,1341,'Auto Close',5,'Active', 478,643),
				
		  (207,'Unity Bio',2880,1,1330,'Auto Close',5,'Active', 499,625),
	      (207,'Unity Bio',2880,2,1341,'Auto Close',5,'Active', 499,625)






		  

		








	      
	      (147,'JLSL',2880,1,247,'Auto Close',5,'Active', 70,595),
	      (147,'JLSL',2880,2,467,'Auto Close',5,'Active', 70,595),
	      (147,'JLSL',2880,1,247,'Auto Close',5,'Active', 70,596),
	      (147,'JLSL',2880,2,467,'Auto Close',5,'Active', 70,596)





--217	47
--218	442




select * from UserCustomerAssignGroupMapping where userId=5 and custAssignmentGroupId in (select custAssignmentGroupId from CustomerAssignmentGroupMapping where assignmentgroupId in (select assignmentgroupId from AssignmentGroup where workgroupId in (200,212,221,227,296)))



select * from AssignmentGroup where workgroupId=2




---------delete from AutoCloseInfo where id in (12654,12655)













--insert into UserCustomerAssignGroupMapping(userId, custAssignmentGroupId,deleted,isAssignEnabled,AssignToWorkgroup) 

select 5, custAssignmentGroupId,0,0,0 from CustomerAssignmentGroupMapping where custAssignmentGroupId not in (select custAssignmentGroupId from UserCustomerAssignGroupMapping where userId=5)


--update UserCustomerAssignGroupMapping set deleted=0 where userId=5 and deleted=1


]


For customer --> 203:
   

         -- insert into AutoCloseInfo (customerid,customerName,autocloseTime,ticketTypeID,closureCode,closureCodeText,userID,isActive,serviceid,workgroupid) values
	      (203,'Bosch � Scottsdale',2880,1,1242,'Auto Close',5,'Active', 415,2),
	      (203,'Bosch � Scottsdale',2880,2,1251,'Auto Close',5,'Active', 415,2),

		  (203,'Bosch � Scottsdale',2880,1,1242,'Auto Close',5,'Active', 415,10),
	      (203,'Bosch � Scottsdale',2880,2,1251,'Auto Close',5,'Active', 415,10),

		  (203,'Bosch � Scottsdale',2880,1,1242,'Auto Close',5,'Active', 415,47),
	      (203,'Bosch � Scottsdale',2880,2,1251,'Auto Close',5,'Active', 415,47)


		  for customer --> 204:

		  1293	Auto Close	1
          1306	Auto Close	4
          1367	Auto Close	2

		  for customer 204 --> 204 

		  for customer 202---> 202: 

		   insert into AutoCloseInfo (customerid,customerName,autocloseTime,ticketTypeID,closureCode,closureCodeText,userID,isActive,serviceid,workgroupid) values

	      (202,'SMC New khaitan and co	SMC New khaitan and co',2880,1,1368,'Auto Close',5,'Active', 232, 452),
	      (202,'SMC New khaitan and co	SMC New khaitan and co',2880,2,1369,'Auto Close',5,'Active', 232, 452),
				
		  (202,'SMC New khaitan and co	SMC New khaitan and co',2880,1,1368,'Auto Close',5,'Active', 236, 460),
	      (202,'SMC New khaitan and co	SMC New khaitan and co',2880,2,1369,'Auto Close',5,'Active', 236, 460),
		   		
		  (202,'SMC New khaitan and co	SMC New khaitan and co',2880,1,1368,'Auto Close',5,'Active', 238, 452),
	      (202,'SMC New khaitan and co	SMC New khaitan and co',2880,2,1369,'Auto Close',5,'Active', 238, 452),
				
		  (202,'SMC New khaitan and co	SMC New khaitan and co',2880,1,1368,'Auto Close',5,'Active', 239, 452),
	      (202,'SMC New khaitan and co	SMC New khaitan and co',2880,2,1369,'Auto Close',5,'Active', 239, 452),
		   		
		  (202,'SMC New khaitan and co	SMC New khaitan and co',2880,1,1368,'Auto Close',5,'Active', 239, 454),
	      (202,'SMC New khaitan and co	SMC New khaitan and co',2880,2,1369,'Auto Close',5,'Active', 239, 454),
				
		  (202,'SMC New khaitan and co	SMC New khaitan and co',2880,1,1368,'Auto Close',5,'Active', 241, 459),
	      (202,'SMC New khaitan and co	SMC New khaitan and co',2880,2,1369,'Auto Close',5,'Active', 241, 459)




		  for customer 202 --> 202

		  1368	Auto Close	1
          1369	Auto Close	2








	
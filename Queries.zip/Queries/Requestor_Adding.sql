

--->  Microland -URL: https://rmcops.microland.com/Account/microland

   select * from Users where email like '%GIS.SD@tataconsumer.com%'

     select * from Users where email like '%Sudhira@microland.com%'

	 ---->  26356

   --update Users set password ='SUv/GzSv2NSYGeW1YMGviQ==' , saltvalue = null where userid = 26540

      select * from Users where userid = 26529

      Insert into Users(firstName, lastName, userName, displayName, mobileNo, email,loginName,password, workgroupId,custAssignmentGroupId,deleted,IsWorkgroup,isPasswordPolicyApplicable,
      lastUpdatedOn,isAutoAssignmentEnable,roleId,createdById,updatedById,createdOn,updatedOn,IsEnabled,timezoneinfoId,AboutMe,instanceId,ProfilePicture,PasswordPolicyId
       ,SaltValue, primaryAssignmentGroupId, deletedOn, levelid,UserTypeId  )

	   select * from Users where userid in (26525)

	   --update Users set IsEnabled =1  where userid in (26543, 26541)

	     Pawan.Satyawali@tataconsumer.com
         Kenneth.Constantine@tataconsumer.com

	   Insert into Users(firstName,lastName,displayName,mobileNo,email,loginName,password, deleted, IsWorkgroup, isPasswordPolicyApplicable,isAutoAssignmentEnable,roleId,createdById,createdOn,timezoneinfoId,instanceId,SaltValue,levelid, UserTypeId)
	    
		--Select 'Pawan','Satyawali','Pawan Satyawali','123','Pawan.Satyawali@tataconsumer.com', 'Pawan.Satyawali','SUv/GzSv2NSYGeW1YMGviQ==', 0,0,0, 0, 140,6,GETDATE(),24,1,null,1, 4

        Select 'Kenneth','Constantine','Kenneth Constantine','123','Kenneth.Constantine@tataconsumer.com', 'Kenneth.Constantine','SUv/GzSv2NSYGeW1YMGviQ==', 0,0,0, 0, 140,6,GETDATE(),24,1,null,1, 4

		
		    select * from Users where email like '%PavithraR12@microland.com%'




			select * from UserInstanceMapping where UserId in (26525, 26560, 26562)

			-- update Users set IsEnabled =1  where userId in (26525, 26560, 26562)

			select * from Instance

			--->  https://rmcops.microland.com/Account/microland

			select * from AuthenticationType

			--Insert into UserInstanceMapping(UserId, InstanceId)
			--values (26560,1),
			--(26562,1)

			select * from UserCustomerAssignGroupMapping where UserId in ( 26562)

			--Insert into UserCustomerAssignGroupMapping (Userid, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
			--select 26562, custAssignmentGroupId, deleted, 0, 0 from UserCustomerAssignGroupMapping where userId = 26525


			    select * from Users where loginName like '%PrasanjeetBi1%'

				-- update Users set email ='itsd.hoe1@heromotocorp.com' where userId = 26481

                 --itsd.hoe1@heromotocorp.com

				  select * from autoticketserviceemailconfig where apikey in (
				   select keyname from ApiKey where customerId = 3
				  )

        select * from Requestor where requestorEmail like '%CDC_operations%'

	--	Insert into Requestor (requestorName, requestorEmail, isCriticalUser,employeeId, firstname, lastname,  alias, department, location, mobileno, 
	--createdOn, UpdatedOn, createdby, updatedby, deleted, LastLoginTime, CountryCode, failedLoginAttemptCount, isAccountLocked)

	--values ('VAAudit Scan_Corp', 'CDC_operations@microland.com', 0, '1231', 'VAAudit', 'Scan_Corp', 'VAAuditScan_Corp', 'Devops', 'Banglore' ,'121',
	--GETDATE(), GETDATE(), 6, 6, 0, GETDATE(), 61, 0, 0)  ---> 56324 , 

	----> 50743  , 53475

	select * from CustomerRequestorMapping where Requestorid = 56324
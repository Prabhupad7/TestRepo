

select customerId,serviceId,workgroupId,TicketTypeid,* from Ticket where ticketno = 1561215  ---->  1561215  IM1563200

select customerId,serviceId,workgroupId,TicketTypeid,* from Ticket where ticketno = 1563200  ---->  1561215  IM1563200

--customerId	serviceId	workgroupId	TicketTypeid
--1	              1	          19	   1

select * from NotificationRules 
where customerId = 1 and deleted = 0 
and ticketTypeId = 1 and templateId = 475

----->  IM1563200 new test ticket: 

select * from NotificationRules 
where customerId =1 and deleted = 0  
and serviceId =1 and workgroupid = 2
and templateId = 475




 select * from NotificationHistory where TicketNo = 1561215 

select customerId,serviceId,workgroupId,TicketTypeid,* from Ticket where ticketno = 1563200  ---->  1561215  IM1563200
select * from NotificationRegistry where sourceId in (1561215) and ruleId = 3101349  ---->  notificationId: 22298299
select * from NotificationRegistry where sourceId in (1563200) and ruleId = 3101349 ---->  22326722  22298299  for new Ticket notificationId: 22328206
select * from NotificationHistory  where TicketNo = 1563200 --->  and NotificationId = 22328206
select * from NotificationHistory where TicketNo = 1561215 
select * from NotificationRules where ruleId in (2870074,2870026,3101349,3021392,3021632,3021792,3021872,3021472,3021552,3021712,3021952)


 select * from NotificationHistory 
 where TicketNo = 1563200 and NotificationId = 22328206

   select E.stateEntryId, e.ticketNo, e.statusId, t.status, e.entryTime, e.exitTime, e.activePhase from ServiceLevelStateEntry E
  inner join TicketStatus T on T.statusId = E.statusId
  where ticketNo = 1561215

select * from NotificationRules where ruleId in (
2870074,2870026,3101349,3021392,3021632,3021792,3021872,3021472,3021552,3021712,3021952)

--22298299
--22326722
--22326277

select * from NotificationRegistry where sourceId in (
1530170   
) and notificationId = 21842878


select * from NotificationRegistry where sourceId in (
1530585  
) and notificationId = 21842878

select * from NotificationRegistry where sourceId in (
1530193 
) and notificationId = 21842878


--> IM1530193 
select * from NotificationHistory where TicketNo = 1530170 




select * from NotifyBasedOn

select * from NotificationRules where ruleId in (
2863002, 2870026
)

select * from NotificationEmailTemplate 
where templateId in ( 643, 477, 475)

---->   643	Assigned Template


select top  10 * from NotificationRules where ruleId in (
2863002, 2870026,2870026,
3101350
,3101349
,3101348
,3101347)

-- Update NotificationRules set templateId = 643, entryStateId = null
-- where ruleId in (
--3101350
--,3101349
--,3101348
--,3101347)

----->  Test ticket: IM1563577

 --exec deletetickets @ticketNo = '1563577'




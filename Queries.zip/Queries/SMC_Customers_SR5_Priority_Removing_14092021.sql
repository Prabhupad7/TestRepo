

 select * from NotificationRules where deleted = 0 and customerid in(150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
 and duePercent in (70,80,90,100,120,150) 

  select * from ServiceLevelAgreement where customerId in (150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
   and subTypeId = 2

   select * from Priority where ticketTypeId = 2 ---> 16	SR5

    



		---------------------  24//82020:


		select * from WorkHours        -----

		--- Insert into WorkHours (Name, description, timeZone)
		values ('09:00am to 07:00pm', '09:00am to 07:00pm', 'India Standard Time')

		select top 1 * from workHours order by 1 desc  --- 122


		select * from WorkHours  

		select * from WorkHoursDetail where workHourId =10

		insert into WorkHoursDetail (workHourId, dayNumber, dayName, startTime, EndTime, durationInSec)
		values (122, 1, 'Monday', '2015-12-10 09:00:00.000', )


		----- 7, 9, 6

		---

		select * from 

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Vijyawada ALC%'  --- 117	

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Vijaywada Area Office%'  --- 111	

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Varanasi Area Office%'  --- 108	

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Varanasi ALC%'  --- 733

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Vadodara Area Office%'  --- 732

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Vadodara ALC%'  --- 731

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Udaipur Area Office%'  --- 107

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Udaipur ALC%'  --- 1461

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%TTpark Hyderabad%'  --- 1276

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Varanasi ALC%'  --- 733

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Varanasi ALC%'  --- 733

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Varanasi ALC%'  --- 733

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Varanasi ALC%'  --- 733
		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Varanasi ALC%'  --- 733
		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Varanasi ALC%'  --- 733

		


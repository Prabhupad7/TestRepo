		
		
		--->  select top  100 * from Location where  locationName like '%HR1K-Kukas -R And D%'

		select * from Hero_Locations where ADLocation like '%HR1K-Kukas -R And D%'

		select * from Hero_Locations where SLALocation like '%HR1K%'
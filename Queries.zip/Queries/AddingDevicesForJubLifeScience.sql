


          SELECT * FROM Customer C WHERE C.customerName LIKE '%jub%'  -- 192	
	   
	   SELECT * FROM Customer C WHERE C.customerId = 192

	   AWS-VSR-059 --- 10.160.17.15.
       AWS-VSR-060 � 10.160.16.18
       AWS-VSR-061 -- 10.160.16.19

       AWS-VSR-062--  10.160.16.20
       AWS-VSR-063 -- 10.160.50.22  --->  10.160.55.22
       AWS-VSR-064-DB --  RDS DB .

	   select * from Device where deleted = 0 and customerId = 192 
	   order by 1 desc
	   
   --    INSERT INTO device(devicename, alternateName, ipAddress, customerId, deleted, hostName) 
	  --values ('AWS-VSR-079','AWS-VSR-079','10.160.50.25', 192, 0,'AWS-VSR-079'),
	  --       ('AWS-VSR-080','AWS-VSR-080','10.160.55.22', 192, 0,'AWS-VSR-080')
			 
	   select * from Device where ipAddress ='10.160.55.22' --> 10.160.17.17

	   select * from Device where deviceName ='AWS-VSR-080' --> 10.160.17.17
	

	  Select top 2 * from Device   order by 1 desc 

	        select * from Device where deviceId  In (
			29980
			,29979)


	   select * from DeviceServiceMapping where deviceId in (30256
      ,30255)

	       -- update Device set customerId = 3 where deviceId In (
			29980
			,29979)

			select * from Service where serviceId in (
			select serviceId from ServiceCustomerMapping where customerId in (192)  and deleted = 0)

			--->  502

			select * from ServiceCustomerMapping where customerId in (192)  and deleted = 0 and serviceId = 502

30256
30255
     --479	Cloud Operations	Cloud Operations
     --502	Cloud Service	Cloud Service

	 -- INSERT INTO DeviceServiceMapping (serviceId, deviceId , deleted, ticketTypeId)
	 -- VALUES
	 --    (479,30256,0,1)
  --      ,(479,30256,0,2)
		--,(479,30256,0,3)
  --      ,(479,30256,0,4)


	 --   ,(502,30255,0,1)
  --      ,(502,30255,0,2)
		--,(502,30255,0,3)
		--,(502,30255,0,4)


		select * from workGroupEscalationMatrix

		select * from workGroupEscalationMatrix_AskML


select top 1000 * from RulesForAssignment



  select * from Service where servicename like '%CIS%'  ---->  68

  ----->  2104

  select * from Subcategory where categoryid = 2104 ----> 9135	Peripherals

  select * from classification where subcategoryid = 9135 ---->  78891	New Monitor
 
  select * from Category where category like '%Accessories%' and deleted = 0



  ------>    approvalEntityMappingId in ( 3230, 3231, 3242, 3243, 3244) 


   Select * from ApprovalEntityMapping 
   where approvalMappingRule like
   '%{customerId=147;categoryId=2104;subCategoryId=9135;classificationId=45116;ticketTypeId=2;}%' --> 

 --->   Update ApprovalEntityMapping set deleted = 1 where  approvalEntityMappingId = 3244


  Select * from ApprovalEntityMapping 
 where customerid = 3 and  approvalMappingRule like
 '%{customerId=4;}%'


  Select * from ApprovalEntityMapping 
 where approvalMappingRule like
 '%{customerId=3;categoryId=2111;subCategoryId=18667;classificationId=79306;ticketTypeId=2;}%'


 ----->   IM2860904  

 select * from ApiKey where keyname ='8C5DD19C-8B3F-4948-A143-CAF98A28EB8D'

 select * from autoticketserviceemailconfig where apikey='819FFDDB-1B8C-4A66-BA50-643DA862A988'

  select * from autoticketserviceemailconfig where emailId like '%%'
  
  select * from Customer where customerName like '%NOKIA%' ---> 213	Nokia
  
  select distinct u.userId, u.firstName, u.lastName, u.mobileNo, u.email from Users U 
  inner join UserCustomerAssignGroupMapping UC
  on U.userId = UC.userId
  inner join CustomerAssignmentGroupMapping C on c.custAssignmentGroupId = uc.custAssignmentGroupId
  where u.deleted = 0 and uc.deleted = 0 and c.customerId= 213 and c.deleted = 0
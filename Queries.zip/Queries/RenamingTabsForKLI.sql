
select * from CustomAttributeColumnMapping where  DisplayName = 'Installation date' 

update  CustomAttributeColumnMapping set DisplayName='Goods Received Date' where DisplayName = 'Installation date' 


-- Also updat in the Procedure:

--SP Name:    KLI_AM_GetAssetDumpData



    -- select * from Service 

    -- select * from Classification where deleted = 0 and classificationId= 1937

	 select * from Classification where deleted = 0 
	 and classification ='Salary and tax computaion-Undefined' and subCategoryId = 2201

	--Update Classification set deleted = 1 where classificationId in (
 --   4042
	--)


		 select * from SubCategory where deleted = 0 
	     and subCategory ='Data Update' and CategoryId = 631



	-- Update SubCategory set deleted = 1 where subCategoryId in (
 --   1954
	--)

	  --->   undefined Undefined


	  --select cc.classificationId, cc.classification, cc.subCategoryId from Category C
	  --inner join ServiceCategoryMapping CM on C.categoryId = Cm.serviceId
	  --inner join Service S on S.serviceId = Cm.serviceId
	  --inner join ServiceCustomerMapping SCM on SCM.serviceId = S.serviceId
	  --inner join SubCategory Sb on C.categoryId = sb.categoryId
	  --inner join  Classification cc on cc.subCategoryId = sb.subCategoryId
	  --where Classification like '%undefifed-Others%' and cc.deleted = 0 and scm.customerId =1 
	  --and c.deleted =0 and sb.deleted = 0
	  -->  undefifed-Others


	   select * from Classification where classification like '%undefifed-Others%' and deleted = 0

	   select * from Classification where classification like '%undefined Undefined%' and deleted = 0

	   select * from Classification where classification='Undefined' and deleted = 0

	   select * from Classification where subCategoryId in (
	3827) 

	Update SubCategory set subCategory ='UAT Issue � IONE-LA Integration' where subCategoryId = 3826

---> Application management,	Messaging Framework,	SMS template Whitelisting

select * from Service where serviceName like '%Application%'  ----> 2	Application Management

select * from Category where category like '%Messaging Framework%'  ----> 357   512

select * from ServiceCategoryMapping
where categoryId in (357,512)  ----> 

---> Template DLT Reg and Whitelisting

select * from SubCategory where categoryId in (357,512) and subCategory like '%SMS template%' ---> 1509, 1510

--Update SubCategory set subCategory = 'Template DLT Reg and Whitelisting' where subCategoryId in (1509, 1510)

select * from Classification where subCategoryId in (1509, 1510) and deleted = 0 ---> 3238 , 3239

select top 100 * from RulesForPriority 
where PriorityRule like '%serviceId=2;categoryId=357;subCategoryId=1509;%'  ---> 924  PriorityId: 9 , impactId: 4 

select top 100 * from RulesForPriority 
where PriorityRule like '%serviceId=2;categoryId=512;subCategoryId=1510;%'  ---> 925 , 2482 , 2483,  PriorityId: 10 , impactId: 4, 7

select top 1000* from RulesForAssignment 
where AssignmentRule like '%serviceId=2;%'

select distinct PrimaryAssignmentGroupId from RulesForAssignment 
where AssignmentRule like '%serviceId=2;%'

select * from AssignmentGroup where assignmentgroupId in (16,
89,
90,
166,
167,
168)

select * from Workgroup where workgroupid in (
3,
22,
23,
102,
103,
104)  ----> 3	Application Management

select count(*) from Ticket where customerId = 1 and workgroupId = 3 
and serviceId = 2 and priorityId in (9,10) and impactId in (4, 7) 

select distinct customerId from ServiceCustomerMapping where serviceId = 2

select * from ServiceLevelAgreement where customerid = 1 

--serviceLevelId	description	customerId
--1	MLRMC SR	1
--2	MLRMC INCIDENT	1
--3	MLRMC PROBLEM	1
--20	Problem Management-RCA	1
--21	Problem Management-RFO	1

select * from ServiceLevelObjective where ServiceLevelAgreementid = 2 and serviceId = 2
and priorityId = 9 and impactId = 4  and workgroupId = 3


--ResponseTime: 60 min
--ResolutionTime: 600 min

select * from ServiceLevelObjective where ServiceLevelAgreementid = 1 and serviceId = 2
and priorityId = 10 and impactId = 4 and workgroupId = 3

--ResponseTime: 180 min
--ResolutionTime: 1080 min


select * from Priority where priorityId in (9,10)

----> Akshay Patil (ML, IT, KLI

select * from TicketStatus where ticketTypeId = 2  ----> 14	Work in Progress

select customerId, workgroupId,serviceId,TicketTypeid, statusId, statusName,
* from Ticket where ticketNo = 1597707 

select * from Workgroup where workgroupId = 2 ---> 2	Desktop-Laptop Management

select * from AssignmentGroup where workgroupId = 2 ---> 15	Desktop-Laptop Management-Queue

select * from CustomerAssignmentGroupMapping where assignmentgroupId = 15 ---> 15	KLI-Desktop-Laptop Management-Queue


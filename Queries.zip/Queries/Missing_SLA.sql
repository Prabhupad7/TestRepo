


Select serviceId ,customerId ,priorityId ,* from ticket where ticketNo = 2579232 --386 --cust --199 -- priority -14

select * from ServiceLevelAgreement where customerId = 199 -- 260

Select * from ServiceLevelObjective where serviceLevelAgreementId = 260 and serviceId = 386 and serviceLevelObjectiveTypeId = 2 and priorityId = 14


Select * from ServiceLevelObjectiveType

URl : https://rmcops.microland.com/Administration/MissingSLAindex

--Vignesh.


      SR2575947
	  SR2576866

	  SR2579232

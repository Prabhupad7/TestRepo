

--Please find the List of HDU customers:
--Account Name

select * from Customer where customerName like '%SonicWall%'

select * from Customer where customerId in (3, 194, 192, 167, 169, 58, 59, 188, 158, 221, 8, 61, 189, 203, 4, 168, 210, 207, 196
, 213,  214, 215, 218, 217, 220 , 219, 147)


--MLCIS , Jubilant Pharma, Jubilant Life Science, EFL, Comviva, SAP, Innocent Drinks, Enzen, UTC, FGIC, Bosch App Support,Bosch Island Support,Bosch Scottsdale,
--MLRMC, Actifio, BeiGene (SD), BeiGene (AWS and Intune), NTTA - Technologent, UNITY BIOTECHNOLOGY, INC, Oreta MMSG SD, Indosat Nokia, Mott Macdonald, GCC AbInBev,
--Bunge, Menabev , Aveva
--SonicWall


select * from Customer where customerId in 
(3, 194, 192, 167, 169, 58, 59, 188, 158, 
 221, 8, 61, 189, 203, 4, 168, 210, 207, 196
 ,213,  214, 215, 218, 217, 220 , 219)


 select * from Workgroup W
 inner join AssignmentGroup A on A.workgroupId = W.workgroupId
 inner join CustomerAssignmentGroupMapping C on C.assignmentgroupId = A.assignmentgroupId
 where c.customerId = 147 and w.workgroupId = 248













 
select * from NotificationRules 
where notificationTo like '%ChangeandProblemManagement@microland.com%' 
order by customerId



select distinct customerId from NotificationRules 
where notificationTo like '%ChangeandProblemManagement@microland.com%' 


-----> 

1. 220	Aveva	Aveva
2. 196	Oreta-MMSG VOIP







select * from Customer where customerid = 3    -----> 

select * from Customer where customerName like '%Unity Bio%'  --->207	Unity Bio

select * from Workgroup where workgroup like '%RMC Citrix%'  ----> 248

select * from NotificationRules 
where notificationTo like '%ChangeandProblemManagement@microland.com%' 
and customerId = 147


select * from Workgroup where deleted = 0 and workgroup like '%RMC Cloud%'

----> 47, 446, 248, 625, 7, 12, 4, 404, 3, 10, 13, 69, 4892, 60, 626




 select w.workgroupId, w.workgroup from Workgroup W
 inner join AssignmentGroup A on A.workgroupId = W.workgroupId
 inner join CustomerAssignmentGroupMapping C on C.assignmentgroupId = A.assignmentgroupId
 where c.customerId = 207
 and w.workgroupId in ( 47, 446, 248, 625, 7, 12, 4, 404, 3, 10, 13, 69, 4892, 60, 626) and
 c.deleted = 0 and w.deleted = 0 and a.deleted = 0


 select * from NotificationEmailTemplate  
 where customerId = 207 and templateName like '%change%'

 --insert into NotificationEmailTemplate

 --select templateName, template, templateSubject,207, NotifyBasedOn, ImageIds, 0,  oldtemplateid, isApprovalTemplate, notificationemailtemplateCategoryId,isOutageSMSNotification
 --from NotificationEmailTemplate where templateId=2143

 select * from NotificationEmailTemplate  where templateId=2162
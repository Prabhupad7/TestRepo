
select * from UrgencyImpactPriorityMatrix where CustomerId = 220 and priorityId in (
6,
10,
14,
15,
16
)


--delete from UrgencyImpactPriorityMatrix where id in (
--130,
--138,
--142
--)

select * from UrgencyImpactPriorityMatrix where CustomerId = 220 and priorityId in (
9
)

select * from UrgencyTicketTypeMapping

select * from Urgency

select * from Priority where ticketTypeid = 1 ---> 5	P2

--select * from customer where customerid = 220

select * from UrgencyImpactPriorityMatrix 
where CustomerId = 220 and deleted =0 -- and urgencyId = 3 --and impactId = 7
and tickettypeid = 4

 
 select top 12 * from UrgencyImpactPriorityMatrix 
 order by 1 desc


--Update UrgencyImpactPriorityMatrix set tickettypeid = 4 where id in (166,
--165,
--164,
--163,
--162,
--161,
--160,
--159,
--158,
--157,
--156,
--155)

--Insert into UrgencyImpactPriorityMatrix

select 1, 5, 6, 2, 0, 220 UNION ALL


--UrgencyImpactPriorityMatrix values(4, 7,6,2, 0, 220)

----> For SR Mapping (only SR2)  

select * from Priority where priorityId in (6, 10, 14, 15, 16)

select * from TicketType ---> 4	Problem

select * from Priority where ticketTypeId = 4

USP_GetPriorityByUrgencyandImpact 4,6,2,220


4
8
12
42

--Insert into UrgencyImpactPriorityMatrix values(4, 7, 4, 2, 0, 220)
--Insert into UrgencyImpactPriorityMatrix values(4, 6, 8, 2, 0, 220)
--Insert into UrgencyImpactPriorityMatrix values(4, 5, 12, 2, 0, 220)

--Insert into UrgencyImpactPriorityMatrix values(3, 7, 8,2, 0, 220)
--Insert into UrgencyImpactPriorityMatrix values(3, 6, 12,2, 0, 220)
--Insert into UrgencyImpactPriorityMatrix values(3, 5, 42,2, 0, 220)


--Insert into UrgencyImpactPriorityMatrix values(2, 7,  12,2, 0, 220)
--Insert into UrgencyImpactPriorityMatrix values(2, 6,  42,2, 0, 220)
--Insert into UrgencyImpactPriorityMatrix values(2, 5,  8,2, 0, 220)


--Insert into UrgencyImpactPriorityMatrix values(1, 7,  8, 2,0, 220 )
--Insert into UrgencyImpactPriorityMatrix values(1, 6,  12, 2,0, 220)
--Insert into UrgencyImpactPriorityMatrix values(1, 5,  42, 2,0, 220 )



--select 2, 6, 6, 2, 0, 220 UNION ALL
--select 3, 7, 6, 2, 0, 220 UNION ALL

--select 1, 5, 10, 2, 0, 220 UNION ALL
--select 2, 6, 10, 2, 0, 220 UNION ALL
--select 3, 7, 10, 2, 0, 220 UNION ALL

--select 1, 5, 14, 2, 0, 220 UNION ALL
--select 2, 6, 14, 2, 0, 220 UNION ALL
--select 3, 7, 14, 2, 0, 220 UNION ALL

--select 1, 5, 15, 2, 0, 220 UNION ALL
--select 2, 6, 15, 2, 0, 220 UNION ALL
--select 3, 7, 15, 2, 0, 220 


select * from Priority where ticketTypeId in ( 2)

27	P4  15	SR4


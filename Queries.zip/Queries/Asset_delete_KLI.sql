

select  * from Assets where AssetNumber like 'KLI35261'

select  isDeleted, * from Assets where SerialNumber like '8V4XDV2' --->  25572


  select * from Asset_Assignment where assetId = 25572

 ----> update Asset_Assignment set deleted =1 , IsActive =0 where  assetId = 25572

    --EXEC Usp_AssetDeletetionByAssetId 19943

 select * from Workgroup 


 select requestorId,* from Ticket where ticketNo = 1635058 ---> 16822

 select * from ServiceLevelTracking where sourceId = 1635058

 --Update ServiceLevelTracking set statusId = 3 where sourceId = 1635058

 select * from Requestor where requestorId = 16822

 ---> Department:OperationsNewBusinessUnit  LoginName:LO3814

  select top 100 * from Asset_users where Alias ='LO3814' ---> 9892774375

  select top 100 * from Asset_users where Mobile like '%9892774375%' --->

  select top 100 * from Asset_users where FirstName='Manish' and LastName='kumar' ---> 

  select top 100 * from Asset_users where EmployeeId ='1126335'


  ---> AEDBXHFW001   10.84.127.20
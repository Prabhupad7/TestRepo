  --  execute usp_Asset_Inventory 1, 5

    select * from AssetEntityType  where id = 1 --->  1	Asset	Assets	Asset Management

    select * from AssetEntityType  where id = 35 --->  35	Database	Database

	 select * from AssetEntityType  where name like '%server%' ----> 17  displayorder 4

	 	 select * from AssetEntityType  where name like '%Hardware%' ----> 23 ---> 5

		 select * from AssetEntityType  where id in(3, 35, 17, 23)

	    Insert into AssetEntityType (Name,DisplayName,Description,ParentId,DisplayOrder,AllowAssetCreation,	FaIcon,	EnableForleftMenu,CreatedById,CreatedOn,UpdatedById,UpdatedOn,
		Deleted,SourceTypeId, IsActive, isAutoDiscoverEnabled,isBulkuploadEnabled)
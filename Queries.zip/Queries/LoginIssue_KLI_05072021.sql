

select * from Users where LoginName like '%LE81321%'

select * from Users where LoginName ='LE81321'  ----> 1475  1362

--Update Users set password ='SUv/GzSv2NSYGeW1YMGviQ==', SaltValue = null, mobileNo ='8692085838' where userId =  1475

select * from Users where userId in ( 6, 1475, 1362)  ----> 


select * from UserInstanceMapping where UserId in ( 6, 1475, 1362) 

select * from Users where LoginName ='LE44060'  -----> dipali.kerkar@kotak.com

select * from UserInstanceMapping where UserId = 1362

--Insert into UserInstanceMapping

--select 1475 , 1

--Insert into UserCustomerAssignGroupMapping 

--select 1475, 179, 0, 1, 1

select * from UserCustomerAssignGroupMapping where userId = 1362

select * from UserCustomerAssignGroupMapping where userId = 1475

select * from Users where email like '%jiten.patel@kotak.com%'



select * from Requestor where Requestoremail like '%jiten.patel@kotak.com%' ---> 27529

select * from Requestor where Requestoremail like '%jiten.patel@kotak.com%' ---> 27529

select * from CustomerRequestorMapping where Requestorid = 27529  ---> 54056	27529	49	KLIHr	1

select * from Customer where customerId =  49

select top 100 * from Asset_users where emailId like '%jiten.patel%'  ----> jiten.patel@kotak.com  LE81321


--Insert into Users(firstName,	lastName,	userName,	displayName	,mobileNo,	email,	loginName	, workgroupId, 
--custAssignmentGroupId,	deleted,	IsWorkgroup,	isPasswordPolicyApplicable,	lastUpdatedOn,	isAutoAssignmentEnable,	roleId	,createdById,
--updatedById,	createdOn,	updatedOn,	IsEnabled,	timezoneinfoId,	AboutMe,	instanceId,	ProfilePicture,	PasswordPolicyId,	SaltValue,
--primaryAssignmentGroupId,	deletedOn,	levelid	,UserTypeId)


--select 'jiten', 'patel','jiten patel',	'jiten patel'	,'919830107782',	'jiten.patel@kotak.com', 'LE81321'	,'1',
--0,	0,	0,	isPasswordPolicyApplicable,	GETDATE(),	isAutoAssignmentEnable,	roleId	,createdById,
--updatedById,	GETDATE(),	GETDATE(),	IsEnabled,	timezoneinfoId,	AboutMe,	instanceId,	ProfilePicture,	PasswordPolicyId,	null,
--primaryAssignmentGroupId,	deletedOn,	1	,UserTypeId from users where userId = 1362

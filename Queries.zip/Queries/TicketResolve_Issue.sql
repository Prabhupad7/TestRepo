

  select * from ServiceLevelTracking where sourceId = 2718545

  --update ServiceLevelTracking set statusId = 3 
  --where serviceLevelTrackingId = 6117332


  --> 

    select * from Users where email like '%NaveenCMC@microland.com%'  ---> 440

	select * from Users where email like '%SaswatA@microland.com%'  ---> 26103

	select * from Users where email like '%karthiks@microland.com%'  ---> 26103

	select * from Users where userId in (440, 26103)

	-- RoleID -->  58


    select * from ReportMaster  where name like '%visibility%'

	select * from Usres


 select * from workGroupEscalationMatrix_AskML where CustomerId = 147

  select * from workGroupEscalationMatrix where CustomerId = 147 and workGroupId = 200

  ---> 247	Remote Resolution Group
  
    select top 100 * from workGroupEscalationMatrix_AskML where  workGroupId = 247

	select  * from workGroupEscalationMatrix where Level1Email like '%MLIT Service desk%'  --> 981

	--Update workGroupEscalationMatrix set Level1Name='Rahul A R', Level1Email='RahulRA3@microland.com', Level1Extension='919663623976'
	--where id = 981

	select  * from workGroupEscalationMatrix_AskML where Level2Name like '%S Ramesh Reddy%'

	---> S Rameshreddy

	--Update workGroupEscalationMatrix_AskML set Level2Name='S Ramesh Reddy', Level2Email='SRN@microland.com'
	--where Level2Name like '%Aravindsagar%'

	select  * from workGroupEscalationMatrix_AskML where Level2Name like '%Srinivasulu Reddy E%'


	select top 100 * from workGroupEscalationMatrix where Level2Extension like '%919108799997%'

	Select top 100 * from workGroupEscalationMatrix_AskML where Level2Email like '%ManjunathK@microland.com%'

	select top 100 * from workGroupEscalationMatrix_AskML where Level2Email like '%MLIT Service desk%'

	select top 100 * from workGroupEscalationMatrix_AskML where Level2Extension like '%919108799997%'

	select  * from ApprovalEmailRules
where NotificationBody like '%ManjunathK@microland.com%'

--Rahul A R	919663623976	RahulRA3@microland.com	Ajit Bedekar	919731911099	AjitB@microland.com



select * from NotificationEmailTemplate where template like '%ManjunathK@microland.com%'

select count ( *) from ApprovalEmailRules
where NotificationBody like '%ManjunathK@microland.com%'


    select * from workGroupEscalationMatrix_AskML where  Level2Name like '%Manjunth%'

	----> Rahul A R	919663623976	RahulRA3@microland.com

--	Update workGroupEscalationMatrix_AskML set Level1Name='Rahul A R', Level1Extension='919663623976', Level1Email='RahulRA3@microland.com'
--	where id in (2,4,5,6,14,17,41,42,43,44,45,46,47,48,49,50,51,
--52,53,55,56,57,58,59,60,61,76,93,94)


 select * from workGroupEscalationMatrix where CustomerId = 147  and WorkgroupName like '%CIS%' -- and workGroupId =247
 
 select * from workGroupEscalationMatrix_AskML where CustomerId = 147 and WorkgroupName like '%ML IT Servicedesk%'

  select * from workGroupEscalationMatrix_AskML where CustomerId = 147 and WorkgroupId =200 --->  423

  ----> Rahul A R	919663623976	RahulRA3@microland.com



  --->  368

   --Insert into workGroupEscalationMatrix_AskML(CustomerId, WorkgroupName, Level1Name, Level1Extension, Level1Email, Level2Name, Level2Extension, Level2Email, 
   --Level3Name, Level3Extension, Level3Email, workGroupId)

   --select CustomerId, 'ML IT Servicedesk', Level1Name, Level1Extension, Level1Email, Level2Name, Level2Extension, Level2Email, 
   --Level3Name, Level3Extension, Level3Email, 200 from workGroupEscalationMatrix_AskML where id = 368


    select * from workGroupEscalationMatrix_AskML where  Level1Name like '%NAgamani Basavaraju%' ---->  231

	select * from workGroupEscalationMatrix_AskML where  Level1Name like '%nagamani%' ---->  231

	select * from Workgroup where workgroupid in (226,231)

	select * from Admin_UserCustomerMapping


	--------------> id 931
-- Aravindsagar Venkatesh
   -->   this is the correct table for EUP portal 
select * from workGroupEscalationMatrix where CustomerId = 147 and id =931

 ---> and for mail notifications table is:

   select * from workGroupEscalationMatrix_AskML

   select * from workGroupEscalationMatrix where CustomerId = 147 and id = 931 

   ------------------------------->

   	select  * from ApprovalEmailRules
where NotificationBody like '%ManjunathK@microland.com%'

select  * from ApprovalEmailRules where id in (4104,4105,4106,4107,4108,4109,4110,4111,4112,4113,4114,4115,4116,4117,4118,4119,4120,4121,4122,4123,4124,4125,4126,4127,4128,4129,4130,
4131,4132,4133,4134,4135,4136,4137,4138,4139,4140,4141,4142,4143,4144,4145,4146,4147,4148,4149,4150,4151,4152,4153,4154,4155,4156,4157,
4158,4159,4180,4181,4182,4183,4184,4185,4186,4187,4188,4189,4190,4191,4192,4193,4194,4195,4196,4197,4198,4199,4200,4201,4202,4203,4204,
4205,4206,4207,4218,4219,4242,4243,4244,4245,4246,4247,4248,4249,4250,4251,4252,4253,4254,4255,4256,4257,4258,4259,4260,4261,4262,4263,
4264,4265,4266,4267,4268,4269,4270,4271,4272,4273,4274,4275,4276,4277,4278,4279,4284,4285,4286,4287,4294,4295,4296,4297,4298,4299,4300,
4301,4302,4303,4304,4305,4306,4307,4308,4309,4310,4311,4312,4313,4314,4315,4316,4317,4318,4319,4320,4321,4322,4323,4324,4325,4326,4327,
4330,4331,4332,4333,4334,4335,4973,4974,4975,4976,4977,4978,4983)


--Rahul A R	919663623976	RahulRA3@microland.com	Ajit Bedekar	919731911099	AjitB@microland.com

--Update ApprovalEmailRules set NotificationBody =Replace(NotificationBody, 'SrinivasuluRE@microland.com', '')
--where id in
--(4104,4105,4106,4107,4108,4109,4110,4111,4112,4113,4114,4115,4116,4117,4118,4119,4120,4121,4122,4123,4124,4125,4126,4127,4128,4129,4130,
--4131,4132,4133,4134,4135,4136,4137,4138,4139,4140,4141,4142,4143,4144,4145,4146,4147,4148,4149,4150,4151,4152,4153,4154,4155,4156,4157,
--4158,4159,4180,4181,4182,4183,4184,4185,4186,4187,4188,4189,4190,4191,4192,4193,4194,4195,4196,4197,4198,4199,4200,4201,4202,4203,4204,
--4205,4206,4207,4218,4219,4242,4243,4244,4245,4246,4247,4248,4249,4250,4251,4252,4253,4254,4255,4256,4257,4258,4259,4260,4261,4262,4263,
--4264,4265,4266,4267,4268,4269,4270,4271,4272,4273,4274,4275,4276,4277,4278,4279,4284,4285,4286,4287,4294,4295,4296,4297,4298,4299,4300,
--4301,4302,4303,4304,4305,4306,4307,4308,4309,4310,4311,4312,4313,4314,4315,4316,4317,4318,4319,4320,4321,4322,4323,4324,4325,4326,4327,
--4330,4331,4332,4333,4334,4335,4973,4974,4975,4976,4977,4978,4983)
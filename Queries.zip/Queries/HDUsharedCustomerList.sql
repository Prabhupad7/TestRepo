


   select * from Customer where deleted = 0 and CustomerId in (168, 61, 189, 203, 169, 158, 167, 8, 188, 192, 194, 3, 4, 58, 207)


Actifio Apotex
168

BOSCH
61

Bosch � Scottsdale
189

BOSCH DCS
203

Comviva Technologies
169

EnzenNGN
158

Eureka Forbes Limited
167

FGIC
8

Innocent Drinks
188

Jubilant Lifescience
192

Jubilant Pharma
194

MLCIS
3

MLRMC
4

SAP GD
58

Unity Bio
207

              select * from Customer where deleted = 0 
			  and CustomerId in (168, 61, 189, 203, 169, 158, 167, 8, 188, 192, 194, 3, 4, 58, 207)

			  select * from Users where email like '%Manjunathks@microland.com%' ---  25872	Manjunath

			  select * from Users where email like '%SomNS@microland.com%' ---  35	Som	Nath Singh





               select * from users where email like '%surajr@microland.com%'  --- 26246   26246	Suraj	Rvr	NULL	Suraj Rvr	9886014788	surajr@microland.com

			   select * from Workgroup W where W.displayName like '%RMC Cloud%'    ---- 625

			    SELECT * FROM AssignmentGroup where workgroupId = 7   --- 203

				---> HDU Shared customer list:

				  select * from CustomerAssignmentGroupMapping where deleted = 0 
			      and CustomerId in (168, 61, 189, 203, 169, 158, 167, 8, 188, 192, 194, 3, 4, 58, 207)
				  order by custAssignmentGroupId  ---> 302 count

			  -- custAssignmentGroupId   222



			  select distinct custAssignmentGroupId from CustomerAssignmentGroupMapping where customerId in ( 1 )   and deleted = 0 

			     select * from UserCustomerAssignGroupMapping where    userId in (35 ) and deleted =0 and custAssignmentGroupId in(
			     select custAssignmentGroupId from CustomerAssignmentGroupMapping where deleted = 0 
			      and CustomerId in (168, 61, 189, 203, 169, 158, 167, 8, 188, 192, 194, 3, 4, 58, 207)
				 )




				  select * from CustomerAssignmentGroupMapping where deleted = 0 
			      and CustomerId in (168, 61, 189, 203, 169, 158, 167, 8, 188, 192, 194, 3, 4, 58, 207)

				  and custAssignmentGroupId not in (
				  select custAssignmentGroupId from UserCustomerAssignGroupMapping where userId in (35))
				


		      -- INSERT INTO UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
			  values
(35,1188,0,0,0),



   -- Update UserCustomerAssignGroupMapping  SET deleted =0,  isAssignEnabled =0 , AssignToWorkgroup = 0 WHERE userCustomerAssignGroupId IN (

   26283
54743
,54744
,54745
)
Please find HDU Shared SMC Customers list:
SL No	Account Name

1	Eureka Forbes
2	MLCIS
3	MLRMC
4	Comviva
5	Actifio 
6	Jubilant Life Science
7	GCC AbInBev
8	Nokia
9	Innocent Drinks
10	Enzen
11	Mott Macdonald
12	SAP
13	Oreta MMSG
14	Jubilant Pharma & JDR
15	FGIC
16	UNITY BIOTECHNOLOGY, INC
17	Bosch App Support 
18	Bosch Island Support
19	Bosch Scottsdale
20	MenaBev

Regards,
Manjunath


select * from Customer where customername like '%MenaBev%'


select * from Customer where customerid in (167, 3, 4, 169, 168, 192, 215, 213, 188, 158, 
 214, 58, 59, 196, 194, 8, 207, 61, 189, 203, 217)
USE [SmartCenterProduction]
GO
/****** Object:  StoredProcedure [dbo].[usp_getallAssetsbaseonAssetTypeId]    Script Date: 6/14/2021 12:06:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--[usp_getallAssetsbaseonAssetTypeId] 1,147,15,1,6
--Procedure 2
ALTER procedure [dbo].[usp_getallAssetsbaseonAssetTypeId]
@assetTypeID int,
@CustomerId int ,
@SourceId int ,
@PageId int,
@userId int =null
AS
BEGIN

--Declare @assetTypeID int
--Declare @CustomerId int 
--Declare @SourceId int 
--Declare @PageId int
--Declare @userId int =null

--Set @assetTypeID =1
--Set @CustomerId =147
--Set @SourceId =204
--Set @PageId =1
--Set @userId =6

declare @colQuery varchar(max)
declare @Query varchar(max)
DECLARE   @ConcatString VARCHAR(4000)
DECLARE   @ConcatString3 VARCHAR(4000)

SELECT   @ConcatString = COALESCE(@ConcatString + '  , ', '') + case when (CustomerAttributeTablename='Assets' or CustomerAttributeTablename='knowledges') then 'c.'
										when (CustomerAttributeTablename='VarcharCustomAttribute' or CustomerAttributeTablename='KM_VarcharCustomAttribute') then 'v.'
										when (CustomerAttributeTablename='IntCustomAttribute' or CustomerAttributeTablename='KM_IntCustomAttribute') then 'ic.'
										when (CustomerAttributeTablename='BitCustomAttribute' or CustomerAttributeTablename='KM_BitCustomAttribute') then 'bc.'
										when (CustomerAttributeTablename='DateTimeCustomAttribute' or CustomerAttributeTablename='KM_DateTimeCustomAttribute') then 'd.' else '' end+ AttributeName+' as ['+ DisplayName+']' FROM 
(SELECT TOP 100 PERCENT CustomerAttributeTablename, AttributeName, DisplayName  FROM CustomAttributeColumnMapping  where SourceId=@SourceId and SourceTypeId=@assetTypeID and CustomerId=@customerId and pageid=@PageId and IsVisible=1 
 ORDER BY Displayorder) temp
 --Print @ConcatString
SELECT   @colQuery=@ConcatString 

print @colQuery


---- Data Permission Start --
DECLARE @permissionClause nvarchar(max) = ''
IF(exists(SELECT 1 FROM Asset_EntityAndDataPermissionMapping EADP left JOIN Asset_EntityTypeUserMapping ETUM ON ETUM.Id = EADP.entityUserMappingId 
         WHERE ETUM.entityTypeId = @SourceId AND ISNULL(EADP.isDeleted,0) = 0 AND ETUM.userId = @UserId))
BEGIN 
print 'permissionClause'
	SELECT @permissionClause = ( STUFF((SELECT REPLACE('OR (' + LTRIM(RTRIM(CLAUSE)) + ') ', 'OR (AND', 'OR (') FROM (
		SELECT clauseId,  (STUFF((
				SELECT '  ' + conditionType  + ' ' + columnName + ' ' + operator + ' ' + columnValue
				FROM Asset_EntityAndDataPermissionMapping EADP
				JOIN Asset_EntityTypeUserMapping ETUM on ETUM.Id = EADP.entityUserMappingId 
				WHERE clauseId = aec.clauseId AND ETUM.entityTypeId = @SourceId AND ISNULL(EADP.isDeleted,0) = 0 AND ETUM.userId = @UserId
				FOR XML PATH('')
				), 1, 2, '')
			) AS CLAUSE FROM Asset_EntityAndDataPermissionMapping aec
			JOIN Asset_EntityTypeUserMapping aem on aem.Id = aec.entityUserMappingId 
			GROUP BY clauseId) finalresult FOR XML PATH('')), 1, 2, ''))
END


IF(@permissionClause <> '')
BEGIN 
    SELECT @permissionClause = ' AND (' + @permissionClause + ')'
    print 'where clause fetched: ' + @permissionClause
END

-- Data Permission End

if (@assetTypeID =1 )
begin
  -- IF exists(Select top 1 * from AssetEntityType where parentid = (select Top 1 Id FROM AssetEntityType Where Name = 'Consumable') and ID = @SourceId)
  -- begin   
		--declare @SQLQuery varchar(max)
		--Declare @SourceColumn nvarchar(max)
		--Declare @DestinationColumn nvarchar(max)

		--Set @SourceColumn = (select Top 1 Attributename from customattributecolumnmapping where sourceid=@SourceId and displayname='Current Stock')
		--Set @DestinationColumn = (select Top 1 Attributename from customattributecolumnmapping where sourceid=@SourceId and displayname='Actual Asset Count')

		--Set @SQLQuery = 'update intcustomattribute set ' + @DestinationColumn + ' = ' + @SourceColumn + ' - i.AssignedCount
		--from 
		--(select A.id as AssetId,count(AA.id) as AssignedCount from Assets A
		--left outer join Asset_Assignment AA on AA.Assetid=A.id And ISNULL(AA.IsActive,0) = 1 AND ISNULL(AA.deleted,0) = 0
		--where A.sourceid = ' + cast (@SourceId as varchar(100)) +'
		--group by A.id) i
		--where intcustomattribute.sourceid =' + cast (@SourceId as varchar(100)) +'
		--and intcustomattribute.primaryid= i.AssetId'
		----Print(@SQLQuery)
		--Exec(@SQLQuery)
				
		--Set @SQLQuery = 'update assets set AssetName=Assetnumber
		--		where sourceid =' + cast (@SourceId as varchar(100))
		----Print(@SQLQuery)
		--Exec(@SQLQuery)
		

  -- end
   IF exists(Select top 1 Id from AssetEntityType where parentid = (select Top 1 Id FROM AssetEntityType Where Name = 'Consumable') and ID = @SourceId)
   BEGIN 
   DECLARE   @consumableConcatString VARCHAR(4000)
        SELECT   @consumableConcatString = COALESCE(@consumableConcatString + '  , ', '') + case when (CustomerAttributeTablename='Assets' or CustomerAttributeTablename='knowledges') then 'c.'
										when (CustomerAttributeTablename='VarcharCustomAttribute' or CustomerAttributeTablename='KM_VarcharCustomAttribute') then 'v.'
										when (CustomerAttributeTablename='IntCustomAttribute' or CustomerAttributeTablename='KM_IntCustomAttribute') then 'ic.'
										when (CustomerAttributeTablename='BitCustomAttribute' or CustomerAttributeTablename='KM_BitCustomAttribute') then 'bc.'
										when (CustomerAttributeTablename='DateTimeCustomAttribute' or CustomerAttributeTablename='KM_DateTimeCustomAttribute') then 'd.' else '' end+ AttributeName+' as ['+ DisplayName+']' FROM 
		(SELECT TOP 100 PERCENT CustomerAttributeTablename, AttributeName, DisplayName FROM CustomAttributeColumnMapping  where SourceId=@SourceId and SourceTypeId=@assetTypeID and CustomerId=@customerId and pageid=@PageId and IsVisible=1 AND DisplayName <> 'Current Stock'
		ORDER BY Displayorder) temp
										
		SELECT   @colQuery=@consumableConcatString 
										
		PRINT @consumableConcatString
        set @Query='select TOP 2000 c.id as [Select],'+ cast( @colQuery  as varchar (max)) +', int2 AS [Current Stock]
		 from  assets c
		 left join  VarcharCustomAttribute v 
		on v.PrimaryId=c.id
		 left join DateTimeCustomAttribute d 
		on d.PrimaryId=c.id
		 left join IntCustomAttribute ic 
		on ic.PrimaryId=c.id
		left join BitCustomAttribute bc 
		on bc.PrimaryId=c.id
		 where ISNULL(c.isDeleted,0) = 0 AND c.sourceid='+ cast( @SourceId as varchar (50)) +' and c.SourceTypeId='+cast( @assetTypeID as varchar (50)) +' and c.CustomerId='+cast( @customerId as varchar (50)) ++
	     @permissionClause +
		  ' order by c.id desc'
   END
    else if @SourceId=(SELECT iD FROM AssetEntityType Where Name = 'Platform' AND SourceTypeId = 1 and parentid in (select id from assetentitytype where name='PM'))
   begin
       set @Query='select TOP 4900 c.id as [Select],'+ cast( @colQuery  as varchar (max)) +',  Cus.customerName As [Customer Name]
		 from  assets c
		 left join  VarcharCustomAttribute v 
		on v.PrimaryId=c.id
		 left join DateTimeCustomAttribute d 
		on d.PrimaryId=c.id
		 left join IntCustomAttribute ic 
		on ic.PrimaryId=c.id
		left join BitCustomAttribute bc 
		on bc.PrimaryId=c.id
		left join (
       select distinct ast.Id,AssetName as customerName,customerid,ar.sourceAssetId from assets ast join  Asset_relationship ar on ast.id=ar.relatedAssetId and relatedassettypeid=(SELECT iD FROM AssetEntityType Where Name = ''Customer'' AND SourceTypeId = 1 and parentid in (select id from assetentitytype where name=''PM'')  AND ISNULL(ast.isDeleted,0) = 0)
       )as Cus on c.id=Cus.sourceAssetId 
		OUTER APPLY fn_GetAssetAssignmentDetailByAssetTypeId(c.id) aa	
		 where ISNULL(c.isDeleted,0) = 0 AND c.sourceid='+ cast( @SourceId as varchar (50)) +' and c.SourceTypeId='+cast( @assetTypeID as varchar (50)) +' and c.CustomerId='+cast( @customerId as varchar (50)) ++
		 @permissionClause +
		  ' order by c.id desc'
   end
   ELSE
   BEGIN
       set @Query='select TOP 4900 c.id as [Select],'+ cast( @colQuery  as varchar (max)) +'
		 from  assets c
		 left join  VarcharCustomAttribute v 
		on v.PrimaryId=c.id
		 left join DateTimeCustomAttribute d 
		on d.PrimaryId=c.id
		 left join IntCustomAttribute ic 
		on ic.PrimaryId=c.id
		left join BitCustomAttribute bc 
		on bc.PrimaryId=c.id
		OUTER APPLY fn_GetAssetAssignmentDetailByAssetTypeId(c.id) aa	
		 where   ISNULL(c.isDeleted,0) = 0 AND c.sourceid='+ cast( @SourceId as varchar (50)) +' and c.SourceTypeId='+cast( @assetTypeID as varchar (50)) +' and c.CustomerId='+cast( @customerId as varchar (50)) ++
		 @permissionClause +
		  ' order by c.id desc'
   END
 end
 else if (@assetTypeID =3 )
 BEGIN
 DECLARE @ID int
 SET @ID = (select count(id) from AssetEntityType where parentid  =@SourceId)
 If(@ID >=1)
 BEGIN
 SELECT   @ConcatString3 = COALESCE(@ConcatString3 + '  , ', '') + AttributeName+' as ['+ DisplayName+']' FROM (SELECT TOP 100 PERCENT CustomerAttributeTablename, AttributeName, DisplayName FROM CustomAttributeColumnMapping  where SourceId=@SourceId and SourceTypeId=@assetTypeID and CustomerId=@customerId and pageid=@PageId and IsVisible=1 
		ORDER BY Displayorder) temp
SELECT   @colQuery=@ConcatString3 
	SET @Query='select 1 as test, c.id as [Select],'+ cast( @colQuery  as varchar (max)) +' from  knowledges c
	 left join  KM_VarcharCustomAttribute v on v.PrimaryId=c.id
	 left join KM_DateTimeCustomAttribute d on d.PrimaryId=c.id
	 left join KM_IntCustomAttribute ic on ic.PrimaryId=c.id
	 left join KM_BitCustomAttribute bc on bc.PrimaryId=c.id
	 where c.sourceid in('+ 'select Id from AssetEntityType where ParentId = '+cast(@SourceId as varchar (50)) +') and c.SourceTypeId='+cast(@assetTypeID as varchar (50)) +' and c.CustomerId='+cast(@customerId as varchar (50)) +
	 ' order by c.id desc'
 END
 ELSE
 BEGIN
 SET @Query='select 1 as test, c.id as [Select],'+ cast( @colQuery  as varchar (max)) +' from  knowledges c
	 left join  KM_VarcharCustomAttribute v on v.PrimaryId=c.id
	 left join KM_DateTimeCustomAttribute d on d.PrimaryId=c.id
	 left join KM_IntCustomAttribute ic on ic.PrimaryId=c.id
	 left join KM_BitCustomAttribute bc on bc.PrimaryId=c.id
	 where c.sourceid in('+cast(@SourceId as varchar (50)) +') and c.SourceTypeId='+cast(@assetTypeID as varchar (50)) +' and c.CustomerId='+cast(@customerId as varchar (50)) +
	 ' order by c.id desc'
 END
 END
 print @Query
 execute(@Query)
  
END





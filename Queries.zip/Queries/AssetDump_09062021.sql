

select * from customer where customerName like '%innoce%' ----> 188

select * from customer where customerName like '%Bosch%' ---->  61	BOSCH

select distinct s.serviceId, s.serviceName from Service S
inner join ServiceCustomerMapping SM on s.serviceId = sm.serviceId
where s.deleted =0 and sm.deleted =0 and sm.customerId = 61  ----> 


select * from CustomerAssignmentGroupMapping where customerId = 61 and deleted = 0

select a.AssetNumber as 'Host Name', a.SerialNumber as 'Serial Number',
a.Status, v.Varchar1 as 'Workstation Number', v.Varchar31 as 'Site Name' , 
i.int31 as 'SiteNameId', v.varchar42 as 'Department Name', v.varchar43 'Project Name' , 
a.domain, a.domainId, a.Manufacturer, a.ManufacturerId, a.Model, a.ModelId, a.OSName as 'OS',
a.OSNameId , v.Varchar26 as 'FA Number', a.LocationName, a.LocationId
from assets a inner join VarcharCustomAttribute v on v.PrimaryId = a.Id
inner join IntCustomAttribute i on i.PrimaryId = a.Id
where a.SourceId = 1 and a.CustomerId = 188 and ISNULL(a.isDeleted, 0) = 0





select * from Users where firstName like '%Shas%'  ----> 984	Shashikant	Lugade Roleid: 6

select * from Users where firstName like '%geeta%'  -----> 899  38

select * from Users where userId in (984, 899)   -----> 

select * from Users where firstName like '%Shas%'  ----> 984	Shashikant	Lugade Roleid: 6

declare @customerIds varchar(100) = '1'
select  distinct c.customerId, c.customerName, assignmentgroupName, ag.assignmentgroupId
--, w.workgroupId, w.workgroup  workgroupName ,r.roleId, r.name roleName, isAssignEnabled, AssignToWorkgroup   
from Users u     
inner join Role  r  on u.roleid=r.roleId and u.deleted=0  
inner join UserCustomerAssignGroupMapping ucag  on ucag.userid=u.userid and ucag.deleted=0     
inner join customerassignmentgroupmapping cag on  ucag.custAssignmentGroupId=cag.custAssignmentGroupId and cag.deleted=0    
inner join (select cast(Items as int) custid from dbo.split(@customerIds,',')) cids on  cids.custid  = cag.customerId            
inner join customer c   on c.customerid=cag.customerId and  c.deleted=0  
inner join AssignmentGroup ag on ag.assignmentgroupId=cag.assignmentgroupId  
inner join WorkGroup w  on w.workgroupId=ag.workgroupId and ag.deleted=0  
left join OnlineUsers Ousr  on Ousr.LoginId=984 
left join EventsMaster Em on Em.Id= Ousr.EventId



---------> 1	TATA AIG	Server - Unix - Queue	162


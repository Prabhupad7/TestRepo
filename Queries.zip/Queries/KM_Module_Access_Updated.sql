

---> insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)

Select 25664,285,GETDATE(),6,0

union all

Select 25664,66,GETDATE(),6,0

 --insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)

 -- Select 25664,285,GETDATE(),6,0

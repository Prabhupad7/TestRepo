

   select * from ServiceCustomerMapping where deleted=0 and serviceId=6

select top 10* from ServiceCategoryMapping sc inner join Category c on sc.categoryId=c.categoryId where sc.deleted=0 and sc.serviceId=6 

   select * from Service s where s.serviceName like '%Application Management%'  -- 2

   select * from Category where  category like '%Group InstaClaim%'  --- 1016  , 1017



   select top 100 * from Category where categoryId in (450
   ,451) and deleted =0


		-- insert into Category(category,deleted,Isdefaultcategory,isEUPVisible,icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn) 
		values
		('Group InstaClaim', 0,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())

		select top 200 * from ServiceCategoryMapping where deleted =0 order by 3

			--insert into ServiceCategoryMapping (serviceId,categoryId,deleted,ticketTypeId)
			--values (2,1016,0,1),(2,1017,0,2)



				INSERT INTO SubCategory (subCategory, categoryId,deleted,Isdefaultcategory, isEUPVisible ,Icon,Icon_Color ,Icon_BgColor,CreatedBy, CreatedOn, UpdatedBy, UpdatedOn)   
				VALUES 
				('Data request', 1017,0,0,0,'fa fa-2x fa-shield','#F5CF87', '#C75C5C',6,GETDATE(),6, GetDATE()),
				('Request', 1017,0,0,0,'fa fa-2x fa-shield','#F5CF87', '#C75C5C',6,GETDATE(),6, GetDATE()),
				('Others', 1017,0,0,0,'fa fa-2x fa-shield','#F5CF87', '#C75C5C',6,GETDATE(),6, GetDATE())




				-- select top 3 * from SubCategory order by subCategoryId desc



				-- INSERT INTO Classification(classification,subCategoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn, UpdatedBy, UpdatedOn)
				VALUES
				('Undefined',4820,0,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
				('Undefined',4821,0,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
				('Undefined',4822,0,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())


				-- select top 3 * from Classification order by subCategoryId desc

--subCategoryId
--1522
--1521


   select  * from Category WHERE DELETED = 0 AND category LIKE '%Online Policy Manager%'

   SELECT * FROM  ServiceCategoryMapping WHERE categoryId IN (360, 417)


   ---   Policy Deposit Receipt 
   --  PayConnect
   -- 363 --im, TICKETTYPEID -1
   -- 420 --SR,  TICKETTYPEID -2

      SELECT * FROM SubCategory WHERE categoryId = 363

  --   DONE -- --INSERT INTO SubCategory( subCategory,	categoryId,	deleted, Isdefaultcategory,	isEUPVisible,	Icon,	Icon_Color,	Icon_BgColor,	CreatedBy,	CreatedOn,	UpdatedBy,	UpdatedOn)
	 --VALUES ('Policy Deposit Receipt', 363, 0, 0, 1, NULL, NULL, NULL, 6, GETDATE(), 6, GETDATE())




	 -- INSERT INTO SubCategory( subCategory,	categoryId,	deleted, Isdefaultcategory,	isEUPVisible,	Icon,	Icon_Color,	Icon_BgColor,	CreatedBy,	CreatedOn,	UpdatedBy,	UpdatedOn)
	 --VALUES ('Policy Deposit Receipt', 420, 0, 0, 1, NULL, NULL, NULL, 6, GETDATE(), 6, GETDATE())


   ----  Online Policy Manager

      -- 360 --im, TICKETTYPEID -1
      -- 417 --SR,  TICKETTYPEID -2


	       --INSERT INTO SubCategory( subCategory,	categoryId,	deleted, Isdefaultcategory,	isEUPVisible,	Icon,	Icon_Color,	Icon_BgColor,	CreatedBy,	CreatedOn,	UpdatedBy,	UpdatedOn)
	       --VALUES ('Policy Deposit Receipt', 360, 0, 0, 1, NULL, NULL, NULL, 6, GETDATE(), 6, GETDATE())


	       --INSERT INTO SubCategory( subCategory,	categoryId,	deleted, Isdefaultcategory,	isEUPVisible,	Icon,	Icon_Color,	Icon_BgColor,	CreatedBy,	CreatedOn,	UpdatedBy,	UpdatedOn)
	       --VALUES ('Policy Deposit Receipt', 417, 0, 0, 1, NULL, NULL, NULL, 6, GETDATE(), 6, GETDATE())


		     SELECT	* FROM RulesForPriority where PriorityRule like '%categoryid=417%'

			 -- for cat-363 im 

			 --INSERT INTO RulesForPriority (RuleDescr, PriorityRule, PriorityId, ImpactId, RulePriority, Deleted,RuleTemplateId,urgencyId)

			 --VALUES('Rules', '{customerId=1;serviceId=2;categoryId=417;subCategoryId=4645;ticketTypeId=2;}',6 ,7, 1, 0, 967, null)


			 SELECT	top 4 * FROM RulesForPriority order by 1 desc


		   	 SELECT	* FROM RulesForPriority where PriorityRule like '%categoryid=360;subCategoryId=4644%'



			SELECT * FROM SubCategory WHERE categoryId = 417 and subCategory = 'Policy Deposit Receipt'  --  4645

			 select * from priority where ticketTypeid in (2)

			 select * from impact 

			 {customerId=1;serviceId=2;categoryId=363;subCategoryId=1089;ticketTypeId=1;}


			 ----- For mapping the rules for priority:

			 Select top 2000 * from RulesForPriority

			 select * from RuleTemplates where RuleTemplateId = 1890

			 select * from Priority where ticketTypeId = 2

			 select * from SubCategory where categoryId = 1017

			 select * from Classification where subCategoryId = 4822

			 select top 10 * from Classification order by 1 desc

			 select * from Impact

				--4	Low
				--7	Medium
				--10	High

			 --- 35	RuleKLI54	{customerId=1;serviceId=9;categoryId=177;subCategoryId=34;ticketTypeId=2;}	10	4	1	0	967	NULL
			 1780	Incident P1	{customerId=53;serviceId=32;categoryId=652;subCategoryId=2050;classificationId=2066;ticketTypeId=1;}	9	7	1	0	1890	NULL

			 --Insert into RulesForPriority (RuleDescr, PriorityRule, PriorityId, ImpactId, RulePriority, Deleted, RuleTemplateId)
			 values 
			 ('RuleKLI', '{customerId=1;serviceId=2;categoryId=1016;subCategoryId=4817;classificationId=8838;ticketTypeId=1;}', 5, 10, 1, 0, 1890),
			 ('RuleKLI', '{customerId=1;serviceId=2;categoryId=1016;subCategoryId=4818;classificationId=8839;ticketTypeId=1;}', 5, 10, 1, 0, 1890),
			 ('RuleKLI', '{customerId=1;serviceId=2;categoryId=1016;subCategoryId=4819;classificationId=8840;ticketTypeId=1;}', 27, 7, 1, 0, 1890),

			 ('RuleKLI', '{customerId=1;serviceId=2;categoryId=1017;subCategoryId=4820;classificationId=8841;ticketTypeId=2;}', 10, 7, 1, 0, 1890),
			 ('RuleKLI', '{customerId=1;serviceId=2;categoryId=1017;subCategoryId=4821;classificationId=8842;ticketTypeId=2;}', 10, 7, 1, 0, 1890),
			 ('RuleKLI', '{customerId=1;serviceId=2;categoryId=1017;subCategoryId=4822;classificationId=8843;ticketTypeId=2;}', 16, 4, 1, 0, 1890)

			select top 6 * from RulesForPriority order by 1 desc

			--2890
			--2889
			--2888
			--2887
			--2886
			--2885
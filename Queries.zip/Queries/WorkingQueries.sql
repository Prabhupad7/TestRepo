
SELECT * FROM  TICKET T WHERE T.ticketNo = 2522254

Select T.TICKETTYPEID ,t.statusId, t.statusName   from ticket  t where t.ticketNo = 2522254  

Select * from TicketStatus TS WHERE TS.TICKETTYPEID = 2

--  UPDATE TICKET SET statusId = 19, statusName = 'Resolved' WHERE ticketNo = 2529137



select * from Customer where customerId = 207

select * from customer where customerName like '%unity bio%'

--select  * from users WHERE USERNAME LIKE '%venkat%'

  select custAssignmentGroupId from CustomerAssignmentGroupMapping where customerId = 207 order by custAssignmentGroupId

  select * from CustomerAssignmentGroupMapping where customerId = 207 -- and ass  Unity Bio - Cloud Ops Unity Bio - Cloud Ops

  select * from CustomerAssignmentGroupMapping where customerId = 207 and custAssignmentGroupName like '%Cloud%'  -- groupId --2732

  select * from usercustomerassigngroupmapping where userid = 25961  


   update usercustomerassigngroupmapping set AssignToWorkGroup = 1
   where userCustomerAssignGroupId = 161443

  select * from Users where userid = 25961

    select * from Users where loginName like '%srikantharr1%' and deleted = 0



	userCustomerAssignGroupId
    161443

  UserCustomerAssignGroupMapping

  select * from UserCustomerAssignGroupMapping

sudhindrab
asifa
salmank
pramodpk
siddharthm


 --  select * from usercustomerassigngroupmapping where userid = 25961  

   select * from Users where loginName like '%sudhindrab%' and deleted = 0   -- userId = 25305

   select * from Users where loginName like '%asifa%' and deleted = 0   -- userId = 25010

   select * from Users where loginName like '%salmank%' and deleted = 0   -- userId = 24994

   select * from Users where loginName like '%pramodpk%' and deleted = 0   -- userId = 1669

   select * from Users where loginName like '%siddharthm%' and deleted = 0   -- userId = 24278

   select * from UserCustomerAssignGroupMapping where userId = 25305             

   select * from CustomerAssignmentGroupMapping where customerId = 207

	 select custAssignmentGroupId from CustomerAssignmentGroupMapping where customerId = 207



	   -- custAssignmentGroupId--> 2717 to 2732 for customerId= 207

	        select top 10* from UserCustomerAssignGroupMapping where userId = 24278 and 
			custAssignmentGroupId in (2717, 2718, 2719, 2720, 2721, 2722, 2723, 2724, 2725, 2726, 2727, 2728, 2729, 2730, 2731, 2732)


			-- For UserId -->  25305

	        Insert into UserCustomerAssignGroupMapping
            select 25305, 2717, 0, 0, 0
			union all			   	  
			select 25305, 2718, 0, 0, 0
			union all			   	  
			select 25305, 2719, 0, 0, 0
			union all			   	  
			select 25305, 2720, 0, 0, 0
			union all			   	  
			select 25305, 2721, 0, 0, 0
			union all			   	  
			select 25305, 2722, 0, 0, 0
			union all			   	  
			select 25305, 2723, 0, 0, 0
			union all			   	  
			select 25305, 2724, 0, 0, 0
			union all			   	  
			select 25305, 2725, 0, 0, 0
			union all			   	  
			select 25305, 2726, 0, 0, 0
			union all			   	  
			select 25305, 2727, 0, 0, 0
			union all			   	  
			select 25305, 2728, 0, 0, 0
			union all			   	  
			select 25305, 2729, 0, 0, 0
			union all			  	  
			select 25305, 2730, 0, 0, 0
			union all			   	  
			select 25305, 2731, 0, 0, 0
			union all			  	  
			select 25305, 2732, 0, 0, 0



						-- For UserId -->  25010

	        Insert into UserCustomerAssignGroupMapping
            select 25010, 2717, 0, 0, 0
			union all			   	  
			select 25010, 2718, 0, 0, 0
			union all			   	  
			select 25010, 2719, 0, 0, 0
			union all			   	  
			select 25010, 2720, 0, 0, 0
			union all			   	  
			select 25010, 2721, 0, 0, 0
			union all			   	  
			select 25010, 2722, 0, 0, 0
			union all			   	  
			select 25010, 2723, 0, 0, 0
			union all			   	  
			select 25010, 2724, 0, 0, 0
			union all			   	  
			select 25010, 2725, 0, 0, 0
			union all			   	  
			select 25010, 2726, 0, 0, 0
			union all			   	  
			select 25010, 2727, 0, 0, 0
			union all			   	  
			select 25010, 2728, 0, 0, 0
			union all			   	  
			select 25010, 2729, 0, 0, 0
			union all			  	  
			select 25010, 2730, 0, 0, 0
			union all			   	  
			select 25010, 2731, 0, 0, 0
			union all			  	  
			select 25010, 2732, 0, 0, 0

									-- For UserId -->  24994

	        Insert into UserCustomerAssignGroupMapping
            select 24994, 2717, 0, 0, 0
			union all			   	  
			select 24994, 2718, 0, 0, 0
			union all			   	  
			select 24994, 2719, 0, 0, 0
			union all			   	  
			select 24994, 2720, 0, 0, 0
			union all			   	  
			select 24994, 2721, 0, 0, 0
			union all			   	  
			select 24994, 2722, 0, 0, 0
			union all			   	  
			select 24994, 2723, 0, 0, 0
			union all			   	  
			select 24994, 2724, 0, 0, 0
			union all			   	  
			select 24994, 2725, 0, 0, 0
			union all			   	  
			select 24994, 2726, 0, 0, 0
			union all			   	  
			select 24994, 2727, 0, 0, 0
			union all			   	  
			select 24994, 2728, 0, 0, 0
			union all			   	  
			select 24994, 2729, 0, 0, 0
			union all			  	  
			select 24994, 2730, 0, 0, 0
			union all			   	  
			select 24994, 2731, 0, 0, 0
			union all			  	  
			select 24994, 2732, 0, 0, 0


			-- For UserId -->  1669

	        Insert into UserCustomerAssignGroupMapping
            select 1669, 2717, 0, 0, 0
			union all			   	  
			select 1669, 2718, 0, 0, 0
			union all			   	  
			select 1669, 2719, 0, 0, 0
			union all			   	  
			select 1669, 2720, 0, 0, 0
			union all			   	  
			select 1669, 2721, 0, 0, 0
			union all			   	  
			select 1669, 2722, 0, 0, 0
			union all			   	  
			select 1669, 2723, 0, 0, 0
			union all			   	  
			select 1669, 2724, 0, 0, 0
			union all			   	  
			select 1669, 2725, 0, 0, 0
			union all			   	  
			select 1669, 2726, 0, 0, 0
			union all			   	  
			select 1669, 2727, 0, 0, 0
			union all			   	  
			select 1669, 2728, 0, 0, 0
			union all			   	  
			select 1669, 2729, 0, 0, 0
			union all			  	  
			select 1669, 2730, 0, 0, 0
			union all			   	  
			select 1669, 2731, 0, 0, 0
			union all			  	  
			select 1669, 2732, 0, 0, 0


						-- For UserId -->  24278

	        Insert into UserCustomerAssignGroupMapping
            select 24278, 2717, 0, 0, 0
			union all			   	  
			select 24278, 2718, 0, 0, 0
			union all			   	  
			select 24278, 2719, 0, 0, 0
			union all			   	  
			select 24278, 2720, 0, 0, 0
			union all			   	  
			select 24278, 2721, 0, 0, 0
			union all			   	  
			select 24278, 2722, 0, 0, 0
			union all			   	  
			select 24278, 2723, 0, 0, 0
			union all			   	  
			select 24278, 2724, 0, 0, 0
			union all			   	  
			select 24278, 2725, 0, 0, 0
			union all			   	  
			select 24278, 2726, 0, 0, 0
			union all			   	  
			select 24278, 2727, 0, 0, 0
			union all			   	  
			select 24278, 2728, 0, 0, 0
			union all			   	  
			select 24278, 2729, 0, 0, 0
			union all			  	  
			select 24278, 2730, 0, 0, 0
			union all			   	  
			select 24278, 2731, 0, 0, 0
			union all			  	  
			select 24278, 2732, 0, 0, 0

			// 11/5/2020:

			Today ticket:  SR2527760 check this also
             i will tell you how to do:
			 AutoClose ticket.

			 // 13/4/2020:
			 // Vamsi Hall Ticket : 2014131422  \

			 // phone number: 9502606989

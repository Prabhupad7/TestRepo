
	    select * from Customer where customername like '%Unity%' -- 207	Unity Bio

		select * from Customer where customername like '%Bosc%' -- 61	BOSCH	BOSCH

		-- 61	BOSCH	BOSCH	0	NULL
  --       189	BOSCH DCS	BOSCH DCS	0	NULL
  --       203	Bosch � Scottsdale	Bosch � Scottsdale	0	NULL

     --- ShraddhaHN@microland.com 

	    select * from notificationRules where customerid in ( 61, 189, 203) and deleted = 0 and 
		notificationTo like '%ShraddhaHN@microland.com%' and notifyBasedOnId = 2

		 select * from notificationRules where customerid in ( 61, 189, 203) and deleted = 0 and 
		notificationTo like '%ShraddhaHN@microland.com%' and notifyBasedOnId = 2


	



		select * from notificationRules where  deleted = 0 and 
		notificationCC like '%ShraddhaHN@microland.com%' 



			select * from notificationRules where  deleted = 0 and 
		notificationTo like '%ShraddhaHN@microland.com%' 



		select top 10 * from Requestor where requestorEmail 
		like '%ShraddhaHN@microland.com%'  ---- 919739794576



		Enzen and Innocent drinks customers 
		  
		select * from Customer where customerName like '%Enzen%'   ----158

		select * from Customer where customerName like '%Innocent drinks%'   ----188

			Innocent Drinks and NGN-Enzen.

				select * from notificationRules where  deleted = 0 and 
		notificationCC like '%ShraddhaHN@microland.com%'  and customerId in (158, 188) and notifyBasedOnId = 3

			select * from notificationRules where  deleted = 0  and customerId in (61, 189, 203) and notificationMode like '%AWSSMS%'

			---- 919739794576
	
			select * from notificationRules where  deleted = 0  and customerId in (158, 188) and notificationMode like '%AWSSMS%'

				select * from notificationRules where  deleted = 0  and customerId in (158, 188)
				and notificationMode like '%AWSSMS%' 

--	     update notificationRules set notificationTo = notificationTo + ',919886766766' where ruleId in 
--			(
--2072344
--,2072347
--,2072341
--,2072345
)






			select * from NotificationRules where ruleId in (
			2213414,2213422)

			

		---  BinuTP@microland.com

		update notificationRules set notificationCC = REPLACE (notificationCC, 'ShraddhaHN@microland.com', 'BinuTP@microland.com')

			select * from notificationRules where  deleted = 0 and 
		notificationTo like '%ShraddhaHN@microland.com%' 


		--     Karthik - 9739886229
        --     Dilip - 8748857574

	select * from customer where customerid = 3


	select * from Service where serviceName like '%CIS%'

	---  Issue in Work group: 193

	select * from Customer where customername like '%SMC RMC%' -- 154

	select * from users where loginName = 'BooraPo'


	select * from Instance 

	select * from AuthenticationType  

	select * from Workgroup where workgroupid in (

	select distinct WorkgroupId from ServiceLevelObjective where serviceId = 84 and isDelete = 0
	) and workgroup not like '%RMC%'

	SR2619465


	select * from Workgroup where workgroup like '%Global Mobility%'

	select * from RulesForAssignment where AssignToId = 26007

	select * from Service where serviceName like '%HR%'-- 84

	select * from NotificationRules where customerId = 147 and deleted = 0 -- 1958   Work in progress, 488	Open notication_HR, 484  Assigned Template_HR , 489

	select * from NotificationRules where customerId = 147 and deleted = 0 and templateId = 1958

	select * from NotificationEmailTemplate where templateId = 1958

	select * from NotificationEmailTemplate where templateId = 488

	select * from NotificationEmailTemplate where customerId = 147 and deleted

	select * from TicketStatus where ticketTypeId =1 --3	Work in Progress
	
	select * from TicketStatus where ticketTypeId =2 --14	Work in Progress

	       INSERT INTO NotificationRules (customerId, ticketTypeId, notificationMode, notificationTo, notificationCC, templateId, ruleName, 
		   serviceId, notifyBasedOnId, entryStateId, deleted)

		   values(147, 2, 'Email', '$REQUESTOREMAIL', '$ASSIGNEDENGINEEREMAIL', 1958, 'Work in Progress', 84, 1, 64, 0)

			-- where templateName like '%Work%' and customerId = 147  --- 1946  templateId

        	insert into NotificationEmailTemplate(templateName,template,templateSubject, customerId, isOutageNotificationTemplate, isOutageSMSNotification) 
            values('workin- progress','', ' $PRIORITYNAME Notification - Ticket Number: [ $TICKETNOTODISPLAY ]  has been updated', 147,  0,0)
        

	
	select top 100 * from NotificationEmailTemplate where templateName like '%Work%' and customerId = 211  --- 1946  templateId, 1365, 1450





	--update Workgroup set workgroupEmail = 'ShubhaB@microland.com;CarolMR@microland.com' where workgroupId = 229

	----  ASHISHG@microland.com;CarolMR@microland.com

	select * from NotificationRules where notificationTo like '%itsd.cns@heromotocorp.com%'

	select * from NotificationRules where notificationCC like '%itsd.cns@heromotocorp.com%'


	--154	Network	Network

-- update NotificationRules set notificationTo = Replace (notificationTo, 'itsd.cns@heromotocorp.com', 'centralteam-fms@heromotocorp.com') where ruleid in (
2130304
,2130305
,2130306
)

	
	select * from NotificationRules where notificationTo like '%itsd.cns@heromotocorp.com%'

	--update Workgroup set workgroupEmail = 'AMR@microland.com' where workgroupId = 249

	select * from workgroup where workgroupid = 154

	select * from RulesForAssignment where AssignToId = 1581






	select * from Customer where customername like '%COMVIVA%' -- 169

	select * from CustomerAssignmentGroupMapping where customerId = 199, 212

	select * from users where Email= 'BhagyaYL@microland.com'  -- like '%sisir.bose@khaitanco.com%' -- 1554

	select * from users where Email= 'CarolMR@microland.com'   --  24750

	select * from RulesForAssignment where AssignToId = 24750

	update RulesForAssignment set AssignToId = 24750  where RuleId = 79079

	select * from Category where categoryId = 4715

	select * from Service where serviceId = 84


	select * from UserCustomerAssignGroupMapping where userid = 25434

	select * from CustomerAssignmentGroupMapping where customerId = 212, --custAssignmentGroupId -- 2920, 2921

	select * from UserCustomerAssignGroupMapping where userid = 25434 and custAssignmentGroupId in (2920, 2921)

	insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
	values

	(25434, 2920, 0, 1, 1),
	(25434, 2921, 0, 1, 1)




	select * from AssignmentGroup 

	select distinct devicename, * from device where customerid = 194 and deleted = 0

	

	select T.customerId, t.customerName, * from ticket T where ticketno = 2609456

	select * from NotificationRegistry where sourceId = 2609456   ---,   1168

	select * from Feedback where TicketNo = 2609456

	select * from FeedbackConfig where customerid



	select * from NotificationEmailTemplate where templateId in (
	1223

                 


	select  top 100 T.statusId, T.statusName, t.TicketTypeid, * from ticket T where customerId = 190 
	--and createdOn BETWEEN  '2020-07-22' AND '2020-07-13' 
	and statusId in (9,11, 19,21) and TicketTypeid in (1,2)
	order by 1 desc

	select * from TicketStatus where ticketTypeId in (1,2)

	  select top 100 * from NotificationRegistry  

	  select * from NotificationRegistry where sourceId in (2604888
,2604731
,2604701
,2604624
)

and sourceModule like '%CSAT%'

           

            select * from users U where U.email in ('VipinKC@microland.com')  -- 23854
			-- before ashish --4
			

		 	 select * from users U where U.email in ('VipinKC@microland.com')  -- 23854
			 
			  select * from NotificationRules where notificationTo like '%VipinKC@microland.com%' 



			    select distinct workgroupid from NotificationRules where notificationCC  like '%VipinKC@microland.com%'  -- workgroupid-- 212, 599

			    select * from NotificationRules where notificationCC  like '%VipinKC@microland.com%'  

				-- UPDATE NotificationRules SET notificationCC = REPLACE(notificationCC, 'VipinKC@microland.com', 'MLITAssetManagement2@microland.com')

				WHERE ruleId IN ()


			  select * from Workgroup w where w.workgroupEmail like '%VipinKC@microland.com%'

			  select * from Workgroup where workgroup like '%cis-asset not in stock-business request%'
			  select * from Workgroup where workgroup like '%cis-asset not%'
			  select * from Workgroup where workgroup like '%cis-pending %'
			  select * from Workgroup where workgroup like '%asset management%'

			  select * from Workgroup where workgroupId in (212, 599)
			 	  
				  	select * from users where email like '%ManjunathK@microland.com%'  -- 26110

	          select * from CustomerAssignmentGroupMapping where customerId = 147
	          
	          select * from UserCustomerAssignGroupMapping where userId = 26110
	          
	          select * from NotificationRules where notificationCC like '%ManjunathK@microland.com%'

		  	  select * from NotificationRules where notificationTo like '%ManjunathK@microland.com%' 

			  --select * from NotificationRules where notificationCC  like '%ManjunathK@microland.com%'

			   select  * from NotificationRules where notificationCC  like '%ManjunathK@microland.com%'  and workgroupid in (
			   203
,205
,206
,211
,212

)





			  select * from workgroup where workgroupId in (
			  select  distinct workgroupid from NotificationRules where notificationCC  like '%ManjunathK%' and deleted =0) 
			  and deleted = 0 and  workgroupid not in (195
,200
)

			   select * from Workgroup where workgroupEmail like '%ManjunathK@microland.com%'

			   select * from CustomerAssignmentGroupMapping where assignmentgroupId in (
			   select assignmentgroupId from AssignmentGroup where workgroupId in (select workgroupId from Workgroup where workgroup like '%DSS%' )) and customerId=147

			   --216

			   select * from Workgroup where workgroup like '%sd' 
			   select * from Workgroup where workgroup like '%DSS%'
			  	 

		      select * from Workgroup w where w.workgroupEmail like '%SandeepkumarM@microland.com%' 
			  select * from RulesForAssignment where  AssignToId = 1591 
			  select top 100 * from FeedbackConfig where ToAddr like '%OmkarKN@microland.com%'

			   SELECT top 100 * FROM NotificationRegistry where notificationTo like '%SandeepkumarM@microland.com%' 
			   SELECT top 100 * FROM NotificationRegistry where notificationCC like '%SandeepkumarM@microland.com%' 
			  
			 

			 -- 25420



		 -------------  sachin.hatankar@kotak.com).


	  --   update users set levelid = 1 where userid = 26235     --email = 'chiranjib@maventic.com'

		 --update users set levelid = 1, UserTypeId = 3  where userid = 25474   -- email = 'ashishpa@microland.com'

		 --	     update users set levelid = 1 where userid = 26235     

		 --update users set levelid = 1, UserTypeId = 3  where userid = 25474   


		 select * from RulesForAssignment where AssignToId = 1092 --  25474

		 --update RulesForAssignment set AssignToId = 25474 where RuleId in (79074, 79078)

		 select * from AssignmentGroup where assignmentgroupId in (343, 348)

		 select top 10* from Workgroup where 








		 select top 10 * from CustomerAssignmentGroupMapping 

		 --update users set deleted = 1 where userId = 25176

	  --   UPDATE Workgroup SET workgroupEmail = REPLACE(workgroupEmail,'SaiPratikB@microland.com', '')  WHERE workgroupId in(227, 232, 249, 364)

		 select top 100 * from FeedbackConfig where ToAddr like '%OmkarKN@microland.com%'

		 -- select * from FeedbackConfig where ToAddr like '%NatarajanG@microland.com%'

		 select * from RulesForAssignment where AssignToId = 24382  

		 LPBNG00040723373_IS_Katabathin


			  



select * from Customer where customerName like '%oreta%' and deleted=0
 
select * from users U where U.email = 'DeepakRC@microland.com'

     SalmanK@microland.com

select * from notificationrules where customerid in  (Select customerId from customer where customername like '%Oreta%' and deleted =0 or customerId in (161,70,184)) and notificationMode = 'awssms' and deleted=0

--update NotificationRules set deleted=1 where ruleId in (2252344,


  -- SELECT * FROM USERS WHERE email ='DeepakRC@microland.com'
 -- UPDATE Users SET deleted =1 WHERE userId = 1494
   

   --REPLACE(workgroupEmail, 'deepakrc@microland.com', '')



   -- Bank Account Changes --> Only Girishl need to be there 
   -- BGV account Canges--> only GirishL
   -- For Employee Exit process--> Anusha and preet.

   --  SouravDU@microland.com;deepakrc@microland.com

    --SET notificationTo =REPLACE(notificationTo,'ArunR@microland.com', 'deepakrc@microland.com') 













   select * from Users U where U.email = 'NikhilDaB@microland.com'

   select * from Users U where U.email = 'SouravDU@microland'   --> No mobile Number

   select * from Requestor R where r.requestorEmail = 'rmcshiftmanager@microland.com'

    select * from Requestor R where r.requestorEmail = 'hduqualityteam@microland.com'



	select t.statusname, * from ticket t
     join requestor r on r.requestorId=t.requestorId
     where customerId=4 and r.requestorEmail='vishalds@microland.com'


	 select top 20 * from AutoTicketEventLog  order by createdOn desc 

	 select t.TicketTypeid, * from Ticket t where t.ticketNo = 2046002

	 select * from TicketStatus where ticketTypeId=4

	 select * from TicketType

	 select * from Users where email='AnkurDe1@microland.com'

	 KadireshMU@microland.com


	    select * from NotificationRules n where n.notificationtO like '%RavikiranMK@microland.com%'

	 	 select * from NotificationRules n where n.workgroupid = 628


		 		 
         select * from NotificationRules where notificationCC like '%DeepakRC%' 
         select * from NotificationRules where notificationTo like '%DeepakRC%'
		 select * from Workgroup w where w.workgroupEmail like '%RavikiranMK@microland.com%'


		 sudhir.chavan@shapoorji.com



		 9886123455


		 ---   ANAND.MAHAJAN@shapoorji.com; Durga.Prasad@shapoorji.com
		 
    select * from NotificationRules where notificationCC like '%bharat.reddy@shapoorji.com%'

    select * from NotificationRules where notificationTo like '%bharat.reddy@shapoorji.com%'

	 select * from Workgroup w where w.workgroupEmail like '%bharat.reddy@shapoorji.com%'

	 -- select * from Workgroup w where w.workgroupEmail like '%Sachin.Goutam%'

	      UPDATE Workgroup SET workgroupEmail = REPLACE (workgroupEmail, 'bharat.reddy@shapoorji.com',


	      'girish.kulkarni@shapoorji.com') 
	      
	      WHERE WorkgroupId in (341
,343
,345
,346
,349
,352
,406
,409
,410
,594)




	select * from RulesForAssignment where assigntoId = 24993




	UPDATE NotificationRules SET notificationTo =REPLACE(notificationTo,'919986704724', '')
	 
	 where ruleId in(2134148

,2154906
,2214500)




	    select * from NotificationRules where notificationCC like '%SalmanK@microland.com%'

    select * from NotificationRules where notificationTo like '%SalmanK@microland.com%'

		 --update Workgroup  set workgroupEmail = 'KadireshMU@microland.com; '


		 -- for below description and Escalation Matrix missed:

----		 Hi Team

----Please provide mirror access of KadireshMU@microland.com to AnkurDe1@microland.com. Going forward Ankur Dev will resolve tickets related to Queries on General LD.

----Kadiresh M U can be mapped as the escalation point of contact for General LD.

----Also please note that auto-assignment of general LD queries much go to Ankur Dev however email notification should go to Kadiresh M U  Ankur Dev.

		 select * from users where email = 'AnushaYG1@microland.com'  --26197

		 select * from users where userid in ( 26087, 26222)
		 select * from users where userid = 26222

		 update Users set levelid = 1 where userId = 26222

		  select * from users where email = 'niharikad@microland.com'    26222

		  

         select * from users where email = 'KadireshMU@microland.com' -- 26006

         
         select * from Workgroup where workgroup like '%HM6C%'  --  607


         
         select * from RulesForAssignment where AssignToId = 1494                 --Auto Assignment means we need to check table: RulesForAssignment

		 (79081, 79087)
         
         select * from AssignmentGroup where assignmentgroupId = 759
         
         select * from workGroupEscalationMatrix_AskML where workGroupId = 628
         select * from workGroupEscalationMatrix where workGroupId = 628           -- escalation matrix to setup.

		 select * from workGroupEscalationMatrix_Notification where workGroupId = 628

         select * from UserCustomerAssignGroupMapping where userId = 26006
         
         select * from UserCustomerAssignGroupMapping where userId = 26197 

		 -- 26197

		 UPDATE Workgroup SET workgroupEmail = 'KadireshMU@microland.com; AnkurDe1@microland.com' WHERE workgroupId = 628
		 UPDATE RulesForAssignment SET AssignToId = 26197 WHERE RuleId = 79071                                             
		 --FOR AUTOASSIGNMENT.



		 ----   Ticket Conversion failed i.e Unable to Move from one state onother:
		 select statusId,priorityId,priorityname from ticket where ticketNo = 2564237--13	14	SR3

SR - IM

select * from TicketStatus where statusId = 13--tickettypeId -2. need to check for typeId 1
select * from TicketStatus where ticketTypeId =1 and deleted = 0 --as it is converted to IM so assigned = 2
select * from Priority where ticketTypeId = 1 and deleted = 0 --it was SR3 so take P3--9

update ticket set statusId = 2, priorityId = 9,priorityName = 'P3'where ticketNo = 2564237 




-----  > CSAT (Feed Back ) Configuration. 23/06/2020

select * from customer where customerId = 182 


select * from NotificationEmailTemplate where customerId = 182 --962

select * from NotificationRules where customerId = 182 and deleted = 0 and duePercent is null and templateId = 962

select distinct(serviceId) from ServiceCustomerMapping where customerId = 182  and deleted = 0 

select * from NotifyBasedOn

select * from TicketStatus


select  * from ticket where customerId in(select customerId from Customer where customerName like '%smc%') 

  and CONVERT( varchar(10), createdOn, 120 )= convert(varchar(10), GETDATE(), 120)

select GETDATE()


select * from customer where customerName like '%smc%'

   1.ts_Autoscheduler
   customer and time , Requestor where createdTime 

   ts_AutoTicketSchedulerRegistry where ts_autoschedulerId = ''
   ticket

      select * from TS_AutoTicketSchedular where 

	  select * from TS_AutoTicketSchedularRegistry where 

            


			select * from customer where customerName like '%HMCL%' -- 152

















  -- Regarding Ticket Number: SR2565626
  dhanraj / subhan,  need to call at 1 or 2 PM. 
  
  080 6175 5768

  select * from Users where email like '%VivekDe@microland.com%'

  SELECT * FROM Workgroup W WHERE W.displayName LIKE '%%'

  --  15/6/2020:

    select * from NotificationRules where notificationTo like '%Anusha%'

    select * from NotificationRules where notificationCC like '%Anusha%'

	select * from RulesForAssignment where AssignToId = 26197 

    select * from Workgroup W where W.workgroupEmail like '%Lauren%'

    select * from RulesForAssignment


	--vivekde@microland.com
	--samikshat@microland.com


	--DilipSK@microland.com



	-- 16/6/2020:
	
	 select * from Customer where customerName like '%Ownership%' 

	 select * from NotificationRules where notificationTo like '%AshleyDN@microland.com%' and customerId = 161

	 select * from Workgroup W where W.workgroupEmail like '%AshleyDN@microland.com%'

	 selecT * from NotificationRules where customerId in (Select customerId from customer where customername
	 like '%Oreta%' and deleted =0 or customerId in (161,70,184) ) 

	


	  UPDATE NotificationRules SET notificationTo =REPLACE(notificationTo,'AshleyDN@microland.com', '')
	 
	 where ruleId in(1845993,1845994,1845995,1872070,1872071,1872072,1845996,1845997,1845998,1872073,1872074,1872075,1845999,1846000,1846001,1872076,1872077,1872078,
1846002,
1846003)


   -- 06/07/2020: 

   

   


   select * from NotificationRules where ruleid in (2329326
,2329322
,2329318
,2329319)

---KGI

select * from NotificationRegistry where sourceid = 71802
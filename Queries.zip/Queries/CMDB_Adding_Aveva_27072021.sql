

--> 774094

select * from AssetEntityType where id in (429,447,241) --> 241	CMDB (Its a parent Id:)

---> 447	 Switch	Network Devices 

select * from Assets where id = 764728 ----> 774125

select * from Assets where id = 774125 ---->

--update assets set isDeleted = 1 where id = 774094

select * from VarcharCustomAttribute where PrimaryId = 764728

select * from VarcharCustomAttribute where PrimaryId = 774125

select * from VarcharCustomAttribute where PrimaryId in  
(select id from Assets where CustomerId = 192 and SourceTypeId =220)

select * from DeviceServiceMapping where deviceId in (34062,34063,34064)


--Insert into Assets (CustomerId, SourceId, SourceTypeId, AssetName,SerialNumber, IpAddress, Createdbyid, CreatedOn, LastUpdatedBy, LastUpdatedOn)
--values 
--(192,447,1,'AWS-VSR-112','','10.160.16.32',6,Getdate(), 6, getdate()),
--(192,447,1,'AWS-VSR-113','','10.160.16.33',6,Getdate(), 6, getdate()),
--(192,447,1,'AWS-VSR-114','','10.160.50.30',6,Getdate(), 6, getdate()),
--(192,447,1,'COR-SR-092','','10.160.16.34',6,Getdate(), 6, getdate()),
--(192,447,1,'AWS-VSR-115','','10.160.16.35',6,Getdate(), 6, getdate())


select top 5 * from Assets order by 1 desc

--Insert into VarcharCustomAttribute (CustomerId, SourceId, SourceType, PrimaryId)
--values 
--(192, 447, 1, 774477),
--(192, 447, 1, 774476),
--(192, 447, 1, 774475),
--(192, 447, 1, 774474),
--(192, 447, 1, 774473)

-----> Enabling the BULK Upload option for CMDB Aveva:

select IsBulkUpdate,* from CustomAttributeColumnMapping 
where CustomerId = 220 and SourceId = 447 and PageId = 3

select * from VarcharCustomAttribute where PrimaryId = 774477

select IsBulkUpdate,* from CustomAttributeColumnMapping 
where CustomerId = 192 and SourceId = 447 and PageId = 3

select * from AssetEntityType where id in (447) ---> 447	 Switch

--Update AssetEntityType set isBulkuploadEnabled = 1 where id in (447)

--------------------->

Email Id - kgi.jayanta-mondal@Kotak.com
Login ID - GC0193


select * from users where email like '%kgi.jayanta-mondal@Kotak.com%' ----> 89	Jayanta 

 select distinct u.userCustomerAssignGroupId,u.custAssignmentGroupId,u.deleted, u.isAssignEnabled, u.AssignToWorkgroup,
 c.custAssignmentGroupName, a.assignmentgroupId, 
 a.assignmentgroupName, w.Workgroupid , w.Workgroup from  Workgroup W
 inner join AssignmentGroup A on A.workgroupId =  W.workgroupId
 inner join CustomerAssignmentGroupMapping C on C.assignmentgroupId = A.assignmentgroupId
 inner join UserCustomerAssignGroupMapping U on U.custAssignmentGroupId = C.custAssignmentGroupId
 where u.userId = 89 and u.deleted= 0 and c.deleted = 0 and a.deleted = 0 and w.deleted = 0


-- userCustomerAssignGroupId	custAssignmentGroupId	deleted	isAssignEnabled	AssignToWorkgroup	custAssignmentGroupName
--923	5	0	1	1	KGI-GIST Support-Queue


--Update UserCustomerAssignGroupMapping set isAssignEnabled = 1 where userCustomerAssignGroupId in (
--926,
--922,
--928,
--923,
--929,
--930,
--921,
--932,
--925,
--927,
--920,
--931,
--924,
--1179
--)


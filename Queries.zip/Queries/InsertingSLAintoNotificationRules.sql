

select * from notificationrules where customerid=207 and deleted=0 and ruleName like '%sla%' --order by ruleName

select * from notificationrules where customerid=207 and deleted=0

---Response SLA 40
----insert into NotificationRules(serviceId,ticketTypeId,duePercent,notificationMode,notificationTo,notificationCC,templateId,ruleName,notifyBasedOnId,deleted)
select distinct(serviceId), ticketTypeId,40,'Email', 'karthikv@microland.com;RMCShiftManager@microland.com;rmcdcteam@microland.com;
PrakashN@microland.com;MaheshAS@microland.com; rmccollaborationteam@microland.com;DilipMY@microland.com;', 'karthikv@microland.com',
1927,'Response SLA 40%',2,0  from notificationrules where customerid=207 and deleted=0

---Response SLA 50
----insert into NotificationRules(serviceId,ticketTypeId,duePercent,notificationMode,notificationTo,notificationCC,templateId,ruleName,notifyBasedOnId,deleted)
select distinct(serviceId), ticketTypeId,50,'Email', 'karthikv@microland.com; rmccollaborationteam@microland.com', 'ArunKA@microland.com; karthikv@microland.com;
RMCShiftManager@microland.com; rmcdcteam@microland.com;
 PrakashN@microland.com; RitwikD@microland.com;DilipMY@microland.com;',
1929,'Response SLA 50%',2,0  from notificationrules where customerid=207 and deleted=0

---Response SLA 60
----insert into NotificationRules(serviceId,ticketTypeId,duePercent,notificationMode,notificationTo,notificationCC,templateId,ruleName,notifyBasedOnId,deleted)
select distinct(serviceId), ticketTypeId,60,'Email', 'ArunKA@microland.com; rmccollaborationteam@microland.com; RitwikD@microland.com;',
'PrabhuKR@microland.com; SriramMo@microland.com; RMCShiftManager@microland.com; 
rmcunixteam@microland.com ; PrakashN@microland.com; karthikv@microland.com; DilipMY@microland.com;',
1930,'Response SLA 60%',2,0  from notificationrules where customerid=207 and deleted=0


---RESOLUTION SLA 40
----insert into NotificationRules(serviceId,ticketTypeId,duePercent,notificationMode,notificationTo,notificationCC,templateId,ruleName,notifyBasedOnId,deleted)
select distinct(serviceId), ticketTypeId,40,'Email', 'karthikv@microland.com;RMCShiftManager@microland.com;rmcdcteam@microland.com;
PrakashN@microland.com;MaheshAS@microland.com; rmccollaborationteam@microland.com;DilipMY@microland.com;', 'karthikv@microland.com',
1928,'RESOLUTION SLA 40%',3,0  from notificationrules where customerid=207 and deleted=0

---RESOLUTION SLA 50
----insert into NotificationRules(serviceId,ticketTypeId,duePercent,notificationMode,notificationTo,notificationCC,templateId,ruleName,notifyBasedOnId,deleted)
select distinct(serviceId), ticketTypeId,50,'Email', 'RMCShiftManager@microland.com; rmcdcteam@microland.com; PrakashN@microland.com; DilipMY@microland.com;',
'karthikv@microland.com; MaheshAS@microland.com;',
1931,'RESOLUTION SLA 50%',3,0  from notificationrules where customerid=207 and deleted=0

---RESOLUTION SLA 60
----insert into NotificationRules(serviceId,ticketTypeId,duePercent,notificationMode,notificationTo,notificationCC,templateId,ruleName,notifyBasedOnId,deleted)
select distinct(serviceId), ticketTypeId,60,'Email', 'karthikv@microland.com; MaheshAS@microland.com;', 'ArunKA@microland.com;
karthikv@microland.com; RMCShiftManager@microland.com; rmcdcteam@microland.com; PrakashN@microland.com;
RitwikD@microland.com; DilipMY@microland.com',
1932,'RESOLUTION SLA 60%',3,0  from notificationrules where customerid=207 and deleted=0





1927	RESPONSE SLA 40
1928	RESOLUTION SLA 40
1929	RESPONSE SLA 50
1930	RESPONSE SLA 60
1931	RESOLUTION SLA 50
1932	RESOLUTION SLA 60
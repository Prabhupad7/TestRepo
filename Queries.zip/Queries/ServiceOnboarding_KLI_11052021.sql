

select * from service where serviceid = 2 

---> Infra Security device Management

select * from service where serviceName like '%SAP EUROPLAN (IBP)%' ---> 550	SAP EUROPLAN (IBP)

---> STEP 1:

--Insert into Service (serviceName,alternateName,	description,createdDate,typeId,	contactId,	createdById,modifiedById,deleted,
--isEUPVisible,Icon,	Icon_Color,	Icon_BgColor)

--select 'SAP EUROPLAN (IBP)', 'SAP EUROPLAN (IBP)','SAP EUROPLAN (IBP)', GETDATE(), 4, 1, 1, 1, 0,0, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C'

select * from Customer where customerId  = 167  ---> 167	Eureka Forbes Limited

select * from ServiceCustomerMapping where customerId= 167 and deleted =0  ---> 51

select * from ServiceCustomerMapping where serviceId = 198 and customerId = 167   ---> 51

---> STEP 2:

--Insert into ServiceCustomerMapping 

--select 550, customerId, deleted, ticketTypeId from ServiceCustomerMapping 
--where serviceId = 198 and customerId = 167

select * from Workgroup where workgroup like '%SAP EUROPLAN-IBP%'  ---> 774	SAP EUROPLAN-IBP

select * from AssignmentGroup where workgroupId = 774 ---> 909	SAP EUROPLAN-IBP - Queue

select * from CustomerAssignmentGroupMapping where assignmentgroupId = 909  ----> 3088	Eureka Forbes Limited - SAP EUROPLAN-IBP - Queue

select * from Category where category like '%SCM Team%'  ----> 6029	SCM Team

select * from SubCategory where categoryId = 6029 ---> 23013

select * from Classification where subCategoryId = 23013 ---> 91476
 
---->   9740953532 --> Manjunath: 

select * from ServiceCustomerMapping where customerId= 2  ---> 51 52

select * from Priority where ticketTypeId = 2

select * from ServiceCustomerMapping where serviceId= 550

select top 100 * from servicePriorityMapping where serviceId = 93

select top 100 * from servicePriorityMapping where serviceId = 550

--Insert into servicePriorityMapping (customerPriorityMappingId,	serviceId,	deleted,	customerId,	PriorityId)

--select customerPriorityMappingId,	550,	deleted,	customerId,	PriorityId
--from servicePriorityMapping where serviceId = 198 and customerId = 167

select top 100 * from Classification
order by 1  desc  ----> Others-Undefined


select * from service where serviceName like '%Infra Security%' ---> 93

select * from servicePriorityMapping where serviceId = 93

select * from servicePriorityMapping where serviceId = 550

--------> 

--->Configuring the SLA:

select  * from ServiceLevelObjective  where serviceId = 92 and serviceLevelAgreementId = 23 
select  * from ServiceLevelObjective  where serviceId = 93 -- and serviceLevelAgreementId = 23 

select  * from ServiceLevelObjective  where serviceId = 94 

--Insert into ServiceLevelObjective 

select distinct 15 serviceLevelAgreementId , serviceLevelObjectiveTypeId,initialStatusId,finalStatusId,5400 responseTimeInMin,excludeStatusIds,93 serviceId,2 priorityId
,impactId,holidayCalendarId,1 workHourId,is24X7Service,locationId,143 workgroupId,isDelete,isDefault from ServiceLevelObjective
where serviceId = 92 and serviceLevelAgreementId = 23  and isDelete = 0 and serviceLevelObjectiveTypeId = 2

--->1080/5400


select * from ServiceLevelAgreement where customerId = 92 ---> 15	BranchOperations SR

--Intial Status 

 select * from TicketStatus where ticketTypeId = 2 and deleted = 0 ---> 16, 17

 select * from WorkHours  --->  1	9:30am to 6:30pm

 select top 10 * from HolidayCalendar

 ------> Configuring the Notification Rules:

 select * from NotificationRules
 where serviceId = 92 and deleted = 0  and duePercent in (60, 80, 40)

 select * from NotificationRules
 where serviceId = 92 and deleted = 0  and duePercent is null and ticketTypeId = 2

 select distinct ruleName, templateId from NotificationRules
 where customerid =  93 and deleted = 0  and duePercent is null and ticketTypeId = 2



 select distinct ruleName, templateId from NotificationRules
 where customerid =  93 and deleted = 0  and duePercent is null and ticketTypeId = 2

 select * from NotificationEmailTemplate where customerid = 92

--680	Assigned Template
--681	Resolved notication
--682	SLA 80
--684	SLA 60   Response
--689	Re-Open notification
--681	Resolved notication
--676	On Hold Customer
--678	Open notication
 ---------------> 

 select top 100 * from RulesForAssignmnet 

 select * from NotificationRules
 where serviceId = 92 and deleted = 0  and duePercent is null and ticketTypeId = 2

 select distinct ruleName, templateId from NotificationRules
 where customerid =  93 and deleted = 0  and duePercent is null
 and ticketTypeId = 2

 ---> 748

  select * from NotificationEmailTemplate where templateId = 757


select * from service where serviceName like '%POLICY SERVICING%' ---> 93

select * from ServiceCustomerMapping where customerId= 92  ---> 51

select * from Workgroup where workgroup like '%POLICY SERVICING%'  ---> kli.tsd2@kotak.com ---> 143

---> 677	SLA 60 Resolution ,
---> 682	SLA 80
---> 763	SLA 40 Resolution 

--Insert into NotificationRules (customerId, ticketTypeId,duePercent, notificationMode, notificationTo,notificationCC ,templateId, ruleName, serviceId, notifyBasedOnId, deleted)
--values
--(93, 2, 40,'mlmail', '$ASSIGNEDENGINEEREMAIL','sameera.kamath@kotak.com',763 , 'SLA 40 Resolution', 93,  3, 0),
--(93, 2, 60,'mlmail', '$ASSIGNEDENGINEEREMAIL','beenoy.pereira@kotak.com',677 , 'SLA 60 Resolution',  93, 3, 0),
--(93, 2, 80,'mlmail', '$ASSIGNEDENGINEEREMAIL','anirban.mondal@kotak.com',682 , 'SLA 80 Resolution',  93, 3, 0)


--Insert into NotificationRules 
--(customerId, ticketTypeId, notificationMode, notificationTo,notificationCC ,templateId, ruleName, workgroupid,serviceId, notifyBasedOnId,entryStateId ,deleted)

--select customerId, ticketTypeId, notificationMode, '$REQUESTOREMAILID;','srijith.ravindran@westernacher.com;sudharson.narayanan@westernacher.com;',
--templateId, ruleName, 774,550,
--notifyBasedOnId,entryStateId ,deleted from NotificationRules 
--where customerId = 167 and deleted = 0 and serviceId = 543 and ruleName ='Resolved'


select * from NotificationRules 
where customerId = 167 and deleted = 0 and serviceId = 543
order by ruleName



select * from servicePriorityMapping where serviceId = 550

----Update NotificationRules set customerId = 92 where serviceId = 93
  
 select * from NotificationRules
 where serviceId = 93 and deleted = 0  and ticketTypeId = 2 and  duePercent in (40, 60, 80)
 and notifyBasedOnId = 3

 ---> --689	Re-Open notification

 select * from DeviceServicemapping where serviceid = 550

 select * from Priority where ticketTypeId = 2  ---> 16	SR4

 select * from Impact ---> 4	Low

  select top 100 * from RulesForPriority where PriorityRule like '%customerId=1;serviceId=94;%'

 select top 100 * from RulesForPriority  ---> where RuleTemplateId = 14
 order by 1 desc  ---> 3118

 

 select * from Priority where ticketTypeId =2  ---> 
 select * from Impact

 select * from RulesForPriority where customerid = 167

-- Insert into RulesForPriority (RuleDescr, PriorityRule, PriorityId, ImpactId, RulePriority, Deleted, RuleTemplateId, customerid)
-- values 
--('Eureka Forbes Limited', '{customerid=167;serviceid=550;categoryid=6028;subcategoryid=23012;classificationid=91475;tickettypeid=1;}',9, 6,1,0,1890,167),
--('Eureka Forbes Limited', '{customerid=167;serviceid=550;categoryid=3107;subcategoryid=12230;classificationid=52801;tickettypeid=2;}',14, 6,1,0,1890,167)



 select top 100 * from RulesForAssignment 

 select * from RuleTemplates

 ---> 139	{priorityId=<<priorityId>>;serviceId=<<serviceId>>;impactId=<<impactId>>;}

 ---> 352	{customerId=<<customerId>>;serviceId=<<serviceId>>;}ciTypeId=<<ciTypeId>>;categoryId=<<categoryId>>;}

  select * from RuleTemplates where RuleTemplate like
  '%{customerId=<<customerId>>;serviceId=<<serviceId>>;}%' ---> 14

  select * from AssignmentGroup where workgroupId = 143 ---> 208

  select top 100 * from RulesForAssignment order by 1 desc

  select * from RulesForAssignment where AssignmentRule like '%customerid=167;%'

  --Insert into RulesForAssignment (RuleDescr, AssignmentRule, PrimaryAssignmentGroupId, SecondaryAssignmentGroupId, RulePriority, Deleted, RuleTemplateId,
  --customerId, AssignmentType, AssignToId, NoOfParams)
  --values 
  --('Rule', '{customerId=167;serviceId=550;categoryId=6028;}', 909, 909,1,0,91,167,1,0,3),
  --('Rule', '{customerId=167;serviceId=550;categoryId=6029;}', 909, 909,1,0,91,167,1,0,3)


   select * from NotificationRules
 where serviceId = 93 and deleted = 0  and ticketTypeId = 2 and  duePercent is null
 --and notifyBasedOnId = 3

 --Update NotificationRules set templateId = 713 where ruleId = 3101355

  select distinct ruleName, templateId from NotificationRules
 where customerid =  98 and deleted = 0  and duePercent is null
 and ticketTypeId = 2

 select * from NotificationEmailTemplate where templateId in (643
,662
,678
,680
,681
,689,757) ---> 


select  * from AutoCloseInfo  where customerid = 167 and serviceid = 550  ---> 

--Insert into AutoCloseInfo

--select  customerid, customerName, 2880, ticketTypeID, closureCode, closureCodeText, userID, isActive, 550,774
-- from AutoCloseInfo  where customerid = 167 and serviceid = 414


--insert into AutoCloseInfo (customerid,	customerName,	autocloseTime,	ticketTypeID,	closureCode,	closureCodeText,	userID,
--isActive,	serviceid,	workgroupid)

--values 
--(1,	'KLI', 2880,	1,	23,	'Auto Close',	5,	'Active',94,144),
--(1,	'KLI', 2880,	2,	24,	'Auto Close',	5,	'Active',94,144)

select * from Requestor where requestorEmail like '%venkataramana%' --> 30501 venkataramanaiahk@microland.com 

select * from CustomerRequestorMapping where requestorId = 30501

--Insert into CustomerRequestorMapping (requestorId, customerId, customerName)
--values (30501, 92, 'BranchOps')

select * from ServiceCustomerMapping where customerId= 92  ---> 51

select d.deviceId, d.deviceName from DeviceServiceMapping DS 
inner join Device D on d.deviceId = ds.deviceId
where ds.serviceId = 93 and d.deleted = 0 and ds.deleted = 0

--Insert into DeviceServiceMapping

--select 93, deviceId, deleted, ticketTypeId from DeviceServiceMapping where serviceId =  51

select * from Users  --> 6

select * from Workgroup where workgroup like '%POLICY SERVICING%'  ---> kli.tsd2@kotak.com ---> 143

select * from AssignmentGroup where workgroupId = 143 ---> 208

select * from CustomerAssignmentGroupMapping where assignmentgroupId = 208  ----> 228

select * from UserCustomerAssignGroupMapping where userid = 6

--insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
--values (6, 228, 0,1, 1)

 ---->  SR1580035

 --exec deletetickets @ticketNo = '1580035'


 select * from servicePriorityMapping where serviceId = 550  ---> 283

 select * from CustomerPriorityMapping where customerId = 92

 select * from Priority where priorityId = 2 ---> 

 select * from Category where category like '%Alte%' --> 1741

 --Update Category set deleted = 1 where categoryId = 1741

 select * from ServiceCategoryMapping where categoryId = 1741

 --update ServiceCategoryMapping set deleted = 1 where categoryId = 1741

 select impactId, impactName, * from Ticket where ticketno = 1580072
 order by 1 desc


    select * from ImpactTicketTypeMapping where serviceid = 550 and impactId =10
	select  * from AutoCloseInfo  where customerid = 167 and serviceid = 550 

	--Insert into ImpactTicketTypeMapping 

	--select impactId, ticketTypeId, deleted, 550 from ImpactTicketTypeMapping where serviceid = 413 

select * from Asset_users where EmailId like '%SriramN@microland.com%' ---->  id= 99826,  managerId= 63926
select * from Asset_users where EmailId like '%BharathKu@microland.com%' ---->  id= 22949,  managerId= 63926  

select * from Asset_users where id = 63926

select * from Customer where customerName like '%SMC KLI%' ---> 150

select * from Users where email like '%venkataramana%'  ---> 26093

select * from CustomerAssignmentGroupMapping where customerId = 150 and deleted = 0

select toolTicketNo, * from Ticket where toolTicketNo = '344497' 

--------------->

select * from Assets where Id = 766516

---> https://techassist.kotakmf.co.in/Account/Logon/KAM  kmamcsmartcenter Jan$2020

--update CustomerAssignmentGroupMapping
--set deleted=1
--from CustomerAssignmentGroupMapping c
--INNER JOIN UserCustomerAssignGroupMapping uc on c.custAssignmentGroupId = uc.custAssignmentGroupId
--where c.deleted=0 and uc.deleted=0 and c.custAssignmentGroupName like '%RMC Database%' and uc.userId not in (1814,26138,1762,25295,26515,26940)

--select distinct userId from CustomerAssignmentGroupMapping c
--INNER JOIN UserCustomerAssignGroupMapping uc on c.custAssignmentGroupId = uc.custAssignmentGroupId
--where c.deleted=0 and uc.deleted=0 and c.custAssignmentGroupName like '%RMC Database%' 
--and uc.userId not in (1814,26138,1762,25295,26515,26940)


----update users
----set password = 'SUv/GzSv2NSYGeW1YMGviQ==', SaltValue = NULL
----where userid = 24393 and deleted = 0r

---------------> 

select top 50 * from log order by 1 desc
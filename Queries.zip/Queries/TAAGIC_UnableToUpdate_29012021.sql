
   select * from CustomAttributeColumnMapping
   where CustomerId = 1 and SourceId = 23 and DisplayName like '%Rack%'  ------>   23  PageId:1

      select * from CustomAttributeColumnMapping
   where CustomerId = 1 and SourceId = 23 and PageId =2

         select * from CustomAttributeColumnMapping
   where CustomerId = 1 and SourceId = 4 and PageId =1

            select * from CustomAttributeColumnMapping
   where CustomerId = 1 and SourceId = 4 and PageId =2

      select * from CustomAttributeColumnMapping
   where CustomerId = 1 and SourceId = 23 and DisplayName like '%OS Name%'

         select * from CustomAttributeColumnMapping
   where CustomerId = 1 and SourceId = 23 and DisplayName like '%Primary owner%'

   --Update CustomAttributeColumnMapping set IsDuplicate = 0 where id in (2380, 2381, 1569, 1570)

   select Varchar86,Varchar43,  * from VarcharCustomAttribute where PrimaryId = 14226

   select * from CustomAttributeColumnMapping
   where CustomerId = 1 and SourceId = 4 and DisplayName like '%Rack%'


   select top 50 * from Log order by 1 desc    
   
   --  Update CustomAttributeColumnMapping set IsDuplicate = 0 where id in (2380, 2381, 1569, 1570)

   ---->  SR2809277
   ---->  Asset_EntityTabConfiguration

  ---->   need to update to the SourceType in varcharCustomAttribute
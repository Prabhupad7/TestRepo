

select * from Assets where AssetNumber= 'KLI/28108'  --------->  18265 

--Update Assets set LastUpdatedOn = GETDATE() where id = 18265

select top 1000 * from Asset_users where DisplayName like '%Rakesh%' ---->28539 Rakesh Hariram Kumar (Tied, KLI)  rakesh.-kumar@kotak.com

select top 1000 * from Asset_users where EmployeeId = 'OM116577'

--Update Asset_users set RoleId = 1 , isdeleted = 0 where id  = 28539

select top 100 * from Asset_users where Alias like '%OM116273%'

select * from Asset_Assignment where assetId = 18265   ------->  39562  'Raju Varma (Teamlease, CPC, KLI)'  kli.raju-varama@kotak.com

--update Asset_Assignment set IsActive = 0 where id = 39329

select top 100 * from Asset_Assignment order by 1 desc

select * from Asset_users where DisplayName like '%Shweta Prasad%' --->  26260

--Insert into Asset_Assignment (assetId,	assignedToId,	assignedToName,	UserRelationId,	Relationship,	createdById	, createdOn,
--updatedById	, updatedOn	, IsActive	,deleted	,TicketNumber)

-- values (18265, 28539, 'Rakesh Hariram Kumar (Tied, KLI)', 3, 'Used By', 718,GETDATE(), 718, GETDATE(), 1, 0, 0)


--Arindom Dey KA KLI Employee ID: OM36873 from SMC asset tag No. KLI05415

--Unable to remove user name - Apurba Bhagawati Tied KLI Employee ID: OM21401 from SMC asset tag No. KLI25134






select top 2 * from TAAGIC_27102020  
select top 2  * from Assets order by 1 desc

select * from AssetEntityType --->  4	Laptop

  select top 10 * from Assets order by 1 desc

  --Insert into Assets (CustomerId, SourceId, SourceTypeId, AssetName, LocationName,Model, Createdbyid, CreatedOn, LastUpdatedBy, LastUpdatedOn )

  --select 1, 4, 1, AssetTag, NewLocations, Model, 915, getdate(), 915, getdate()  from TAAGIC_27102020

  select top 213 * from Assets order by 1 desc

  select * from CustomAttributeColumnMapping where DisplayName like '%Model%' and SourceId= 4 and CustomerId=1 

  
  --Update Assets Set A.manufacturer = t.make from TAAGIC_27102020 T
  --inner join Assets A
  --on A.AssetName = T.AssetTag
  --where A.Id in (
  
  --)

  --->  RAM	Varchar10
  --->  Hard Disk	Varchar8
  --->  Asset Tag	Varchar34

  select top 10 * from VarcharCustomAttribute  where Varchar10 is not null

 --   Insert into VarcharCustomAttribute (CustomerId, SourceId, SourceType, PrimaryId, varchar10, Varchar8)
	--select 1, 4, 1, Id, '8 GB', '1 TB' from Assets where Id in ( Select top 213 Id from Assets order by 1 desc)

  select * from VarcharCustomAttribute where PrimaryId in (
  
   select top 213 Id from Assets order by 1 desc
  )



  --update VarcharCustomAttribute 
  --set Varchar34 = A.AssetName
  --from
  --Assets A 
  --inner join VarcharCustomAttribute b
  --on A.Id =b.primaryId
  --where b.PrimaryId in (
  
  
  --)

   select top 213 * from Assets order by 1 desc

   select top 3 Manufacturer , * from Assets order by 1 desc

   select  Manufacturer, * from Assets where AssetName like '%DP-17779%'
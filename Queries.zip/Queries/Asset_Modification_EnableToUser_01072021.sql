

select * from Assets where Id = 206

select * from AssetEntityType where id = 206  ---> 

--Update AssetEntityType set Name = 'Mobiles | Tablets', DisplayName = 'Mobiles | Tablets', Description ='Mobiles | Tablets' where id = 206

select * from CustomAttributeColumnMapping where CustomerId = 147 and SourceTypeId = 206

select * from CustomAttributeColumnMapping where CustomerId = 147 and SourceId = 206

select * from AssetEntityTypeCustomerMapping where CustomerId = 147 and AssetEntityTypeId = 206  ---> 235

--Update AssetEntityTypeCustomerMapping set IsDeleted = 0 where id = 235

----> To Provide any asset access to the users we need to provide AssetId and its parentId access to the User:

select * from Users where email ='YuvarajS@microland.com'  ----> 26706  YuvarajS@microland.com

select * from Asset_EntityTypeUserMapping where id = 1967 

select * from Asset_EntityTypeUserMapping 
where userId = 26706 and entityTypeId in ( 206, 38)

--Insert into Asset_EntityTypeUserMapping 

--select 26706, 206, GETDATE(), 6, 0, NULL

select instanceId,* from users where userId in (25010,26670,26669,26577,26459,26710)

select * from Admin_UserCustomerAdminMapping
where CustomerID = 220 and UserId = 26710

--Update Admin_UserCustomerAdminMapping set Deleted = 1 where UCAMID in (1525, 1531)





--select 26710,220,2,GETDATE(),6,GETDATE(),6,0

select * from Customer where customerName like '%Bunge%'  ---> 218 Bunge

select * from Device where customerId = 218 and deleted = 0


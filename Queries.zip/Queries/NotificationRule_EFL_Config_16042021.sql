
select * from Customer where customerName like '%Eureka%'   ------>  167 

select * from Service where serviceName like '%DCS%'  ---->  194,307,313,475

select * from ServiceCustomerMapping 
where customerId = 167 and serviceid in (select serviceid from Service where serviceName like '%DCS%')  ----> 196 DCS

select * from Workgroup where workgroup like '%RMC Windows%' ---->   7


select * from NotificationRules where deleted = 0 
and customerId = 167 and serviceId = 196 and ticketTypeId = 1 
and priorityId = 1 and ruleName='Assigned' and workgroupid =2





--Update NotificationRules set notificationTo = notificationTo +';rmcdcteam@microland.com;',
--notificationCC = notificationCC +';eflitservicedesk@eurekaforbes.co.in;'
--where ruleId in (
--2179813
--)


    


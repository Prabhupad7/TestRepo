


    ------>  IM2885654  IM2885660
   
    select customerid,serviceId, workgroupId,* from Ticket where ticketno = 2952077 

	----->>  SR2943388  IM2951161  SR2952077


	---->   IM2949372 customerid: 152, serviceId: 87, workgroupid: 256

	select customerid,serviceId, workgroupId,* from Ticket where ticketno =2943388   -- 80, 

	select top 100 * from FeedbackConfig 
	where ToAddr like '%Preetnh@microland.com%'

	select top 100 * from FeedbackConfig 
	where custid = 68   and ServiceId = 51 and workgroupId in(91 )



	select top 100 * from FeedbackConfig 
	where custid = 68   and ServiceId = 51 and workgroupId in(693 )



	select * from workgroup where workgroupid = 693 ----> 693	Oncall Hardware

		select * from workgroup where workgroupid = 80 ----> 693	Oncall Hardware

--	delete from FeedbackConfig where id in (841
--,842
--,843
--,844)


	select top 100 * from FeedbackConfig 
	where custid = 68   and ServiceId = 51 and workgroupId in(88 )



	select top 100 * from FeedbackConfig  
	where custid = 152  and ServiceId = 87 and CcAddr ='pawan9.kumar@heromotocorp.com'  ----> 26

	select * from Workgroup where workgroupid in (

	select distinct workgroupId from FeedbackConfig  where custid = 68 ) and deleted = 0




	select * from workgroup where workgroupid = 128


	2886192

	--	Insert into FeedbackConfig (CustId, SurveyExpiryDays, ResurveyExpiryDays, TicketTypeId, RatingImages, CommentRating,	
	--ServiceId, ToAddr, CcAddr, TemplateId, RatingForEmail, ClientLogo, FeedbackTemplate, Interval, NumberOfFeedbacks, workgroupId, Mandatorycommentrating)

	--	select CustId, SurveyExpiryDays, ResurveyExpiryDays, TicketTypeId, RatingImages, CommentRating,	
	--ServiceId, ToAddr, CcAddr, TemplateId, RatingForEmail, ClientLogo, FeedbackTemplate, Interval, NumberOfFeedbacks, 128, Mandatorycommentrating from FeedbackConfig  
	--where custid = 68  and ServiceId =51 and workgroupId =  88
	

select * from NotificationEmailTemplate where templateId in( 535,434)

custid = 68   and ServiceId = 51 and workgroupId in(88 )


--434	Highly Dissatisfied Rating Email
--535	Dissatisfied Rating Email


select * from Workgroup where workgroup like '%HM2G%'

----->  89	HM2G	HM2G

select * from Requestor where requestorEmail like '%yashika.chopra@heromotocorp.com%'

select * from Hero_Users where emailAddress like '%yashika.chopra@heromotocorp.com%'


select serviceid, * from Ticket  where ticketno = '2839981'


	select * from Workgroup where deleted =0 and workgroup like '%CIT%'

HM1D ----> 87
HM2G ----> 89
HM3H ----> 90
HP3N ----> 101
HM4N ----> 102
HM5V ----> 167
HM6C ----> 607
HMCI ----> 88
HO   ----> -- need to check 91   92
CIT  ----> 93


---------->  


	select top 100 * from FeedbackConfig  
	where custid = 68  and RatingForEmail in (3, 4) 
	and ServiceId = 51 and workgroupId =  89

		select top 100 * from FeedbackConfig  
	where custid = 68  and RatingForEmail in (3, 4) 
	and ServiceId = 51  and workgroupId =  87



	--Insert into FeedbackConfig (CustId, SurveyExpiryDays, ResurveyExpiryDays, TicketTypeId, RatingImages, CommentRating, SendNotificationByTime,	
	--ServiceId, ToAddr, CcAddr, TemplateId, RatingForEmail, ClientLogo, FeedbackTemplate, Interval, NumberOfFeedbacks, workgroupId, Mandatorycommentrating)

	--select CustId, SurveyExpiryDays, ResurveyExpiryDays, TicketTypeId, RatingImages, CommentRating,	SendNotificationByTime,
	--ServiceId, ToAddr, CcAddr, TemplateId, RatingForEmail, ClientLogo, FeedbackTemplate, Interval, NumberOfFeedbacks, 87, Mandatorycommentrating from FeedbackConfig  
	--where custid = 68  and RatingForEmail = 3 and ServiceId =51 and workgroupId =  89

	---->  SR2943388

	select customerId, serviceId, serviceName, workgroupId,* from ticket where ticketNo = 2943388

	select customerId, serviceId, serviceName, workgroupId,* from ticket where ticketNo = 2955994

	select custid ,ServiceId, workgroupId, * from FeedbackConfig  
	where custid = 68 and ServiceId =51 and workgroupId =   80   ---->  689,690,691,692

	select custid ,ServiceId, workgroupId, * from FeedbackConfig  
	where custid = 68 and ServiceId =51 and workgroupId =   88 
	
	---->  Neemrana GPC location 

	select * from Workgroup where workgroupId in (80, 88)

--SR2952077,
--IM2951161,
--SR2943388 

select * from Workgroup where workgroup like '%Tallint Tech Support%'  ---->  766	Tallint Tech Support

--usp_MIS_HR_Filter_GetWorkGroupByUser 

----->   Test tickets created by me:   SR2955994    SR2956132

select * from Service where serviceId = 51  ---->  51	End User Support


	select customerId, serviceId, serviceName, workgroupId,* from ticket where ticketNo = 2955994

	select customerId, serviceId, serviceName, workgroupId,* from ticket where ticketNo = 2956132

	select custid ,ServiceId, workgroupId, * from FeedbackConfig  
	where custid = 68 and ServiceId =51 and workgroupId =   80   ---->  689,690,691,692

	select custid ,ServiceId, workgroupId, * from FeedbackConfig  
	where custid = 68 and ServiceId =51 and workgroupId =   88 




--->  SR2928238   SR2957724   SR2957724  SR2959183

select top 10 * from Feedback where ticketNo = 2957700 ----->  


--delete from Feedback where id =251398


select * from Users where email like '%itsd.areaoffice%'  ---->  26483 

---->   itsd.areaoffice@heromotocorp.com

---->   Update users set email ='itsd.areaoffice@heromotocorp.com' where userId = 26483

--->  Ml service unix:  SR2928238

select * from Users where email like  '%PravinV@microland.com%' ----> 

--http://secure-web.cisco.com/1IHzo56ilzdX-j-gZMywnp89-mfaWzldBP89H46Av7ep7xwcvayfYWGWfgyHp6IWajC4ANd2gmajfZeMdgW1cl-SNkb8k5wURfWQKS85Yxoq7u_fr40M9udY5UNSNuLFs7rC1jA9KKWmw4EQs8CksVUgyN7DtW-K5U-9KYfuDQ0gf56XUrkXjtezpAeDWTP_UM2aShi6GnNXgoD1-33PeLpp_8gqRrK9Ka1XI6fPjxZF6oABho0YNA3pnkO-xCA0NtKBXh2X0iXFeJOsKxGghA4DMpFsUJnps38SJVBFew2PbaP1dPfcT1itlGnU14aoJ0MxUkNNiSeZvzeF7yK7EjA/http%3A%2F%2Fitservicedesk.heromotocorp.com%2FFeedbackUrl%3FstrReq%3DfAj6Z%2FDEIwY8u%2BATPkO79g%3D%3D



select * from Feedback where TicketNo = 2957724 

--delete from Feedback where TicketNo = 2957724

---->  kanhubc@microland.com - KANHUBC

--IM2949372  

select * from [dbo].[MIS_HMCL_EmailSendLocationWise]  ----->> 

select * from Workgroup where workgroup like '%General%'  ---->  628	General L&D



	--Insert into FeedbackConfig 

	--select CustId, SurveyExpiryDays, ResurveyExpiryDays, TicketTypeId, RatingImages, CommentRating,	SendNotificationByTime,
	--ServiceId, ToAddr, CcAddr, TemplateId, RatingForEmail, ClientLogo, FeedbackTemplate, Interval, NumberOfFeedbacks, 87, Mandatorycommentrating from FeedbackConfig  
	--where id in ()

---> 08092021: 

--1	Highly Satisfied
--2	Satisfied 
--3	Dissatisfied
--4	Highly Dissatisfied 

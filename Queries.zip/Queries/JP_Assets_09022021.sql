
-- just change the sourceid for different assets he asks..
-- this should be taken care till the standard report is prepared.. 

select a.AssetNumber as 'Host Name', a.SerialNumber as 'Serial Number', a.Status, v.Varchar1 as 'Workstation Number', v.Varchar31 as 'Site Name' , i.int31 as 'SiteNameId', v.varchar42 as 'Department Name', v.varchar43 'Project Name' ,  a.domain, a.domainId, a.Manufacturer, a.ManufacturerId, a.Model, a.ModelId, a.OSName as 'OS', a.OSNameId , v.Varchar26 as 'FA Number', a.LocationName, a.LocationId
from assets a inner join VarcharCustomAttribute v on v.PrimaryId = a.Id
inner join IntCustomAttribute i on i.PrimaryId = a.Id
where a.SourceId = 15 and a.CustomerId = 147 and ISNULL(a.isDeleted, 0) = 0
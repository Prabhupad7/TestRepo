



select * from users where email like '%SagarMi@microland.com%'   ----->  26755	Sagar	Mishra


select * from requestor where alias like '%rmcquality%'  ---->  59308


select * from requestor where requestoremail like '%venkataramanaiahk@microland.com%'  ---->  54539  SUv/GzSv2NSYGeW1YMGviQ==

 --Update Requestor set Password='SUv/GzSv2NSYGeW1YMGviQ==' where requestorid = 59308

 --SMCNewkhaitanandco

 select * from customer where customerName like '%SMC new kha%' ---->  202 SMC New khaitan and co

 select * from CustomerRequestorMapping where requestorId = 59308

 --Insert into CustomerRequestorMapping (requestorId, customerId, customerName, isLoginAllowed)
 --values (59308, 202, 'SMC New khaitan and co',1)

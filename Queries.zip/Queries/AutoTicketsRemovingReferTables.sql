﻿	   select * from NotificationRules where customerId in (192, 194) and priorityId = 9 and deleted = 0 

	   -- update NotificationRules set deleted =1 where ruleId In (2086506,)   -- done for 2220 rows

	   select  * from rulesforassignment where customerId in (192, 194) and deleted=0 and AssignmentRule like '%priority%'

					--	   i)	RulesForAssignment
					--ii)	AutoTicketServiceRuleDetails
					--iii)	AutoTicketServiceRule
					--iv)	AutoTicketEventLog

					select top 100 * from AutoTicketServiceRuleDetails

					select top 100 * from AutoTicketEventLog

					select distinct (D.deviceId) from Device  D
					inner join DeviceServiceMapping DS
					on D.deviceId = DS.deviceId 
					where D.customerId in (192, 194) and d.deleted = 0 and ds.deleted = 0 


					
					---- Query to disable auto ticket notifications , query to review:

					select  * from AutoTicketServiceRule where TicketTypeId = 1 and PriorityId = 9 and isDeleted = 0 and deviceId in 
					(
					select distinct (D.deviceId) from Device  D
					inner join DeviceServiceMapping DS
					on D.deviceId = DS.deviceId 
					where D.customerId in (192, 194) and d.deleted = 0 and ds.deleted = 0 
					)

					[‎8/‎21/‎2020 12:44 PM]  Mahesh K:  
                     select * from autoticketservicemailconfig 
                     SELECT * FROM AUTOTICKETSERVICERULE
                     SELECT * FROM AUTOTICKETSERVICERULEDETAILS
                     SELECT * FROM AUTOTICKETSERVICERULECOLUMN
                     SELECT * FROM APIKEYACTIONMAPPING 


     Select distinct serviceId from NotificationRules where deleted = 0 and customerId = 68 and workgroupid =  128 )

    ----   pawan9.kumar@heromotocorp.com

      Select notificationTo, notificationCC, * from NotificationRules where deleted = 0 and customerId = 68 and workgroupid =  128 and

	  notificationTo like '%budhi.prakash@heromotocorp.com%' 

	   	  select * from WorkGroupEmail  where workgroupid =  128


		 -- Update WorkGroupEmail set ToEmail='itsd.ptl@heromotocorp.com;itsd.om@heromotocorp.com;budhi.prakash@heromotocorp.com;pawan9.kumar@heromotocorp.com' where id in (665, 666, 667)

		 select * from Workgroup where workgroup like '%HM6C%' --- 607

		 select * from Hero_Locations where ADLocation like '%HM6C%'

		 select * from Hero_Locations where SLALocation like '%HM6C%' ---143

		 Select top 10 * from ServiceLevelObjective where workgroupId = 607

		 --- As discussed over the phone Chittoor location office timings from 9Am to 5:30 PM.

		 --- 26	09:00am to 05:30pm  Mon to sat	09:00am to 05:30pm  Mon to sat	India Standard Time

		 ---113	9:00am to 5:30pm Mon to Fri	9:00am to 5:30pm Mon to Fri	Pacific Standard Time



		 select * from ServiceLevelAgreement where customerId = 68 

		 select * from ServiceLevelObjective where locationId = 143 and isDelete = 0

		 select * from WorkHours where workHourId = 17

		 select * from Service where serviceId in (Select serviceId from ServiceCustomerMapping where customerId = 68)
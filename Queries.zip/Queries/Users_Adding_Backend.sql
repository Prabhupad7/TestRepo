

select * from Assets where AssetNumber ='KLI/11708' ---->  17506


select * from Asset_Assignment where assetid  = 17506


--update Asset_Assignment set IsActive = 0 , deleted = 1 where id = 39408

select * from Asset_users where id = 1754 ---  Sathyanarayana Nayak (KA, KLI)

--update Asset_Assignment set assignedToName='Sathyanarayana Nayak (KA, KLI)' where id = 7800

select * from Workgroup where workgroup like '%Autoremediation%'  ---> 640	RMC Autoremediation

select * from users where email like '%ArunR@microland.com%' ---->    47	Yashwant

select * from users where email like '%Jesty%'    ----->   24800	Jesty JestyDS@microland.com

select * from users where email like '%DhairyasheelSM%'    ----->  24798 24522	VennamA@microland.com

select * from users where email in (
'Phil.Stephenson@aveva.com',
'Rob.Browning@aveva.com',
'Prasanth.Nekkalapudi@aveva.com',
'John.Connolly@aveva.com',
'Tim.chitsiga@aveva.com'
)

--Update Users set roleId = 147 where userId in (
--26946,
--26943,
--26945,
--26944,
--26947
--)

--Update users set instanceId = 3
--where userid = 24798

select * from Users where userid in ( 24800, 24522, 24798) ---> 24798

--Update UserInstanceMapping set InstanceId = 3 where UserId = 24798

select * from UserInstanceMapping where UserId = 24798

--Update  Users set deleted =1 where userid in ( 26890, 26891)

select * from Users where userId in (24800, 24522)

select * from users where userid = 6

select * from users where email like '%SyedAl@microland.com%'    ----->  27153 

select * from customer where customerId = 220 ---> 220	Aveva

select * from CustomerAssignmentGroupMapping where customerId = 220  ---> 3015	Aveva - RMC Network

select * from UserCustomerAssignGroupMapping where userId = 47

--insert into UserCustomerAssignGroupMapping 
--select 26668, 3015, 0, 1, 1
--union all
--select 26617, 3015, 0, 1, 1
--union all
--select 26688, 3015, 0, 1, 1

  select * from Users where email like '%SyedImtiazA%'  ----> 1776

  select top 100 * from Users where email like '%Dmittar@Sonicwall.com%'  ---->26643  Desh Mittar

    select top 100 * from Users where email like '%adhablania@Sonicwall.com%'   ---> 27193	Atul

  select * from Users where userid in (1776, 26135, 27126)


  --update users set password='SUv/GzSv2NSYGeW1YMGviQ==', saltvalue=null 
  --where userid = 27126

  ----> Atul	adhablania@SonicWall.com


--Insert into Users(firstName,	lastName,	userName,	displayName	,mobileNo,	email,	loginName	, workgroupId, 
--custAssignmentGroupId,	deleted,	IsWorkgroup,	isPasswordPolicyApplicable,	lastUpdatedOn,	isAutoAssignmentEnable,	roleId	,createdById,
--updatedById,	createdOn,	updatedOn,	IsEnabled,	timezoneinfoId,	AboutMe,	instanceId,	ProfilePicture,	PasswordPolicyId,	password,SaltValue,
--primaryAssignmentGroupId,levelid	,UserTypeId,IsIntegrationUser)


--select 'Atul', '','Atul',	'Atul'	,'14082505946', 'adhablania@SonicWall.com', 'adhablania'	,'1',
--0,	0,	0,	isPasswordPolicyApplicable,	GETDATE(),	isAutoAssignmentEnable,	roleId	,createdById,
--updatedById,	GETDATE(),	GETDATE(),	IsEnabled,	timezoneinfoId,	AboutMe,	instanceId,	ProfilePicture,	PasswordPolicyId,
--'SUv/GzSv2NSYGeW1YMGviQ==', null,
--primaryAssignmentGroupId,	1	,UserTypeId,IsIntegrationUser from users where userId = 26643




select  * from Users where roleid = 147 order by 1 desc

-----> 26971,26970,26969,26968,26967 , 26972

  --insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
  --select 26972, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup
  --from UserCustomerAssignGroupMapping where userid = 26943 and deleted = 0

---->  SUv/GzSv2NSYGeW1YMGviQ==

---->  SUv/GzSv2NSYGeW1YMGviQ==

select * from users where Email like '%Vignesh%'
select * from Users where userId in (6, 1776,26135,27193)
---> 1776  27126	Surendra

select * from UserInstanceMapping where UserId in (26643,27193)

--Insert into UserInstanceMapping (UserId, InstanceId)

--select 27193, 1

select * from UserCustomerAssignGroupMapping where userid = 27193 and deleted  = 0

select top 50 * from smc_userotp 
order by 1 desc

--Insert into UserCustomerAssignGroupMapping

--select 27193, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup
--from UserCustomerAssignGroupMapping 
--where userid = 26643 and deleted  = 0



  select * from Users where email like '%MonishaO@microland.com%'  ----> 26966	Monisha  MonishaO@microland.com

  select * from Users where email like '%SanjivkumarGJ@microland.com%'  ----> 26749

  select * from Instance where id = 2   ----> 2	MLRMC	Microland RMC	1

  select * from UserCustomerAssignGroupMapping where userid = 26749 and deleted = 0
  and custAssignmentGroupId in (2874,2875,2876,2877,2878,2879,2880,2881,3044,3056,3058,3081,3082)

  --insert into UserCustomerAssignGroupMapping

  select 26135, custAssignmentGroupId, deleted, 0, AssignToWorkgroup
  from UserCustomerAssignGroupMapping where userid = 1776 and deleted = 0

  select * from CustomerAssignmentGroupMapping where custAssignmentGroupId in (2874,2875,2876,2877,2878,2879,2880,2881,3044,3056,3058,3081,3082)

  --1776  27126

  --insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)

  --select 26135, custAssignmentGroupId, deleted, 0, 0
  --from UserCustomerAssignGroupMapping where userid = 1776 and deleted = 0


    select * from UserCustomerAssignGroupMapping where userid = 26651

	---------------> Admin Access providing: 

	select * from Admin_UserCustomerAdminMapping  where UserId = 6 

	--Insert into Admin_UserCustomerAdminMapping

	--select 26126, customerid, instanceId, getDate(), 6, Getdate(),  6, deleted
	--from Admin_UserCustomerAdminMapping  where UserId = 6  

-----> SMC UAT link: https://smcuat.microland.com/Account/microland

	------>   9885415815  

	select * from CustomerAssignmentGroupMapping 
where customerId in (214,220) and deleted = 0

	select * from CustomerAssignmentGroupMapping where custAssignmentGroupId in (

    select custAssignmentGroupId from UserCustomerAssignGroupMapping where userid = 26651)


	select * from Requestor where alias ='helpdesk'


--	Update Requestor set failedLoginAttemptCount = 0 , isAccountLocked = 0 where requestorId in (
	
--	2919
--,3006
--,16890
--,16891
--,53776
--,53930)


   select * from Hero_Users

   -----> heromotocorp.com

   select * from Requestor where deleted = 0 and requestorEmail like '%heromotocorp.com%'

   select * from Users where email like '%its.areaoffice@heromotocorp.com%' ----   26483

   --Update Users set email ='its.areaoffice@heromotocorp.com' where userId = 26483


   select * from Requestor where requestorEmail like '%Ajayt%' --->   AjayT@microland.com
  -----> AjayTr@microland.com

  select * from Users where email like '%SureshR12@microland.com%' ---> 

  select * from Users where email like '%NarendraM@microland.com%' ---> 26503

  select instanceId,* from Users where email like '%SureshR12@microland.com%' --->  26779

  --Update users set instanceId = 1, password ='SUv/GzSv2NSYGeW1YMGviQ==', SaltValue = null where UserId = 26779  

  select * from UserInstanceMapping where UserId = 26779

  --Update UserInstanceMapping set InstanceId = 1 where UserId = 26779

  select url, * from Instance 

  --->  rmcops.microland.com/account/microland

  --https://rmcops.microland.com/Account/microland

  --https://rmcops.microland.com/AdminModules/GetGrid?moduleId=19

  --Smartcenter Support <smartcentersupport2@microland.com>
  -------------> 
  --update Instancepasswordchangehistory set PwdUpdatedDate = GETDATE() where Id = 1106


select * from Workgroup where workgroup like '%RMC Tools%' ----> 13	RMC Tools

select * from Workgroup where workgroup like '%RMC Coll%' ----> 7	RMC Collaboration

select * from Customer where customerName like '%Bunge%'  ----> 218	Bunge




 select * from Users where email like '%SnehalMM@microland.com%' ----> 25506	Snehal  3067

 select * from UserCustomerAssignGroupMapping where userId = 25506 and deleted = 0


  select * from Users where email in (
'AmodiniSi@microland.com'
,'SubhodeepDa1@microland.com'
,'RaviRa12@microland.com'
,'ChandrakanthL@microland.com'
,'AmodiniS@microland.com'
,'SubhodeepD@microland.com'
)

25699
26777
26469
25784
25697

select * from Customer where customerName like '%Sonic%'  ---> 219	SonicWall

select * from CustomerAssignmentGroupMapping  where customerId = 219  ---> 3006	SonicWall-RMC Sonicwall L1

select * from UserCustomerAssignGroupMapping where userid = 25697

--Insert into UserCustomerAssignGroupMapping

--select 25699, 3006, 0, 1, 1
--UNION ALL
--select 26777, 3006, 0, 1, 1
--UNION ALL
--select 26469, 3006, 0, 1, 1
--UNION ALL
--select 25784, 3006, 0, 1, 1
--UNION ALL
--select 25697, 3006, 0, 1, 1


select * from CustomerAssignmentGroupMapping where custAssignmentGroupId = 3006  ----> 869

select * from AssignmentGroup where assignmentgroupId in (869,2)  ----> RMC Sonicwall L1	734, 2	RMC Windows

select * from RulesForAssignment where customerId = 219

--Update RulesForAssignment set PrimaryAssignmentGroupId = 869, SecondaryAssignmentGroupId = 869
--where RuleId = 81896

-------------------------->

Select * from ReportMaster where reportMasterID = 152   ----> usp_StandardReport_ASKML_getAllActiveIMAndSRCombinedTicketDump_RP004

-----------> IM3049629 , IM3049680 Aveva tickets: resolved without Resolution code:



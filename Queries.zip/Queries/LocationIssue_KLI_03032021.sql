


          select LocationId, LocationName, * from Assets where AssetNumber ='KLI/23739'  -----> ID= 17717 ,   locationId = 174

		  select LocationId, LocationName, * from Assets where AssetNumber ='KLI/34290'  -----> Id = 24601,  locationId = 174

		  select LocationId, LocationName, * from Assets where AssetNumber ='KLI/28342'  -----> ID= 18312 ,   locationId = 174

		  select LocationId, LocationName, * from Assets where AssetNumber ='KLI/32693'  -----> Id = 22982,  locationId = 174

		  
          select * from Asset_relationship where sourceAssetId = 174 and deleted = 0

		  select LocationId, * from Assets where Id = 174

		  select LocationId, * from Assets where AssetName like '%BA2E%'

		  select LocationId, * from Assets where AssetName like '%KLI - Balasore%' --174

		  ---->  KLI - Balasore   BA2E

		  --Update Assets set AssetName ='KLI - Balasore' where Id = 174

		  select  varchar1,*  from VarcharCustomAttribute V where v.PrimaryId = 24601

		   select  varchar1,*  from VarcharCustomAttribute V where v.PrimaryId = 174

		  --Update VarcharCustomAttribute set varchar1 ='BA2E' where id = 174

		   select A.Id, A.AssetName, A.LocationName,k.LocationName, k.locationCode,* from Assets A 
		   inner join KLI_03122020 K 
		   on A.AssetNumber = K.AssetTag -- and A.SerialNumber = K.SerialNumber


         select  varchar1,*  from VarcharCustomAttribute V where v.PrimaryId = 174   ----->  BA1E



		  select * from CustomAttributeColumnMapping 
		  where DisplayName like '%Location%'
		  and CustomerId=1 and SourceId = 6  ------>  2	Location Code	Varchar1

           select * from CustomAttributeColumnMapping 
		  where DisplayName like '%Location%'  and CustomerId=1 and SourceId =22 --->  LocationName


		  select * from Assets where LocationId = 174 

		  --update assets set LocationName = 'KLI - Balasore' where LocationId = 174 


		     select * from CustomAttributeColumnMapping 
		  where DisplayName like '%Name%'  and CustomerId=1 and SourceId =6

		 ----> KLI/34290

	      select * from Asset_relationship where sourceAssetId = 174 and deleted = 0

 	  select LocationId, * from Assets where Id = 174

	  select  varchar1,*  from VarcharCustomAttribute V where v.PrimaryId = 174

	    select * from CustomAttributeColumnMapping 
		  where DisplayName like '%Location%'
		  and CustomerId=1 and SourceId = 6  ------>  2	Location Code	Varchar1



      select  varchar1,*  from VarcharCustomAttribute V where v.PrimaryId = 24601
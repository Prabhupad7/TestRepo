

select * from ticket t
join requestor r on r.requestorId=t.requestorId
where customerId=4 and r.requestorEmail='vishalds@microland.com'

--exec deletetickets @ticketNo = '560770 ';
--exec deletetickets @ticketNo = '1806721';   
--exec deletetickets @ticketNo = '2457051';
--exec deletetickets @ticketNo = '2622596';
--exec deletetickets @ticketNo = '2626043';
--exec deletetickets @ticketNo = '2626800';
--exec deletetickets @ticketNo = '2626994';
--exec deletetickets @ticketNo = '2627041';
--exec deletetickets @ticketNo = '2627264';
--exec deletetickets @ticketNo = '2627280';


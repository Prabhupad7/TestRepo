


select top 100 * from ITSM_DynamicAttributeConfiguration where customerid in( 3,220)

--insert into ITSM_DynamicAttributeConfiguration
--(customerid, TicketTypeid, pageid, DisplayName, isVisible, IsMandatory, IsEditable, DisplayOrder, IsDeleted)

--select 220, TicketTypeid, pageid, DisplayName, isVisible, IsMandatory, IsEditable, DisplayOrder, IsDeleted from ITSM_DynamicAttributeConfiguration where customerid = 3




select isBulkuploadEnabled,* from AssetEntityType where id in (447)

--Update AssetEntityType set isBulkuploadEnabled = 1 where  id in (447)

select IsBulkUpdate,* from CustomAttributeColumnMapping
where CustomerId = 220 and SourceId = 447 and PageId = 3


--Update CustomAttributeColumnMapping set IsBulkUpdate = 1 
--where CustomerId = 220 and SourceId = 447 and PageId = 3

select * from Asset_AutoDiscoverConfiguration 
where ToolId = 3  and CustomerId = 220 and AssetEntityId = 447

--Insert into Asset_AutoDiscoverConfiguration (	CustomerId,	AssetEntityId,	isAutoUpdate,	isVersioning	,UniqueKeys,	isDeleted	,CreatedOn,	CreatedById	,ToolId	,isDeletedRequired	,IsInsertRequired	,IsUpdateRequired)

--select 220, 447, 1, 0, 'Device Name', 0, GETDATE(), 6, 3, 0, 1,1
--UNION ALL
--select 220, 447, 1, 0, 'Primary IP Address', 0, GETDATE(), 6, 3, 0, 1,1



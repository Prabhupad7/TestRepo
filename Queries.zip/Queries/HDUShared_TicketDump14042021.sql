

---->   RP000025

select * from customer c where  c.customerId in
(3, 194, 192, 167, 169, 58, 59, 188, 158, 221, 8, 61, 189, 203, 4, 168, 210, 207, 196
, 213,  214, 215, 218, 217, 220 , 219, 147)


--LIST OF HDU SHARED CUSTOMERS:

--(167,3,4,169,168,192,215,213,188,158,221,214,58,59,8,217,196,207,61,189,203)

select distinct w.workgroupId, w.workgroup from Workgroup W
inner join AssignmentGroup A on W.workgroupId = A.workgroupId
inner join CustomerAssignmentGroupMapping C on C.assignmentgroupId = A.assignmentgroupId
where w.deleted =0 and a.deleted =0 and c.deleted =0 and c.customerId in
(3, 194, 192, 167, 169, 58, 59, 188, 158, 221, 8, 61, 189, 203, 4, 168, 210, 207, 196
, 213,  214, 215, 218, 217, 220 , 219, 147)


select * from ReportMaster where reportMasterID = 25  ---->  usp_StandardReport_getAllIM&SRCombinedSLATicketDump

--Exec [usp_StandardReport_getAllIM&SRCombinedSLATicketDump] '2021-01-01', '2021-04-14', 'createdOn', '167,3,4,169,168,192,215,213,188,158,221,214,58,59,8,217,196,207,61,189,203',
--'1,2,3,4,5,6,7,9,10,11,12,13,15,47,48,49,51,53,55,56,57,58,59,69,104,166,248,293,299,300,335,336,337,338,340,341,342,343,345,346,348,349,352,361,363,365,366,367
--,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,390,392,393,394,395,403,404,406,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425
--,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,443,491,502,504,557,586,594,608,612,616,625,640,642,643,644,645,646,647,650,651,654,655,656,657
--,684,685,688,689,690,692,695,697,698,701,702,708,709,710,711,712,713,715,716,717,718,719,720,721,722,723,724,736,737,738,739,745,763', 330


----------> SR2998072   ----> 9082108480  amodjp@microland.com
----------> Kindly add those keywords in SMC and assign them to given workgroup. 

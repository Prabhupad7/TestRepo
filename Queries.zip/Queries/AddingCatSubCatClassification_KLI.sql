

		  select * from Customer where customerId = 1

		   select * from Customer where customerName like '%APC%' ----->  93
		  select * from Service where serviceName like '%DAC%' --->  92

		  select * from Category where category like '%Smart sell  related%' -->  1009



			 Select * from ServiceCategorymapping where categoryid in  (363,420,454)

			 ---->   363	0	1
		  -- Insert into Category(category,deleted,ticketTypeId,serviceId,Isdefaultcategory,isEUPVisible,icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)

	        values('Commission',   0,1,6,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
          ('De-Commission',0,1,6,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())


		     select * from Category where category like '%Others%'   ----->  1752

			 select * from SubCategory where categoryId = 1752 ---> and subCategory like '%IMPS%' -->  4834

		     Insert into SubCategory (subCategory,categoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)
			 values
			 --('Documents Requirement', 1750, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6,GETDATE(), 6, GETDATE()),
			 --('Communication not received', 1750, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6,GETDATE(), 6, GETDATE()),
			 --('NAV Issue', 1750, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6,GETDATE(), 6, GETDATE()),
			 ('Other Query', 1752, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6,GETDATE(), 6, GETDATE()),
			 --('Other Query', 1751, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6,GETDATE(), 6, GETDATE())
			 --('Details not updated in system as per request', 1750, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6,GETDATE(), 6, GETDATE())
			 

			 ('Communication not received', 1742, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6,GETDATE(), 6, GETDATE())

			 
			 select top 1 * from SubCategory where categoryId = 1752  order by 1 desc
			 
			 --Insert into Classification (classification,subCategoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)
			 --values 
			 --('Others-Undefined', 5174, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5173, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5172, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5171, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5170, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5169, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),			 
			 --('Others-Undefined', 5168, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),		 
			 --('Others-Undefined', 5167, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5166, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5165, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5164, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5163, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5162, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5161, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5160, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5159, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),			 
			 --('Others-Undefined', 5158, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),		 
			 --('Others-Undefined', 5157, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5156, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5155, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5154, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5153, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5152, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5151, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5150, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5149, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),			 
			 --('Others-Undefined', 5148, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),		 
			 --('Others-Undefined', 5147, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5146, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5145, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE()),
			 --('Others-Undefined', 5144, 0, 0, 1, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, GETDATE())

			 select * from Priority where ticketTypeId = 1  ----> 1	P1	120

--priorityId	priority
--1	            P1
--5	            P2
--9	            P3
--15	        P5

select * from Impact ---> 7	Medium

select * from 

5171
5172
5173



			 --select 'Others-Undefined', 44398, 0, Isdefaultcategory, isEUPVisible, Icon, Icon_Color, Icon_BgColor, CreatedBy, 
			 --GETDATE(), UpdatedBy, GETDATE() from Classification where classificationId = 8453



			 --from SubCategory where subCategoryId = 4834

              --update Classification set deleted = 1 where classificationId = 8823

			  select * from Classification where subCategoryId = 4834

			 --Insert into Classification (classification,subCategoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)

			 --select 'Others-Undefined', 44398, 0, Isdefaultcategory, isEUPVisible, Icon, Icon_Color, Icon_BgColor, CreatedBy, 
			 --GETDATE(), UpdatedBy, GETDATE() from Classification where classificationId = 8453


			 select top 100 * from RulesForPriority where Deleted =0 order by 1 desc 

			 select top 1000 * from RulesForPriority where PriorityRule like '%{customerId=1;serviceId=2;categoryId=363;}%'

			 --insert into RulesForPriority (RuleDescr, PriorityRule, PriorityId, ImpactId, RulePriority, Deleted, RuleTemplateId, urgencyId)

			 --values ('Rules', '{customerId=1;serviceId=2;categoryId=363;subCategoryId=4834;ticketTypeId=1;}', 1, 7, 1, 0,967, null )

			 -- Update SubCategory set subCategory = 'Production Issue � Genie'  where subCategoryId = 3827

			 --->   7738	Production Issue � Genie

			 select * from SubCategory where categoryId = 630 and deleted = 0



			 -- Insert into SubCategory (subCategory,categoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)

			 --select 'Password reset - Policy servicing', categoryId, deleted, Isdefaultcategory, isEUPVisible, Icon, Icon_Color, Icon_BgColor, CreatedBy, 
			 --GETDATE(), UpdatedBy, GETDATE() from SubCategory where subCategoryId = 4473


-----> 

select distinct s.serviceId, s.serviceName from Service  S
inner join ServiceCustomerMapping SC on s.serviceId =  sc.serviceId
where sc.deleted = 0 and s.deleted = 0 and sc.customerId = 1


---------------------------------->



select distinct 
case scm.tickettypeid when 1 then 'Incident'  when 2 then 'Service Request' when 3 then 'Change Ticket' when 4 then 'Problem Ticket' end 'Ticket Type',
s.serviceId,s.serviceName,c.categoryId, c.category, sc.subCategoryId, sc.subcategory,cl.classificationId, cl.classification, case when scm.deleted = 0 
and c.deleted = 0 
and sc.deleted = 0 and cl.deleted = 0 and scc.deleted=0 then 'Active' else 'Inactive' end as Active 
from ServiceCategoryMapping scm
join servicecustomermapping scc on scc.serviceid= scm.serviceid
join service s on s.serviceid = scm.serviceid
join category c on scm.categoryid = c.categoryId
join subcategory sc on sc.categoryId = c.categoryId
join Classification cl on cl.subCategoryId = sc.subCategoryId
where scc.customerid=1  and c.deleted = 0 and sc.deleted = 0 and cl.deleted = 0
and scm.tickettypeid in (1, 2, 3, 4)  and s.serviceid = 2
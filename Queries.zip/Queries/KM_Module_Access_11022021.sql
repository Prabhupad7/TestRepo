

select * from users where email like '%Tim.chitsiga@aveva.com%'

--26945
--26946
--26947

--Step 1:

--insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)
--Select 26972 ,66,GETDATE(),6,0
--UNION ALL
--Select 26972 ,285,GETDATE(),6,0

Step2: 

select * from customer where customerName like '%Aveva%'


---> exec KM_ProvideKnowledgePermission  26943, 220  (UserId, customerId)


  ----->  24765  25446  1106 26096 1036

  select * from Asset_EntityTypeUserMapping where userId = 26947

  select * from Assetentitytype where id in (66, 285)

  select * from Customer where customerName like '%Aveva%'  ----> 220	Aveva

  select * from Users U 
  inner join UserCustomerAssignGroupMapping UC on u.userId = UC.userId
  inner join CustomerAssignmentGroupMapping CC on cc.custAssignmentGroupId = uc.custAssignmentGroupId
  where u.deleted = 0 and uc.deleted = 0 and cc.deleted = 0 and cc.customerId = 220


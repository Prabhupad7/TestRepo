
  --> create table ##UserEmails(Id int, Name nvarchar(max), RMName nvarchar(max), EmailID nvarchar(max), HMCLMailID nvarchar(max))

  select * from ##UserEmails

--  Insert into ##UserEmails (Id, Name, RMName, EmailID, HMCLMailID)
--  values 
--  (9931,'Sudhir Kumar Sharma','Ritesh Kumar','SUDHIRSK@microland.com','itsd.im@heromotocorp.com'),
--(13404,'Ajay Kumar Singh','Ritesh Kumar','AJAYKS@microland.com','itsd.messaging@heromotocorp.com'),
--(16361,'Muhammad  Taufik','Mahavir Negi','MUHAMMADT@microland.com','itsd.areaoffice@heromotocorp.com'),
--(16366,'Ritesh  Shukla','Ritesh Kumar','RITESHSH@microland.com','itsd.hotl@heromotocorp.com'),
--(16394,'Vinod Singh Rawat','Ritesh Kumar','VINODRS@microland.com','itsd.h@heromotocorp.com'),
--(16423,'Gaurav  Saini','Ritesh Shukla','GAURAVSAN@microland.com','itsd.hose@heromotocorp.com'),
--(16469,'Prakash Chandra Pant','Sunil Kumar','PRAKASHPC@microland.com','itsd.gac@heromotocorp.com'),
--(16494,'Rajesh  Chand','Sunil Kumar','RAJESHCH@microland.com','itsd.gsa@heromotocorp.com'),
--(16565,'Surender  Kumar','Manoj Kumar','SURENDERK@microland.com','itsd.nse@heromotocorp.com'),
--(16574,'Om Prakash Singh','Ritesh Kumar','OMSP@microland.com','itsd.messaging@heromotocorp.com'),
--(16576,'Sukhvinder  Singh','Ritesh Shukla','SUKHVINDERS@microland.com','itsd.cz@heromotocorp.com'),
--(16577,'Mukesh  Chejara','Ritesh Kumar','MUKESHC@microland.com','itsd.cittl@heromotocorp.com'),
--(16579,'Ritesh  Kumar','Anuj Gupta','RITESHKM@microland.com','itsd.om@heromotocorp.com'),
--(16580,'Vimal  Chamoli','Ritesh Kumar','VIMALC@microland.com','itsd.htl@heromotocorp.com'),
--(16581,'Preetam  Sharma','Ritesh Shukla','PREETAMS@microland.com','itsd.hoac@heromotocorp.com'),
--(16582,'Diwakar Lal Srivastava','Ritesh Kumar','DIWAKARSL@microland.com','itsd.ac@heromotocorp.com'),
--(16584,'Mahavir Singh Negi','Ritesh Shukla','MAHAVIRNS@microland.com','itsd.csdtl@heromotocorp.com'),
--(16585,'Sunil  Kumar','Ritesh Kumar','SUNILKM@microland.com','itsd.gtl@heromotocorp.com'),
--(16586,'Sanjay Pal Singh','Ritesh Kumar','SANJAYSIP@microland.com','itsd.h@heromotocorp.com'),
--(16587,'Ajitab Singh Parmar','Ritesh Kumar','AJITABPS@microland.com','itsd.h@heromotocorp.com'),
--(16588,'Manoj  Kumar','Ritesh Kumar','MANOJKR@microland.com','itsd.ntl@heromotocorp.com'),
--(16747,'Satish Kumar Suman','Ritesh Kumar','SATISHSK@microland.com','itsd.sa@heromotocorp.com'),
--(16805,'Sourav  Biswas','Ritesh Shukla','SOURAVB@microland.com','itsd.ez@heromotocorp.com'),
--(16815,'Kapil  Sharma','Mukesh Chejara','KAPILSH@microland.com','itsd.ce@heromotocorp.com'),
--(16905,'Gopikrishna  Kota','Ritesh Kumar','GOPIKRISHNAK@microland.com','itsd.cpac@heromotocorp.com'),
--(16928,'Saurabh  Kokcha','Mukesh Chejara','SAURABHKO@microland.com','itsd.ce@heromotocorp.com'),
--(16958,'Abhishek  Kumar','Ritesh Shukla','ABHISHEKKUM@microland.com','itsd.hose@heromotocorp.com'),
--(16971,'Mandeep  Rawat','Ritesh Kumar','MANDEEPR@microland.com','itsd.dsa@heromotocorp.com'),
--(16990,'Jagdish  Gola','Ritesh Kumar','JAGDISHG@microland.com','itsd.dtl@heromotocorp.com'),
--(16993,'Tariq  Habib','Mukesh Chejara','TARIQH@microland.com','itsd.citac@heromotocorp.com'),
--(17054,'Rohit  Kumar','Ritesh Kumar','ROHITKMR@microland.com','itsd.dac@heromotocorp.com'),
--(17071,'Roojvelt  Bhattacharya','Mahavir Negi','ROOJVELTB@microland.com','itsd.areaoffice@heromotocorp.com'),
--(17109,'Ashish Kumar Jain','Mukesh Chejara','ASHISHJK@microland.com','itsd.ce@heromotocorp.com'),
--(17385,'Rajat  Bajaj','Anuj Gupta','RAJATB@microland.com','itsd.pm@heromotocorp.com'),
--(18044,'Prasanta  Swain','Rajat Bajaj','PRASANTAS@microland.com','itsd.ctl@heromotocorp.com'),
--(18178,'Chandramohan Singh Negi','Ritesh Kumar','CHANDRAMOHANNS@microland.com','itsd.cns@heromotocorp.com'),
--(18357,'Pulkit Kumar Pant','Ritesh Kumar','PULKITPK@microland.com','itsd.hac@heromotocorp.com'),
--(20075,'Jaiminkumar Mafatbhai Patel','Ritesh Kumar','JAIMINKUMARPM@microland.com','itsd.vtl@heromotocorp.com'),
--(20194,'Hoshiyar  Singh','Ritesh Kumar','HOSHIYARS@microland.com','itsd.sa@heromotocorp.com'),
--(20613,'Shankar Kumar Jha','Ritesh Kumar','SHANKARJK@microland.com','itsd.ns@heromotocorp.com/itsd.soc@heromotocorp.com'),
--(20683,'Pawan Kumar Sah','Ritesh Kumar','PAWANSAK@microland.com','itsd.messaging@heromotocorp.com'),
--(20684,'Dan Singh Dhami','Ritesh Kumar','DANDS@microland.com','itsd.ns@heromotocorp.com/itsd.soc@heromotocorp.com'),
--(20698,'Manoj  Padiyar','Ritesh Kumar','MANOJPA@microland.com','itsd.sa@heromotocorp.com'),
--(20728,'Rohit Kumar Sharma','Ritesh Kumar','ROHITSHK1@microland.com','itsd.ns@heromotocorp.com/itsd.soc@heromotocorp.com'),
--(20734,'Arvind  Kumar','Ritesh Kumar','ARVINDKU@microland.com','itsd.messaging@heromotocorp.com'),
--(20786,'Anand  Deo','Ritesh Kumar','ANANDD@microland.com','itsd.ns@heromotocorp.com/itsd.soc@heromotocorp.com'),
--(20817,'Santosh  Kumar','Ritesh Kumar','SANTOSHKU@microland.com','itsd.ns@heromotocorp.com/itsd.soc@heromotocorp.com'),
--(20867,'Arshad  Aslam','Ritesh Kumar','ARSHADAS@microland.com','itsd.cns@heromotocorp.com'),
--(20967,'Sandeep Kumar Soni','Ritesh Shukla','SANDEEPSOK@microland.com','itsd.i@heromotocorp.com'),
--(21016,'Chittaranjan  Rout','Ritesh Kumar','CHITTARANJANR@microland.com','itsd.cns@heromotocorp.com'),
--(21023,'Piyush  Agarwal','Ritesh Kumar','PIYUSHA@microland.com','itsd.cns@heromotocorp.com'),
--(21264,'Daya Parkash Saini','Ritesh Kumar','DAYASP@microland.com','itsd.tsw@heromotocorp.com'),
--(21271,'Sagar Laxmanaraoji Baigane','Ritesh Kumar','SAGARBL@microland.com','itsd.cns@heromotocorp.com'),
--(22097,'Harman  Singh','Ritesh Kumar','HARMANS@microland.com','itsd.ns@heromotocorp.com/itsd.soc@heromotocorp.com'),
--(900594,'Durgesh Kumar Rai','Mahavir Negi','DURGESHRK@microland.com','it.servicedesk@heromotocorp.com'),
--(900632,'Sunil  Pandey','Sunil Kumar','SUNILPA@microland.com','itsd.gse@heromotocorp.com'),
--(900694,'Priya  Vij','Mahavir Negi','PRIYAV@microland.com','it.servicedesk@heromotocorp.com'),
--(900704,'Mohit  Saini','Ritesh Shukla','MOHITSA1@microland.com','itsd.hoe@heromotocorp.com'),
--(900768,'Gunjan Kumar Shrivastava','Ritesh Kumar','GUNJANSK@microland.com','itsd.d@heromotocorp.com'),
--(900858,'Anand  Arumugam','Ritesh Shukla','ANANDAR1@microland.com','itsd.cp@heromotocorp.com'),
--(900909,'Jitendra  Singh','Ritesh Kumar','JITENDRASI1@microland.com','itsd.dse@heromotocorp.com'),
--(900949,'Mohd.  Mustak','Mukesh Chejara','MOHDMU@microland.com','itsd.ce@heromotocorp.com'),
--(900984,'Anmol  Tikoo','Mahavir Negi','ANMOLT@microland.com','it.servicedesk@heromotocorp.com'),
--(900989,'Hari Gautam  Singh','Sunil Kumar','HARISG@microland.com','itsd.gse@heromotocorp.com'),
--(901018,'Neha  Singh','Mahavir Negi','NEHASI@microland.com','it.servicedesk@heromotocorp.com'),
--(901084,'Khemendra  Saini','Manoj Kumar','KHEMENDRAS@microland.com','itsd.nac@heromotocorp.com'),
--(901143,'Pramod  Kumar','Sunil Kumar','PRAMODK@microland.com','itsd.g@heromotocorp.com'),
--(901177,'Junaid  Khan','Ritesh Kumar','JUNAIDK@microland.com','itsd.gpcac@heromotocorp.com'),
--(901265,'N V S Pradeep Kumar','Ritesh Shukla','NSV@microland.com','itsd.sz@heromotocorp.com'),
--(901444,'Manjeet  Kumar','Ritesh Kumar','MANJEETKU1@microland.com','itsd.gpc@heromotocorp.com'),
--(901448,'Rahul  Soni','Ritesh Kumar','RAHULSO1@microland.com','itsd.nse@heromotocorp.com'),
--(901524,'Sangita  Rani','Mahavir Negi','SANGITAR@microland.com','it.servicedesk@heromotocorp.com'),
--(901918,'Pankaj  Kumar','Sunil Kumar','PANKAJKU12345@microland.com','itsd.gna@heromotocorp.com'),
--(901926,'Bantu  Kumar','Ritesh Kumar','BANTUKU@microland.com','itsd.vac@heromotocorp.com'),
--(901973,'Sachin Kumar Srivastava','Ritesh Kumar','SACHINSK@microland.com','itsd.sa@heromotocorp.com'),
--(901982,'Girvar  Dayal','Ritesh Kumar','GIRVARD@microland.com','itsd.gpc@heromotocorp.com'),
--(901997,'Mukesh Kumar Yadav','Sunil Kumar','MUKESHYK@microland.com','itsd.g@heromotocorp.com'),
--(902057,'Navneet  Sharma','Ritesh Kumar','NAVNEETSH@microland.com','itsd.n@heromotocorp.com'),
--(902060,'Bobby  Rana','Sunil Kumar','BOBBYR@microland.com','itsd.g@heromotocorp.com'),
--(902062,'Qasim  Husain','Mahavir Negi','QASIMH@microland.com','itsd.i@heromotocorp.com'),
--(902071,'Patel Kumar Bhaveshkumar','Ritesh Kumar','PATELBK@microland.com','itsd.v@heromotocorp.com'),
--(902073,'Anand Prakash Verma','Ritesh Shukla','ANANDVP@microland.com','itsd.nz@heromotocorp.com'),
--(902124,'Kishorsinh Gohil','Ritesh Kumar','kishorsinhga@microland.com','itsd.v@heromotocorp.com'),
--(90120723,'Pawan kumar Saxena ','Manoj kumar','PAWANSAK1@microland.com','itsd.n@heromotocorp.com')


   select u.userId, u.userName,u.loginName,UE.HMCLMailID, u.email from Users U 
   inner join   ##UserEmails UE
   on U.email =UE.HMCLMailID
   where u.deleted = 0


    
   --update Users set email = UE.HMCLMailID	from Users U 
   --inner join   ##UserEmails UE
   --on U.email =UE.EmailID
   --where u.deleted = 0 and u.

   ---->  25439, 25444, 25445, 25462, 25463

   select * from  users where userId in (25439, 25444, 25445, 25462, 25463)
   
   --update users set email = 'itsd.ns@heromotocorp.com' where userId in (25439, 25444, 25445, 25462, 25463)

   select * from Users where 
   userId in (
   656
,754
,25075
,25462
,26357
,25257
,25461
,1067
,26180
,26338
,26064
,25659
,25444
,25781
,703
,649
,25888
,939
,25161
,25247
,25233
,1039
,25202
,25424
,929
,25333
,26499
,753
,1048
,25672
,758
,25441
,25225
,24942
,636
,697
,26334
,25271
,25525
,747
,26113
,26359
,25438
,26487
,25658
,646
,1051
,1711
,720
,24931
,1806
,26335
,26196
,26313
,676
,755
,665
,1805
,25445
,1047
,26234
,25782
,26292
,25694
,749
,25463
,844
,994
,25439
,900
,759
,692
,751
,24812
,993
,756
,625
   )



   select * from Workgroup where workgroup like '%SOC%' 

    select * from Workgroup where workgroupId = 154

   select workgroupid, * from ticket where ticketno = 2726265

   select * from customer where customerId =68

   select * from NotificationRules where deleted=0 and customerId = 68 and workgroupid in (75, 104,155 )


   --------->

   select * from customer where customerName  like '%Kotak%' --->  163


   select * from Ticket where customerId = 163 and createdOn between '2020-10-22 00:00:00' and '2020-10-23 23:59:00'

   select * from NotificationRules where ruleId in (
     select ruleId from Ticket where customerId = 163 and createdOn between '2020-10-22 00:00:00' and '2020-10-23 23:59:00'
   )
﻿
-- Unable to Open the ticket: 

 Vignesh Annadurai:  
select workgroupId,serviceId,categoryId,priorityId ,* from ticket where ticketNo  =69382  --9

--update ticket set workgroupId = 8 where ticketNo  =69382

Select * from RulesForAssignment where customerId = 1 and AssignmentRule like '%serviceid=18%'

--insert into RulesForAssignment(RuleDescr,AssignmentRule,PrimaryAssignmentGroupId,SecondaryAssignmentGroupId,RulePriority,Deleted,RuleTemplateId,customerId,AssignmentType,AssignToId,NoOfParams)

--select 'KGI Rule','{customerId=1;priorityId=9;serviceId=18;}',7,7,1,0,79,1,1,0,3

Select * from AssignmentGroup where assignmentgroupId = 7 --8 
 






-- fOR CUSTOMER ID =207

  select * from ReasonForResponseBreach where customerid = 207 and isdeleted = 0 --233,236

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (233, 236)

  select * from SLAExceptionCode where customerId = 207 and deleted = 0  -- 2528,2535

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2528,2535) 

  update SLAExceptionCode set deleted = 0 where slaExceptionCodeId in(2516
,2517
,2518
,2519
,2520
,2521
,2522)


  -- FOR CUSTOMERID = 168   Actifio-Apotex

  select * from ReasonForResponseBreach where customerid = 168 and isdeleted = 0 --240,244

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (240,244)

  select * from SLAExceptionCode where customerId = 168 and deleted = 0  -- 2543,2550

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2543,2550) 


    --FOR CUSTOMERID = 61  (BOSCH)

  select * from ReasonForResponseBreach where customerid = 61 and isdeleted = 0 --248,252

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (248,252)

  select * from SLAExceptionCode where customerId = 61 and deleted = 0  -- 2558,2565

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2558,2565) 




      --FOR CUSTOMERID = 189 (BOSCH DCS)

  select * from ReasonForResponseBreach where customerid = 189 and isdeleted = 0 --256,260

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (256,260)

  select * from SLAExceptionCode where customerId = 189 and deleted = 0 and ticketTypeId = 2 -- 2573,2580

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2573,2580) 


  
-- FOR CUSTOMERID = 203 (BOSCH Scottsdale)

  select * from ReasonForResponseBreach where customerid = 203 and isdeleted = 0 --264,268

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (264,268)

  select * from SLAExceptionCode where customerId = 203 and deleted = 0  -- 2588,2595

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2588,2595) 



  -- FOR CUSTOMERID = 169 (Comviva)

  select * from ReasonForResponseBreach where customerid = 169 and isdeleted = 0 --272,276

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (272,276)

  select * from SLAExceptionCode where customerId = 169 and deleted = 0  -- 2603,2610

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2603,2610) 


  
-- FOR CUSTOMERID = 158 (Enzen-NGN)

  select * from ReasonForResponseBreach where customerid = 158 and isdeleted = 0 --280,284

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (280,284)

  select * from SLAExceptionCode where customerId = 158 and deleted = 0  -- 2618,2625

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2618,2625) 


  -- FOR CUSTOMERID = 8 (FGIC)

  select * from ReasonForResponseBreach where customerid = 8 and isdeleted = 0 --288,292

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (288,292)

  select * from SLAExceptionCode where customerId = 8 and deleted = 0  -- 2633,2640

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2633,2640) 


    -- FOR CUSTOMERID = 188 (Innocent Drinks)

  select * from ReasonForResponseBreach where customerid = 188 and isdeleted = 0 --(296,300)

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (296,300)

  select * from SLAExceptionCode where customerId = 188 and deleted = 0  -- 2648,2655

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2648,2655) 


      --FOR CUSTOMERID = 192 (Jubilant Life Sciences)

  select * from ReasonForResponseBreach where customerid = 192 and isdeleted = 0 --(304,308)

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (304,308)

  select * from SLAExceptionCode where customerId = 192 and deleted = 0  -- (2663,2670)

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2663,2670) 



        --FOR CUSTOMERID = 194 (Jubilant Pharma)

  select * from ReasonForResponseBreach where customerid = 194 and isdeleted = 0 --(312,316)

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (312,316)

  select * from SLAExceptionCode where customerId = 194 and deleted = 0  -- (2678,2685)

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2678,2685)


          -- FOR CUSTOMERID = 3 (MLCIS)

  select * from ReasonForResponseBreach where customerid = 3 and isdeleted = 0 --(320,324)

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (320,324)

  select * from SLAExceptionCode where customerId = 3 and deleted = 0  -- (2693,2700)

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2693,2700)


            -- FOR CUSTOMERID = 4 (MLRMC)

  select * from ReasonForResponseBreach where customerid = 4 and isdeleted = 0 --(328,332)

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (328,332)

  select * from SLAExceptionCode where customerId = 4 and deleted = 0  -- (2708,2715)

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2708,2715)



              -- FOR CUSTOMERID = 58 (SAP GD)

  select * from ReasonForResponseBreach where customerid = 58 and isdeleted = 0 --(336,340)

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (336,340)

  select * from SLAExceptionCode where customerId = 58 and deleted = 0  -- (2723,2730)

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2723,2730)




                -- FOR CUSTOMERID = 161 (Ownership)

  select * from ReasonForResponseBreach where customerid = 161 and isdeleted = 0 --(344,348)

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (344,348)

  select * from SLAExceptionCode where customerId = 161 and deleted = 0  -- (2738,2745)

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2738,2745)


  
-- FOR CUSTOMERID = 196 (Oreta-MMSG VOIP)

  select * from ReasonForResponseBreach where customerid = 196 and isdeleted = 0 --(360,364)

  UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (360,364)

  select * from SLAExceptionCode where customerId = 196 and deleted = 0  -- (2753,2760)

  update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2753,2760)



  ---- FOR CUSTOMERID = 196 (Oreta-MMSG VOIP)

  --select * from ReasonForResponseBreach where customerid = 196 and isdeleted = 0 --(360,364)

  --UPDATE ReasonForResponseBreach SET ReasonForResponseBreachName = 'Breach Reason Undetermined by Engineer' WHERE ID IN (360,364)

  --select * from SLAExceptionCode where customerId = 196 and deleted = 0  -- (2753,2760)

  --update SLAExceptionCode set slaExceptionCode  = 'Breach Reason Undetermined by Engineer' where slaexceptioncodeid in (2753,2760)


  Icici Bank : city std code 33337777



  SR2568709	
SR2569653	
SR2569668	
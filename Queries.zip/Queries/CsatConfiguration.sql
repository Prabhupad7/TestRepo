


select t.statusName, * from ticket t
join requestor r on r.requestorId=t.requestorId
where customerId=4 and r.requestorEmail='vishalds@microland.com'

  

select * from customer where customerId = 182 







select * from NotificationEmailTemplate where customerId = 182 --962

select * from NotificationRules where customerId = 182 and deleted = 0 and duePercent is null and templateId = 962

select distinct(serviceId) from ServiceCustomerMapping where customerId = 182  and deleted = 0 

select * from NotifyBasedOn

select * from TicketStatus Call with Venkataramanaiah Katabathina (venkataramanaiahk@microland.com) has ended. 25 minutes   


select * from customer where customerId = 150 

select * from NotificationEmailTemplate where customerId = 150 --962

select * from NotificationRules where customerId = 150 and deleted = 0 and duePercent is null -- and templateId = 962

select distinct(serviceId) from ServiceCustomerMapping where customerId = 150  and deleted = 0 



150
151
152
153
154
155
156
157 
take from customerid 150


     SELECT * FROM CUSTOMER WHERE customerId IN (               150
,151
,152
,153
,154
,155
,156
,157 )
    
 



                  select * from customer where customerid = 150

				  select * from NotificationEmailTemplate where customerId = 150

				  select * from NotificationRules where customerId = 150 and deleted = 0 and duePercent is null and  templateId = 527


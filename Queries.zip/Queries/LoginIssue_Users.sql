
      select * from Users where  email like '%SudhirA%'  ---- 26356	Sudhir	Arora	NULL	Sudhir Arora	1234	SudhirA@microland.com	SudhirA
	  
		select * from Users where loginName like '%SunilS1%' --->  23891

      select * from UserInstanceMapping where UserId = 26356

	   select * from UserInstanceMapping where UserId = 23891

    -- update Users set password = 'SUv/GzSv2NSYGeW1YMGviQ==', SaltValue =null where userId = 26356


Microland -URL: https://rmcops.microland.com/Account/microland   ---->  using Db password, ResetPassword option will be there
Microland RMC -URL: https://rmcops.microland.com/Account/mlrmc   ----> Ad password, there is no ResetPassword option.
JubilantPharma -URL: https://jpi.jolcorp.info/Account/JublPharma

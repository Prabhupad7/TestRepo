

select * from Device where deviceName like '%blrecoprdmw102%' ---> 3310	blrecoprdmw102

select deleted,customerId, * from Device where customerId = 194
and  deviceName like '%TRIADWEBSERVICE%' ---> 39582

select * from DeviceServiceMapping where deviceId  = 39576

select top 100 * from RulesForAutomationRemedial
where assignmentrule like '%3310%'order by CreatedOn desc  ---> 4400

select top 100 * from RulesForAutomationRemedial
where assignmentrule like '%39576%'order by CreatedOn desc 

select top 13 * from RulesForAutomationRemedial order by 1 desc


--Insert into RulesForAutomationRemedial 
--values 
--('Remedial', 3, 'customerid=3;description like Packet Loss has entered Critical state;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like Util In has entered Critical state;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like Util Out has entered Critical state;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like System Uptime has entered Critical state;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like CPU Utilization has entered Critical state;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like packet loss for unix has entered critical state;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like Packet Loss has entered Critical state;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like disk utilization for unix is above threshold;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like Service;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like Physical Memory Used has entered Critical state;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like Physical Memory Usage has entered Critical state;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like Overall CPU Load has entered Critical state;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL),
--('Remedial', 3, 'customerid=3;description like Space Util;ticketTypeId=1;deviceId=5266;', 'contains', '771', 1, 5266, 4, 1, NULL, NULL, 6, GETDATE(), NULL, NULL, 0, NULL, NULL)

--Update RulesForAutomationRemedial set ApiJson = (select ApiJson from RulesForAutomationRemedial where RuleId = 4559)
--where RuleId in (
--4703,
--4702,
--4701,
--4700,
--4699,
--4698,
--4697,
--4696,
--4695,
--4694,
--4693,
--4692,
--4691)
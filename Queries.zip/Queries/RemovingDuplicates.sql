


select * from SLAExceptionCode where customerId = 207 and deleted = 0  -- 2528,2535

 update SLAExceptionCode set deleted = 1 where slaExceptionCodeId in(2516
,2517
,2518
,2519
,2520
,2521
,2522)

  select * from SLAExceptionCode where customerId = 189 and deleted = 0 and ticketTypeId =1 


   update SLAExceptionCode set deleted = 1 where slaExceptionCodeId in(1812
,1813
,1814
,1815
,1816
,1817
,1818
,1819
,1820
,1821
,2386
,2388
,2390
,2392
,2394)



    select * from SLAExceptionCode where customerId = 189 and deleted = 0 and ticketTypeId = 2



	   update SLAExceptionCode set deleted = 1 where slaExceptionCodeId in(1803
,1804
,1805
,1806
,1807
,1808
,1809
,1810
,1811
,1822
,2387
,2389
,2391
,2393
,2395)


 --  select * from ReasonForResponseBreach where customerid = 169 and isdeleted = 0 
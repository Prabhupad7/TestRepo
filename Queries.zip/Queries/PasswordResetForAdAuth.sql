



	select * from Users where email like '%nikhildab%'   --- 26328  , 2

	select * from Instance 

	select * from AuthenticationType  


	select * from UserInstanceMapping where UserId = 26328


 -- 	update Users set password = 'SUv/GzSv2NSYGeW1YMGviQ==' , SaltValue = null where userId = 26328

  --	update Instancepasswordchangehistory set PwdUpdatedDate = GETDATE() where Id = 26328
     
	 select * from Instancepasswordchangehistory where id =26328

	--- Need to send details in Text message
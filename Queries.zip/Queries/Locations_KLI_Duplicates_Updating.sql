

   select a.id, a.AssetName, a.AssetNumber, a.LocationId, a.LocationName, v.Varchar3,v.Varchar1 from Assets a
inner join VarcharCustomAttribute v on v.PrimaryId = a.Id
where AssetName like '%KLI - Pune 1 - Sohrab Hall%'  

--->  111

	select a.id, a.AssetName, a.AssetNumber, a.LocationId, a.LocationName,v.Varchar1, v.Varchar3,v.PrimaryId from Assets a
	inner join VarcharCustomAttribute v on v.PrimaryId = a.Id
	where LocationName like  '%KLI - Pune 1 - Sohrab Hall%'  and v.Varchar3 = 'BLDS'

		select a.id, a.AssetName, a.AssetNumber, a.LocationId, a.LocationName,v.Varchar1, v.Varchar3,v.PrimaryId from Assets a
	inner join VarcharCustomAttribute v on v.PrimaryId = a.Id
	where  v.Varchar3 like  '%K-65 Sec 18%'

		select distinct v.Varchar3 from Assets a
	inner join VarcharCustomAttribute v on v.PrimaryId = a.Id
	where LocationName = 'KLI - Kolkata 5- India House'

	--Update VarcharCustomAttribute set Varchar3 = 'HU1S' where PrimaryId in (
 --    7129
	--) 


select a.id, a.AssetName, a.AssetNumber, a.LocationId, a.LocationName, v.Varchar3,v.Varchar1 from Assets a
inner join VarcharCustomAttribute v on v.PrimaryId = a.Id
where a.SourceId = 6 and a.AssetName = 'KLI - Bangalore 3 - Indira Nagar'



--  update VarcharCustomAttribute set Varchar3 = 'BL3S' where PrimaryId in(10666,15579,25675)

--  update VarcharCustomAttribute set Varchar3 = 'BL4S' where PrimaryId in(7333,20712)



	select * from device wherr 

	-----> Mapping the correct Location to the State.
  
select * from assets where LocationName like '%KLI - Pune 1 - Sohrab Hall%' 

select * from assets where AssetName  like '%KLI - Pune 1 - Sohrab Hall%' 

select * from CustomAttributeColumnMapping where DisplayName like '%Location Value%' 

select * from VarcharCustomAttribute where PrimaryId in (
4192
,4193
,4195
,4196
)


 select * from Assets where id = 169





select * from assets where AssetName like '%KLI - Noida-1 - K-64, K-65 Sec 18%' --149



select * from assets where Id = 25

--update Asset_relationship set sourceAssetId = 25 where relatedAssetId = 57

select * from Asset_relationship where relatedAssetId = 236

insert into Asset_relationship(sourceAssetId,sourceAssetTypeId,relatedAssetId,relatedAssetTypeId,relationId,IsEnableForMap,createdBy,createdOn,deleted)
select 16,6,25737,6,1,1,6,GETDATE(),0

select * from Assets where AssetName = 'KLI - Bangalore 1 -Residency Road' --25737

select LocationName, locationid, * from Assets where id = 17352

select * from VarcharCustomAttribute where PrimaryId = 17352

select * from VarcharCustomAttribute  where varchar7 = 'KLI - Bangalore 6 - Cears Plaza'

  ----->  update VarcharCustomAttribute set Varchar7= 'KLI - Bangalore 1 -Residency Road' where PrimaryId = 17352

  select top 100 * from CustomAttributeColumnMapping where AttributeName like '%varchar7%' 

  select * from Assets where id = 122 --->  KLI - Bangalore 6 - Cears Plaza


   select top 10 * from Asset_relationship where relatedAssetId = 8556 ---> SourceAssetId -- 122

   -- 117  17352

  -- update Asset_relationship set SourceAssetId = 117 where relatedAssetId = 17352 

    -- update Assets set LocationId = 117 where id = 17352 

     select LocationName, LocationId, * from Assets where AssetNumber = 'KLI/07610' --->  16294  122

	 select * from Assets where AssetName like '%KLI - Bangalore 1 -Residency Road%' --->  117
	 
	 select varchar7,* from VarcharCustomAttribute where PrimaryId = 8556

	 -->  update Assets set LocationId = 117 where id = 16294


    select A.Id, A.LocationName, A.LocationId from Assets A
	inner join KLI_03122020 K
	on A.AssetNumber = K.AssetTag


	    select distinct LocationName from KLI_03122020

		select * from KLI_03122020

		select * from Assets where LocationName like '%KLI - Noida-1 - K-64, K-65 Sec 18%'

		sel

		
		select * from Assets where AssetName like '%KLI - Noida-1 - K-64, K-65 Sec 18%'

		select * from Assets where AssetName in (
			'KLI - Ahmedabad 2 - Shivaranjini'
			,'KLI - Bangalore 1 -Residency Road'
			,'KLI - Mumbai - Kotak Infinity - HO'
			,'KLI - Mumbai 18 - Thane 3'
		)


	   --Update A  set A.LocationId= k.LocationId
	   --from KLI_03122020 K
	   --inner join Assets A 
	   --on A.AssetNumber = K.AssetTag 
	   --where A.id in (select Assetid from KLI_03122020)

	   --->  SR2773841   SR2774264

	  --exec deletetickets @ticketNo = '2773841';
	  --exec deletetickets @ticketNo = '2774264';

    select * from KLI_03122020 where AssetTag in (
 'KLI/21576'
,'KLI/30950'
,'KLI/32058'
,'KLI/32061') 

15702
21074
22207
22210

 select * from VarcharCustomAttribute where PrimaryId in (
 15702
,21074
,22207
,22210
 )

    Update VarcharCustomAttribute set Varchar3 = 'AH2G' where PrimaryId in (
 15702
,21074
,22207
,22210
 )

   update Assets set LocationName ='KLI - Ahmedabad 2 - Shivaranjini' where id in (
 15702
,21074
,22207
,22210
 )

 select * from Assets where id in (
 15702
,21074
,22207
,22210
 )

 --->  65


   select * from Assets where id =65

   --->  KLI - Ahmedabad 2 - Shivaranjini
         KLI - Ahmedabad 2 - Shivaranjini       
		 



		 select * from Assets where AssetName like '%KLI - Noida-1 - K-64%' ---> 236

		 -- update Assets set AssetName ='KLI - Noida-1 - K-64 K-65 Sec 18' where id = 236

		 ---->  KLI - Noida-1 - K-64, K-65 Sec 18

		  select * from Assets where isDeleted =0 and LocationId =236

		  select * from Assets where LocationName like '%KLI - Noida-1 - K-64%' ---> 236

		  -- Update Assets set LocationName ='KLI - Noida-1 - K-64 K-65 Sec 18'

		  --where id in (
		  
		  --)

		  --->  KLI - Noida-1 - K-64, K-65 Sec 18

		  	
		  
		    

	     --exec deletetickets @ticketNo = '2773841';
		 --exec deletetickets @ticketNo = '2774264';


	--Insert into VarcharCustomAttribute (CustomerId, SourceId, SourceType, PrimaryId, Varchar2, Varchar4, Varchar5, Varchar6, Varchar7, varchar8, 
	--Varchar9, Varchar10, Varchar11, Varchar12, Varchar13, Varchar14, Varchar15)

	--select '1', '68', '1', AssetId,  ApplicationSPOC, Environment,	WebserverIP,	WebserverHostname,	WebOSVersion,	WebMiddlewareVersion,	WebServicesInstalledonpath,
	--AppserverIP,	AppserverHostname,	AppOSVersion,	AppMiddlewareVersion,	AppServicesInstalledonpath,	Remarks
 --   from TA_18122020 


 --exec deletetickets @ticketNo = '2787414';



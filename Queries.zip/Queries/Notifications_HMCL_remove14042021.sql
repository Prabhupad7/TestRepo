

--->   sujoy.b@heromotocorp.com

--Need to Remove : atul.tyagi@heromotocorp.com sujoy.b@heromotocorp.com
--Need to be add : harish.bawari@heromotocorp.com

select * from Customer where customerName like '%Hero%' ---->  68	Hero MotoCorp Ltd

select * from NotificationRules where customerId = 68 and deleted =0 and duePercent in (100, 125)
and notificationto like '%atul.tyagi@heromotocorp.com%'

select * from NotificationRules where customerId = 68 and deleted =0 --and duePercent in (100, 125)
and notificationto like '%sujoy.b%'

select * from NotificationRules where customerId = 68 and deleted =0 --and duePercent in (100, 125)
and notificationCC like '%sujoy.b%'

---->  SR2946603 

select * from NotificationRegistry where sourceId = 2946603 

select * from NotificationRules where ruleId in (
1408647
,1407279)

select * from NotificationHistory where TicketNo =  2946603

select * from Workgroup where workgroupId = 126  ---> 

select * from NotificationRules where customerId = 68 and deleted =0 and duePercent in (100, 125)
and notificationto like '%harish.bawari@heromotocorp.com%'
---- and notificationCC like '%sujoy.b@heromotocorp.com%'

---->  harish.bawari@heromotocorp.com


--Update NotificationRules set notificationTo = REPLACE (notificationTo, ';;', ';')
--where customerId = 68 and deleted =0 and duePercent in (100, 125)
--and notificationto like '%atul.tyagi@heromotocorp.com%'

select * from NotificationRules where customerId = 68 and deleted =0 -- and duePercent in (100, 125)
 and notificationCC like '%sujoy.b@heromotocorp.com%'

 ---->  SR2946603

select * from WorkGroupEmail  ---->  $workgroupToMLEmail125Percent

select * from WorkGroupEmail where ToEmail like '%sujoy.b@heromotocorp.com%'
select * from WorkGroupEmail where ToEmail like '%atul.tyagi@heromotocorp.com%'

select * from WorkGroupEmail where id in (
291
,296
,301
,306
,311
,321
,324
,327
,330
,333
,336
,339
,340
,342
,345
,348
,351
,354
,357
,360
,363
,366
,369
,372
,375
,378
,381
,384
,387
,390
,393
,396
,399
,400
,401
,402
,403
,404
,405
,409
,410
,415
,420
,425
,430
,435
,440
,457
,458
,460
,461
,463
,464
,466
,467
,469
,470
,472
,473
,476
,484
,485
,489
,490
,492
,493
,590
,615
,616
,619
,620
,628
,629
,633
,634
,638
,639
,643
,644
,648
,649
,653
,654
,658
,659
,661
,662
,663
,664
,678
,679
,687
,690
,691
,694
,695
,698
,699
,702
,703
,707
,711
,714
,715
,718
,719
,722
,723
,727
,731
,735
,739
,743
,747
,751
,754
,755
,758
,759
,763
,767
,771
,774
,775
,778
,779
,783
,786
,787
,791
,794
,795
,799
,803
,807
,810
,811
,815
)

--Update WorkGroupEmail set ToEmail = Replace(ToEmail, ';;', ';') where id in (
--291
--,296
--,301
--,306
--,311
--,321
--,324
--,327
--,330
--,333
--,336
--,339
--,340
--,342
--,345
--,348
--,351
--,354
--,357
--,360
--,363
--,366
--,369
--,372
--,375
--,378
--,381
--,384
--,387
--,390
--,393
--,396
--,399
--,400
--,401
--,402
--,403
--,404
--,405
--,409
--,410
--,415
--,420
--,425
--,430
--,435
--,440
--,457
--,458
--,460
--,461
--,463
--,464
--,466
--,467
--,469
--,470
--,472
--,473
--,476
--,484
--,485
--,489
--,490
--,492
--,493
--,590
--,615
--,616
--,619
--,620
--,628
--,629
--,633
--,634
--,638
--,639
--,643
--,644
--,648
--,649
--,653
--,654
--,658
--,659
--,661
--,662
--,663
--,664
--,678
--,679
--,687
--,690
--,691
--,694
--,695
--,698
--,699
--,702
--,703
--,707
--,711
--,714
--,715
--,718
--,719
--,722
--,723
--,727
--,731
--,735
--,739
--,743
--,747
--,751
--,754
--,755
--,758
--,759
--,763
--,767
--,771
--,774
--,775
--,778
--,779
--,783
--,786
--,787
--,791
--,794
--,795
--,799
--,803
--,807
--,810
--,811
--,815
--)

select * from Asset_users where EmailId  like '%SBa1@microland.com%' ---->   99867

select * from Requestor where requestorEmail  like '%SBa1@microland.com%' ---->  59775


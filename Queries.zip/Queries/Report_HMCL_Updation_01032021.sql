

		  select * from HMCL_26022021$ where RequestorId is null

    EUP PI Call summary - usp_MIS_HMCL_REP_ResolvedTicketDump_Daily_EUP



    Daily Ageing report - MIS_HMCL_REP_ageingTicketDump_NonML  and MIS_HMCL_REP_ageingTicketDump_ML


	select * from MIS_HMCL_NewEmailReport where id in (1, 5)





	--Update MIS_HMCL_NewEmailReport set 
	--body='<p>Dear Harish Sir,<br/><br/>This is to inform you that we have not received any P1 ticket for @date <br/><br/>Regards,<br/><br/> Microland Team </p>'
	--where id = 1


	--	,DefaultBodyTemplate='<p>Dear Harish Sir,<br/><br/>Please find below snapshot of Daily Ageing Report as on @date and refer attached summary.<br/><br/><b><U>Synopsis:</b></U><br/><br/>1. @MLTicket Tickets having more than 7 days ageing for ML account.<br/><br/>@Image0<br/><br/>2. @NonMLTicket Tickets having more than 7 days ageing for NON-ML account.<br/><br/>@Image1<br/><br/>Regards,<br/> Microland Team </p>'
	
	--where Id in (5)

	--	Update MIS_HMCL_NewEmailReport set UserEmail='Maheshk1@microland.com'
	--where Id in (1,5)


	Oncall Hardware and OnCall Software Workgroups 

	select * from Workgroup where workgroup like '%Oncall Hardware%' -----> 693	Oncall Hardware

	select * from Workgroup where workgroup like '%OnCall Software%' -----> 694	OnCall Software

	select * from [dbo].[MIS_HMCL_EmailSend_Weekly]

	---->  CarolMR@microland.com

	Select * from customer where customername like '%Ask%' -----> 147	Ask Microland


	select * from Workgroup where workgroup like '%PF vendor%' ---->  235	PF Vendor	PF Vendor

	select * from service where serviceid in (78, 68, 75, 84, 193) ---->  84	HR	HR



	
--	Update MIS_HMCL_NewEmailReport set userEmail ='	itsd.pm@heromotocorp.com;itsd.csdtl@heromotocorp.com;;itsd.qc@heromotocorp.com;itsd.pp@heromotocorp.com;itsd.om@heromotocorp.com;smartcentersupport2@microland.com
--'

--	where id = 5

<p>Dear Harish Sir,<br/><br/>This is to inform you that we have not received any P1 ticket for 
@date <br/><br/>Regards,<br/><br/> Microland Team </p>

<p>Dear Harish Sir,<br/><br/>Please find below snapshot of EUP Daily P1 Summary for @date <br/><br/><U><b>Synopsis:</b></U><br/><br/>@Synopsis<br/><br/><U><b>P1 Call Summary:</b></U><br/><br/>@Image0<br/><br/><U><b>P1 Resolved Summary:</b></U><br/><br/>@Image1<br/><br/><U><b>P1 Pending Reason:</b></U><br/><br/>@Image2<br/><br/>Regards,<br/><br/> Microland Team </p>


<p>Dear Harish Sir,<br/><br/>Please find below snapshot of Daily Ageing Report as on @date and refer attached summary.<br/><br/><b><U>Synopsis:</b></U><br/><br/>1. 40 Tickets having more than 7 days ageing for ML account.<br/><br/>@Image0<br/><br/>2. 38 Tickets having more than 7 days ageing for NON-ML account.<br/><br/>@Image1<br/><br/>Regards,<br/> Microland Team </p>

<p>Dear Harish Sir,<br/><br/>Please find below snapshot of Daily Ageing Report as on @date and refer attached summary.<br/><br/><b><U>Synopsis:</b></U><br/><br/>1. @MLTicket Tickets having more than 7 days ageing for ML account.<br/><br/>@Image0<br/><br/>2. @NonMLTicket Tickets having more than 7 days ageing for NON-ML account.<br/><br/>@Image1<br/><br/>Regards,<br/> Microland Team </p>

------>   919738381093
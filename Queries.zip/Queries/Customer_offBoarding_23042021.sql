
please provide approval email from account head.


--step -- Cusomer table mark customer as delted


--Service Customermapping mark deleted 


--customerassignment group mapping deleted = 0


---------------------------------------------------------------------------------------------------------------------------------------------


select * from Customer where customerName like '%JLSL%'  ---->  160


select * from Customer where customerName = 'Vodafone Idea' and deleted = 0 --195
--update Customer set deleted = 1 where customerId = 160


select * from ServiceCustomerMapping where customerId = 160 and deleted = 0
--update ServiceCustomerMapping set deleted = 1 where serviceCustomerMappingId in(1291,1292,1293,1294,1295,1296,1297,1298,1299,1300,1301,1302,1429,1430
--,1431,1432,1433,1434,1435,1436,1437,1438,1439,1440,1441,1442,1443,1444,1445,1446,1447,1448,1449,1450,1451,1452,1453,1454,1455,1456,1457,1458)


select * from CustomerAssignmentGroupMapping where customerId = 160 and deleted = 0

--update CustomerAssignmentGroupMapping set deleted = 1 where custAssignmentGroupId in(1971,1972,1973,1974,1975,1976,1977,1978,1979,1980,1991,2174,2175,2176,2177
--,2178,2179,2180,2181,2182,2183,2184,2185,2186,2187,2188,2189,2190,2191,2192,2193,2194,2195,2196,2197,2198,2199,2200,2201,2202,2203,2690)
 
 ------>  off-boarding the customer.

 ---> Im ticket Reference:  IM2571116   SR2238309



 select * from Ticket where ticketno = 2571116


 --Update Ticket set serviceId =167, serviceName ='DCS', categoryId = 1888, categoryName ='Security', subCategoryId =7760 , subCategoryName = 'Antivirus',
 --classificationId = 40136, classificationName ='Communication issue', deviceId =5167 , deviceName = 'Generic', workgroupId =429, workgroupName = 'Desktop Team-Plant Roorkee'
 --where ticketNo = 2641891

 ------>  160

 select * from ServiceLevelAgreement where customerId = 160

 select * from NotificationRules where customerId = 160 and deleted = 0

 --update NotificationRules set deleted = 1 where customerId = 160 and deleted = 0

 ---->  Unique key for Desktop and laptop: Asset Tag,Serial Number


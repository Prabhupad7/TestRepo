

    select * from EmailTransactionAttributeConfiguration where customerid in (167, 3, 4, 169, 168, 192, 215, 213, 188, 158, 
    214, 58, 59, 196, 194, 8, 207, 61, 189, 203, 217)


	--insert into EmailTransactionAttributeConfiguration
	--select 219,'Email Transation',1,1,1,1,0,6,Null


     select * from B2BAttachmentConfiguration where customerid in (167, 3, 4, 169, 168, 192, 215, 213, 188, 158, 
    214, 58, 59, 196, 194, 8, 207, 61, 189, 203, 217) order by 2 

	--Insert into B2BAttachmentConfiguration (CustomerId, FileSize, FileTypes, IsVisible, noofattachments)
	--values 
	--(207, 3, '.doc, .docx, .xls, .xlsx, .msg, .zip, .rar, .jpg, .jpeg, .txt, .zipx, .xps, .png, .pdf', 1, 5),
	--(213, 3, '.doc, .docx, .xls, .xlsx, .msg, .zip, .rar, .jpg, .jpeg, .txt, .zipx, .xps, .png, .pdf', 1, 5),
	--(196, 3, '.doc, .docx, .xls, .xlsx, .msg, .zip, .rar, .jpg, .jpeg, .txt, .zipx, .xps, .png, .pdf', 1, 5)


    -----   >   HDU Shared customer List:  

    select * from Customer where customerid in (167, 3, 4, 169, 168, 192, 215, 213, 188, 158, 
    214, 58, 59, 196, 194, 8, 207, 61, 189, 203, 217)


--207
--213
--196


select isApprovalInitiated,approvalEntityMappingId,* 
from Approval where approvalNo ='3167960' ---> APR3096296  4466

select * from Ticket where ticketNo = 3066578  3066578

select top 100 * from ApprovalEmail where subject like '%3096296%'

select top 100 * from ApprovalEmail where subject like '%3066578%'

select top 100 * from ApprovalEmailRules where ApprovalEntityMappingId = 3208  

select * from ApprovalMatrixCriteria where value like '%Automation%' ---> 272	161

select * from ApprovalEntityMapping where approvalCriteriaId = 161 ---> 3747

select top 100 * from ApprovalEmailRules where ApprovalEntityMappingId = 3315  

select top 100 * from ApprovalEmailRules where ApprovalEntityMappingId in (4114,4115)

--insert into ApprovalEmailRules

--select 4466, NotificationTo, NotificationCc, NotificationBcc, NotificationSubject,
--NotificationBody, NotificationMode, Deleted, NULL, NULL, NULL, isMoreInfoTemplate
--from ApprovalEmailRules where ApprovalEntityMappingId = 3747 


select top 100 * from Approval where sourceWorkgroupName like '%Salary%'
order by 1 desc 



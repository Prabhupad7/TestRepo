

--select * from Users 

--select getdate()

----> sp_help_log_shipping_monitor  suhassn@microland.com



SR3103547
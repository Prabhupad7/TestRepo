
			 -------------  To Add Vendor:

			 select * from Organization where organization like '%Citrix%'

			  -- select top 3 * from Organization order by 1 desc

			--  update Organization set organization = 'Steller', description='Steller', displayName ='Steller' where organizationId = 173

			select * from Customer where customerId = 147

			select * from Customer where customerName like '%hero%' ----> 68  217

			select * from Organization where customerId = 68
			order by 1 desc

			--Please add "Maventic" as a Vendor for Ewaybill Support in SmartCenter

		  --  Insert into Organization(organization, description, isCustomer, isOperator, isVendor, isServiceProvider, isInsuranceCompany,deleted, displayName, customerId)
			 --values ('Maventic', 'Maventic', 0, 0, 1,0, 0, 0, 'Maventic', 68)


			 --       ('AWS', 'AWS', 0, 0, 1,0, 0, 0, 'AWS', 217),
				--	('Qualys', 'Qualys', 0, 0, 1,0, 0, 0, 'Qualys', 217),
				--	('Evernex (HPE Partner)', 'Evernex (HPE Partner)', 0, 0, 1,0, 0, 0, 'Evernex (HPE Partner)', 217),
				--	('Veeam', 'Veeam', 0, 0, 1,0, 0, 0, 'Veeam', 217)


--           Update Organization set IsInsuranceCompany =0 where organizationid in (
		   
-- 7110
--,7109
--,7108
--,7107
--,7106 )



			        ('NM', 'NM', 0, 0, 1, 0, 0, 'NM', 1),
			        ('NII', 'NII', 0, 0, 1, 0, 0, 'NII', 1)


					
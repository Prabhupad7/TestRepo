

select * from ApprovalMatrixCriteria where Value like '%Automation%' --> 161


select A.* from HRSheet H
inner join ApprovalMatrixApprover A on H.LevelId = A.LevelId
where a.deleted = 0 and a.levelName like '%2%'


select A.* from HRSheet H
inner join ApprovalMatrixApprover A on H.LevelId = A.LevelId
where a.levelName like '%2%' and a.deleted = 0



----> approverTypeId	approverId	approverName
                 --375	52590	Ashish Garg
 
-- Update A set A.approverTypeId = 375, a.approverId=52590, approverName='Ashish Garg'   from HRSheet H
--inner join ApprovalMatrixApprover A on H.LevelId = A.LevelId
--where a.levelName like '%2%' and a.deleted = 0
 
--REVENUE ASSURANCE - NE 
--JLSL    --MSIL -- HMCL -- INDIGO


select * from ApprovalEntityMapping where ApprovalCriteriaId in( 161) and customerId=147 and deleted=0 

select * from ApprovalMatrixLevel where approvalMatrixId in (676) and levelName like '%2%'
 
select * from ApprovalMatrixApprover where levelId in(1309) and deleted = 0

--Update ApprovalMatrixApprover set approverTypeId =375, approverId=52590, approverName='Ashish Garg' 
--where approvalMatrixApproverId = 1858


 select * from ApprovalMatrixApprover where levelId in
(select levelId from ApprovalMatrixLevel where approvalMatrixId in 
(select approvalMatrixId from ApprovalEntityMapping where ApprovalCriteriaId in( 166 )and deleted=0 and customerId=147)
and levelName like '%2%') and deleted=0 

select * from ApprovalMatrixApprover where levelId in
(select levelId from ApprovalMatrixLevel where approvalMatrixId in 
(select approvalMatrixId from ApprovalEntityMapping where ApprovalCriteriaId in( 124 )and deleted=0 and customerId=147)
and levelName like '%1%') and deleted=0 


--Update ApprovalMatrixApprover set approverTypeId = 378, approverId = 98625, approverName = 'Sandeep Gupta' 
--where approvalMatrixApproverId = 1880



-----> 1878   Pradeep Kumar	PradeepKu@microland.com  ---> 56051
select * from Asset_Users where displayName like '%Sandeep Gupta%' ----> SandeepGK@microland.com    98625

select * from Asset_Users where emailId like '%RajatB@microland.com%' ---->  55012 'Rajat Bajaj'

select * from Asset_Users where id = 56051  ---> SurajK@microland.com

select * from Users where email like '%SurajK@microland.com%'  ----> 

select * from UserDepartmentrole where userEmailId='SandeepGK@microland.com'  ----> 378 Admin

select * from UserDepartmentrole where userEmailId='PradeepKu@microland.com'  ----> 451  

select * from UserDepartmentrole where userDepartment like '%REVENUE%'  ---> 35	REVENUE ASSURANCE - NE

--Insert into UserDepartmentrole

--select 'REVENUE ASSURANCE - NE', 'BU Head', 'PradeepKu@microland.com',0,0,6, 'smcadmin',  GETDATE(), 6, 'smcadmin', GETDATE(), 0 , NULL


select distinct c.Value, u.EmployeeId,am.approverName, am.levelId, am.levelName,u.EmailId from
ApprovalMatrixCriteria c join ApprovalEntityMapping m on m.approvalCriteriaId = c. ApprovalMatrixCriteriaId join 
ApprovalMatrixLevel l on l.approvalMatrixId = m.approvalMatrixId join ApprovalMatrixApprover am on am.levelId= l.levelId 
join Asset_users u on u.id = am.approverId where m.customerId = 147 
and m.deleted = 0 and am.deleted = 0 and am.levelName like '%Level%'



select * from Users  ---> SR3035058

select  * from Assets where AssetNumber = '5069851719'

select * from AssetEntityType  
where Name like '%Insurance%' ---> 370	Insurance

select top 500 * from Assets 
where SourceId = 370 order by 1 desc




select * from VarcharCustomAttribute  where Primaryid = 762883

select id, CustomerId, SourceId, SourceTypeId, AssetNumber, SerialNumber, Createdbyid, CreatedOn,StatusId, Status, Model, ModelId, 
ManufacturerId, Manufacturer, LastUpdatedOn, LastUpdatedBy, Department, Project	 from Assets 
where SourceId = 370 order by 1 desc  

select serviceId, categoryId, categoryName, subCategoryId, subCategoryName, classificationId, classificationName, impactId,impactName,
* from Ticket where ticketNo = 3044555

select * from Impact 

--Update ticket set categoryId =350, categoryName='Server-Related', subCategoryId=6811, subCategoryName='FTP Server',
--classificationId=38839, classificationName ='Login'
--where ticketNo = 3044555

select * from ServiceCategoryMapping 
where serviceId = 51 and ticketTypeId = 1 and deleted = 0  --> 350

select * from Category where categoryId = 350
select * from SubCategory where categoryId = 350
select * from Classification where subCategoryId = 6811

  select * from Service where serviceId =2

  select * from Category where category Like '%Group InstaClaim%'

   --update Category set isEUPVisible = 1 where categoryId in (1016, 1017) 
   
   select * from SubCategory where categoryId in ( 1017) 

   select * from SubCategory where subCategoryId in (4817
,4818
,4819
,4820
,4821
,4822) 

      update SubCategory set isEUPVisible = 1 where subCategoryId in (4817
,4818
,4819
,4820
,4821
,4822) 

 update Classification set isEUPVisible = 1 where classificationId in (
 8838
,8839
,8840
,8841
,8842
,8843
 ) 

  select * from Classification where subCategoryId in (4817
,4818
,4819
,4820
,4821
,4822) 

  select * from ServiceCategoryMapping where categoryId in (1016, 1017)



  select top 10 * from RulesForPriority order by 1 desc
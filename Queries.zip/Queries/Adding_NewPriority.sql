


----> from Sweta Saran
    
--ADDING SERVICE REQUEST -:


---> Open(https://rmcops.microland.com/Dashboard/14) with admin credentials
---> Go to SR --> create a request --> Go to Ticket Prioritization --> mark it as 'NO' -> check the Priority dropdown

 select * from TicketType --get ticket type 2
 Select * from Priority where priority = 'SR4' and ticketTypeId = 2 -- get priority id:  15

 SELECT * FROM CUSTOMER WHERE displayNAME like '%Wool%' -- get customer id:  188

 Select * from Customer where displayname like '%Green%'-- get customer id

 Select * from customerprioritymapping where customerId in(188) and priorityid = 15  ----> 981
 
 --insert record in the table & get

--- CustomerPriorityMappingid

 select * from ServiceCustomerMapping where CustomerId in(188) and ticketTypeId = 2 ---get Serviceid  1779  295

 select * from ServicePriorityMapping where customerId in(188) and priorityid = 15 ---- insert record

 --Update ServicePriorityMapping set deleted  = 0 where servicePriorityMappingId =8998

--- Finally go to Admin & refresh the cache and see the whether data is reflecting in 'Priority' dropdown.

 select top 1000 * from RulesForPriority where PriorityRule like
 '% {customerid=167;serviceid=195;categoryid=3107;subcategoryid=12230;classificationid=52802;tickettypeid=2;}%'

 --Insert into RulesForPriority (RuleDescr, PriorityRule, PriorityId, ImpactId, RulePriority, Deleted, RuleTemplateId, 
 --customerid)

 --values('Innocent Drinks','{customerid=188;serviceid=188;categoryid=3783;subcategoryid=15509;classificationid=68728;tickettypeid=2;}',
 --15, 5, 1, 0, 1890, 188)

 select top 1 * from RulesForPriority order by 1 desc  ---->  89711

 select top 1000 * from RulesForAssignment where customerId = 188  ---->  ruleid = 71229  963

 select top 1000 * from RulesForAssignment where RuleTemplateId  =  963

 select top 10 * from RulesForAssignment order by 1 desc

 --Insert into RulesForAssignment (RuleDescr, AssignmentRule, PrimaryAssignmentGroupId, SecondaryAssignmentGroupId, RulePriority, 
 --Deleted, RuleTemplateId, customerId, AssignmentType, AssignToId,NoOfParams)

 --values ('InnocentDrinks','{customerId=188;serviceId=188;categoryId=3783;subCategoryId=15509;classificationId=68728;}', 93, 93, 1, 0, 963, 188, 1, 0, 5)

 --update RulesForAssignment set AssignmentRule='{customerId=188;serviceId=295;categoryId=3783;subCategoryId=15509;classificationId=68728;}' where RuleId = 82436

select top 1000  * from ServiceLevelAgreement where description like '%Innocent Drinks%'
---> 295
---> 224	Innocent Drinks- SR

select top 1000  * from ServiceLevelObjective 
where serviceLevelAgreementId = 224 and serviceId = 295 --->  and

--Insert into ServiceLevelObjective(serviceLevelAgreementId, serviceLevelObjectiveTypeId,	initialStatusId,finalStatusId,
--responseTimeInMin,	excludeStatusIds,	serviceId,	priorityId,	impactId,	holidayCalendarId,	workHourId,
--is24X7Service,	locationId,	workgroupId	,isDelete	,isDefault)

--select serviceLevelAgreementId, serviceLevelObjectiveTypeId,	initialStatusId,finalStatusId,
--14400,	excludeStatusIds,	295,	15,	7,	holidayCalendarId,	workHourId,
--is24X7Service,	locationId,	47	,isDelete	,isDefault from ServiceLevelObjective
--where serviceLevelObjectiveId = 637688

 select * from Requestor where requestorEmail like '%venkataramana%' -- 54539

 select * from CustomerRequestorMapping where requestorId = 54539

 select * from ServiceLevelTracking where sourceId = 2843437


 ---->  SR2843437



select * from NotifyBasedOn where notifyBasedOn like '%Reject%'

--notifyBasedOnId	notifyBasedOn
--36	REJECTED

--37	REJECT_AND_CLOSE

--38	FIRSTLEVEL_REJECT

select * from TicketStatus where ticketTypeId = 4 

select * from NotificationRules where customerId in (3,4,8,58,59,61,158,167,168,169,182,188,189,192,194,196,201,203,207,213,214,215,217,218,219,220,221)and ticketTypeId = 4 and entryStateId in (26,27)

select top 100 * from NotificationEmailTemplate where template like '%</a>%'
order by 1 desc

--Subject:
RCA Reject Notification ($customerName) - Ticket Number: $ticketNoToDisplay 

---> Body: 

Dear $REQUESTORNAME <br/><br/>
RCA is rejected for the ticket  $TICKETNOTODISPLAY.
<br/><br/> 
Following are the comments provided

(@@ Comments Variable(if exists))

Following are the ticket details
<br/><br/>
<table>
    <th>TicketNo</th> (link to open a ticket)
    <th>descrription<>
   
</table>
<br/><br/>
<Click here(link)> to open the ticket: and Take the required action.




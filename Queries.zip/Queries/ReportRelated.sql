
Anakha Ravindran 14361
Vipin KC 9423
Deepak RC 6940

select * from Users where firstName like '%Anakha%'   ---- 26386, roled = 48

select * from Users where firstName like '%Vipin%'   ---- 23854, roled = 48

select * from Users where firstName like '%Deepak%'   ---- 1494, roled = 122

   select * from Users where email like '%manoj.maurya@heromotocorp.com%'  --- 714   Manoj.maurya@heromotocorp.com

     ----  (nikhil.sharma@heromotocorp.com

	  select * from Users where email like '%nikhil.sharma@heromotocorp.com%'  --- 910, roleid: 96
   
    select * from ReportRoleMapping where roleId = 97 and ReportMasterId in (38, 62)





	select * from Customer where customerName like '%hero%' --- 68

	   select * from MenuRoleMapping where roleID = 97 and menuID in (14, 167, 235)

	   Select * from MenuMaster  where menuName like '%Asset%'   --- 14, 167, 235


    select * from Users where userid in (26386, 23854, 1494)
          
    select * from RePortMaster where name like '%ITSM%'
    
    select * from RePortMaster where customerIds in ('68') and reportMasterID in (38, 62)

	Select * from MenuMaster  where menuID in (select menuID from MenuRoleMapping where roleID = 97)

	--- 38, 62

	select * from ReportRoleMapping where RoleId = 97

	select * from ReportRoleMapping where RoleId = 95

		--  68 user need to map.
    --  96 user deleted.

		select * from ReportRoleMapping where RoleId = 68

		Select * from MenuMaster  where menuID in (select menuID from MenuRoleMapping where roleID = 96)

      select * from ReportRoleMapping where ReportMasterId = 154

	  --- 46, 50
	  49, 48

	  Insert into ReportRoleMapping (RoleId, ReportMasterId, IsDeleted) values
	      (48, 154, 0), (49, 154, 0)

		    select * from Users where loginName in ('LO4997', 'LO5595', 'LO4995', 'LO3556', 'LO4772')



		--- 1699	Ranganath	HN	RanganathHN  --> roleId = 95

		select * from Users where roleId = 95

		-- update Users set roleId = 96 where userId = 1699

		select * from Workgroup where workgroup like '%Indosat%'








select userid, firstName, lastName, userName, email, loginName from Users where RoleId in(select roleId from ReportRoleMapping where ReportMasterId = 326 and deleted = 0
) and deleted = 0 and userId in ( 

select distinct(userId) from UserCustomerAssignGroupMapping where custAssignmentGroupId in
(select custAssignmentGroupId from CustomerAssignmentGroupMapping where customerId in (3,147)) and deleted = 0)


  Select * from MenuMaster where menuName like '%Reports%'  --- 244

    Select * from MenuMaster where menuName like '%Reports%'  --- 244

  select userid, firstName, lastName, userName, email, loginName from Users where RoleId in(select roleId from ReportRoleMapping where ReportMasterId = 326
) 

--  from Vignesh
-- for getting the Users who are all having the AssetModule Access:

   Select * from AssetEntityType where Id = 1

      Select * from AssetEntityType where Name like '%Reports%'

     select * from  Asset_EntityTypeUserMapping where entityTypeId = 1 and isDeleted = 0 and userId in (714)

    select * from  Asset_EntityTypeUserMapping where  isDeleted = 0 and userId in (714)

    select * from  Asset_EntityTypeUserMapping where entityTypeId = 1 and isDeleted = 0 and userId in (6)

			--Insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)
			Values(26386,1,GETDATE(),6,0)

		--	update Asset_EntityTypeUserMapping set instanceid = 1 where entityTypeId = 1 and isDeleted = 0 and userId in (26386, 23854, 1494)

		--exec Asset_ProvideAssPermission '26386',147,1,null
		--exec Asset_ProvideAssPermission '23854',147,1,null
		--exec Asset_ProvideAssPermission '1494',147,1,null


  --select distinct(userId) from UserCustomerAssignGroupMapping where custAssignmentGroupId in
  --(select custAssignmentGroupId from CustomerAssignmentGroupMapping where customerId in (3,147)) and deleted = 0)

   select * from MenuRoleMapping where roleID = 97


select userid, firstName, lastName, userName, email, loginName from Users where userId in (1492
,1766
,1512)



----------------

  select * from Users where loginName like '%smcadmin%'  -- 6


  /****** Object:  StoredProcedure [dbo].[Asset_ProvideAssPermission]    Script Date: 08/19/2020 20:30:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--exec Asset_ProvideAssPermission '708',1,1,null



select distinct( roleid ) from Users where LoginName  in  ('saarsul',
'nidriss'
,'shyedre'
,'osarmal'
,'amishra4'
,'Snalawd'
,'kepatil1'

,'Gokrish'
)


   Select * from AssetEntityType where Id = 3

  select * from  Asset_EntityTypeUserMapping where entityTypeId =3 and isDeleted = 0 and userId in (1089, 718, 1069)

   --- update Asset_EntityTypeUserMapping set isDeleted = 1 where id in (792, 793, 794)

    select * from  Asset_EntityTypeUserMapping where entityTypeId =3 and isDeleted = 0 and userId in (6)


		-- Insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)
		-- Values
		--(1089,3,GETDATE(),6,0),
		--( 718,3,GETDATE(),6,0),
		--( 1069,3,GETDATE(),6,0)



		--exec Asset_ProvideAssPermission '1089',1,1,null
		--exec Asset_ProvideAssPermission '718',1,1,null
		--exec Asset_ProvideAssPermission '1069',1,1,null










select * from AssetEntityType where id=1

select * from Asset_EntityTypeUserMapping where userId = 6

--Select 963,1,GETDATE(),6,0


[8:25 PM] Vignesh Annadurai
   -- Asset_ProvideAssPermission 
   
  -- exec Asset_ProvideAssPermission '1003',1,1,null


  select * from  Asset_EntityTypeUserMapping where entityTypeId = 1 and isDeleted = 0 and userId in (

931,
962,

1000,
1003) 

   -- update Asset_EntityTypeUserMapping set instanceid = 1 where entityTypeId = 1 and isDeleted = 0 and userId in (


1003) 

  select * from customer where customerName like '%Jubiliant Pharma%'



  [usp_StandardReport_SLAcalculation]




  Select * from workGroupEscalationMatrix where customerid = 147 and deleted = 0 and workgroupid = 227

    Select * from workGroupEscalationMatrix where customerid = 68 and deleted = 0 and workgroupid = 227

  Select * from workGroupEscalationMatrix_AskML where workGroupId = 227 and customerid = 147

      Select * from workGroupEscalationMatrix_AskML where customerid = 147   and workgroupid in (
 203
,214
,224
,225
,227
,229
,232
,233
,235
,238
,241
,249
,495
,496
,512
,513
,515
,525
,595
,596
,628
,629
,630
,631
,632
,687)

    select * from Workgroup where workgroupid = 203  --- Employee Information Changes

	select * from Workgroup where workgroup like '%Attendance%'  ---- 631  Employee Letters

	--- 227	Attendance & Leave (India)	Attendance & Leave (India)


	--- test ticket: SR2659776

	select workgroupid, * from Ticket where ticketNo = 2659790

	select top 1 * from workGroupEscalationMatrix_AskML order by 1 desc 
	-- 397	147	NULL	NULL	Employee Information Changes	Niharika Das	NiharikaD@microland.com	8770222282

	  Select * from workGroupEscalationMatrix_AskML where workGroupId = 227 and customerid = 147

	  Select * from workGroupEscalationMatrix_AskML where  customerid = 147



	--Insert into workGroupEscalationMatrix_AskML (CustomerId	, WorkgroupName	,  Level1Name , Level1Extension	, Level1Email,	Level2Name,	Level2Extension,	Level2Email,
	Level3Name,	Level3Extension,	Level3Email,	workGroupId)

	


    Select * from workGroupEscalationMatrix_AskML where customerid = 147   and workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687)

select * from Workgroup where workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687)

-- 631, 227

-- Insert into workGroupEscalationMatrix_AskML (CustomerId	, WorkgroupName	,  Level1Name , Level1Email,	Level2Name,	Level2Email, Level3Name,	Level3Email,	workGroupId)

      select 147, 'Datacard & Broadband',  Level1Name , Level1Email,	Level2Name,	Level2Email, Level3Name,	Level3Email,	687 from workGroupEscalationMatrix_AskML
      where workGroupId = 203 and customerid= 147



  select * from NotificationRegistry where sourceId = 2659790    --- 2659776


             select * from NotificationEmailTemplate where templateId in ( 1958, 488, 484)

select * from NotificationEmailTemplate where customerId = 147 

-- update NotificationEmailTemplate set templateName = 'Work in progress_HR' where templateId = 1958

  select * from Customer where customerName like '%SMC ucfs%'  --- 208

  select * from NotificationEmailTemplate where customerid = 182 and templateId = 961   ---- 961	Ticket Update

  select * from NotificationEmailTemplate where customerid = 208 and templateId = 961  

  select * from NotificationEmailTemplate where customerid = 147 and templateName like '%HR%'    

  select * from NotificationEmailTemplate where  templateId = 498

 -- update NotificationEmailTemplate set template = '' where templateId = 1958

  

  select * from NotificationRegistry where sourceId = 2660438 

  select workgroupId,* from ticket where ticketNo = 2658694   ---203



  select top 1000 * from NotificationRules where customerId = 208 and deleted = 0 and duepercent is null



        select  * from NotificationRules where customerId = 147 and deleted = 0 
		and duePercent = 60 and  workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687)



	    select  distinct workgroupid from NotificationRules where customerId = 147 and deleted = 0 and duePercent in( 50) and notifybasedonid in (2) and   serviceid = 68 and
		workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687)



   select * from NotificationRules where customerId = 147 and deleted = 0 and duePercent in( 90) and notifybasedonid in (2) and   serviceid = 84 and  
		workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687)

   select * from NotificationRules where customerId = 147 and deleted = 0 and duePercent in( 90) and notifybasedonid in (3) and   serviceid = 84 and  
		workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687)


  -- Insert into NotificationRules (customerId, ticketTypeId	, priorityId,	duePercent,	notificationMode,	notificationTo,	notificationCC,
	 templateId,	ruleName,	workgroupid, serviceId, notifyBasedOnId, deleted)


	  select  147, ticketTypeId	, priorityId,	90,	notificationMode,	'$ASSIGNEDENGINEEREMAIL;NiharikaD@microland.com;PreetNH@microland.com', '$WORKGROUPEMAIL;', 2004,	'RESOLUTION SLA 90%',	workgroupid, 84, 3, 0 from NotificationRules 
	  where customerId = 147 and deleted = 0 and duePercent in( 50) and notifybasedonid in (3) and   serviceid = 84 and  
		workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687)






		--update NotificationRules set templateId = 1999 where ruleId in ()
		--- '$ASSIGNEDENGINEEREMAIL;NiharikaD@microland.com'

	  ----	'$WORKGROUPEMAIL;NiharikaD@microland.com'

		$WORKGROUPEMAIL;PreetNH@microland.com



	   select  * from NotificationRules where customerId = 147 and deleted = 0 and duePercent in( 50 , 75, 90) 
	and workgroupid in( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628 ,629,630,631,632,687)
	and serviceId ! = 84 and notificationCC like '%preetnh@microland.com%' 


		--update  NotificationRules set deleted = 1 where customerId = 147 and deleted = 0 and duePercent in( 50 , 75, 90) 
	and workgroupid in( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628 ,629,630,631,632,687)
	and serviceId ! = 84 and notificationTo like '%NiharikaD@microland.com%' 


	

	select * from Workgroup where workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687)


  select * from Workgroup where workgroupId = 233

 -- update Workgroup set IsVisible = null where workgroupId = 233



     select * from NotificationEmailTemplate where customerid = 147 and templateName like '%HR%'


	 ---  491	Feedback Template_HR
	 ---  1085	Feedback Template_HR _Test

	 ---  1459	Five rating Feedback _HR



	 select * from Service where serviceId = 84

	 select * from NotificationRules where customerId = 147 and serviceId = 84 and templateId = 491 and workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687)


   select * from NoticationRules where ruleid in (
   2329463
,2337860
,1695109
,2337861
,1695105
,2337862
,2337968
,2338496
,2338730
,2337863
,1695106
,2337864
,1695107
,1695108
,2338262
,2338964
,2339198)

 -- update NotificationRules set templateId = 491 where 

  ruleId in (1693986
,1693992
,1693998
,1694004
,2172165
,1694466
,1694472
,1694478
,1694484
,2172285
,1694946
,1694952
,1694958
,1694964
,2172405
,1694994
,1695000
,1695006
,1695012
,2172417
,1695090
,1695096
,1695102
,1695108
,2172441
,1695186
,1695192
,1695198
,1695204
,2172465
,1695330
,1695336
,1695342
,1695348
,2172501
,1695378
,1695384
,1695390
,1695396
,2172513
,1695474
,1695480
,1695486
,1695492
,2172537
,1695618
,1695624
,1695630
,1695636
,2172573
,1695762
,1695768
,1695774
,1695780
,2172609
,2158282
,2158288
,2158294
,2158300
,2178532
,2086294
,2086300
,2086306
,2086312
,2177505
,2086342
,2086348
,2086354
,2086360
,2177517
,2158330
,2158336
,2158342
,2158348
,2178544
,2329307
,2329313
,2329319
,2329325
,2329331)



select * from NotificationEmailTemplate where templateId = 491

select * from NotificationEmailTemplate where templateId = 1958

select * from NotificationEmailTemplate where customerid = 147 and templateName like '%HR%'

---  2000	RESPONSE SLA 75_HR

---   2003	RESOLUTION SLA 75_HR



--  1459	Five rating Feedback _HR

  --  update NotificationEmailTemplate set template=''
  
  where templateId = 491


 ----  SR2667043

 ----- SR2667214

    select * from Customer where customerName like '%indosat%'


	---  SR2668244
	---  SR2668246

	kli.mangesh-jagtap@kotak.com

	kli.tsd2@kotak.com


	select * from NotificationRegistry where sourceId = 2668244

		select * from NotificationRegistry where sourceId = 2668246



select * from AssetEntityType where Id = 66 

select * from AssetEntityType where Name like '%CMDB%'


select * from AssetEntityType where Name like '%asset%'





Select * from Asset_EntityTypeUserMapping where entityTypeId = 285

-- KM � entitytype 285 or 66 

-- Insert the new row as below

--insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)

--Select 25664,285,GETDATE(),6,0

--insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)

select * from Users where email like '%AshokkumarGu@microland.com%' -----> 25644

select * from Users where email like '%venkataramana%' -----> 26093

select * from Asset_EntityTypeUserMapping where userId =26093 and entityTypeId in (
143,
241,
427
)



Select 25664,66,GETDATE(),6,0

 -- Insert into Asset_EntityTypeUserMapping (userId,entityTypeId,createdOn,createdBy,isDeleted)
 --Values

 --(25644,143,GETDATE(),6,0),
 --(25644,241,GETDATE(),6,0),
 --(25644,427,GETDATE(),6,0)

select top 100 * from users 

select * from Users where LoginName  like  '%nidriss%'

select * from Users where LoginName  in  ('saarsul',
'nidriss'
,'shyedre'
,'osarmal'
,'amishra4'
)



--Category
--Sub Category
--Classification

--Desktop/Laptop Management
--Avamar
--Avamar related issues

--Desktop/Laptop Management
--MS Office
--MS - Outlook Related Issue

--Desktop/Laptop Management
--Printer
--Paper Jam Issue

--Desktop/Laptop Management
--Printer
--Unable to take prints

--Desktop/Laptop Management
--Proxy
--Certificate related issue

select * from Requestor where requestorEmail like '%SagarMi@microland.com%' ---->  59308

select * from CustomerRequestorMapping where Requestorid = 59308























 

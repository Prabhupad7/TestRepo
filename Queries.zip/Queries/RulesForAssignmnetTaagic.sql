
select * from Service


select * from Category where CategoryId in (Select distinct CategoryId from ServiceCategoryMapping
 where serviceId = 1 ) and deleted =0



  select top 100 * from RulesForAssignment

  select top 1 customerId, serviceId, categoryId, TicketTypeid , TicketTypeid , * from ticket




 --  update RulesForAssignment set Deleted = 1 
   
   Select * from Category where 

   -- Insert into RulesForAssignment (RuleDescr, AssignmentRule, PrimaryAssignmentGroupId, SecondaryAssignmentGroupId, RulePriority, Deleted, 
	RuleTemplateId, customerId, AssignmentType, AssignToId, NoOfParams)

	---- For WorKgroup---> Helpdesk Support

	Values ('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=9;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),
	       ('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=5;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),
		   ('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=11;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),
		   ('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=10;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),
		   ('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=2;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),
		    ('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=4;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),
		   ('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=15;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),
		    ('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=7;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),
			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=8;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=12;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),
			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=13;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=14;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),
			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=17;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			----  Mail Messaging   Missing Category
			----  Storage Management
			------ NA
            ----- Application Details


			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=51;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),
			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=53;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=54;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=57;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=79;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=80;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=83;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=85;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),



			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=93;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=94;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=95;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=96;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=24;}', 153, 153, 1, 0, 79, 1, 1, 0, 3),


			---- For WorKgroup---> ID Management

			--54	ID Management
   --         56	ID Management


			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=54;}', 165, 165, 1, 0, 79, 1, 1, 0, 3),
			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=56;}', 165, 165, 1, 0, 79, 1, 1, 0, 3),


			---- For WorKgroup---> O365

			('TAAGIC Rule', '{customerId=1;serviceId=1;categoryId=80;}', 172, 172, 1, 0, 79, 1, 1, 0, 3),


	select * from  AssignmentGroup 


  ---   'TAAGIC Rule'

  --  Select * from NotificationEmailTemplate where templateId= 79


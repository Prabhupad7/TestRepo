

select top 50 * from Log 
order by 1 desc

--30982518
--30982517
--30982516

--30983472	2	1	Error	page = TimeStamp - 5/25/2021 5:05:44 AM, reports , method= DownloadFile, UserID= user
--30983471	3	1	Error	page = TimeStamp - 5/25/2021 5:05:44 AM, reports , method= DownloadFile, UserID= user
--30983470	1	1	Error	page = TimeStamp - 5/25/2021 5:05:44 AM, reports , method= DownloadFile, UserID= user

select * from Customer where customerId in 
(3, 194, 192, 167, 169, 58, 59, 188, 158, 
 221, 8, 61, 189, 203, 4, 168, 210, 207, 196
 ,213,  214, 215, 218, 217, 220 , 219)




select * from Users where email like '%Manju%' ---> 25872 ManjunathKS@microland.com

select * from Users where userId = 25872

select * from Customer where customerName like '%SAP GD%'  ----> 58	SAP GD

select * from Admin_UserCustomerAdminMapping 
where UserId = 25872 and CustomerID = 58

--Insert into Admin_UserCustomerAdminMapping

--select 25872, 58, 0, GETDATE(), 6, GETDATE(), 6, 0

-----> MayaMJ@microland.com;KarthikS@microland.com;LikhithoshSK@microland.com;AjayA@microland.com

select  * from FeedbackConfig where CustId = 194

---->  MayaMJ@microland.com;KarthikS@microland.com;LikhithoshSK@microland.com;AjayA@microland.com

--Update FeedbackConfig set ToAddr = REPLACE(ToAddr, 'MayaMJ@microland.com;', '') where id in (
--318,
--316,
--319,
--320,
--321,
--322,
--317,
--323,
--324,
--325
--)

select * from Asset_users where EmployeeId in (
'14321','14372','15617','18457','19316','19702',
'19771','20929','20951','21383','21525','21962',
'22162','22339')  -----> 55225

select * from Asset_users where id = 55225  ----> RizwanR@microland.com  14334

select * from Asset_users where EmployeeId = '14334'   -----> 54236 MohammedKAH@microland.com

--IM2388157

  select isAccountLocked, failedLoginAttemptCount,Password, deleted, * from Requestor
  where alias = 'CIShelpdesk' and deleted = 0  

  ----> CISHelpdesk

  --Update Requestor set alias ='CISHelpdesk' where requestorId = 91271

 select * from CustomerRequestorMapping where requestorId = 2919

  select * from CustomerRequestorMapping where requestorId = 91271

  --Insert into CustomerRequestorMapping

  --select 91271, 155, 'SMC CIS', 1

  ---->  select * from Requestor where alia

--Update Requestor set failedLoginAttemptCount=0, isAccountLocked =0 where requestorId in (
--2919
--,3006
--,16890
--,16891
--,53776
--,53930
--,59711,
--91271
--)

------------> KLI

select * from Category where category like '%CFI%'   ---> 1745

select * from SubCategory where categoryid= 1745  ----> 5106



select * from Service where serviceid= 93   ----> 93	POLICY SERVICING

select top 100 * from RulesForPriority 
order by 1 desc

----> {customerId=92;serviceId=93;categoryId=1740;subCategoryId=5060;ticketTypeId=2;}

--insert into RulesForPriority

select 'Branch Ops', '{customerId=92;serviceId=93;categoryId=1745;subCategoryId=5106;ticketTypeId=2;}', 2, 10, 1, 0, 967, NULL


select * from Workgroup where workgroup like '%POLICY%'  --->  143

Select * from AssignmentGroup where workgroupId = 143   -----> 208

select * from CustomerAssignmentGroupMapping 
where assignmentgroupId = 208   ------> 228

select * from Users where firstName like '%Sameera%'

select * from Users where loginName like '%LE56315%'  -----> 

---------------------------------------------------------------------->

----->: march 1st till Today

select * from ReportMaster where reportMasterID = 102   ----> 102	RP001 - Incident and Service request SLA dump


--usp_StandardReport_getAllIMAndSRCombinedSLATicketDump_RP001

--     usp_StandardReport_getAllIMAndSRCombinedSLATicketDump_RP001

--Exec usp_StandardReport_getAllIMAndSRCombinedSLATicketDump_RP001 '2021-02-01', '2021-02-28', 'resolvedTime', '3,194,192,167,169,58,59,188,158,221,8,61,189,203,4,168,210,207,196,213,214,215,218,217,220,219,147',
--'1,2,3,4,5,6,7,9,10,11,12,13,15,47,48,49,51,53,55,56,57,58,59,69,104,166,189,190,193,196,200,203,206,211,212,214,216,220,221,224,225,227,229,232,233,235,238,241,247,248,249,250,264,293,296,299,300,335,336,337,338,340,341,342,343,345,346,348,349,352,361,363,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,390,392,393,394,395,403,404,406,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,443,452,489,491,502,504,512,513,515,525,527,528,529,530,531,532,533,535,537,539,542,551,552,553,557,558,586,587,588,590,591,594,595,596,599,602,603,608,612,613,614,615,616,625,628,629,630,631,632,634,640,642,643,644,645,646,647,650,651,654,655,656,657,660,661,662,663,664,665,666,667,668,669,670,671,672,673,674,675,676,677,678,679,680,681,682,683,684,685,686,688,689,690,692,695,697,698,699,701,702,707,708,709,710,711,712,713,715,716,717,718,719,720,721,722,723,724,725,734,735,736,737,738,739,744,745,746,747,748,750,751,752,753,754,755,756,757,758,759,760,761,762,763,764,765,766,767,768',
--330, '1,2', NULL, NULL, NULL, NULL, NULL, NULL

------------------------->

select * from ReportMaster where reportMasterID = 102

select customerId,serviceId, workgroupId, priorityId, impactId,* from Ticket where ticketNo = 2998375  ------> 

select * from ServiceLevelAgreement  where customerId = 147  ---> 74

select * from ServiceLevelObjective where serviceLevelAgreementId = 74 and
serviceId = 84  and priorityId = 14 and impactId = 5  and workgroupId = 631   ---> Workgroup is not added.  14
 
---> 1710

select * from ServiceLevelTracking where sourceId = 3000573

	SR3000573

--2021-06-04 09:00:00.000
--2021-06-04 09:00:00.000
--2021-06-12 15:13:35.000

--delete from ServiceLevelTracking
--where serviceLevelTrackingId in (6880770)

--Update ServiceLevelTracking set expectedEndTime ='2021-06-04 09:00:00.000'
--where  serviceLevelTrackingId in (6886616)


select * from WorkHoursDetail where workHourId = 14


select * from WorkHours where workHourId = 14


select * from ServiceLevelObjective where serviceLevelObjectiveId in (
816258, 
816254,
759163
)

select * from ServiceLevelObjective where serviceLevelObjectiveId in (
404333,
760069,
816302
)


--Insert into ServiceLevelObjective

--values 
--(74,	1,	64,	14,	60,	NULL,	84,	14,	5,	59,	14,	0,	0,	    631,	0,	0),
--(74,	2,	64,	19,	1710,	'15,16,17',	84,	14,	5,	59,	14,	0,	0,	631,	0,	0)




--Update ServiceLevelObjective set isDefault = 0 where serviceLevelObjectiveId = 759163

-----> 759163

--60
--1710

-----> for Ticket 

----->   Dipak.Nikam@eurekaforbes.com

--1710
--60

--250

select top 100 * from Ticket
where serviceId = 84 and workgroupId = 224
order by 1 desc

select * from TicketStatus where ticketTypeId = 2  ----> 21	Closed

select * from TicketStatus where ticketTypeId = 1  ----> 11	Closed


select top 100 * from NotificationRules where deleted = 0 and customerId = 147 and entryStateId = 21
order by 1 desc


-----> CAB changes done for IT Infra and SAP.

SR2999977

select * from NotificationEMailTemplate where templateid in (
483,
646

select customerId,TicketTypeid,serviceId, workgroupId, priorityId,
* from Ticket where ticketNo in(91335,91334, 91333) 



--Insert into NotificationRules (customerId, ticketTypeId, priorityId,notificationMode, notificationTo, notificationCC, templateId, ruleName, workgroupid, serviceId, 
--notifyBasedOnId, entryStateId, deleted)
--values 
--(1,1,27, 'mlmail','$REQUESTOREMAIL', '$ASSIGNEDENGINEEREMAIL', 646, 'STATUS',  21, 4, 1, 9, 0),
--(1,1,15, 'mlmail','$REQUESTOREMAIL', '$ASSIGNEDENGINEEREMAIL', 646, 'STATUS',  21, 4, 1, 9, 0),
--(1,1,9, 'mlmail','$REQUESTOREMAIL', '$ASSIGNEDENGINEEREMAIL', 646, 'STATUS',  21, 4, 1, 9, 0),
--(1,1,5, 'mlmail','$REQUESTOREMAIL', '$ASSIGNEDENGINEEREMAIL', 646, 'STATUS',  21, 4, 1, 9, 0),
--(1,1,1, 'mlmail','$REQUESTOREMAIL', '$ASSIGNEDENGINEEREMAIL', 646, 'STATUS',  21, 4, 1, 9, 
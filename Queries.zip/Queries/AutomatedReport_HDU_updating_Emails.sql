--->  select * from "sendmail"  EmailSend

	select * from MIS_RMC_EmailSendReport where 

	select * from MIS_HMCL_EmailSend_DPCR_ML_NONML

	select * from MIS_HMCL_EmailSend_Weekly

	select * from MIS_HMCL_EmailSendLocationWise

	select * from MIS_HMCL_EmailSendLocationWise_Test


    
    select * from  MIS_SMC_EmailReport where Id=15 and CCEmail like '%Prabhu%'

	--Update MIS_SMC_EmailReport set 
	--CCEmail ='AbdulMR@microland.com;RitwikD@microland.com;ArunKA@microland.com;ChandramohanR@microland.com;ManoshBh@microland.com;AshokkumarGu@microland.com;ShujahullaS@microland.com;PrakashN@microland.com;AshwinAK@microland.com;HDUQualityTeam@microland.com;RMCShiftManager@microland.com;maheshk1@microland.com;BinuTP@microland.com;karthikv@microland.com'
	          
	--where  Id=15

	    select * from  MIS_SMC_EmailReport where UserEmail like '%Ashwin%'



	--->  MLRMCBackupteam@microland.com;MLRMCStorageTeam@microland.com;#ML-RMCDCTeam@microland.com;rmcdatabaseteam2@microland.com;rmcnetworktechsupport@microland.com;ML-RMCMessagingTeam@microland.com;RMCVoiceTeam@microland.com;RMCToolTeam@microland.com;ML-RMCSOC@microland.com;hdusharedims@microland.com;MLRMCUnixTeam@microland.com;ML-RMCCollaborationTeam@microland.com;ML-RMCMiddlewareTeam@microland.com;MLRMCCitrixTeam@microland.com;RMCQualityDocketNotification@microland.com;ML-RMCShiftManager@microland.com;DarshanS@microland.com

﻿


    -- 9347480938


	[‎7/‎1/‎2020 12:01 PM]  Vignesh Annadurai:  

--insert into Admin_LevelMaster(LevelName,CreatedOn,CreatedBy,Deleted)

--select 'Level4',GETDATE(),6,0

Select * from Admin_ModuleLevelMapping where LeveID  = 3

--insert into Admin_ModuleLevelMapping(ModuleID,LeveID,CreatedOn,CreatedBy,Deleted) 

--Select 1,4,GETDATE(),6,1 
 
	  [‎7/‎1/‎2020 11:57 AM]  Vignesh Annadurai:  


	  select levelid, * from Users where email ='jagdishg@microland.com'

     update users set levelid = 4 where email = 'Sukhvinders@microland.com' 

     update users set levelid = 4 where email = 'Anandar1@microland.com'

	 update users set levelid = 4 where email = 'sanjaysj@microland.com'

	 update users set levelid = 4 where email = 'Amitku12345@microland.com'

	 update users set levelid = 4 where email = 'SouravB@microland.com'
	   
	 update users set levelid = 4 where email = 'VimalC@microland.com'

	 update users set levelid = 4 where email = 'mukeshc@microland.com'

     update users set levelid = 4 where email = 'AlpeshCk@microland.com'

     update users set levelid = 4 where email = 'gopikrishnak@microland.com'

	 update users set levelid = 4 where email = 'Manjeetku1@microland.com'

	 update users set levelid = 4 where email = 'jagdishg@microland.com'
	  



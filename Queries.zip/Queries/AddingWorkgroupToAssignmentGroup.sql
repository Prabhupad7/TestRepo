
     select * from Workgroup where workgroupid in (256, 452)

     select * from Workgroup where workgroup like '%SMC Password Reset%' -->  725

	    select * from AssignmentGroup where workgroupid in (256, 452)

		--Insert into AssignmentGroup (assignmentgroupName, workgroupId, supportgroupId, deleted, lastUpdatedOn, modifiedBy)
		--values ('SMC Password Reset', 725, 5, 0, GETDATE(), 6)

		select * from AssignmentGroup where workgroupid in (725)

		-- update AssignmentGroup set deleted =1 where assignmentgroupId = 860

		 select * from CustomerAssignmentGroupMapping where assignmentgroupId = 859 --->  2984


		    select * from UserCustomerAssignGroupMapping where userid in (26087, 26222,25448) and custAssignmentGroupId = 2984

			--	Insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
			--	values
			--(26087, 2984,0,1,0),
			--(26222, 2984,0,1,0),
			--(25448, 2984,0,1,0)
		


		  --UPDATE UserCustomerAssignGroupMapping SET deleted =1 ,isAssignEnabled =0
		--where userCustomerAssignGroupId in 


     select * from Users where Email like '%EktaB@microland.com%'  -->  26087	, 26222, 25448
 
     select * from Users where userId  in ( 26087	, 26222, 25448)

	 --->  venkataramanaiahk@microland.com;MohammedKI@microland.com;SwetaS@microland.com

	 select * from Users where Email like '%SwetaS@microland.com%'  -->  26093	, 25892, 25893


     select * from UserCustomerAssignGroupMapping where userid in (26087, 26222,25448) 

     select * from AssignmentGroup where workgroupid in (256, 452)

     --->  373, 571

    select * from UserCustomerAssignGroupMapping where userid in (26087, 26222,25448) and custAssignmentGroupId in(
 	select custAssignmentGroupId from CustomerAssignmentGroupMapping where assignmentgroupId in (373, 571))

--		UPDATE UserCustomerAssignGroupMapping SET isAssignEnabled = 0, AssignToWorkgroup = 1
--		where userCustomerAssignGroupId in 
--		(
--			179204
--,179202
--,179203)



		select * from [dbo].[MIS_HMCL_EmailSend_Weekly] 

		select * from [dbo].[MIS_HMCL_EmailReport]

		select * from [dbo].[MIS_HMCL_EmailSendLocationWise]




		--> Update [dbo].[MIS_HMCL_EmailSend_Weekly]  set UserEmail = UserEmail+';smartcentersupport2@microland.com'

                            https://rmcops.microland.com/Account/mlrmc
                            https://rmcops.microland.com/Account/mlrmc 


							Microland -URL: https://rmcops.microland.com/Account/microland
                                Microland RMC -URL: https://rmcops.microland.com/Account/mlrmc



		select * from Users where loginName like '%SunilS1%'


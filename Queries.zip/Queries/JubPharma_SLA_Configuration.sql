
   select * from customer where customerName like '%Jubilant Pharma%'--  194

   select top 10 * from ServiceLevelObjective where serviceLevelAgreementId in (245, 246)  order by 1 desc

   select *  from Service where serviceName like '%CloudOps%'

			--503	CloudOps
			--504	CloudOps  ---> T  1
			--505	CloudOps  ---->T  2 
			--509	CloudOps

			select * from ServiceCustomerMapping where customerId = 194 and serviceId in (503, 504, 505, 509)

			select *  from Workgroup where workgroup like '%RMC Cloud%'  --->  625

			select * from AssignmentGroup where workgroupId = 625 --->  756	RMC Cloud

			select * from CustomerAssignmentGroupMapping where customerId =194 and assignmentgroupId in (
			select assignmentgroupId from AssignmentGroup where workgroupId = 625 )  ---> 756

			select * from CustomerAssignmentGroupMapping where customerId =194 and assignmentgroupId = 756

			---->   2886	Jubiliant-RMC Cloud-Queue	194

			   select  * from ServiceLevelObjective where serviceLevelAgreementId in (245, 246)  and serviceId  in ( 504, 505) and workgroupId =625
			   order by 1 desc

			  select top 100  * from ServiceLevelObjective where serviceLevelAgreementId in (245)  and serviceId  in ( 504) 
			  order by 1 desc
			   
			          select * from ServiceLevelAgreement where customerId = 194

							-- ServiceLeveleAg
							--245	Jubilant Pharma- IM
							--246	Jubilant Pharma- SR

						select * from ServiceLevelObjectiveType 

						--1	Response SLA
						--2	Resolution SLA

			  	    select * from TicketStatus where ticketTypeId =1

					select * from TicketStatus where ticketTypeId = 2
	    
					select * from TicketStatus where statusId in (15,16,17,18)

					select * from Impact --->  1, 5, 6, 7

					select * from Priority where ticketTypeId = 1
					select * from Priority where ticketTypeId = 2

					 select top 100 * from ServiceLevelObjective order by 1 desc

					-- update ServiceLevelObjective set serviceId = 505 where serviceLevelObjectiveId in (
					-- 1881399
					--,1881398
					--,1881397
					--,1881396
					--,1881395
					--,1881394
					--,1881393
					--,1881392
					-- )

			  select top 1000  * from ServiceLevelObjective where serviceLevelAgreementId in (245, 246) and workgroupId =625   

			   select top 1000  * from ServiceLevelObjective where serviceLevelAgreementId in (246) 

			   --Insert into ServiceLevelObjective 
			   --(serviceLevelAgreementId, serviceLevelObjectiveTypeId, initialStatusId, finalStatusId, responseTimeInMin, serviceId, priorityId, excludeStatusIds,
			   --                                   impactId, holidayCalendarId, workHourId, is24X7Service, locationId, workgroupId, isDelete, isDefault )
      --         values (246, 2, 64 , 19, 1440, 504, 14,'15,16,17,18', 1, 0, 0,1, 0, 625, 0, 0),
			   --       (246, 2, 64 , 19, 1440, 504, 14,'15,16,17,18', 5, 0, 0,1, 0, 625, 0, 0),
					 -- (246, 2, 64 , 19, 1440, 504, 14,'15,16,17,18', 6, 0, 0,1, 0, 625, 0, 0),
					 -- (246, 2, 64 , 19, 1440, 504, 14,'15,16,17,18', 7, 0, 0,1, 0, 625, 0, 0)


							



			select  * from ServiceLevelObjective where    serviceId  in ( 504, 505) 
			order by 1 desc

		 select  top 100 * from  ServiceLevelObjective where is24X7Service =1

	     select * from ServiceLevelAgreement where customerId =194







		select * from WorkHours -->  19 	12:00am to 11:59pm Mon to Fri	12:00am to 11:59pm Mon to Fri	India Standard Time

		--->  89	12:00am to 11:59pm Mon to Sun	12:00am to 11:59pm Mon to Sun	India Standard Time


		select * from WorkHoursDetail where workHourId = 89



	



		


   select top 10 * from ServiceLevelAgreement where customerId = 194

			--1	245	Jubilant Pharma- IM	194
			--2	246	Jubilant Pharma- SR	194
			--3	247	Jubilant Pharma- CM	194

   select top 10 * from CustomerPriorityMapping where customerId = 194 order by 1 desc

   select serviceId, serviceName, * from Ticket where ticketNo = 2703723

            	select * from Priority where ticketTypeId = 1

				--> 1,5,9,27

				select * from Priority where ticketTypeId = 2

				--> 6,10,14,15,16

					select * from ImpactTicketTypeMapping where serviceId = 241 order by 1 desc
   
			select * from ImpactTicketTypeMapping where serviceId = 505 order by 1 desc

			--Insert into ImpactTicketTypeMapping (impactId, ticketTypeId, deleted, serviceId)

			select impactId, ticketTypeId, deleted, 504 from ImpactTicketTypeMapping where serviceId = 505 

			select * from ImpactTicketTypeMapping where serviceId = 504 order by 1 desc




			select  * from ImpactTicketTypeMapping where serviceId in (504, 505) order by 1 desc

			select  * from servicePriorityMapping where serviceId in (504, 505) order by 1 desc

			select * from CustomerPriorityMapping where customerId = 194 order by 1 desc

                    select top 10 * from ServiceLevelObjective order by 1 desc

			select * from ServiceCustomerMapping where customerId = 194

				    select * from Priority where ticketTypeId = 1

					select * from Priority where ticketTypeId = 2

		     select *  from Service where serviceName like '%CloudOps%'

			 select * from Requestor where requestorEmail like '%MLRMCCloudTeam@microland.com%'

			 select * from Requestor where requestorEmail like '%vigneshN@microland.com%'

			--Update requestor set deleted =0, requestorEmail='mlrmccloudteam@microland.com', requestorName = 'RmcCloudTeam', firstname='RmcCloudTeam', lastname='RmcCloudTeam', displayname='RmcCloudTeam'  where requestorId = 55474

			--> 55474	RMCBackupTeam	NULL	mlrmccloudteam@microland.com

			--->  56327	mlrmccloudteam	NULL	mlrmccloudteam@microland.com

			select * from CustomerRequestorMapping where requestorId = 55474

			select * from CustomerRequestorMapping where requestorId = 56327


			--503	CloudOps
			--504	CloudOps  ---> T  1
			--505	CloudOps  ---->T  2 
			--509	CloudOps

			select * from NotificationEmailTemplate where templateId = 1852
		    select * from NotificationEmailTemplate where customerId = 194

			select * from NotificationRules where deleted =0 and customerId =194 and workgroupid = 625 and duePercent is not null

			--->  $ASSIGNEDENGINEEREMAIL;$WORKGROUPEMAIL

			select * from NotificationRules where deleted = 0 and customerId =194  and duePercent in (60, 75, 90)  and serviceId = 504 -- and workgroupid =625
			and priorityId in (1, 5, 9)  order by duePercent

			---> 60 -- 1881
			---> 75 -- 1229
		    ---> 90 -- 1893

			--update NotificationRules set deleted =1 where ruleId in (2339728, 2339729)

			select * from NotificationRules where deleted = 0 and customerId =194  and duePercent in (60, 75, 90) and serviceId = 504 and workgroupid = 625
			and notifyBasedOnId = 2 and priorityId in (14)  order by duePercent

			select * from Workgroup where deleted =0 and  workgroup like '%RMC%'


			--Insert into NotificationRules (customerId, ticketTypeId, priorityId, duePercent, notificationMode, notificationTo, notificationCC, templateId, ruleName, workgroupid,
			--                               serviceId, notifyBasedOnId, entryStateId, deleted)

			--select customerId, ticketTypeId, 9, duePercent, notificationMode, '$ASSIGNEDENGINEEREMAIL;mlrmccloudteam@microland.com', 'rmcshiftmanager@microland.com;', templateId, ruleName,workgroupid ,
			-- serviceId, notifyBasedOnId, entryStateId, deleted  from NotificationRules where deleted = 0 and customerId =194  and duePercent in (60, 75, 90) and serviceId = 504 and workgroupid = 625
			--and notifyBasedOnId = 2 and priorityId in (1, 5, 9)  order by duePercent

			 select customerId, 2, 14, 90, notificationMode, notificationTo, notificationCC, 1893, 'SLA Resolution 90',workgroupid ,
			 serviceId, 3, entryStateId, deleted  from NotificationRules where deleted = 0 and customerId =194  and duePercent in (75) and serviceId = 504 and workgroupid = 625
			 and notifyBasedOnId = 2 and priorityId in (14)  order by duePercent 


			 select * from Users where email like '%HariTN@microland.com%'  --->  26182



			 -->  756 assignment groupid

			 select * from CustomerAssignmentGroupMapping where customerId =194 and assignmentgroupId in (756, 781, 979)

			 select * from RulesForAssignment where AssignToId = 26182

			  select * from Device where  customerId = 194 and deviceName like '%TRIADNPS%'
			  order by 1 desc

			  --Update Device set deleted =1 where deviceId = 23559

			  select * from DeviceServiceMapping where deviceId = 23559

			 select top 36 * from Device where deleted = 0 and customerId = 194
			 order by 1 desc  -->  30196



			 select distinct serviceId from DeviceServiceMapping where deviceId in (
			 30200
,30199
,30198
,30197
,30196
,30195
,30194
,30193
,30192
,30191
,30190
,30189
,30188
,30187
,30186
,30185
,30184
,30183
,30182
,30181
,30180
,30179
,30178
,30177
,30176
,30175
,30174
,30173
,30172
,30171
,30170
,30169
,30168
,30167
,30166
,30165
			 )

			 select * from Service where serviceId in (
			 503
			,504
			,505
			,509)

			 select top 1000 * from RulesForAssignment where customerId =194 and Deleted = 0

			 select top 100 * from RuleTemplates  

			 --->   14	{customerId=<<customerId>>;serviceId=<<serviceId>>;}

			  Select * from RulesForAssignment where  RuleTemplateId = 14 and  customerId =194 and Deleted = 0

			  --Insert into RulesForAssignment (RuleDescr, AssignmentRule, PrimaryAssignmentGroupId, SecondaryAssignmentGroupId, RulePriority, Deleted,RuleTemplateId 
			  --,customerId, AssignmentType,  NoOfParams)

			  values ('Rules', '{customerId=194;serviceId=503;}', 756, 756, 1, 0, 14, 194, 1, 2),
			         ('Rules', '{customerId=194;serviceId=504;}', 756, 756, 1, 0, 14, 194, 1, 2),
					 ('Rules', '{customerId=194;serviceId=505;}', 756, 756, 1, 0, 14, 194, 1, 2),
					 ('Rules', '{customerId=194;serviceId=509;}', 756, 756, 1, 0, 14, 194, 1, 2)

					 select * from Workgroup where workgroup like '%Service%'

					 select * from AssignmentGroup where assignmentgroupId in  
					 (select assignmentgroupId from CustomerAssignmentGroupMapping where deleted = 0 and customerId =194)

					 --->  670	Service Desk	542	5	0	2018-11-23 05:52:52.480	6

			  select * from RulesForAssignment where customerId =194 and PrimaryAssignmentGroupId = 670

			  

--			  update RulesForAssignment set RulePriority = 2 where ruleId in (
--			  71230
--,71231
--,73723
--,73724
--			  ) 

			   Select * from RulesForAssignment where  AssignToId = 26222
			  

			    Select * from RulesForAssignment where  customerId =194 and Deleted = 0
			   

			 select * from Workgroup where workgroup like '%RMC Cloud%'  ---> 625

			 select * from AssignmentGroup where workgroupId = 625  --->  756




  // reference ticket no:  IM2606482  
     --  21/7/2020: finding diff deviceServicemapping for SR and IM:

	 --select * from DeviceServiceMapping where serviceId in (select serviceId  from ServiceCustomerMapping
  --   where customerId = 3 and deleted = 0) and deleted = 0 and ticketTypeId = 1 and deviceId
  --   not in (select deviceId from DeviceServiceMapping where serviceId in (select serviceId  from ServiceCustomerMapping
  --   where customerId = 3 and deleted = 0) and deleted = 0 and ticketTypeId = 2)

	 -- 919900150778  -- darshan.

	   select  * from Customer where customerId = 4

	   select  * from Customer where customerName like '%Jub%' --> 194

	   select * from ServiceCustomerMapping where customerId = 194 and serviceId in (
	     select serviceId from service where serviceName like '%cloudops%'
	   )
	   

	   select  * from Customer where customerId = 158

	   select * from Device where hostName like '%AWSPWDBBA166%'

	   select * from service where serviceName like '%cloudops%'

	   select distinct d.deviceId, d.deviceName from deviceserviceMapping DM
	   inner join  Device D
	   on D.deviceId = DM.deviceId
	   where dm.serviceId in ( 503 , 504, 505, 509)and  d.deleted = 0 and d.ipAddress !='' and d.customerid = 194 and d.deviceName in ()


      --- update Device set deleted = 1 where deviceId in (
)






	   select deviceName, alternateName, ipAddress, hostName, customerId,  deleted ,  * from device where deviceName like '%punbrduo101%' and customerId = 3 and deleted = 0

	   select deviceName, alternateName, ipAddress, hostName, customerId,  deleted ,  * from device where deviceName like '%blrecoduo101%' and customerId = 3 and deleted = 0

	  -- update Device set deleted = 0 where deviceId = 26091

	    select deviceName, alternateName, ipAddress, hostName, customerId,  deleted,* from device where deviceName like '%hdueco-auto01.mlrmc.net%' and customerId = 4 and deleted = 0




     INSERT INTO device(devicename, alternateName, ipAddress, customerId, deleted, hostName) 
	  values 
('AWS-VSR-145','AWS-VSR-145','10.165.50.11',192, 0,'AWS-VSR-145')

--('AWS-VSR-074','AWS-VSR-074','10.160.16.23',192, 0,'AWS-VSR-074'),
--('AWS-VSR-075','AWS-VSR-075','10.160.16.24',192, 0,'AWS-VSR-075'),
--('AWS-VSR-076','AWS-VSR-076','10.160.16.25',192, 0,'AWS-VSR-076'),
--('AWS-VSR-077','AWS-VSR-077','10.160.16.26',192, 0,'AWS-VSR-077'),
--('AWS-VSR-078','AWS-VSR-078','10.160.16.27',192, 0,'AWS-VSR-078')




	
	

	        Select top 1 * from Device where customerId =192  order by 1 desc --> 40941

			select distinct serviceId from ServiceCustomerMapping 
			where customerId =192 and deleted = 0 and ticketTypeId = 4

			select top 50 * from smc_userotp order by 1 desc


			 --INSERT INTO DeviceServiceMapping (serviceId, deviceId , deleted, ticketTypeId)
			 -- VALUES (167, 40941, 0,1),
			 --        (168, 40941, 0,1),
				--	 (169, 40941, 0,1),
				--	 (502, 40941, 0,1),


		    Select top 38 * from Device where customerId = 194  order by 1 desc 


	        select * from Device where deviceId  In (
			29980
			,29979)


	  select * from DeviceServiceMapping where deviceId in (29980
      ,29979)

	       -- update Device set customerId = 3 where deviceId In (
			29980
			,29979)
			-- for jub life science

			select * from Service where serviceName like '%Cloud Service%' --> 479, 502

			select * from ServiceCustomerMapping where customerId =192 and deleted =0 AND serviceId in ( 499, 502)

		   --   INSERT INTO DeviceServiceMapping (serviceId, deviceId , deleted, ticketTypeId)
			  --VALUES (502, 30252, 0,1),
			  --       (502, 30251, 0,1),
					-- (502, 30250, 0,1),
					-- (502, 30249, 0,1),
					-- (502, 30248, 0,1),
					-- (502, 30247, 0,1),
				 --    (502, 30252, 0,2),
			  --       (502, 30251, 0,2),
					-- (502, 30250, 0,2),
					-- (502, 30249, 0,2),
					-- (502, 30248, 0,2),
					-- (502, 30247, 0,2),
					-- (502, 30252, 0,3),
			  --       (502, 30251, 0,3),
					-- (502, 30250, 0,3),
					-- (502, 30249, 0,3),
					-- (502, 30248, 0,3),
					-- (502, 30247, 0,3),
					-- (502, 30252, 0,4),
			  --       (502, 30251, 0,4),
					-- (502, 30250, 0,4),
					-- (502, 30249, 0,4),
					-- (502, 30248, 0,4),
					-- (502, 30247, 0,4)





				select * from Service where serviceName like '%DCS%'

				select * from ServiceCustomerMapping where customerId in (3, 4) and serviceId in ( 1, 19, 20) and deleted =0

				select * from MIS_HMCL_NewEmailReport 
				select * from MIS_HMCL_NewEmailReport
				select * from MIS_HMCL_NewEmailReport

				smartcentersupport2@microland.com
				smartcentersupport2@microland.com

   
       SELECT * FROM Customer C WHERE C.customerName LIKE '%eureka%'  -- 167	Eureka Forbes Limited	Eureka Forbes Limited	0
	   
	   SELECT * FROM Customer C WHERE C.customerId = 3

      -- INSERT INTO DeviceServiceMapping (serviceId, deviceId , deleted, ticketTypeId)
	  VALUES
	    (1,3268,0,2)
        ,(1,3269,0,2)


		select * from device where ipAddress in ('172.21.10.28', '172.21.10.29') and deleted = 0


   172.21.10.28
172.21.10.29


				10.101.155.1

				select * from Device where ipAddress ='10.101.155.1' and deleted = 0 and customerId = 167

				EFL_jaipur_Kota_Airtel_2mbps

--   3268  , ticket type 2
--  3269

   SELECT tOP  10 * FROM DeviceServiceMapping 

   SELECT * FROM Service S WHERE S.serviceName = 'DCS'  -- 196 , 198

   select Count(*) Total, serviceId, ticketTypeId, deviceid from (select * from  DeviceServiceMapping 
   where serviceId in (select distinct(serviceid) from ServiceCustomerMapping where customerId=3 and deleted=0 and ticketTypeId in (1,2)))
   as abc group by serviceId, deviceId,ticketTypeId



   select count (*), serviceId, deviceid from DeviceServiceMapping where serviceid in(

   select distinct(serviceid) from ServiceCustomerMapping SCM where scm.customerid =3 and deleted = 0
   ) AND serviceName LIKE '%dcs%'


   group by serviceId



   SELECT * FROM Feedbackconfig  

   select * from Workgroup T where T.workgroup like 'RMC Windows'

   select * from Device D where D.customerId = 3 and deleted = 0
     select * from Customer where customerId = 3
   -- escape -- 5570

       select * from device where deviceid in (
      select distinct (DSM.deviceId) from DeviceServiceMapping DSM where DSM.serviceId = 196 and DSM.deleted = 0
	  )


	  select distinct d.deviceId , d.deviceName, d.ipAddress from Device D
	  inner join DeviceServiceMapping DS 
	  on D.deviceId = DS.deviceId
	  where D.customerId = 4 and D.deleted = 0 and DS.deleted = 0

	  
	  select distinct d.deviceId, d.deviceName, Ds.serviceId, S.serviceName from Device D
	  inner join DeviceServiceMapping DS 
	  on D.deviceId = DS.deviceId
	  inner join Service S on S.serviceId = DS.serviceId
	  where D.customerId = 4 and D.deleted = 0 and DS.deleted = 0 and DS.ticketTypeId = 1


	  select distinct d.deviceId , d.deviceName, d.ipAddress from Device D
	  inner join DeviceServiceMapping DS 
	  on D.deviceId = DS.deviceId
	  where D.customerId = 4 and D.deleted = 0 and DS.deleted = 0 and DS.ticketTypeId = 1

	  select distinct d.deviceId , d.deviceName from Device D
	  inner join DeviceServiceMapping DS 
	  on D.deviceId = DS.deviceId
	  where D.customerId = 3 and D.deleted = 0 and DS.deleted = 0 and DS.ticketTypeId = 2


	  select distinct (deviceId), * from DeviceServiceMapping where Serviceid in (
	  select distinct serviceId from ServiceCustomerMapping where customerId = 3 and deleted = 0) and ticketTypeId =1  and deleted = 0



	


				select * from Device where ipAddress ='10.101.155.1' and deleted = 0 and customerId = 167

				EFL_jaipur_Kota_Airtel_2mbps



	  select top 100 * from device where deviceid in (
      select distinct (DSM.deviceId) from DeviceServiceMapping DSM where DSM.serviceId = 198 and deleted = 0
	  ) and deleted = 0


	    select top 100 * from device where customerid = 167 order by deviceid desc

		select top 98 * from device where customerid = 167 order by deviceid desc





	  -- DELETING THE DEVICES OF SERVICE --> 196

--	  UPDATE DeviceServiceMapping SET DELETED = 1 WHERE DEVICEID IN(5612,
5613,
5614,
5615,

)

     -- DELETING THE DEVICES OF SERVICE -->198

--UPDATE DeviceServiceMapping SET deleted = 1 WHERE deviceId IN (5612,
5613,
5614,

)

      -- INSERT DEVICES FOR SERVICE (DCS)  --19	  INSERT INTO device(devicename,alternateName,ipAddress,customerId,deleted,hostName) 
	  VALUES
	  
('ADFS-EFL','ADFS-EFL','10.1.0.8',167,0,'ADFS-EFL')




	  -- INSERT DEVICES FOR SERVICE (NCS) -- 19	  INSERT INTO device(devicename,alternateName,ipAddress,customerId,deleted,hostName) 
	  VALUES
,


   -- DeviceServiceMapping:

     -- For ticket type ids: 1, 2 , 3, 4, 
	 --   3268  , ticket type 2
--  3269

      select * from DeviceServiceMapping where serviceId = 1 and deviceId in (3268, 3269)

    ---  INSERT INTO DeviceServiceMapping (serviceId, deviceId , deleted, ticketTypeId)
	  VALUES
	    (1,3268,0,2)
        ,(1,3269,0,2)

	 -- For SERVICEID --> 196, TICKET TYPEID - 1,2,3,4
	 -- INSERT INTO DeviceServiceMapping (serviceId, deviceId,deleted,ticketTypeId) 
	  VALUES
 (196,27100,0,1)



    --   INSERT INTO DeviceServiceMapping (serviceId, deviceId, deleted, ticketTypeId)
	   VALUES
 (1,2792,0,2)
,(2,2792,0,2)


    
	 -- For SERVICEID --> 198, TICKET TYPEID - 1,2,3,4

	-- INSERT INTO DeviceServiceMapping (serviceId, deviceId, deleted, ticketTypeId)
	 VALUES

(198,27198,0,1),
(198,27197,0,1),


   --- 8/7/2020:

    select deleted * from DeviceServiceMapping where deviceId in (90
,92
,93
1)


	select deleted, customerId,  * from Device where ipAddress in ('172.21.65.10'
,'172.21.65.14'
,'203.90.5.194'
,'203.90.5.195'

)
 and customerId = 4

        -- UPDATE Device SET deleted = 1 WHERE deviceId IN (90
,92
,93
1)
         
		-- UPDATE DeviceServiceMapping SET deleted = 1 WHERE deviceId IN (90
,92
,93
,94
) 




-- customerId = 4

 select ipAddress, deviceName, * from Device where customerId = 4 and deleted =0 and ipAddress in  (
'203.90.5.129', -- MLRMC-Peer IP 	89
'203.90.5.225', -- IP203.90.5.225 - EcoSpace_TATA_Router	96

)

 select ipAddress, deviceName, * from Device where customerId = 4 and deleted =0 and deviceId in  (89, 96, 100, 105, 106)

   --  INSERT INTO device(devicename,alternateName,ipAddress,customerId,deleted,hostName) 
	  --VALUES

   --   UPDATE Device SET deviceName = 'MLRMCECO3FW01-pri-act', alternateName ='MLRMCECO3FW01-pri-act', hostName ='MLRMCECO3FW01-pri-act' WHERE deviceId = 89
   --   UPDATE Device SET deviceName = 'MLRMCBLR3R01', alternateName ='MLRMCBLR3R01', hostName ='MLRMCBLR3R01' WHERE deviceId = 96
	  --UPDATE Device SET deviceName = 'HDUECO-WUS01', alternateName ='HDUECO-WUS01', hostName ='HDUECO-WUS01' WHERE deviceId = 100
	  -- UPDATE Device SET deviceName = 'HDUECO-RDS01', alternateName ='HDUECO-RDS01', hostName ='HDUECO-RDS01' WHERE deviceId = 105
	  --UPDATE Device SET deviceName = 'HDUECO-PDC01', alternateName ='HDUECO-PDC01', hostName ='HDUECO-PDC01' WHERE deviceId = 106
	  --UPDATE Device SET deviceName = 'HDUECO-PDC01', alternateName ='HDUECO-PDC01', hostName ='HDUECO-PDC01' WHERE deviceId = 2768
	  --UPDATE Device SET deviceName = 'MLRMCECO3FW01-sec-stby', alternateName ='MLRMCECO3FW01-sec-stby', hostName ='MLRMCECO3FW01-sec-stby' WHERE deviceId = 2795
	  --UPDATE Device SET deviceName = 'HDUECO-MON03', alternateName ='HDUECO-MON03', hostName ='HDUECO-MON03' WHERE deviceId = 3251
	  --UPDATE Device SET deviceName = 'HDUECO-WUS01', alternateName ='HDUECO-WUS01', hostName ='HDUECO-WUS01' WHERE deviceId = 4719
	  --UPDATE Device SET deviceName = 'HDUECO-PDC01', alternateName ='HDUECO-PDC01', hostName ='HDUECO-PDC01' WHERE deviceId = 4720
	  --UPDATE Device SET deviceName = 'HDUECO-RDS01', alternateName ='HDUECO-RDS01', hostName ='HDUECO-RDS01' WHERE deviceId = 4723
	  --UPDATE Device SET deviceName = 'HDUECO-MON03', alternateName ='HDUECO-MON03', hostName ='HDUECO-MON03' WHERE deviceId = 4726
	  --UPDATE Device SET deviceName = 'HDUECO-SLS01', alternateName ='HDUECO-SLS01', hostName ='HDUECO-SLS01' WHERE deviceId = 4730
	  --UPDATE Device SET deviceName = 'HDUECO-DHP02', alternateName ='HDUECO-DHP02', hostName ='HDUECO-DHP02' WHERE deviceId = 4734
	  --UPDATE Device SET deviceName = 'HDUCYP-NAS01', alternateName ='HDUCYP-NAS01', hostName ='HDUCYP-NAS01' WHERE deviceId = 4739
	  --UPDATE Device SET deviceName = 'HDUCYP-HYP03', alternateName ='HDUCYP-HYP03', hostName ='HDUCYP-HYP03' WHERE deviceId = 4742
	  --UPDATE Device SET deviceName = 'HDUECO-DHP01', alternateName ='HDUECO-DHP01', hostName ='HDUECO-DHP01' WHERE deviceId = 6009


	  select * from Device where customerId = 4 and deleted = 0 
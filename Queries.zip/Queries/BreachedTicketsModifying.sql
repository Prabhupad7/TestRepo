


select * from ServiceLevelTracking l where l.sourceId=2516842
select t.ResponseSLAStatus, * from ticket t where t.ticketNo=2516842



update ServiceLevelTracking set actualDuration=23,adjustedDuration=23,isBreached=0 where serviceLevelTrackingId=5557884
update ticket set ResponseSLAStatus='Met'  where ticketNo=2516841

update ServiceLevelTracking set actualDuration=23,adjustedDuration=23,isBreached=0 where serviceLevelTrackingId = 5557882
update ticket set ResponseSLAStatus='Met'  where ticketNo=2516842

update ServiceLevelTracking set actualDuration=23,adjustedDuration=23,isBreached=0 where serviceLevelTrackingId = 5557887
update ticket set ResponseSLAStatus='Met'  where ticketNo=2516844

update ServiceLevelTracking set actualDuration=23,adjustedDuration=23,isBreached=0 where serviceLevelTrackingId = 5557918
update ticket set ResponseSLAStatus='Met'  where ticketNo=2516859

update ServiceLevelTracking set actualDuration=23,adjustedDuration=23,isBreached=0 where serviceLevelTrackingId = 5557918
update ticket set ResponseSLAStatus='Met'  where ticketNo=2516880




--IM2516841


--SR2516842

--SR2516844

--IM2516859
  IM2516880


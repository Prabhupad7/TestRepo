


      ------>  narender.singh@heromotocorp.com





      select * from Requestor where requestorEmail like '%mdasheef.nagaralli@heromotocorp.com%'  --->  7480	Shubham 

      select * from Requestor where requestorEmail like '%sudipkumar.giri@heromotocorp.com%' --->  58543

	  select * from Hero_Users where emailAddress like '%sudipkumar.giri@heromotocorp.com%'

	  ----->  Adding User IN Requestor Table:

	  select * from Requestor where requestorEmail ='mohit.gupta@heromotocorp.com'  --->  57294

	  --->  Sales&Marketing

	  --Update Requestor set requestorName='Nikhil Gupta', lastname='Gupta', displayname='Nikhil Gupta'
	  --, department ='Sales&Marketing' where requestorId = 58142
	  
	   select * from CustomerRequestorMapping where requestorId = 58164

	   select * from Requestor where requestorEmail like '%pranav.amle.ext@heromotocorp.com%'

	--> 313	akansha saxena	akansha.saxena@heromotocorp.com	Yes	No	Yes	No	No	32

	      select * from Requestor where requestorEmail like '%pushpendra.singhdasoondi@heromotocorp.com%'

		  select * from Hero_Users where emailAddress like '%pushpendra.singhdasoondi@heromotocorp.com%'

	    --Insert into Hero_Users (firstName, lastName, emailAddress, mobilePhone1, workAddress1,employeeId,employeeTitle, department)
	    --values ('Sudip Kumar', 'Giri', 'sudipkumar.giri@heromotocorp.com', '', 'HR1K', '13991','', '' )



	   select * from Hero_Users where emailAddress =  'pranav.amle.ext@heromotocorp.com' --->   5477

	   --update Hero_Users set employeeId = 13956   where id = 5477




	  --Update Requestor set requestorName='Varun Dinkar', lastname='Dinkar', displayname='Varun Dinkar',
	  --failedLoginAttemptCount=0 where requestorId = 50108

  --Insert into Hero_Users (firstName, lastName, emailAddress, mobilePhone1, workAddress1, employeeId, employeeTitle, 
  -- department)

  -- values ('Gouri', 'Soni', 'gouri.soni@heromotocorp.com', '919351236883','HCHO2-The Grand -HO2', null, null,   null),

  --        ('Vaishali', 'Verma', 'vaishali.verma@heromotocorp.com', null,null, null, null, null),

		--  ('Simran', 'Dhyani', 'simran.dhyani@heromotocorp.com', null,'HCHO2-The Grand -HO2', null, null, null),
		--  ('Chandni', '', 'chandni@heromotocorp.com', '917850086408','HCHO2-The Grand -HO2', null, null, null)




      select * from Hero_Users where emailAddress like '%chandni@heromotocorp.com%' ---->  1040

	  select * from Hero_Users where emailAddress like '%varun1@heromotocorp.com%'

	  ---->  Update Hero_Users set lastName ='Dinkar' where id = 1040

	  select * from CustomerRequestorMapping where requestorId = 50108


	  select * from CustomerRequestorMapping where requestorId = 57613

   ---->   918744993370

   --->  13895, 

   select * from Hero_Users where emailAddress like '%varun1@heromotocorp.com%'

   select * from Hero_Users order by 1 desc

    select * from Requestor where alias like '%abhyuday.banafer@heromotocorp.com%' ----->   58145

   --Insert into Hero_Users (firstName, lastName, emailAddress, mobilePhone1, workAddress1, employeeId, employeeTitle, 
   --department)

   --values ('shreya', 'kulkarni', 'shreya.kulkarni@heromotocorp.com', '919325242830','Nagpur Area Office', 13901 , 'Graduate Engineer Trainee',   'Ao Nagpur')

    

   --->   IM2772072

      select * from ServiceLevelTracking where sourceId = 2802107  --->  


   -- Update ServiceLevelTracking set statusId = 3 where sourceId = 2802107 


   select top 100 * from ServiceLevelAgreement where serviceLevelId in (73, 74)

   select * from ServiceLevelObjective 
   where serviceId =68 and isDelete =0 
   and serviceLevelObjectiveTypeId =1 and finalStatusId = 3


   select distinct initialStatusId, finalStatusId from ServiceLevelObjective 
   where serviceId =68 and isDelete =0 
   and serviceLevelObjectiveTypeId = 1 and workHourId in (89, 114) and  finalStatusId in (3, 14)

   select * from ServiceLevelObjective 
   where serviceId =68 and isDelete =0 
   and serviceLevelObjectiveTypeId = 1 and workHourId in (89, 114) and finalStatusId in (3, 14) 
   and workgroupId in (212,551,217,264,465,462,467,206,464,195,216,200,466,468,247,463)

   select * from ServiceLevelObjective where workgroupId = 463

   select count(distinct workgroupId) from ServiceLevelObjective 
   where serviceId =68 and isDelete =0 
   and serviceLevelObjectiveTypeId = 1 and workHourId in (89, 114) and finalStatusId in (3, 14) 

   select * from Workgroup where workgroup like '%Bagmane%' --->  463

   select * from Workgroup where workgroupId in (212,551,217,264,465,462,467,206,464,195,216,200,466,468,247,463)

   select * from TicketStatus where  status like '%Assigned%'

   --->  2	Assigned   1	2
   --->  13	Assigned   64	13


   select  * from WorkHours where name like '%08.00am to 08.00am Mon to sat%' --->  114

   ---->   12:00 AM tO 11:59 PM (Mon to Sun)

   select  * from WorkHours where name like '%12:00am to 11:59pm Mon to Sun%' --->  89

   select count(*) from HMCL_13012021



 --  	Insert into Requestor (requestorName, requestorEmail, isCriticalUser,employeeId, firstname, lastname,  alias, department, location, mobileno, 
	--createdOn, UpdatedOn, createdby, updatedby, deleted, LastLoginTime,CountryCode, failedLoginAttemptCount, isAccountLocked)

	--values 
	--('eShop Support', 'eshop.support@heromotocorp.com', 0, '', 'eShop', 'Support', 'eshop.support@heromotocorp.com', 'IS', 'Corporate Office - Vasant Vihar' ,'917045410724',
	--GETDATE(), GETDATE(), 6, 6, 0, GETDATE(), 91, 0, 0),
	--('eShop	Info', 'eshop.info@heromotocorp.com', 0, '', 'eShop', 'Info', 'eshop.info@heromotocorp.com', 'IS', 'Corporate Office - Vasant Vihar' ,'917045410724',
	--GETDATE(), GETDATE(), 6, 6, 0, GETDATE(), 91, 0, 0),


		select * from CustomerRequestorMapping where requestorId  = 58145


		--Insert into CustomerRequestorMapping (requestorId, customerId, customerName, isLoginAllowed)
		--values 
		--(58496, 68, 'Hero MotoCorp Ltd', 0),
		--(58504, 68, 'Hero MotoCorp Ltd', 0),

		
		select top 1000 * from Requestor where requestorEmail like '%mike.clarke@heromotocorp.com%'

		--('	', 'mike.clarke@heromotocorp.com', 0, '', 'Mike', 'Clarke', 'mike.clarke@heromotocorp.com', '', 'HMCI' ,'',
	--GETDATE(), GETDATE(), 6, 6, 0, GETDATE(), 91, 0, 0),

	select * from CustomerRequestorMapping where requestorId = 4177

  --Insert into Hero_Users (firstName, lastName, emailAddress, mobilePhone1, workAddress1, employeeId, employeeTitle, 
  -- department)

  -- values

  --  ('Rajasekhar', 'Vardineni', 'rajasekhar.vardineni@heromotocorp.com', '918655850291','HMCI', '13911' , 'Senior Engineer',   'IS'),


  -- ('eShop', 'Support', 'eshop.support@heromotocorp.com', '917045410724','Corporate Office - Vasant Vihar', '' , '',   'IS'),
  -- ('eShop', 'Info',  'eshop.info@heromotocorp.com', '917045410724','Corporate Office - Vasant Vihar', 13932 , 'Senior Engineer',   'IS'),
  -- ('eShop', 'Admin', 'eshop.admin@heromotocorp.com', '917045410724','Corporate Office - Vasant Vihar', '' , '',   'IS'),
  -- ('eShop', 'Grievance Officer', 'eshop.grievance.officer@heromotocorp.com', '917045410724','Corporate Office - Vasant Vihar', '' , '',   'IS'),
  -- ('eShop', 'Infringement', 'eshop.infringement@heromotocorp.com', '917045410724','Corporate Office - Vasant Vihar', '' , '',   'IS'),
  -- ('eShop', 'OrderUpdate', 'eshop.orderupdate@heromotocorp.com', '917045410724','Corporate Office - Vasant Vihar', '' , '',   'IS'),
   
  -- ('Neha', 'Shreya', 'neha.shreya.interns@heromotocorp.com', '917808161089','Corporate Office - Vasant Vihar', 90124266 , 'Summer Intern',   'SAS'),
  
  -- ('100million', '', '100million@heromotocorp.com', '','HMCI', '' , '',   ''),
  
  -- ('nikhil1', 'ext', 'nikhil1.ext@heromotocorp.com', '918806838675','Cit Jaipur', 90121993 , '',   'IS'),
  
  -- ('Shiv', 'Kumar', 'shiv.kumar.ext@heromotocorp.com', '','Cit Jaipur', 90036005 , 'Project Support',   'Styling&Des'),
   
  -- ('Pooja', 'Negi', 'pooja.negi@heromotocorp.com', '919760552509','Corporate Office - Delhi', 13920 , 'Diploma Engineer Trainee',   'HR'),
   
  -- ('Mobile App2', 'Support', 'mobileapp2.support@heromotocorp.com', '919877038266','HMCI', 90122071 , 'Consultant',   'IS'),
  
  -- ('Karan', 'Bhola', 'karan.bhola.ext@heromotocorp.com', '919501133602','Cit Jaipur', 90123398 , 'Project Support',   'Styling&Des'),
   
  -- ('Pushkar', 'Kumar Tiwari', 'pushkar.tiwari@heromotocorp.com', '918979402909','HM3H', 90015712 , 'Associate',   'OBL'),
   
  -- ('Anjali', 'Rana', 'anjali.rana@heromotocorp.com', '917830216790','Corporate Office - Delhi', 13921 , 'Diploma Engineer Trainee',   'HR'),
   
  -- ('JuanCamiloAguilar', 'Londono', 'juancamilo.aguilar@heromotocorp.com', '573197089950','Corporate Office - Delhi', 13897 , 'Deputy Manager',  'Bharti Office'),
  
  -- ('Manju', 'Matiyali', 'manju.matiyali@heromotocorp.com', '917248592514','Corporate Office - Delhi', 13923 , 'Diploma Engineer Trainee',   'HR')
   
    select top 18 * from Hero_Users order by  1 desc


	select * from Workgroup where workgroup like '%RMC SOC%' ---->  

	-- 104
 --    731

  select * from Assignmentgroup where workgroupid in (104,731) ---->  


  select * from Customer where customername like '%MenaBev%'

  select * from CustomerAssignmentGroupMapping 
  where assignmentgroupId in( 164, 866 ) and deleted = 0  and customerid = 217  ---->  164

  --Insert into CustomerAssignmentGroupMapping (custAssignmentGroupName, customerId,customerName,	assignmentgroupId,	deleted,UpdatedBy,	UpdatedDateTime	, CreatedBy,	CreatedDateTime)

  --values ('MenaBev - RMC SOC', 217, 'MenaBev', 164, 0, 6, getdate(), 6, getdate()) ---->  3045

  select * from users where email like '%siddharthm@microland.com%' --->  24278

  select * from UserCustomerAssignGroupMapping where userid in (24278) and custAssignmentGroupId = 3045  ----->  

  --insert into UserCustomerAssignGroupMapping( userId,custAssignmentGroupId,	deleted,	isAssignEnabled	, AssignToWorkgroup)

  --values (24278,3045, 0, 0,0)


  ---->   HMCL tickets issues: SR2842851  SR2854395  SR2839981  SR2839981

  ---->   IM2441799

  --exec deletetickets @ticketNo = '2441799';

  select * from customer where customerid = 68


  select * from NotificationHistory where ticketno = '2854395'

  select * from NotificationHistory where ticketno = '2842851'

  select * from NotificationRegistry where sourceid = '2854395'

  select * from NotificationRegistry where sourceid = '2842851'


  ---------> 

      select * from NotificationRegistry where sourceid = '2855493'

	  select * from NotificationHistory where ticketno = '2855493'



 --update q set deleted = 1

  --select classification, classificationId
  --from classification q
  --where exists
  --(
  --  select *
  --    from classification q2
  --    where q2.[classificationId] = q.[classificationId] and subCategoryId = 976 and 
  --      q2.classificationId > q.classificationId
  --)

      select * from SubCategory where categoryId = 343
	 and subCategory in (
      'Menu / Link Unavailable '
	 )
	order by subCategory



		  WITH cte AS
		( SELECT  subCategoryId, classificationId, classification,  ROW_NUMBER() OVER ( PARTITION BY  subCategoryId, classification ORDER BY classificationId, classification)
		row_num  FROM  classification where  deleted=0 
		and subCategoryId In (		
		select distinct SB.subCategoryId from SubCategory SB
		inner join Category CG on CG.categoryId = SB.categoryId
		inner join ServiceCategoryMapping SCM on SCM.categoryId = CG.categoryId
		inner join ServiceCustomerMapping SC On SC.serviceId = SCM.serviceId
		where SC.customerId = 1 and SC.deleted = 0 and CG.deleted =0 and SCM.deleted = 0 and SCM.ticketTypeId =1		
		)
		)
		SELECT * FROM cte WHERE row_num > 1;



		


		select * from Customer 

		select distinct Sc.serviceId from SubCategory SB
		inner join Category CG on CG.categoryId = SB.categoryId
		inner join ServiceCategoryMapping SCM on SCM.categoryId = CG.categoryId
		inner join ServiceCustomerMapping SC On SC.serviceId = SCM.serviceId
		where SC.customerId = 1 and SC.deleted = 0 and CG.deleted =0 and SCM.deleted = 0	


		select distinct serviceId from ServiceCustomerMapping where customerId =1 and deleted =0



    
  --- EXEC Usp_AssetDeletetionByAssetId 12345


      select * from TicketStatus where tickettypeid = 1

	  ---> 2	Assigned

      select * from priority where tickettypeid = 2  ---> 9	P3

	  select * from ticketStatus where  tickettypeid = 2---> 13	Assigned

	  select * from Impact

	  --exec deletetickets @ticketNo = '2559988'

	  ---> 9	P3

    select t.customerId,TicketTypeid,t.serviceid, t.serviceName,t.priorityid,t.priorityname ,t.statusid,t.statusName,t.categoryId, t.subCategoryId, t.classificationid,impactId, impactName, deviceId, deviceName
	,* from ticket t where t.ticketno= 3156749   -- 14	SR3  9	P3   10823	Generic

	--Update Ticket set statusId = 5, statusName='On Hold (Customer)'
	----categoryId=62, categoryName='Network',
	----subCategoryId=368, subCategoryName='Network', classificationId=235, classificationName='Others-Undefined'
	--where ticketNo = 3156749

	select requestorId,* from Ticket where ticketNo= 3156749 --> 5870

	select * from Requestor where requestorId = 5870

	--Update Requestor set department ='SC,MM and Ind/MRO'
	--where requestorId = 5870

	select * from ServiceCustomerMapping where customerId = 182 
	and deleted = 0 and ticketTypeId = 2  --> 494

	select * from Service where serviceId = 494 ---> 494	Knowledge Management


	select * from ServiceCategoryMapping where serviceId = 494 and ticketTypeId = 2 ---> 5316

	select * from Category where categoryId = 5316  ---> 5316	Active Directory

	select * from SubCategory where categoryId = 5316  ---> 20822	others

	select * from Classification where subCategoryId = 20822  ---> 85872	others

	--Update Ticket set serviceId = 494, serviceName='Knowledge Management', categoryId=5316, categoryName='Active Directory',
	--subCategoryId=20822, subCategoryName='others', classificationId=85872, classificationName='others'
	--where ticketNo = 3164947

	
	      select * from DeviceServiceMapping where serviceid = 4 ---> 63	MUM-BO-S025

		  select * from DeviceServiceMapping where deviceId = 63  

		  select * from ServiceCategoryMapping where serviceId = 1 
		  and ticketTypeId = 2 and deleted = 0 --> 1728

		  select * from Category where categoryId = 1728 --> 1728	Airwatch

		  select * from SubCategory where categoryId = 1728 ---> 4985	Airwatch - New Enrollment

		  select * from Classification where subCategoryId = 4985 ---> 9079	Others-Undefined

		  --Update Ticket set categoryId = 1728, categoryName = 'Airwatch', subCategoryId = 4985, 
		  --subCategoryName ='Airwatch - New Enrollment', classificationId = 9079, classificationName ='Others-Undefined'
		  --where ticketNo = 1672711
		 
		  --update ticket set priorityid=27, priorityName='P4', statusId=1, statusName='Open'		  
		  --where ticketno = 1614686

	select * from servicecustomerMapping where serviceid = 4 and customerid = 1

    

	  --update ticket set categoryId= 996, categoryName ='Others', subCategoryId=4748 , subCategoryName ='Request For Information',
	  --classificationId =8769, classificationName ='Request For Information'
	  --where ticketno = 1448687



	  --Update ticket set serviceId = 328, serviceName = 'DCS', deviceId= 10823, deviceName='Generic',categoryId = 4102,
	  --categoryName ='Application',
	  --subCategoryId= 17601, subCategoryName ='Software-Druva', classificationId = 74733, classificationName='System down or slow' 
	  --where ticketno = 3030382

	  select * from SubCategory where categoryId = 3883

	  select * from Classification where subCategoryId = 16122

	  select d.deviceId, d.deviceName from DeviceServiceMapping DC 
	  inner join Device D on D.deviceId = DC.deviceId
	  where serviceId = 2 and ticketTypeId =2 and d.deleted =0 and dc.deleted = 0



	---->   26, 2021 18:38:10 (Status set to Open)

	select * from Service where serviceid = 68 ---- 68  CIS

	select * from ServiceCustomerMapping where customerid =1 and serviceid = 4

	select * from ServiceCategoryMapping 
	where deleted = 0 and serviceId = 4 and Categoryid = 496

	select * from Category where  category like '%Logistic%'  ----> 2114	Network /Communication

	select * from Category where  Categoryid = 496  ---> 496	 Hardware Issue

	--Update ticket set serviceName ='Datacenter', createdOn= '2021-02-26 18:38:10' where ticketno= 2879449 

	--Update ticket set subCategoryName='GPO' where ticketno= 2879449 

	select * from SubCategory where  categoryId = 496 ----> 1480	Tape Drive Faulty

	select * from Classification where subCategoryId = 1480  ---> 3215	Others-Undefined

	  select * from Customer where customerName like '%SMC%'


	  select * from ServiceLevelTracking where sourceId = 2982200  


	 -- update ticket set priorityid=16, priorityName='SR4' where ticketno = 1453555


select * from ticketstatus where tickettypeid in (2) -- 1,64

select * from priority where priority like '%p4%' and tickettypeid=1

select * from priority where  tickettypeid = 2

select * from priority where priority like '%p3%' and tickettypeid=1

select * from ticketstatus where status = 'open' and tickettypeid in (1,2) -- 1,64

---------------------

 -- For IM tickets issue: 
   --    IM2622230, --  IM2624433  8/4/2020:  IM2635497 IM2635884

   select t.priorityid,t.statusid, t.statusName, t.priorityName, t.TicketTypeid ,t.impactId, t.impactName,t.serviceId, t.serviceName, * 
   from ticket t where t.ticketno= 3004266  -- 14, 	13

   select * from Impact

   --- 4604	Generic Email Ticket	18816	Generic Email Ticket	79681	Generic Email Ticket

   select * from Category where categoryId = 4604

   select * from Service where serviceId = 313

   select * from ServiceCustomerMapping where serviceId = 313 and customerId =190 and deleted = 0

   --InSert into ServiceCustomerMapping(serviceId, customerId, deleted, ticketTypeId)

    ---- values (313, 190, 0, 1)
    

 --   Update ticket set priorityid=15, priorityName = 'SR4',statusId = 13 , statusName = 'Assigned', impactId =5, impactName ='Low'
	--where ticketno= 3004266

   -- Update ticket set priorityid=9, priorityName = 'P3',statusId = 1,impactId =1, impactName ='None'  where ticketno= 2670753


   select * from priority where priority like '%SR3%' and tickettypeid=1

   select * from priority where priority like '%p3%' and tickettypeid=1

   select * from ticketstatus where tickettypeid =1

   Select * from priority where ticketTypeId =2


   --REquestorCustomerMapping

   select * from users where mobileNo = '7043276664'

   select * from Users where loginName like '%LO3424%'  --- 684	Amruta	Chavan	Amruta Chavan


    select * from Role where deleted = 0 and Name like '%EFL%'  --- 86	EFL_Quinnox_Engineer	EFL Quinnox Engineer

	---------  CM2528061


	select t.priorityid,t.priorityName,t.statusid, statusName ,* from ticket t where t.ticketno=2528061 -- 11, 	32

	---11	31	Pending CM Approval	2528061

--   update ticket set statusId=32, statusName ='Pending CM Approval' where ticketno=2528061

   select * from TicketType 

select * from priority where priority like '%SR3%' and tickettypeid=3  -- 3	Change	CHN

select * from priority where priority like '%p3%' and tickettypeid= 3   --- 11	P3


select * from ticketstatus where tickettypeid in (3) -- 29  --- 31	Work in Progress	0	3

select * from ticketstatus where status = 'open' and tickettypeid in (1) -- 29

---  Pending CM Approval

----- 
select t.priorityid,t.statusid, * from ticket t where t.ticketno=2689764 -- 14, 	13

    select * from TicketType
    
	---  4	Problem	PRO
	select * from Priority where ticketTypeId = 4


	select t.priorityid,t.priorityName,t.statusid, statusName ,t.impactId,t.impactName, * from ticket t where t.ticketno=2689764 -- 11, 	32

	-- update Ticket set statusId = 39 ,statusName ='Resolved' where ticketNo =2689764

	select * from TicketStatus where ticketTypeId = 4
 
    select * from AssignmentGroup where assignmentgroupId = 140

	select * from CustomerAssignmentGroupMapping where assignmentgroupId = 140


	--------------> 

	select * from ServiceLevelTracking where sourceId in (3004266,3004299)   ----> 

	select * from ServiceLevelTracking where sourceId = 3004299

	--Update ServiceLevelTracking set actualEndTime = NULL where serviceLevelTrackingId = 6896727

	select * from ServiceLevelObjective where serviceId = 68 and priorityId = 15 and impactId = 15 

--	delete from  ServiceLevelTracking where serviceLevelTrackingId in (
--6896724,
--6896725
--	)

     select * from Customer where customerName like '%BUnge%' ----> 218	Bunge

	 select * from Requestor  where requestorEmail like '%RMCcollabora%' ----> 

	 select * from CustomerRequestorMapping where customerId = 218 and requestorId in (
16955,
50414,
2968
	 )


	 select * from Workgroup where workgroup  like '%RMC to%' ---> 13	RMC Tools

	 select * from AssignmentGroup where workgroupId = 13 ----> 13	RMC Tool,  867	RMC Tools

	 select * from CustomerAssignmentGroupMapping where customerId = 218 ---> 2992	Bunge - RMC Tools	218	Bunge	13	0	6	2020-12-11 16:28:31.027	6	2020-12-11 16:28:31.027

	 --update CustomerAssignmentGroupMapping set deleted = 1 where custAssignmentGroupId = 2992

	 ---->  

	 select * from Requestor where requestorEmail like '%JustinH@microland.com%' ---> 447725258024

	 select * from NotificationRules where notificationCC like '%7725258024%'


------------------------------->

select * from customer where customerName like '%MLCIS%'  ----> 3	MLCIS

--Retheesh Kumar	9972525245
--Karthik P	9845308429
--Veeresh K	9611144288
--Deepak M	6282907583


select * from NotificationRules 
where deleted = 0 and  customerId = 3 
and notificationMode like '%AWSSMS%' and priorityId = 1 
and notificationTO like '%6282907583%'

--Update NotificationRules set notificationTo = notificationTo +',9972525245,9845308429,9611144288,6282907583,'
--where deleted = 0 and  customerId = 3 
--and notificationMode like '%AWSSMS%' and priorityId = 1 and ticketTypeId =1

select * from ServiceLevelAgreement where customerId = 147  ----> 74	Ask ML SR

select * from ServiceLevelObjective where serviceLevelAgreementId =  74 and workgroupId in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687) and serviceId = 84  and workHourId = 38


select * from WorkHoursDetail

select * from WorkHours  ----> 38	9:30am to 6:30pm	9:30am to 6:30pm	India Standard Time

select distinct workHourId from ServiceLevelObjective where serviceLevelAgreementId =  74 and workgroupId in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687) and serviceId = 84 and serviceLevelObjectiveTypeId  = 2





--Update ServiceLevelObjective set workHourId = 38
--where serviceLevelAgreementId =  74 and workgroupId in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
--,629
--,630
--,631
--,632
--,687) and serviceId = 84  and workHourId = 14


select * from Asset_users where EmailId like '%Sundeepp%'  ---> SundeepP@microland.com  62941 , mng: 55509

select * from Asset_users where id = 55509  ----> SarojKM@microland.com

select * from AutoTicketEventLog where ticketNo in (3039806, 3039743)

select * from Customer where customerName like '%JUb%' ----> 194	Jubilant Pharma

select * from ApiKey where customerId = 194 

select top 100 * from AutoTicketEventLog 
where apikeyId in (90,105,108,114,122,128,135,146,150) and inInformation like '%SPOKEXENDPOINT1%' ---> 3011630  IM3011630


select * from NotificationRegistry where sourceId in (3041784, 3041710 )

select * from NotificationRules where ruleId in (1658433,2066418,2329464,2329629,1658428,1658429,2066730,2134047,2134056,2066870,2329465,1588364,1874532,1658430,1874644,1658594,
1658595,1658596,1658726,1658727,1658728,1585546,1585549,1585557,1585546,1585549,1585557,1658726,1658727,1658728,1586481,1586484,1586492,1586481,1586484,1586492,1585546,1585549,
1585557,1585546,1585549,1585557,1588351,1588354,1588362,1658726,1658727,1658728,1658792,1588357,1594608,2067182,1594828,2067202,1594608,2067182,1659012,2069381,2213371,1588355,
2069261,2213371,1659012,2069381,2213371,1658433,2066418,2329464,2329629,1658428,1658429,2066730,2134047,2134056,2066870,2329465,1658594,1658595,1658596,1658726,1658727,1658728,
1585546,1585549,1585557,1585546,1585549,1585557,1594608,2067182) and notificationMode like '%AWSSMS%'

--REQUESTORPHONENO,  ASSIGNEDENGINEEREMOBILE

----> SR3045258


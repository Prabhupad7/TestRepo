




	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 86, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 86, 1, 21, 0, null, null, null


		insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 87, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 87, 1, 21, 0, null, null, null



		insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 88, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 88, 1, 21, 0, null, null, null


		insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 89, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 89, 1, 21, 0, null, null, null


		insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 90, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 90, 1, 21, 0, null, null, null


		insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 91, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 91, 1, 21, 0, null, null, null



		insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 92, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 92, 1, 21, 0, null, null, null


		insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 93, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 93, 1, 21, 0, null, null, null


		insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 150, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 150, 1, 21, 0, null, null, null


		insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 261, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 261, 1, 21, 0, null, null, null



		insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 262, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 262, 1, 21, 0, null, null, null




		insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 263, 1, 11, 0, null, null, null

	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 263, 1, 21, 0, null, null, null
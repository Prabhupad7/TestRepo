




select * from AssetEntityType where DisplayName like '%Wintel%'  --> 4	Laptop

----Id	Name
----17	Server (parent: )
----18	Wintel - Physical
----19	Wintel - Virtual

-----> PageId 3 Last Udated on:

select  * from Assets where SourceId in (18)

select top 1000  * from Assets where SourceId in (19)

-----> 

   --ALTER TABLE Wintel_11092021$ 
   --ADD AssetId int

select * from Wintel_11092021$ where sourceid  = 18 and AssetNumber is NULL

select * from Wintel_11092021$ where sourceid  = 19

--  IpAddress
--10.32.160.25

   select * from Assets A 
   inner join Wintel_11092021$ K 
   on A.MACAddress = K.MACAddress  and A.IpAddress = K.IpAddress1
   where K.Sourceid = 18

      select A.Hostname , K.Hostname,  A.IpAddress , K.IpAddress1  from Assets A 
   inner join Wintel_11092021$ K 
   on A.Hostname = K.Hostname  and A.IpAddress = K.IpAddress1
   where K.Sourceid = 19

   ------> Step 1:

   	--   Update K set K.AssetNumber = A.AssetNumber
	   --from Wintel_11092021$ K
	   --inner join Assets A 
	   --on  A.MACAddress = K.MACAddress  and A.IpAddress = K.IpAddress1
    --   where K.Sourceid = 18

	  -- Update K set K.AssetId = A.Id
	  -- from Wintel_11092021$ K
	  -- inner join Assets A 
	  --  on A.Hostname = K.Hostname  and A.IpAddress = K.IpAddress1
   --where K.Sourceid = 19


--   SELECT Hostname, COUNT(Hostname)
--FROM Wintel_11092021$ where SourceId in (19)
--GROUP BY Hostname
--HAVING COUNT(Hostname)>1

	select  * from Assets where SourceId in (18)

	select AssetID, * from Wintel_11092021$ where sourceid  = 18 and AssetNumber is NULL

	select AssetID, * from Wintel_11092021$ where sourceid  = 19 and AssetNumber is NULL

	select AssetID, * from Wintel_11092021$ where sourceid  = 18
	order by AssetNumber



	select * from Wintel_11092021$ where sourceid  = 18 and HostName='OTTP16TANNMSDR'
	select * from Wintel_11092021$ where sourceid  = 18 and HostName='OTTP12TANDLPDB1'

	--Update Wintel_11092021$ set AssetNumber = 132 where sourceid  = 18 and HostName='OTTP16TANNMSDR'

	--Update Wintel_11092021$ set AssetNumber = 133 where sourceid  = 18 and HostName='OTTP12TANDLPDB1'

	Step 2: 

		select  * from Assets where SourceId in (19)

	--Insert into Assets (CustomerId, SourceId, SourceTypeId, SerialNumber, MacAddress, IpAddress, Hostname, LocationName, Createdbyid, CreatedOn, 
	--StatusId, Status, Model, Vendor, Manufacturer, LastUpdatedOn, LastUpdatedBy, OSName, domain)

	--select  1, 19, 1, SerialNumber,MacAddress,IpAddress1, Hostname,LocationName, 6, GETDATE(), 30, Status,Make, Vendor, Model, GETDATE(),6, OSName, Domain
	--from Wintel_11092021$ where sourceid  = 19 and AssetNumber is NULL

	----> Step 2 or 3:


   	--   Update A set A.SerialNumber =K.SerialNumber, A.Hostname=k.Hostname, A.LocationName=K.LocationName, A.StatusId=30, A.Status=k.Status,
	   -- A.Model=k.Model, A.Vendor=K.Vendor, A.Manufacturer=K.Model,
	   -- A.LastUpdatedOn=GETDATE(), A.LastUpdatedBy=6, A.OSName=K.OSName, A.domain=K.Domain

	   --from Wintel_11092021$ K
	   --inner join Assets A 
	   --on  A.MACAddress = K.MACAddress  and A.IpAddress = K.IpAddress1
    --   where K.Sourceid = 18 and K.AssetID in (
	   --select AssetID from Wintel_11092021$ where sourceid  = 18
	   --)

	   ----> Step : 4


	   	select  * from Assets where SourceId in (18) 

		select AssetID, * from Wintel_11092021$ where sourceid  = 18 and AssetId in (		
24237,24238,24239,24240,24241,24242,24243,24244,24245,24246,24247,24248,24249,24250,24251,24252,24253,24254,
24255,24256,24257,24258,24259,24260,24261,24262,24263,24264,24265,24266,24267,24268,24269)


		select * from VarcharCustomAttribute where sourceid  = 18 and primaryid in (		
24237,24238,24239,24240,24241,24242,24243,24244,24245,24246,24247,24248,24249,24250,24251,24252,24253,24254,
24255,24256,24257,24258,24259,24260,24261,24262,24263,24264,24265,24266,24267,24268,24269)


--  Insert into VarcharCustomAttribute (
--CustomerId, SourceId, SourceType, PrimaryId, Varchar6, Varchar10, Varchar12, Varchar13,  
-- Varchar46, Varchar47, Varchar42, Varchar43, Varchar44, Varchar48, varchar49, Varchar50,   Varchar51,  Varchar52, 
-- Varchar53, Varchar54, Varchar57, Varchar58, Varchar59, Varchar60, Varchar63, Varchar64, Varchar65, 
-- Varchar66, Varchar67, Varchar68, Varchar69,  Varchar70, Varchar71, Varchar73,  Varchar82, Varchar83, Varchar84, Varchar85
--)

--		select 1, 19, 1, AssetId,PhysicalCPU, Isnull( RAMGB,''),Isnull( OSVersion,'') ,Isnull( OSServicePack,'') ,ChasisManagementIP, Subnet, Building, RackNo, ServerType,Gateway, DNSServer, 
--		Environment,Isnull( NetworkAdapter,'') , Traverse, ServerRole, ServiceRoleTataAIG,Isnull( Verified,'') , Isnull( VerifiedBy,'')  ,Isnull( VerificationRemarks,'') ,Isnull( PatchStatus,'') , [Noof CorePerCPU],
--		TotalCoreorThreads, CPUMake, CPUSpeed,Isnull( Partition1,'') ,Isnull( Partition2,'') ,Isnull( Partition3,'') ,Isnull( Partition4,'') ,Isnull( Partition5,'') , Isnull( WarrantyAMCEnd,'') , GroupName, GroupHead,
--		ApplicationOwner, ApplicationDetails
--     from Wintel_11092021$ where sourceid  = 19 and AssetId is not null
	 
	 -- and AssetId in (		
--24237,24238,24239,24240,24241,24242,24243,24244,24245,24246,24247,24248,24249,24250,24251,24252,24253,24254,
--24255,24256,24257,24258,24259,24260,24261,24262,24263,24264,24265,24266,24267,24268,24269)






	--Update assets set AssetNumber = 103 where id = 24237
	--Update assets set AssetNumber = 104 where id = 24238

	--Update assets set AssetNumber = 105 where id = 24239
	--Update assets set AssetNumber = 106 where id = 24240
	--Update assets set AssetNumber = 107 where id = 24241
	--Update assets set AssetNumber = 108 where id = 24242
	--Update assets set AssetNumber = 109 where id = 24243
	--Update assets set AssetNumber = 110 where id = 24244
	--Update assets set AssetNumber = 111 where id = 24245
	--Update assets set AssetNumber = 112 where id = 24246
	--Update assets set AssetNumber = 113 where id = 24247
	--Update assets set AssetNumber = 114 where id = 24248
	--Update assets set AssetNumber = 115 where id = 24249
	--Update assets set AssetNumber = 116 where id = 24250
	--Update assets set AssetNumber = 117 where id = 24251
	--Update assets set AssetNumber = 118 where id = 24252
	--Update assets set AssetNumber = 119 where id = 24253
	--Update assets set AssetNumber = 120 where id = 24254
	--Update assets set AssetNumber = 121 where id = 24255
	--Update assets set AssetNumber = 122 where id = 24256
	--Update assets set AssetNumber = 123 where id = 24257
	--Update assets set AssetNumber = 124 where id = 24258
	--Update assets set AssetNumber = 125 where id = 24259
	--Update assets set AssetNumber = 126 where id = 24260
	--Update assets set AssetNumber = 127 where id = 24261
	--Update assets set AssetNumber = 128 where id = 24262
	--Update assets set AssetNumber = 129 where id = 24263
	--Update assets set AssetNumber = 130 where id = 24264
	--Update assets set AssetNumber = 131 where id = 24265
	--Update assets set AssetNumber = 132 where id = 24266
	--Update assets set AssetNumber = 133 where id = 24267
									
	 select top 100 * from VarcharCustomAttribute where SourceId = 	18							

select * from Asset_AssetNumberConfiguration where AssetTypeId = 19 

--insert into Asset_AssetNumberConfiguration

--select 1, 19, NULL, NULL, 999999, 756, 0, null, null, 'S|Autogen'




--Update assets set AssetNumber =   515 where id =  15782
--Update assets set AssetNumber =   516 where id =  19540
--Update assets set AssetNumber =   517 where id =  19541
--Update assets set AssetNumber =   518 where id =  19542
--Update assets set AssetNumber =   519 where id =  19543
--Update assets set AssetNumber =   520 where id =  19544
--Update assets set AssetNumber =   521 where id =  19545
--Update assets set AssetNumber =   522 where id =  19546
--Update assets set AssetNumber =   523 where id =  19547
--Update assets set AssetNumber =   524 where id =  19548
--Update assets set AssetNumber =   525 where id =  19549
--Update assets set AssetNumber =   526 where id =  19550
--Update assets set AssetNumber =   527 where id =  19551
--Update assets set AssetNumber =   528 where id =  19552
--Update assets set AssetNumber =   529 where id =  19553
--Update assets set AssetNumber =   530 where id =  19554
--Update assets set AssetNumber =   531 where id =  19555
--Update assets set AssetNumber =   532 where id =  19556
--Update assets set AssetNumber =   533 where id =  19557
--Update assets set AssetNumber =   534 where id =  19558
--Update assets set AssetNumber =   535 where id =  19559
--Update assets set AssetNumber =   536 where id =  19560
--Update assets set AssetNumber =   537 where id =  19561
--Update assets set AssetNumber =   538 where id =  19562
--Update assets set AssetNumber =   539 where id =  19563
--Update assets set AssetNumber =   540 where id =  19564
--Update assets set AssetNumber =   541 where id =  19565
--Update assets set AssetNumber =   542 where id =  19566
--Update assets set AssetNumber =   543 where id =  19567
--Update assets set AssetNumber =   544 where id =  19568
--Update assets set AssetNumber =   545 where id =  19569
--Update assets set AssetNumber =   546 where id =  19570
--Update assets set AssetNumber =   547 where id =  19571
--Update assets set AssetNumber =   548 where id =  19572
--Update assets set AssetNumber =   549 where id =  19573
--Update assets set AssetNumber =   550 where id =  19574
--Update assets set AssetNumber =   551 where id =  19575
--Update assets set AssetNumber =   552 where id =  19576
--Update assets set AssetNumber =   553 where id =  19577
--Update assets set AssetNumber =   554 where id =  19578
--Update assets set AssetNumber =   555 where id =  19579
--Update assets set AssetNumber =   556 where id =  19580
--Update assets set AssetNumber =   557 where id =  19581
--Update assets set AssetNumber =   558 where id =  19582
--Update assets set AssetNumber =   559 where id =  19583
--Update assets set AssetNumber =   560 where id =  19584
--Update assets set AssetNumber =   561 where id =  19585
--Update assets set AssetNumber =   562 where id =  19586
--Update assets set AssetNumber =   563 where id =  19587
--Update assets set AssetNumber =   564 where id =  19588
--Update assets set AssetNumber =   565 where id =  19589
--Update assets set AssetNumber =   566 where id =  19590
--Update assets set AssetNumber =   567 where id =  19591
--Update assets set AssetNumber =   568 where id =  19592
--Update assets set AssetNumber =   569 where id =  19593
--Update assets set AssetNumber =   570 where id =  19594
--Update assets set AssetNumber =   571 where id =  19595
--Update assets set AssetNumber =   572 where id =  19596
--Update assets set AssetNumber =   573 where id =  19597
--Update assets set AssetNumber =   574 where id =  19598
--Update assets set AssetNumber =   575 where id =  19599
--Update assets set AssetNumber =   576 where id =  19600
--Update assets set AssetNumber =   577 where id =  19601
--Update assets set AssetNumber =   578 where id =  19602
--Update assets set AssetNumber =   579 where id =  19603
--Update assets set AssetNumber =   580 where id =  19604
--Update assets set AssetNumber =   581 where id =  19605
--Update assets set AssetNumber =   582 where id =  19606
--Update assets set AssetNumber =   583 where id =  19607
--Update assets set AssetNumber =   584 where id =  19608
--Update assets set AssetNumber =   585 where id =  19609
--Update assets set AssetNumber =   586 where id =  19610
--Update assets set AssetNumber =   587 where id =  19611
--Update assets set AssetNumber =   588 where id =  19612
--Update assets set AssetNumber =   589 where id =  19613
--Update assets set AssetNumber =   590 where id =  19614
--Update assets set AssetNumber =   591 where id =  19615
--Update assets set AssetNumber =   592 where id =  19616
--Update assets set AssetNumber =   593 where id =  19617
--Update assets set AssetNumber =   594 where id =  19618
--Update assets set AssetNumber =   595 where id =  19619
--Update assets set AssetNumber =   596 where id =  19620
--Update assets set AssetNumber =   597 where id =  19621
--Update assets set AssetNumber =   598 where id =  19622
--Update assets set AssetNumber =   599 where id =  19623
--Update assets set AssetNumber =   600 where id =  19624
--Update assets set AssetNumber =   601 where id =  19625
--Update assets set AssetNumber =   602 where id =  19626
--Update assets set AssetNumber =   603 where id =  19627
--Update assets set AssetNumber =   604 where id =  19628
--Update assets set AssetNumber =   605 where id =  19629
--Update assets set AssetNumber =   606 where id =  19630
--Update assets set AssetNumber =   607 where id =  19631
--Update assets set AssetNumber =   608 where id =  19632
--Update assets set AssetNumber =   609 where id =  19633
--Update assets set AssetNumber =   610 where id =  19634
--Update assets set AssetNumber =   611 where id =  19635
--Update assets set AssetNumber =   612 where id =  19636
--Update assets set AssetNumber =   613 where id =  19637
--Update assets set AssetNumber =   614 where id =  19638
--Update assets set AssetNumber =   615 where id =  19639
--Update assets set AssetNumber =   616 where id =  19640
--Update assets set AssetNumber =   617 where id =  19641
--Update assets set AssetNumber =   618 where id =  19642
--Update assets set AssetNumber =   619 where id =  19643
--Update assets set AssetNumber =   620 where id =  19644
--Update assets set AssetNumber =   621 where id =  19645
--Update assets set AssetNumber =   622 where id =  19646
--Update assets set AssetNumber =   623 where id =  19647
--Update assets set AssetNumber =   624 where id =  19648
--Update assets set AssetNumber =   625 where id =  19649
--Update assets set AssetNumber =   626 where id =  19650
--Update assets set AssetNumber =   627 where id =  19651
--Update assets set AssetNumber =   628 where id =  19652
--Update assets set AssetNumber =   629 where id =  19653
--Update assets set AssetNumber =   630 where id =  19654
--Update assets set AssetNumber =   631 where id =  19655
--Update assets set AssetNumber =   632 where id =  19656
--Update assets set AssetNumber =   633 where id =  19657
--Update assets set AssetNumber =   634 where id =  19658
--Update assets set AssetNumber =   635 where id =  19659
--Update assets set AssetNumber =   636 where id =  19660
--Update assets set AssetNumber =   637 where id =  19661
--Update assets set AssetNumber =   638 where id =  19662
--Update assets set AssetNumber =   639 where id =  19663
--Update assets set AssetNumber =   640 where id =  19664
--Update assets set AssetNumber =   641 where id =  19665
--Update assets set AssetNumber =   642 where id =  19666
--Update assets set AssetNumber =   643 where id =  19667
--Update assets set AssetNumber =   644 where id =  19668
--Update assets set AssetNumber =   645 where id =  19669
--Update assets set AssetNumber =   646 where id =  19670
--Update assets set AssetNumber =   647 where id =  19671
--Update assets set AssetNumber =   648 where id =  19672
--Update assets set AssetNumber =   649 where id =  19673
--Update assets set AssetNumber =   650 where id =  19674
--Update assets set AssetNumber =   651 where id =  19675
--Update assets set AssetNumber =   652 where id =  19676
--Update assets set AssetNumber =   653 where id =  19677
--Update assets set AssetNumber =   654 where id =  19678
--Update assets set AssetNumber =   655 where id =  19679
--Update assets set AssetNumber =   656 where id =  19680
--Update assets set AssetNumber =   657 where id =  19681
--Update assets set AssetNumber =   658 where id =  19682
--Update assets set AssetNumber =   659 where id =  19683
--Update assets set AssetNumber =   660 where id =  19684
--Update assets set AssetNumber =   661 where id =  19685
--Update assets set AssetNumber =   662 where id =  19686
--Update assets set AssetNumber =   663 where id =  19687
--Update assets set AssetNumber =   664 where id =  19688
--Update assets set AssetNumber =   665 where id =  19689
--Update assets set AssetNumber =   666 where id =  19690
--Update assets set AssetNumber =   667 where id =  19691
--Update assets set AssetNumber =   668 where id =  19692
--Update assets set AssetNumber =   669 where id =  19693
--Update assets set AssetNumber =   670 where id =  19694
--Update assets set AssetNumber =   671 where id =  19695
--Update assets set AssetNumber =   672 where id =  19696
--Update assets set AssetNumber =   673 where id =  19697
--Update assets set AssetNumber =   674 where id =  19698
--Update assets set AssetNumber =   675 where id =  19699
--Update assets set AssetNumber =   676 where id =  19700
--Update assets set AssetNumber =   677 where id =  19701
--Update assets set AssetNumber =   678 where id =  19702
--Update assets set AssetNumber =   679 where id =  19703
--Update assets set AssetNumber =   680 where id =  19704
--Update assets set AssetNumber =   681 where id =  19705
--Update assets set AssetNumber =   682 where id =  19706
--Update assets set AssetNumber =   683 where id =  19707
--Update assets set AssetNumber =   684 where id =  19708
--Update assets set AssetNumber =   685 where id =  19709
--Update assets set AssetNumber =   686 where id =  19710
--Update assets set AssetNumber =   687 where id =  19711
--Update assets set AssetNumber =   688 where id =  19712
--Update assets set AssetNumber =   689 where id =  19713
--Update assets set AssetNumber =   690 where id =  19714
--Update assets set AssetNumber =   691 where id =  19715
--Update assets set AssetNumber =   692 where id =  19716
--Update assets set AssetNumber =   693 where id =  19717
--Update assets set AssetNumber =   694 where id =  19718
--Update assets set AssetNumber =   695 where id =  19719
--Update assets set AssetNumber =   696 where id =  19720
--Update assets set AssetNumber =   697 where id =  19721
--Update assets set AssetNumber =   698 where id =  19722
--Update assets set AssetNumber =   699 where id =  19723
--Update assets set AssetNumber =   700 where id =  19724
--Update assets set AssetNumber =   701 where id =  19725
--Update assets set AssetNumber =   702 where id =  19726
--Update assets set AssetNumber =   703 where id =  19727
--Update assets set AssetNumber =   704 where id =  19728
--Update assets set AssetNumber =   705 where id =  19729
--Update assets set AssetNumber =   706 where id =  19730
--Update assets set AssetNumber =   707 where id =  19731
--Update assets set AssetNumber =   708 where id =  19732
--Update assets set AssetNumber =   709 where id =  19733
--Update assets set AssetNumber =   710 where id =  19734
--Update assets set AssetNumber =   711 where id =  19735
--Update assets set AssetNumber =   712 where id =  19736
--Update assets set AssetNumber =   713 where id =  19737
--Update assets set AssetNumber =   714 where id =  19738
--Update assets set AssetNumber =   715 where id =  19739
--Update assets set AssetNumber =   716 where id =  19740
--Update assets set AssetNumber =   717 where id =  19741
--Update assets set AssetNumber =   718 where id =  19742
--Update assets set AssetNumber =   719 where id =  19743
--Update assets set AssetNumber =   720 where id =  19744
--Update assets set AssetNumber =   721 where id =  19745
--Update assets set AssetNumber =   722 where id =  19746
--Update assets set AssetNumber =   723 where id =  19747
--Update assets set AssetNumber =   724 where id =  19748
--Update assets set AssetNumber =   725 where id =  19914
--Update assets set AssetNumber =   726 where id =  19915
--Update assets set AssetNumber =   727 where id =  19916
--Update assets set AssetNumber =   728 where id =  19917
--Update assets set AssetNumber =   729 where id =  19918
--Update assets set AssetNumber =   730 where id =  19919
--Update assets set AssetNumber =   731 where id =  19920
--Update assets set AssetNumber =   732 where id =  19921
--Update assets set AssetNumber =   733 where id =  19922
--Update assets set AssetNumber =   734 where id =  19923
--Update assets set AssetNumber =   735 where id =  19924
--Update assets set AssetNumber =   736 where id =  19925
--Update assets set AssetNumber =   737 where id =  19926
--Update assets set AssetNumber =   738 where id =  19927
--Update assets set AssetNumber =   739 where id =  19928
--Update assets set AssetNumber =   740 where id =  19929
--Update assets set AssetNumber =   741 where id =  19930
--Update assets set AssetNumber =   742 where id =  19931
--Update assets set AssetNumber =   743 where id =  19932
--Update assets set AssetNumber =   744 where id =  19933
--Update assets set AssetNumber =   745 where id =  19934
--Update assets set AssetNumber =   746 where id =  19935
--Update assets set AssetNumber =   747 where id =  19936
--Update assets set AssetNumber =   748 where id =  19937
--Update assets set AssetNumber =   749 where id =  19938
--Update assets set AssetNumber =   750 where id =  19939
--Update assets set AssetNumber =   751 where id =  19940
--Update assets set AssetNumber =   752 where id =  19941
--Update assets set AssetNumber =   753 where id =  19942
--Update assets set AssetNumber =   754 where id =  19943
--Update assets set AssetNumber =   755 where id =  19944



--Update assets set AssetNumber=756 where id =24270
--Update assets set AssetNumber=757 where id =24271
--Update assets set AssetNumber=758 where id =24272
--Update assets set AssetNumber=759 where id =24273
--Update assets set AssetNumber=760 where id =24274
--Update assets set AssetNumber=761 where id =24275
--Update assets set AssetNumber=762 where id =24276
--Update assets set AssetNumber=763 where id =24277
--Update assets set AssetNumber=764 where id =24278
--Update assets set AssetNumber=765 where id =24279
--Update assets set AssetNumber=766 where id =24280
--Update assets set AssetNumber=767 where id =24281
--Update assets set AssetNumber=768 where id =24282
--Update assets set AssetNumber=769 where id =24283
--Update assets set AssetNumber=770 where id =24284
--Update assets set AssetNumber=771 where id =24285
--Update assets set AssetNumber=772 where id =24286
--Update assets set AssetNumber=773 where id =24287
--Update assets set AssetNumber=774 where id =24288
--Update assets set AssetNumber=775 where id =24289
--Update assets set AssetNumber=776 where id =24290
--Update assets set AssetNumber=777 where id =24291
--Update assets set AssetNumber=778 where id =24292
--Update assets set AssetNumber=779 where id =24293
--Update assets set AssetNumber=780 where id =24294
--Update assets set AssetNumber=781 where id =24295
--Update assets set AssetNumber=782 where id =24296
--Update assets set AssetNumber=783 where id =24297
--Update assets set AssetNumber=784 where id =24298
--Update assets set AssetNumber=785 where id =24299
--Update assets set AssetNumber=786 where id =24300
--Update assets set AssetNumber=787 where id =24301
--Update assets set AssetNumber=788 where id =24302
--Update assets set AssetNumber=789 where id =24303
--Update assets set AssetNumber=790 where id =24304
--Update assets set AssetNumber=791 where id =24305
--Update assets set AssetNumber=792 where id =24306
--Update assets set AssetNumber=793 where id =24307
--Update assets set AssetNumber=794 where id =24308
--Update assets set AssetNumber=795 where id =24309
--Update assets set AssetNumber=796 where id =24310
--Update assets set AssetNumber=797 where id =24311
--Update assets set AssetNumber=798 where id =24312
--Update assets set AssetNumber=799 where id =24313
--Update assets set AssetNumber=800 where id =24314
--Update assets set AssetNumber=801 where id =24315
--Update assets set AssetNumber=802 where id =24316
--Update assets set AssetNumber=803 where id =24317
--Update assets set AssetNumber=804 where id =24318
--Update assets set AssetNumber=805 where id =24319
--Update assets set AssetNumber=806 where id =24320
--Update assets set AssetNumber=807 where id =24321
--Update assets set AssetNumber=808 where id =24322
--Update assets set AssetNumber=809 where id =24323
--Update assets set AssetNumber=810 where id =24324
--Update assets set AssetNumber=811 where id =24325
--Update assets set AssetNumber=812 where id =24326
--Update assets set AssetNumber=813 where id =24327
--Update assets set AssetNumber=814 where id =24328
--Update assets set AssetNumber=815 where id =24329
--Update assets set AssetNumber=816 where id =24330
--Update assets set AssetNumber=817 where id =24331
--Update assets set AssetNumber=818 where id =24332
--Update assets set AssetNumber=819 where id =24333
--Update assets set AssetNumber=820 where id =24334
--Update assets set AssetNumber=821 where id =24335
--Update assets set AssetNumber=822 where id =24336
--Update assets set AssetNumber=823 where id =24337
--Update assets set AssetNumber=824 where id =24338
--Update assets set AssetNumber=825 where id =24339
--Update assets set AssetNumber=826 where id =24340
--Update assets set AssetNumber=827 where id =24341
--Update assets set AssetNumber=828 where id =24342
--Update assets set AssetNumber=829 where id =24343
--Update assets set AssetNumber=830 where id =24344
--Update assets set AssetNumber=831 where id =24345
--Update assets set AssetNumber=832 where id =24346
--Update assets set AssetNumber=833 where id =24347
--Update assets set AssetNumber=834 where id =24348
--Update assets set AssetNumber=835 where id =24349
--Update assets set AssetNumber=836 where id =24350
--Update assets set AssetNumber=837 where id =24351
--Update assets set AssetNumber=838 where id =24352
--Update assets set AssetNumber=839 where id =24353
--Update assets set AssetNumber=840 where id =24354
--Update assets set AssetNumber=841 where id =24355
--Update assets set AssetNumber=842 where id =24356
--Update assets set AssetNumber=843 where id =24357
--Update assets set AssetNumber=844 where id =24358
--Update assets set AssetNumber=845 where id =24359
--Update assets set AssetNumber=846 where id =24360
--Update assets set AssetNumber=847 where id =24361
--Update assets set AssetNumber=848 where id =24362
--Update assets set AssetNumber=849 where id =24363
--Update assets set AssetNumber=850 where id =24364
--Update assets set AssetNumber=851 where id =24365
--Update assets set AssetNumber=852 where id =24366
--Update assets set AssetNumber=853 where id =24367
--Update assets set AssetNumber=854 where id =24368
--Update assets set AssetNumber=855 where id =24369
--Update assets set AssetNumber=856 where id =24370
--Update assets set AssetNumber=857 where id =24371
--Update assets set AssetNumber=858 where id =24372
--Update assets set AssetNumber=859 where id =24373
--Update assets set AssetNumber=860 where id =24374
--Update assets set AssetNumber=861 where id =24375
--Update assets set AssetNumber=862 where id =24376
--Update assets set AssetNumber=863 where id =24377
--Update assets set AssetNumber=864 where id =24378
--Update assets set AssetNumber=865 where id =24379
--Update assets set AssetNumber=866 where id =24380
--Update assets set AssetNumber=867 where id =24381
--Update assets set AssetNumber=868 where id =24382
--Update assets set AssetNumber=869 where id =24383
--Update assets set AssetNumber=870 where id =24384
--Update assets set AssetNumber=871 where id =24385
--Update assets set AssetNumber=872 where id =24386
--Update assets set AssetNumber=873 where id =24387
--Update assets set AssetNumber=874 where id =24388
--Update assets set AssetNumber=875 where id =24389
--Update assets set AssetNumber=876 where id =24390
--Update assets set AssetNumber=877 where id =24391
--Update assets set AssetNumber=878 where id =24392
--Update assets set AssetNumber=879 where id =24393
--Update assets set AssetNumber=880 where id =24394
--Update assets set AssetNumber=881 where id =24395
--Update assets set AssetNumber=882 where id =24396
--Update assets set AssetNumber=883 where id =24397
--Update assets set AssetNumber=884 where id =24398
--Update assets set AssetNumber=885 where id =24399
--Update assets set AssetNumber=886 where id =24400
--Update assets set AssetNumber=887 where id =24401
--Update assets set AssetNumber=888 where id =24402
--Update assets set AssetNumber=889 where id =24403
--Update assets set AssetNumber=890 where id =24404
--Update assets set AssetNumber=891 where id =24405
--Update assets set AssetNumber=892 where id =24406
--Update assets set AssetNumber=893 where id =24407
--Update assets set AssetNumber=894 where id =24408
--Update assets set AssetNumber=895 where id =24409
--Update assets set AssetNumber=896 where id =24410
--Update assets set AssetNumber=897 where id =24411
--Update assets set AssetNumber=898 where id =24412
--Update assets set AssetNumber=899 where id =24413
--Update assets set AssetNumber=900 where id =24414
--Update assets set AssetNumber=901 where id =24415
--Update assets set AssetNumber=902 where id =24416
--Update assets set AssetNumber=903 where id =24417
--Update assets set AssetNumber=904 where id =24418
--Update assets set AssetNumber=905 where id =24419
--Update assets set AssetNumber=906 where id =24420
--Update assets set AssetNumber=907 where id =24421

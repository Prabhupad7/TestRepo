
             
			 
			 select TicketTypeid,priorityId, priorityName, serviceId,requestedById, CurrentlocationName, requestorLocationID,impactId, workgroupId,  * from Ticket where ticketNo = 1439525

			 select * from ServiceLevelObjective where priorityId = 16 and impactId = 4 and serviceLevelAgreementId =1
			 and serviceId = 1 and serviceLevelObjectiveTypeId = 2 and locationId = 118 and isDelete  = 0

			 select * from ServiceLevelAgreement where subTypeId = 2  SR1447639

		     select * from ServiceLevelTracking where sourceId = 1447639 

		--   update ServiceLevelTracking set statusId = 3 where serviceLevelTrackingId = 6152401


		--Insert into ServiceLevelTracking( serviceLevelObjectiveId,sourceId,serviceLevelObjectiveTypeId,startTime,expectedEndTime,expectedDuration,statusId)

		select 2324872, 1439525, 2, '2020-10-31 20:21:25.000', '2020-11-01 12:21:25.000' , 960,3
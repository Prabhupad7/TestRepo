

---->    KB dashboard 

   select count(*) from MIS_HMCL_EmailSend_Weekly

   select * from MIS_HMCL_EmailSend_Weekly

   select * from MIS_HMCL_EmailSendLocationWise  ----->  

   select * from MIS_HMCL_EmailReport
   select * from MIS_HMCL_EmailSend_DPCR_ML_NONML


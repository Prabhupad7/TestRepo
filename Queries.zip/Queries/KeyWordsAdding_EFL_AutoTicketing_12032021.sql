﻿

--[6:06 PM] Vignesh Annadurai
    
--insert into AutoTicketServiceRuleDetails(autoTicketServiceRuleColumnId,criteria,criteriaValue,isDeleted,opr,autoTicketServiceRuleId)
--select 4,'contains','Laptop replacement',0,'contains',1030707
--union all
--select 5,'contains','Laptop replacement',0,'contains',1030707
--​[6:06 PM] Vignesh Annadurai
    
select * from ApiKey where customerId = 167 --140


select * from AutoTicketServiceRule where apiKeyId  =140


select * from Category where categoryId = 3102


select * from SubCategory where subCategoryId = 12106 --- 1030707



select * from AutoTicketServiceRuleDetails where autoTicketServiceRuleId = 1030706 and criteriaValue = 'Email password issue '



--insert into AutoTicketServiceRuleDetails(autoTicketServiceRuleColumnId,criteria,criteriaValue,isDeleted,opr,autoTicketServiceRuleId)
--select 4,'contains','Laptop replacement',0,'contains',1030707
--union all
--select 5,'contains','Laptop replacement',0,'contains',1030707



--insert into AutoTicketServiceRuleDetails(autoTicketServiceRuleColumnId,criteria,criteriaValue,isDeleted,opr,autoTicketServiceRuleId)
--values
--(5,'contains','Laptop replacement',0,'contains',1030707),
--(5,'contains','ASAP utilities installation',0,'contains',1030707),
--(5,'contains','Configuration of new laptop',0,'contains',1030707),
--(5,'contains','allow USB port',0,'contains',1030707),
--(5,'contains','configure VPN ID',0,'contains',1030707),
--(5,'contains','Need to enable USB port',0,'contains',1030707),
--(5,'contains','SAP Application installation',0,'contains',1030707),
--(5,'contains','MS Office installation',0,'contains',1030707),
--(5,'contains','MS Office update',0,'contains',1030707),
--(5,'contains','Deactivate email id',0,'contains',1030707),
--(5,'contains','install Printer in My Laptop',0,'contains',1030707),
--(5,'contains','Laptop allocation',0,'contains',1030707),
--(5,'contains','create email ID',0,'contains',1030707),
--(5,'contains','create new mail id',0,'contains',1030707),
--(5,'contains','new mail Id Configuration',0,'contains',1030707),
--(5,'contains','Desktop allocation',0,'contains',1030707),
--(5,'contains','asset allocation and IMAC process',0,'contains',1030707),
--(5,'contains','generate Email id',0,'contains',1030707),
--(5,'contains','Need the admin rights',0,'contains',1030707),
--(5,'contains','Creation of AD IDs',0,'contains',1030707),
--(5,'contains','Please delete AD Login and email id',0,'contains',1030707)



SELECT TOP 42 * FROM AutoTicketServiceRuleDetails order by 1 desc






select * from AutoTicketEventLog

select * from RulesForAssignment

select * from AutoTicketServiceRule

select * from AutoTicketServiceRuleDetails
	
	
		
	select * from Customer where customerName like '%cloud%'   ---  204	

	select * from ServiceCustomerMapping where customerId = 168 and deleted = 0
	
	select top 10 * from Device where customerId = 168 and deleted =1 and deviceName in ('apomex07',
'apotex06',
'apoawp1',
'torrpt08v',
'barcop1',
'star-print-01',
'torawp1',
'tor-nuance-01'
)
               select  * from Device where customerId = 204 and deleted = 0

					--  TORSAPRP1	10.230.0.24
					--  oraprod09	10.6.4.233

    select  * from  Device where customerId =194 and deleted = 0
	order by 1 desc  ---->  32653

	select * from Customer where customerName like '%Eure%'  ----> 167	Eureka Forbes Limited


-- Insert into Device (deviceName, alternateName, ipAddress, customerId, deleted, hostName)
--	 values 	
--('INFRTVC001','INFRTVC001','10.100.10.20',167,0,'INFRTVC001'),
--('INMHOSA0050','INMHOSA0050','10.101.204.2',167,0,'INMHOSA0050')



select top 2 * from device order by 1 desc  ---> 40359

select s.serviceId, s.serviceName from ServiceCustomerMapping SS
inner join Service S on S.serviceId = SS.serviceId
where ss.customerId = 167 and s.deleted = 0 and ss.deleted = 0

-----> 196	DCS

----> 40361 , 40360

select * from DeviceServiceMapping where deviceId = 26936

--Insert into DeviceServiceMapping (serviceId, deviceId, deleted, ticketTypeId)
--values 
--(196, 40361, 0, 1),
--(196, 40361, 0, 2),
--(196, 40361, 0, 3),
--(196, 40361, 0, 4),

--(196, 40360, 0, 1),
--(196, 40360, 0, 2),
--(196, 40360, 0, 3),
--(196, 40360, 0, 4)

	    select top 24 * from Device order by  1 desc

		select distinct s.serviceId, s.serviceName from ServiceCustomerMapping SC 
		inner join Service S on S.serviceId = SC.serviceId
		where sc.customerId = 3 and sc.deleted = 0 and sc.serviceId=1


		--   479	Cloud Operations
		--   502	Cloud Service





   --  update Device set deleted = 1 where customerId = 168 and deviceId in (24251
33973)

 select * from DeviceServiceMapping where deviceId in (24260)


    -- update DeviceServiceMapping set deleted = 1 where deviceServiceMappingId in (
	 2285327
,2285787 )


select top 10 * from Device where customerId = 168 and deleted =0 and deviceName in ('TORSAPRP1',
'oraprod09 ')
	--- 24251	apomex07

	select * from Service where serviceId in 
	(select distinct serviceId from ServiceCustomerMapping where customerId = 204 and deleted = 0)



	
	select * from Customer where customerName like '%cloud%'   --- 204	MLCloudAppSupport

	select top 10 * from Device where customerId = 204 and deleted =0 

	-- Insert into Device (deviceName, alternateName, ipAddress, customerId, deleted, hostName)

	values ('UBAZUPWUSCELLR01', 'UBAZUPWUSCELLR01', '192.168.3.8', 207, 0, 'UBAZUPWUSCELLR01'), 
	       ('UBAZUPWUSCELLR02', 'UBAZUPWUSCELLR02', '192.168.4.8', 207, 0, 'UBAZUPWUSCELLR02')



		   select Top 21 * from Device order by 1 desc
		  

			select top 10 * from Device where customerId = 207 and deleted =0 and deviceName like '%cellranger-svr-3%'

			select * from Device where DeviceId in ()



			select * from DeviceServiceMapping where deviceId in (29842 )

			select * from DeviceServiceMapping where deviceId in (29952, 29951 )


			select * from Service where serviceId = 499

			select * from ServiceCustomerMapping

			select * from Service where serviceName like '%Traverse%'

			select top 84 * from DeviceServiceMapping order by 1 desc 

	 -- For SERVICEID --> 198, TICKET TYPEID - 1,2,3,4


	select * from Customer where customerName like '%cloud%'   --- 204	MLCloudAppSupport

	select * from Customer where customerName like '%sma%'   --- 204	MLCloudAppSupport


	select * from Service where serviceName like '%Azure%'

	select * from Service where serviceName like '%AWS%'


	select top 10 * from Device where customerId = 207 and deleted =0 

	Insert into Device (deviceName, alternateName, ipAddress, customerId, deleted, hostName)

	values ('UBAZUPWUSCELLR01', 'UBAZUPWUSCELLR01', '192.168.3.8', 207, 0, 'UBAZUPWUSCELLR01'), 
	       ('UBAZUPWUSCELLR02', 'UBAZUPWUSCELLR02', '192.168.4.8', 207, 0, 'UBAZUPWUSCELLR02')




		   ----------------->  
		   


		    select * from Users where Email like '%harrys1@microland.com%' ---->  25446

		    select * from Users where Email like '%manjunathks@microland.com%' ---->  25872


			select * from customer where customerid = 218 

			select * from CustomerAssignmentGroupMapping where customerid = 218 and deleted =0



		 select  * from  UserCustomerAssignGroupMapping where deleted =0 and userid = 25872 and custAssignmentGroupId in (
		 2986 ,2987 ,2988 ,2989 ,2990 ,2991 ,2992 ,2993 ,3042 ,3043 )



-- insert into UserCustomerAssignGroupMapping(userId,	custAssignmentGroupId,	deleted,	isAssignEnabled,	AssignToWorkgroup)

-- values 
--(25872, 2986, 0, 1, 1),
--(25872, 2988, 0, 1, 1),
--(25872, 2989, 0, 1, 1),
--(25872, 2990, 0, 1, 1),
--(25872, 2991, 0, 1, 1),
--(25872, 2992, 0, 1, 1),
--(25872, 2993, 0, 1, 1),
--(25872, 3042, 0, 1, 1),
--(25872, 3043, 0, 1, 1)

  
  select * from [dbo].[MIS_HMCL_EmailSend_Weekly]

  ---->  notifications@microlandsmartcenter.com    microland@bng2

   
  select * from  [dbo].[MIS_HMCL_EmailSend_DPCR_ML_NONML]
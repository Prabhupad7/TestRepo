


  select * from Users 

  select * from KLI_03122020

   --  ALTER TABLE KLI_03122020 
   --ADD AssetId int

   select A.Id, A.AssetName, A.LocationName,k.LocationName, k.locationCode,* from Assets A 
   inner join KLI_03122020 K 
   on A.AssetNumber = K.AssetTag -- and A.SerialNumber = K.SerialNumber

   	--   Update K set K.AssetId = A.Id
	   --from KLI_03122020 K
	   --inner join Assets A 
	   --on A.AssetNumber = K.AssetTag 

	 -->  3531

	   -- Update A set A.LocationName = k.LocationName
	   --from KLI_03122020 K
	   --inner join Assets A 
	   --on A.AssetNumber = K.AssetTag 
	   --where A.Id in (select assetId from KLI_03122020 )

	   select * from Assets where id = 3531

	   --->  MU6W

	   --->  Goregaon KGI - KLI

	   select  *  from VarcharCustomAttribute V where v.PrimaryId = 174

	   --Update VarcharCustomAttribute set varchar3 = 'MU6W' where PrimaryId = 3531

	   --Update A set A.Varchar3 = k.LocationCode
	   --from KLI_03122020 K
	   --inner join VarcharCustomAttribute A 
	   --on A.PrimaryId = K.AssetId 
	   --where A.PrimaryId in (select assetId from KLI_03122020 )

	   -->  varchar7

	     select PreviousLocation, * from KLI_03122020

	   -- Update A set A.varchar7 = isnull(A.varchar7, '' )+' / '+ k.PreviousLocation
	   --from KLI_03122020 K
	   --inner join VarcharCustomAttribute A 
	   --on A.PrimaryId = K.AssetId 
	   --where A.PrimaryId in (select assetId from KLI_03122020 )

	   --->  Activity Type

	   -- Update A set A.Varchar15 = isnull(A.Varchar15, '' )+' / '+ k.ActivityType
	   --from KLI_03122020 K
	   --inner join VarcharCustomAttribute A 
	   --on A.PrimaryId = K.AssetId 
	   --where A.PrimaryId in (select assetId from KLI_03122020 )

	   --Update A set A.LocationName = isnull(A.Varchar17, '' )+' / '+ k.PartReplacementRemarks
	   --from KLI_03122020 K
	   --inner join VarcharCustomAttribute A 
	   --on A.PrimaryId = 17352 
	   --where A.PrimaryId in (17352 )



	   select * from VarcharCustomAttribute  K
	   inner join KLI_03122020 A 
	   on A.AssetId = K.PrimaryId 
	   where A.AssetId in (select assetId from KLI_03122020 )

	    select *  from VarcharCustomAttribute V 
		inner join KLI_03122020 K
		on V.PrimaryId = k.AssetId

        select * from CustomAttributeColumnMapping 
		where DisplayName like '%Location%'  and CustomerId=1 and SourceId =17 --->  LocationName

		select * from AssetEntityType

		select * from KLI_03122020 where assetTag ='KLI/07604' -->  17352

		select top 10 * from ServiceLevelAgreement where serviceLevelId = 16 --> 2

		select * from Service where serviceName like '%SmartSell%' --> 91

		select * from Service where serviceName like '%Kitty%' --> 91

		select * from Workgroup where workgroup like '%IAP%'

		select  * from ServiceLevelObjective  where  serviceId =91 and isDelete =0 --> and serviceLevelAgreementId = 2 

		select * from Category where category like '%ADA%'
		


		select * from users where email like  '%AbhishaiBV@microland.com%' ---> 1814

		select * from Customer where customername like '%bunge%' ----> 218

		select * from CustomerAssignmentGroupMapping where customerid = 218

		select * from UserCustomerAssignGroupMapping where userid  = 1814 and custAssignmentGroupId in (
		select custAssignmentGroupId from CustomerAssignmentGroupMapping where customerid = 218 and deleted =0)

		---->  2988

		--insert into UserCustomerAssignGroupMapping (userId,	custAssignmentGroupId,	deleted, isAssignEnabled, AssignToWorkgroup)
		--values 
		--(1814, 2989, 0, 1, 1),
		--(1814, 2987, 0, 1, 1),
		--(1814, 2986, 0, 1, 1),
		--(1814, 2993, 0, 1, 1),
		--(1814, 2992, 0, 1, 1),
		--(1814, 2990, 0, 1, 1),
		--(1814, 2991, 0, 1, 1),
		--(1814, 3042, 0, 1, 1),
		--(1814, 3043, 0, 1, 1)

		SR2874091

		IM2838348 

		select serviceid, customerid, workgroupid, * from ticket where ticketno = '2838348' --> 243

		select * from FeedbackConfig where custid = 68 and serviceid =51 and workgroupid = 243

		select * from Customer where customerId in (161)

		-- update Customer set deleted = 1 where customerId in (161)
  
       -- update ServiceCustomerMapping set deleted = 1  where customerid in (161)


	    -- update CustomerAssignmentGroupMapping set deleted = 1 where customerId in (161)





		------>  mlbungie@microlandsmartcenter.com

		select * from NotificationRules where Notificationcc Like '%mlbungie@microlandsmartcenter.com%'

		select * from NotificationRules where NotificationTo Like '%mlbungie@microlandsmartcenter.com%'

	    select * from Workgroup where WorkGroupEmail Like '%mlbungie@microlandsmartcenter.com%'

		select * from NotificationRegistry where NotificationTo Like '%mlbungie@microlandsmartcenter.com%'

		select * from NotificationRegistry where Notificationcc Like '%mlbungie@microlandsmartcenter.com%'

		select  * from NotificationHistory where NotificationccTo Like '%mlbungie@microlandsmartcenter.com%'

		select  * from NotificationHistory where NotificationBccTo Like '%mlbungie@microlandsmartcenter.com%'

		select * from users where email like  '%sunils1@microland.com%' ---> 23891

		select * from customer where customerName like '%Innocen%' ----> 188



		select top 100 * from RCAReviewer where customerid = 188 and userid = 23891

		--Insert into RCAReviewer (customerid, userid)
		--values (188, 23891)



		select * from users where email like  '%sunils1@microland.com%' --->  23891

		--Update users set username ='Sunil S Reddy', displayName ='Sunil S Reddy' where userid = 23891
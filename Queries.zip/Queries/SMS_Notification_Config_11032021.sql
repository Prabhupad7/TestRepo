
	select * from customer where customerName like '%SMC HMCL%'  ---> 182	SMC Automation   152	SMC HMCL


	select * from Workgroup where workgroup like '%HP3N%' ----> 101,  102

	select * from Workgroup where workgroupId = 607


	select * from TicketStatus where ticketTypeId in (1, 2) ----> 2	Assigned  13	Assigned

	select * from NotificationRules 
	where customerId = 68 and deleted = 0 and notificationMode ='AWSSMS' and workgroupid in (101,102) and serviceId =51
	order by 1
	 

	 select * from NotificationRules where ruleId in (
	 2342701
,2342702	 )

   ---> 919680512115,919910790552,919024721956,918233760509

   select distinct serviceId from ServiceCustomerMapping where customerId = 68 and deleted = 0


--51
--52
--57
--67
--82
--83
--323
--412

	--Insert into NotificationRules (	customerId,	ticketTypeId,	priorityId,	duePercent,	notificationMode,	notificationTo,	notificationCC,	templateId,	ruleName,	workgroupid,	supportgroupid,	serviceId,	notifyBasedOnId,	entryStateId,	deleted)


	--	select 	customerId,	ticketTypeId,	priorityId,	duePercent,	notificationMode,	'919680512115,919910790552,919024721956,918233760509',	notificationCC,	templateId,	ruleName,	102,	supportgroupid,	serviceId,	notifyBasedOnId,	entryStateId,	deleted from NotificationRules 
	--where customerId = 68 and deleted = 0 and notificationMode ='AWSSMS' and workgroupid in (607)
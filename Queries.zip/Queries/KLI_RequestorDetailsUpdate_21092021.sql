

select * from KLI_21092021$ where ISVIPUSER = 1

select distinct HRGRADE from KLI_21092021$ 

--L12 ,L5,L1,L6,Sa,L11,L3 ,L7 ,L2 ,L4 ,L9 ,L10,L8 ,L7A

select * from KLI_21092021$ where HRGrade in ('L8', 'L9', 'L10', 'L11','L12')

--Update KLI_21092021$ set ISVIPUSER = 1 where  HRGrade in ('L8', 'L9', 'L10', 'L11', 'L12')

select r.requestorId,R.requestorEmail, k.EmailAddress, R.isCriticalUser, R.displayname, k.displayName,
R.location, K.Location, r.designation, k.Title
from Requestor R 
inner join KLI_21092021$ K on K.EmailAddress = R.requestorEmail
where r.deleted = 0 and K.HRGrade in ('L8', 'L9', 'L10', 'L11','L12')

--Update R set R.isCriticalUser=1, R.displayname=K.displayName, R.designation=k.Title
--from Requestor R 
--inner join KLI_21092021$ K on K.EmailAddress = R.requestorEmail
--where r.deleted = 0 and K.HRGrade in ('L8', 'L9', 'L10', 'L11','L12')



     select * from Approval where approvalNo = 2982914  ---> 3285

	 select top 100 * from ApprovalEntityMapping where approvalEntityMappingId = 3285 ---> 531

	 select top 100 * from ApprovalMatrix where approvalMatrixId = 531  ----> 531

	 select top 100 * from ApprovalMatrixLevel where approvalMatrixId = 531   -----> 1018

	 select top 100 * from ApprovalMatrixApprover where levelId = 1018



	 ---------------> New configurations for SR Approvals:
	 
	 --step 1:

	  select top 100 * from ApprovalMatrix order by 1 desc  ----> 804

	  --Insert into ApprovalMatrix 

	  --select 'EFL_Taxilla', 'EFL_Taxilla', 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, NULL

	  ----> Step 2:

	  select top 100 * from ApprovalEntityMapping 
	  where customerId = 167 and deleted = 0 and approvalEntityMappingId = 2832

	  --Insert into ApprovalEntityMapping

	  --select 2, 'TICKET', 167, 'Eurekaforbes Limited', '{customerid=167;serviceid=543;categoryid=5899;subcategoryid=22784;classificationid=91097;tickettypeid=2;}',
	  --NULL, 1, 804, 1890, NULL, 0, 0, null, 1

	  --union all

	  --select 2, 'TICKET', 167, 'Eurekaforbes Limited', '{customerid=167;serviceid=543;categoryid=5900;subcategoryid=22785;classificationid=91098;tickettypeid=2;}',
	  --NULL, 1, 804, 1890, NULL, 0, 0, null, 1

	  ---> step 3

	  select top 100 * from ApprovalMatrixLevel order by 1 desc

	  --Insert into ApprovalMatrixLevel 

	  ----select 804, 'Level 1', 'EFL_Taxilla', NULL, 1, 0, 0, NULL, 1, 6, 'smcAdmin', getdate(), 6, 'smcAdmin', getdate(), 0, 0, 1

	  ----UNION ALL

	  --select 804, 'Level 1', 'EFL_Taxilla', 1444, 1, 0, 0, NULL, 1, 6, 'smcAdmin', getdate(), 6, 'smcAdmin', getdate(), 0, 1, 1
	   
	  --Update ApprovalMatrixLevel set levelName = 'Level 2' where levelId = 1445

--levelId	approvalMatrixId	levelName	levelDescription
--1445	804	Level 2	EFL_Taxilla
--1444	804	Level 1	EFL_Taxilla

	  ---> Step 4:


	   select top 100 * from ApprovalMatrixApprover where levelId = 1018

	   select top 100 * from ApprovalMatrixApprover order by 1 desc


	   --insert into ApprovalMatrixApprover 

	   --select 235, 100196, 'Raja Roy', 1444, 'Level 1', 1, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 1, 1, 1, NULL, 1
	   --UNION ALL
	   --select 232, 84396, 'Brijesh Shah', 1445, 'Level 2', 1, 6, 'smcadmin', GETDATE(), 6, 'smcadmin', GETDATE(), 0, 1, 1, 1, NULL, 1



 select * from assets A where A.SerialNumber = 'FDO1936A03V'  and A.AssetNumber = 'KGIIT000509'  ---->  19176

 select * from EntityType where entityName like '%DEsk%'

  select * from assets A where A.SerialNumber = 'PF10C73S'  and A.AssetNumber = 'KGIIT001543'

  -- KGIIT001360

   select * from assets A where A.SerialNumber = '1BJ1HY2'  and A.AssetNumber = 'KGIIT001360'




  --update Assets set SourceId = 18 where Id = 19793

  Select * from 

  select * from assets A where A.Id In (
20449,
19793)


KGIIT000911	PF10C73S

 select AssetNumber, SerialNumber from Assets where id in (
 25307
,25308)

   --EXEC Usp_AssetDeletetionByAssetId 19176

   --EXEC Usp_AssetDeletetionByAssetId 25308
   --EXEC Usp_AssetDeletetionByAssetId 25310
   --EXEC Usp_AssetDeletetionByAssetId 25311
   --EXEC Usp_AssetDeletetionByAssetId 25312
   --EXEC Usp_AssetDeletetionByAssetId 25313





-- Usp_AssetDeletetionByAssetId 12345

-- [3:19 PM] Vignesh Annadurai
    
--EXEC Usp_AssetDeletetionByAssetId 12345

    select * from LocationType

    select  A.LocationType , * from Assets A where LocationId is not null


	   select top 100 * from assets 

	   select * from CustomAttributeSourceTypes

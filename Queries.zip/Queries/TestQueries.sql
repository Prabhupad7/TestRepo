


      select * from NotificationEmailTemplate where customerid = 147

      select * from NotificationEmailTemplate where customerid = 147


	   Select * from workGroupEscalationMatrix where customerid = 147 and workgroupid in (
 203
,214
,224
,225
,227
,229
,232
,233
,235
,238
,241
,249
,495
,496
,512
,513
,515
,525
,595
,596
,628
,629
,630
,631
,632
,687)


	  Select * from workGroupEscalationMatrix_AskML where customerid = 147 and workgroupid in (
 203
,214
,224
,225
,227
,229
,232
,233
,235
,238
,241
,249
,495
,496
,512
,513
,515
,525
,595
,596
,628
,629
,630
,631
,632
,687)
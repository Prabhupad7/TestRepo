

select * from Customer where deleted = 0 and customerName like '%SMC%' 

--> 150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209

--select * from NotificationRules where deleted = 0 and customerid in 
--and duePercent is not null

--->  

---> vishalds@microland.com;
---> natarajango@microland.com;
---> smartcentersupport2@microland.com
---> natarajango@microland.comsmartcentersupport2@microland.com;vishalds@microland.com;



select * from NotificationRules where deleted = 0 and customerid in (150)
and duePercent is not null
order by duePercent

select * from NotificationRules where deleted = 0 and customerid in (150)
and duePercent is not null and notificationTo  like '%natarajango@microland.com%'
order by duePercent 

----> 
--�	70
--�	80
--�	90
--�	100
--�	120
--�	150

select  top 50 * from SMC_UserOtp order by 1 desc

---> SR3160265

select customerid, serviceId, priorityId, workgroupid,* from Ticket where TicketNo = 3160265

select * from NotificationRules where deleted = 0 and customerid = 150 
and serviceid =88 and priorityid = 14 and workgroupid = 256

select * from Customer where customerName Like '%SMC KLI%' --> 150	SMC KLI

select top 100 * from NotificationRules where Customerid = 147 and notificationMode ='AWSSMS'
and duePercent is not null

---> 1896, 1661

select * from NotificationEmailTemplate where templateId in (1896, 1661)

----> 1896	SLA 75 SMS Resolution

select * from NotificationEmailTemplate where customerId = 150  

select distinct serviceid from ServiceCustomerMapping where customerId = 209  and ticketTypeId = 1 and deleted=0
order by serviceid

select distinct serviceid from ServiceCustomerMapping where customerId = 209  and ticketTypeId = 2 and deleted=0
order by serviceid

--delete from NotificationRules where customerid = 208 and duePercent = 100 and ticketTypeId in( 1,2 )
--and deleted= 0 and notificationMode = 'AWSSMS'

select * from Service where serviceId in (
86,87,88,89,90,91,92,93,150,261,262,263)

select 151,	ticketTypeId,	priorityId,	duePercent,	notificationMode,	notificationTo,	templateId,	ruleName,		serviceId,	notifyBasedOnId,	entryStateId,	deleted
from NotificationRules where customerId =  150 and duePercent =100 and notificationMode = 'AWSSMS'


(150,151,152,153,154,155,157,  170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)

----> 2234	SLA 100 SMS Resolution

--Insert into NotificationRules(customerId,	ticketTypeId,	priorityId,	duePercent,	notificationMode,	notificationTo,	templateId,	ruleName,		serviceId,	notifyBasedOnId,	entryStateId,	deleted	)

----select 151,	ticketTypeId,	priorityId,	duePercent,	notificationMode,	notificationTo,	templateId,	ruleName,		serviceId,	notifyBasedOnId,	entryStateId,	deleted
----from NotificationRules where customerId =  150 and duePercent =100 and notificationMode = 'AWSSMS'


--select 209, 1, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 489,3, NULL, 0  UNION ALL
--select 209, 1, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 490,3, NULL, 0  UNION ALL
--select 209, 1, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 491,3, NULL, 0  UNION ALL
--select 209, 1, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 492,3, NULL, 0  UNION ALL
--select 209, 1, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 493,3, NULL, 0  UNION ALL
--select 209, 1, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 494,3, NULL, 0  UNION ALL
--select 209, 1, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 495,3, NULL, 0  UNION ALL
--select 209, 1, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 496,3, NULL, 0  UNION ALL

--select 209, 2, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 489,3, NULL, 0  UNION ALL
--select 209, 2, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 490,3, NULL, 0  UNION ALL
--select 209, 2, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 491,3, NULL, 0  UNION ALL
--select 209, 2, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 492,3, NULL, 0  UNION ALL
--select 209, 2, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 493,3, NULL, 0  UNION ALL
--select 209, 2, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 494,3, NULL, 0  UNION ALL
--select 209, 2, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 495,3, NULL, 0  UNION ALL
--select 209, 2, NULL, 100, 'AWSSMS', '919845802352,918971970610,919902066973', 2234, 'Resolution 100', 496,3, NULL, 0 





--Insert into NotificationEmailTemplate (templateName, template, customerId, isOutageNotificationTemplate, isOutageSMSNotification)

--select 'SLA 100 SMS Resolution', 'Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 100% Resolution SLA', 150, 0,0

 select distinct notificationCC from NotificationRules where deleted = 0 and customerid in(150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
 and duePercent in (70,80,90,100,120,150) 

  select distinct notificationTo from NotificationRules where deleted = 0 and customerid in(150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
 and duePercent in (70,80,90,100,120,150) 

 select * from NotificationRules where deleted = 0 and customerid in(150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
 and duePercent in (70,80,90,100,120,150)  and notificationCC ='smartcentersupport2@microland.com;RaghavendraSY@microland.com;natarajango@microland.com;vishalds@microland.com;;kli.digambar-Sutar@kotak.com;mangesh.khune@kotak.com;kli.sharvari-shanbhag@kotak.com'

 --Update NotificationRules set notificationCC= 'smartcentersupport2@microland.com;RaghavendraSY@microland.com;natarajango@microland.com;vishalds@microland.com;kli.digambar-Sutar@kotak.com;mangesh.khune@kotak.com;kli.sharvari-shanbhag@kotak.com' where ruleId = 1716301

select * from NotificationRules where deleted = 0 and customerid in (150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
 and duePercent in (70,80,90,100,120,150)
 and notificationTo not like '%vishalds@microland.com%'

 ------>Requirement 1: NotificationTo: AssignedEng, \ NotificationCC: Smartcenter,
------> Vishal, Natarajan, raghavendra,
-----> Req 2: SMS Alert for 100% to Vishal Natarajan and Raghu

---> 
$ASSIGNEDENGINEEREMAIL  
$ASSIGNEDENGINEEREMAIL
---> smartcentersupport2@microland.com;RaghavendraSY@microland.com;natarajango@microland.com;vishalds@microland.com;

 --Update NotificationRules set notificationCC= 'smartcentersupport2@microland.com;RaghavendraSY@microland.com;natarajango@microland.com;vishalds@microland.com;itsd.csdtl@heromotocorp.com' where deleted = 0 and customerid in(150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
 --and duePercent in (70,80,90,100,120,150) and notificationCC ='smartcentersupport2@microland.com;RaghavendraSY@microland.com;natarajango@microland.com;vishalds@microland.com;;itsd.csdtl@heromotocorp.com;;$REQUESTOREMAIL'



 --vishalds@microland.com;anandk@microland;natarajang@microland.comsmartcentersupport2@microland.com;


--> Replace(notificationTo ,'natarajang@microland.com','natarajango@microland.com')
--> vishalds@microland.com;anandk@microland;natarajang@microland.comsmartcentersupport2@microland.com;

--Update NotificationRules Set notificationTo = notificationTo+';natarajango@microland.com;'
--where deleted = 0 and customerid in (150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
-- and duePercent in (70,80,90,100,120,150)
-- and notificationTo not like '%natarajango@microland.com%'

---> natarajango@microland.comsmartcentersupport2@microland.com;vishalds@microland.com;
--> natarajango@microland.coms;martcentersupport2@microland.com;vishalds@microland.com;
--> vishalds@microland.com;natarajango@microland.coms;Smartcentersupport2@microland.com

--update NotificationRules set notificationTo = Replace(notificationTo, 'sSmartcentersupport2@microland.com;','Smartcentersupport2@microland.com;')
--where deleted = 0 and customerid in (150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
--and duePercent =50


select distinct duePercent from NotificationRules where deleted = 0 and customerid in (150)
and duePercent is not null
order by duePercent

---> vishalds@microland.com;natarajango@microland.comsmartcentersupport2@microland.com

select * from NotificationRules where deleted = 0 and customerid in (152)
and duePercent is not null and notificationTo not like '%vishalds@microland.com%'
order by duePercent


--update NotificationRules set notificationTo =notificationTo+';vishalds@microland.com;'
--where deleted = 0 and customerid in (209)
--and duePercent is not null and notificationTo not like '%vishalds@microland.com%'


select * from NotificationRules where deleted = 0 and customerid in (150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
and notificationTO like '%smartcentersupport2@microland.com%'

--Update NotificationRules set notificationTO ='$ASSIGNEDENGINEEREMAIL', notificationCC ='smartcentersupport2@microland.com'
--where deleted = 0 and duepercent= 50 and customerid in (150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
--and notificationTO like '%smartcentersupport2@microland.com%'

vishalds@microland.com;anandk@microland;natarajang@microland.comsmartcentersupport2@microland.com;utkalpk@microland.com,


smartcentersupport2@microland.com;RaghavendraSY@microland.com;natarajango@microland.com;vishalds@microland.com

select * from ChangeType   where customerid in 
(3,4,8,58,59,61,158,167,168,169,182,188,189,192,194,196,201,203,207,213,214,215,217,218,219,220,221)
and changeType='Emergency'

--Update ChangeType set isCMApprovalRequired = 1
--where customerid in 
--(3,4,8,58,59,61,158,167,168,169,182,188,189,192,194,196,201,203,207,213,214,215,217,218,219,220,221)
--and changeType='Emergency'



select * from customer where CustomerName like '%NOKIA%'  ---> 213	Nokia

select * from  ChangeAdvisoryBoard where customerid = 213 and deleted =0

--Update ChangeAdvisoryBoard set deleted = 1 where memberId = 1018 


select * from Workgroup where workgroup like '%Remote Resolution Group%' ---> 769	CIS-Internal

---> 216	ML IT SD Follow-up
---> 200	ML IT Servicedesk, 699	ML-CISDSS-L2 Team, 247	Remote Resolution Group


---> SR3137425  

select distinct templateid from NotificationRegistry where Sourceid = 3137425

select * from NotificationEmailTemplate where Templateid in (
449,450,453,454,455,456,457,458,461,683,684,685,
686,687,990,1010,1011,1012,1510,1958,2032,2099) and template like '%Ajit Bedekar%'

---> Manjunath Kuntumala

 select * from NotificationRules where deleted = 0 and customerid in(150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
 and duePercent in (70,80,90,100,120,150)  and notificationCC ='smartcentersupport2@microland.com;RaghavendraSY@microland.com;natarajango@microland.com;vishalds@microland.com;;kli.digambar-Sutar@kotak.com;mangesh.khune@kotak.com;kli.sharvari-shanbhag@kotak.com'


 ----> kli.digambar-Sutar@kotak.com;mangesh.khune@kotak.com;kli.sharvari-shanbhag@kotak.com

 ---. smartcentersupport2@microland.com;RaghavendraSY@microland.com;natarajango@microland.com;vishalds@microland.com;itsd.csdtl@heromotocorp.com

 --Update NotificationRules set notificationCC = replace(notificationCC, 'smartcentersupport2@microland.com;RaghavendraSY@microland.com;natarajango@microland.com;vishalds@microland.com;', 'smartcentersupport2@microland.com;RaghavendraSY@microland.com;natarajango@microland.com;vishalds@microland.com') where deleted = 0 and customerid in(150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
 and duePercent in (70,80,90,100,120,150) 

  select distinct NotificationCC from NotificationRules where deleted = 0 and customerid in(150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
 and duePercent in (70,80,90,100,120,150)
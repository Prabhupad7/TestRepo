	select * from Workgroup where workgroup like '%HR %'

	select * from Service where serviceName like '%HR%'-- 84

	select * from NotificationRules where customerId = 147 and deleted = 0 -- 1958   Work in progress

	select * from TicketStatus where ticketTypeId =1 --3	Work in Progress, 1	Open, 2	Assigned
	
	select * from TicketStatus where ticketTypeId =2 --14	Work in Progress, 64	Open, 13	Assigned


				 where templateName like '%Work%' and customerId = 147  --- 1946  templateId
        	insert into NotificationEmailTemplate(templateName,template,templateSubject, customerId, isOutageNotificationTemplate, isOutageSMSNotification) 
            values('workin- progress','', ' $PRIORITYNAME Notification - Ticket Number: [ $TICKETNOTODISPLAY ]  has been updated', 147,  0,0)
        

	
	select top 100 * from NotificationEmailTemplate where templateName like '%Work%' and customerId = 211  --- 1946  templateId, 1365, 1450


	
	insert into NotificationEmailTemplate(templateName,template,templateSubject, customerId, isOutageNotificationTemplate, isOutageSMSNotification) 
            values('workin- progress','  ', ' $PRIORITYNAME Notification - Ticket Number: [ $TICKETNOTODISPLAY ]  has been updated', 147,  0,0)


	--- For Notifications:

	select * from NotificationRules where customerId = 147 and serviceId = 84 and deleted = 0 and notifyBasedOnId in (3, 14)
	and templateId in (484, 488, 489)-- 1958   Work in progress

		select * from NotificationRules where customerId = 147 and serviceId = 84 and deleted = 0 and notifyBasedOnId in (64, 13)
	and templateId in (484, 488, 489)-- 1958   Work in progress

	select * from NotificationEmailTemplate where templateId in (484, 488, 489)

	-- For 

	Select * from NotifyBasedOn 

	INSERT INTO NotificationRules(customerId,ticketTypeId, notificationMode, notificationTo,templateId, ruleName, 
	serviceId,notifyBasedOnId, deleted,entrystateid) 

	values(147, 1, '', '', 1946, '', 84, , 0, )

    Select customerId,ticketTypeId,priorityId,duePercent,'EM','',

	1837,'SMS 50', workgroupid, supportgroupid, serviceId,notifyBasedOnId,deleted, entrystateid from NotificationRules WHERE  and customerId=147

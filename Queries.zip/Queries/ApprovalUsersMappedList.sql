   
   
      select  s.serviceName,
	  case 
	  when sc.ticketTypeId = 1 then 'INCIDENT' 
	  when sc.ticketTypeId =2 then 'SERVICE REQUEST'
	  ELSE ''
	  END AS 'Ticket Type',
	  c.category, sb.subCategory, cc.classification,
	  A2.approverName, A1.levelName from vwApprovalEntityMappingConverted VM
      inner join ServiceCategoryMapping SC on VM.categoryId = sc.categoryId
	  inner join Service S on S.serviceId = SC.serviceId
	  inner join ServiceCustomerMapping scc on scc.serviceId = s.serviceId
	  inner join ApprovalMatrixLevel A1 on A1.approvalMatrixId = VM.approvalMatrixId
	  inner join ApprovalMatrixApprover A2 on  A2.levelId = A1.levelId 
	  inner join Category C on C.categoryId = sc.categoryId 
	  inner join SubCategory Sb on sb.categoryId = c.categoryId
	  inner join Classification Cc on cC.subCategoryId = sb.subCategoryId
	  where a1.deleted=0 and s.deleted = 0 and A2.deleted=0 and c.deleted=0 and scc.customerId =167  and sb.deleted=0 and cc.deleted=0 and cc.classificationId in( 
	  select  vm.classificationId from vwApprovalEntityMappingConverted where customerId =167 and categoryId in (
	  select categoryId from ServiceCategoryMapping where ticketTypeId in( 1,2) and deleted = 0 
	  ))
	  and  
	 sb.subCategoryId in (select  vm.subCategoryId from vwApprovalEntityMappingConverted where customerId =167 and categoryId in (
	  select categoryId from ServiceCategoryMapping where  ticketTypeId in (1,2) and deleted = 0 
	  ))
	order by category, A1.levelName asc
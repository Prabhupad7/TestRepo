

        ---> 


		select * from service where serviceName like '%Data%' --->  52	Data Center

		select * from Customer where customerName like '%tagic%'

        select top 10 * from  reportMaster order by 1 desc

		---- 529	No of Emails Triggered Per Each Ticket	GetNoOfEmailsTriggredPerTicket

		RP000530, and SP for this report is  

	    select * from ReportMaster where reportMasterID in ( 24, 530)

		select * from ReportParameter where reportMasterID in ( 24, 530)

		-- update ReportMaster set query= 'usp_GetReassignedTickets_EFL' where reportMasterID in (  530)

	--   Insert  into ReportMaster	(name, 	query,	isCustomReport,	isInline,	deleted,	createdBy,	createdOn,	description,	ticketTypeId,	ThreadId,	SourceTypeId)
    --   VALUES ('Reassigned tickets from RMC Messaging to Service Desk EFL', 'GetReassignedTickets_EFL', 0, 0, 0, 6, GETDATE(), 'Reassigned tickets from RMC Messaging to Service Desk EFL', 1, 1, 2)

	    select top 1  * from ReportMaster order by 1 desc ---> 74

		select  * from ReportMaster where ReportMasterid = 25

		select * from ReportRoleMap


		select * from ReportParameter 

		select * from Users where loginName like '%gc1179%'



		select * from ReportParameter where reportMasterId in (24, 530)

		select * from ReportParameter where reportMasterId = 529 

		select * from ReportParameter where reportMasterId = 530

		select top 1  * from ReportParameter order by 1 desc

	  --Insert into ReportParameter(reportMasterId, title, name, dataType, rowType, ordering, isMandatory)

	  --SELECT 530, title, name, dataType, rowType, 2, isMandatory  FROM ReportParameter where reportParameterId in ( 131)


	--  154	Actual Time Spent & Expected Duration	usp_StandardReport_SLAcalculation

    --Insert  into ReportMaster	(name, 	query,	isCustomReport,	isInline,	deleted,	createdBy,	createdOn,	description,	ticketTypeId,	ThreadId,	SourceTypeId)

    --VALUES ('No of Emails Triggered Per Each Ticket', 'GetNoOfEmailsTriggredPerTicket', 0, 0, 0, 6, GETDATE(), 'No of Emails Triggered Per Each Ticket', 1, 1, 2)


	-- Update ReportMaster set name = 'Actual Time Spent_Expected Duration', description='Actual Time Spent ExpectedDuration'  where reportMasterId  = 154


	select * from ReportMaster where reportMasterID in (24, 530)




	--update ReportMaster set ticketTypeId = 102 where reportMasterID = 530

	select * from ReportParameter where reportMasterId =530

	--update ReportParameter set name = 'endDate' where reportparameterId = 789

	select * from Users where loginName like '%SMC%'

	select * from Users where email like '%venkataramanaiah%'  --26093, 

	select * from Users where email like '%maya%'  --419, 

	----> 39, 48, 75

	select top 10 * from ReportExecution order by 1 desc


	@startDate

	@endDate



	select * from ReportRoleMapping where ReportMasterId =24  and RoleId = 

		select * from ReportParameter where reportMasterId =24

		select * from Users where loginName like '%venkat%'

	--Insert into ReportRoleMapping ( RoleId, ReportMasterId, IsDeleted)
	--values (39, 530, 0),
	--(48, 530, 0)
	


	check in the report which is ITSM report and the check the report masterId in reportMaster table 

	select * from ReportExecution

	select top 100 * from ReportExecution order by id desc

	RP002 - All IM and SR Combined SLA Ticket Dump


	select top 100 * from ReportMaster where reportMasterID = 23

	--- 45	RP004 - All IM and SR Active Ticket Dump_20200831131623686_952.csv	usp_StandardReport_RP004_getAllActiveIM&SRCombinedTicketDump


	usp_StandardReport_RP002_getAllIM&SRCombinedSLATicketDump

	usp_StandardReport_RP002_getAllIM&SRCombinedSLATicketDump


	Select * from Requestor where requestoremail like '%NagaveniC@microland.com%'

	--------   microland@bng1

	select * from ReportMaster where reportMasterID = 19

	select top 1 * from ReportMaster ORDER BY 1 DESC

	select * from ReportMaster where reportMasterID in ( 19, 122, 154)

		select top 10 * from ReportMaster  order by reportMasterID desc

	select * from ReportParameter where reportMasterId  


	--insert into ReportParameter(reportMasterId, title, name, dataType, rowType, ordering, isMandatory)

	SELECT 154, title, name, dataType, rowType, ordering, isMandatory  FROM ReportParameter where reportMasterId = 19


	--  154	Actual Time Spent & Expected Duration	usp_StandardReport_SLAcalculation

  -- Insert  into ReportMaster	(name, 	query,	isCustomReport,	isInline,	deleted,	createdBy,	createdOn,	description,	ticketTypeId,	ThreadId,	SourceTypeId)

    VALUES ('Actual Time Spent & Expected Duration', 'usp_StandardReport_SLAcalculation', 0, 0, 0, 6, GETDATE(), 'Actual Time Spent & ExpectedDuration', 1, 1, 2)


	-- Update ReportMaster set name = 'Actual Time Spent_Expected Duration', description='Actual Time Spent ExpectedDuration'  where reportMasterId  = 154


	select * from ReportMaster where reportMasterID = 24


	exec GetReassignedTickets_EFL '2020-08-07', '2020-10-07'

WITH Ticket AS(
SELECT ROW_NUMBER() OVER(PARTITION BY Ticketno ORDER BY ticketno) rowno,
customerName ,serviceName, requestorName, [Requestor Email], ticketno,createdOn,actualStart,firstAssignmentTime,description, currentStatus,currentWorkgroup,currentPriority,workgroup,status,priority,impact, StartDateTime, EndDateTime, TotalDuration as [TotalDuration(Min)],ActualDuration    as [ActualDuration(Min)],resolvedTime,ResponseSLAStatus,
ResolutionSLAStatus, [Resolution Adjusted/NotAdjusted] AS [Resolution_Adjusted_Status]

FROM dbo.vwTimeStamp V WHERE V.customerId =167 AND createdon BETWEEN '2020-08-07' AND '2020-10-07' and currentStatus like 'Resolved' and currentWorkgroup not like 'RMC%' and (workgroup like 'RMC%' and statusid  in (3,14))   )

SELECT  customerName ,serviceName, requestorName, [Requestor Email], ticketno,createdOn,actualStart,firstAssignmentTime,description,currentStatus,currentWorkgroup,currentPriority,
workgroup,status,priority,impact,StartDateTime,EndDateTime, [TotalDuration(Min)],  [ActualDuration(Min)],resolvedTime,ResponseSLAStatus,
ResolutionSLAStatus,   [Resolution_Adjusted_Status] FROM Ticket T where rowno = 1 order by T.ticketno




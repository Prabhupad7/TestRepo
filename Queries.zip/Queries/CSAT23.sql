  
     select * from customer where customerId = 150

    select distinct rulename  from NotificationRules where customerId = 157 and deleted = 0 and duePercent is null  and ruleName like '%feed%' 

 

   select  * FROM SERVICE WHERE SERVICEID IN (SELECT DISTINCT (serviceId) FROM ServiceCustomerMapping WHERE customerId in (157) AND deleted = 0) 

   SELECT * FROM NotificationEmailTemplate WHERE customerId = 157  --AND DELETED = 0

   SELECT * FROM NotificationEmailTemplate WHERE customerId = 182   -- AND  TEMPLATEID = 962

    $PRIORITYNAME Survey Notification - Ticket Number: $TICKETNOTODISPLAY

	select * from NotifyBasedOn -- Notifybasedon = 1

	select * from ticketstatus where ticketTypeId = 1          --- 11, 

	select * from ticketstatus where ticketTypeId = 2    --- 21, 

	select * from NotificationRules where customerId = 157 and templateId = 962



select t.statusName, * from ticket t
join requestor r on r.requestorId=t.requestorId
where customerId=4 and r.requestorEmail='vishalds@microland.com'
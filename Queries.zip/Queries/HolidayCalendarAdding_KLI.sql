

select * from HolidayCalendar

10	Goa	Goa

select top 17 * from HolidayCalendarDetail order by  1 desc

 --Insert into HolidayCalendarDetail (holidayCalendarId, holidayDate, holidayName)
 --values 
  
 (134, '2021-01-26 00:00:00.000', 'Holiday'),
 (134, '2021-03-29 00:00:00.000', 'Holiday'),
 (134, '2021-04-02 00:00:00.000', 'Holiday'),
 (134, '2021-08-15 00:00:00.000', 'Holiday'),
 (134, '2021-09-10 00:00:00.000', 'Holiday'),
 (134, '2021-10-02 00:00:00.000', 'Holiday'),
 (134, '2021-10-15 00:00:00.000', 'Holiday'),
 (134, '2021-11-04 00:00:00.000', 'Holiday'),
 (134, '2021-12-25 00:00:00.000', 'Holiday'),
 (10, '2021-10-15 00:00:00.000', 'Holiday'),
 (10, '2021-11-04 00:00:00.000', 'Holiday'),
 (10, '2021-12-25 00:00:00.000', 'Holiday'),



 (10, '2021-01-23 00:00:00.000', 'Holiday'),
 (10, '2021-08-21 00:00:00.000', 'Holiday'),
 (10, '2021-01-23 00:00:00.000', 'Holiday')         


 --(2, '2021-08-22 00:00:00.000', 'Holiday'),
 --(2, '2021-10-02 00:00:00.000', 'Holiday')


   select * from Users where email = 'kli.pooja-banavalikar@kotak.com'  ---->  1097   46

   ---->  RP000046     - RP002 All IM & SR Combined SLA Ticket dump

   select * from ReportMaster where reportMasterID = 46

   select * from ReportRoleMapping where RoleId = 46 and reportMasterID = 46  ----->  

   select * from workgroup where workgroupid = 80

   s
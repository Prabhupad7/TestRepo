

select * from Customer where customerName like '%Eureka%' ----> 167	Eureka Forbes Limited

select c.customerName,s.serviceName,ct.category,sct.subCategory,cl.classification,d.deviceName,d.ipAddress,a.assignmentgroupName,vw.Rank
from vwAssignmentRulesConverted vw
                inner join customer c on vw.customerId = c.customerId
                left join Service s on vw.serviceId = s.serviceId
                left join Category ct on vw.categoryId = ct.categoryId
                left join SubCategory sct on vw.subCategoryId = sct.subCategoryId
                left join Classification cl on vw.classificationId = cl.classificationId
                left join Device d on vw.deviceId = d.deviceId
                left join assignmentgroup a on vw.PrimaryAssignmentGroupId=a.assignmentgroupId
                where vw.customerid= 167 and vw.Deleted = 0 and d.deleted = 0 and a.assignmentgroupId = 93


SELECT customerId, serviceId, workgroupId, priorityId,* from Ticket where ticketNo = 3159422

select * from NotificationRules where customerId = 207 and ticketTypeId= 2
and deleted = 0 and serviceId = 476 and workgroupid is null

select * from NotificationRegistry where sourceId = 3159422
order by 1 ASC

select * from NotificationHistory where TicketNo = 3159422

select * from ServiceLevelTracking where sourceId = 3159422

select serviceId, customerId, workgroupId,* from Ticket where ticketNo= 3170614 

select * from ServiceLevelTracking where sourceId = 3159422


	  

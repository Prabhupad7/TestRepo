

---->  ML Unix ShashikantLS@microland.com - SHASHIKANTLS

select * from Users where email like '%JithuJR@microland.com%'  ---->  26701 75

select roleId,* from Users where email like '%venkataramanaiah%'  ---->  26093 48

select roleId,* from Users where email like '%maya%'  ---->  419 75

select roleId,* from Users where email like '%JithuJR@microland.com%'  ---->  26701 75

select * from Users where userId =6  ---->  6 39

select * from MenuMaster where menuUrl like '%TASK%'  ---->  296, 297 , 298

select * from MenuRoleMapping where roleID = 75 and menuID in (296, 297 , 298)

--delete from MenuRoleMapping where id in (5155,
--										 5156,
--										 5157)



select * from MenuMaster where menuUrl like '%TASK%'  ---->  296, 297 , 298

select * from MenuRoleMapping where roleID = 75 and menuID in (296, 297 , 298)

select * from MenuRoleMapping where roleID = 48 and menuID in (296, 297 , 298)

--Update MenuRoleMapping set isdeleted = 0 where id in (5384, 5385, 5386)

select * from Customer where customerName like '%Bunge%'   ---> 218

select * from SMCFeatures  ---->  51	TASK_MANAGEMENT

select top 100 * from SMCFeatureCustomerMapping 
where FeatureId = 51 and CustomerId = 218

select top 100  * from SMCFeaturesStatusMapping where SMCFeaturesId =51

---> select landingPageUrl,* from role where roleId=48


select * from RoleAccess  where accessName like '%TASK%'


select * from RoleAccessMapping  where roleId = 39 and roleAccessId in (
select Id from RoleAccess  where accessName like '%TASK%'
)


select * from RoleAccessMapping  where roleId = 75 and roleAccessId in (
select Id from RoleAccess  where accessName like '%TASK%'
)


select * from RoleAccess where ticketTypeId = 5

---> RoleId : 39 75

--insert into RoleAccessMapping (roleId, roleAccessId, permission, isdeleted)


select 75, roleAccessId, permission, isdeleted from RoleAccessMapping  where roleId = 75 and roleAccessId in (
select Id from RoleAccess  where accessName like '%TASK%'
)


select c.customerId, c.customerName, c.custAssignmentGroupId, c.custAssignmentGroupName from UserCustomerAssignGroupMapping U
inner join CustomerAssignmentGroupMapping C on c.custAssignmentGroupId = u.custAssignmentGroupId
where u.userId = 26701

select * from Customer where customername like '%Bunge%'   ----->  218	Bunge

select workgroupId, WorkgroupName, * from ticket where customerid = 218 and ticketTypeid = 5   ----->  218	Bunge

select distinct workgroupId, WORKGROUPnAME from ticket where customerid = 218 and ticketTypeid = 5 


---->  


select * from customer where customerName like '%Cloud%'

select * from customer where customerName like '%khaitan%' ---> 199	Khaitan And Co

select * from autoticketserviceemailconfig
where apikey in (Select keyname from ApiKey where customerId=199) ---> itsupport@Khaitanco.com

select top 100 * from NotificationServiceEMailconfig where customerid = 199 

--update autoticketserviceemailconfig set password ='Summer123' where id = 325

--update NotificationServiceEMailconfig set password ='Summer123' where id = 75

Select top 100 * from AutoTicketEventLog  where apikeyid in (Select keyid from ApiKey where customerId=204) 
order by createdOn desc;  ----> apikeyId = 19

---> After that we need to Restart the Services: Smartcenter Common email exchange , Smartcenter Ticket Schedular service.

----> After that we need to send a test email and then need to verify Mail box and as well ticket for email.

select top 50 * from AutoTicketEventLog where apikeyId in (106,115,117)
order by 1 desc

select * from ApiKey where customerId = 199  --> 106,115,117

select top 500 * from AutoTicketEventLog 
order by 1 desc

select * from Users where email like '%RAMDj@microland.com%'

select * from Users where loginName like '%HimalayTP%'
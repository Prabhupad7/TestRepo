

--> Kumar-R&d Body Engine	sandeep1.kumar@heromotocorp.com


--Update Requestor set RequestorName ='Pramod Kumar Sharma', LastName='Kumar Sharma',
--department='Sales and marketing' where Requestorid = 5069  abhinav.grover@heromotocorp.com

----> rishabhsingh.parihar@heromotocorp.com  14367

select * from Requestor where employeeId = '14367'
  
select * from Requestor where requestorEmail like '%kush.agarwal@heromotocorp.com%'  ---->  93825

--Update Requestor set requestorName='Neeraj Gupta',	lastname='Gupta', displayname='Neeraj Gupta', department ='R and D Chassis',
--mobileno='919999511590'
--where requestorId = 93825 
 
select * from Hero_Users where emailAddress like '%kush.agarwal@heromotocorp.com%'  --->  



--Insert into Hero_Users (firstName, lastName, emailAddress, workAddress1, mobilePhone1, employeeId, employeeTitle, manager, department)

--values ('Kush', 'Agarwal', 'kush.agarwal@heromotocorp.com', 'HM5V','918826680690', '14457','Team Manager','','Frame Plant')

--+918570863964  
select * from Hero_Users where id = 5710

--update Requestor set mobileno='8655882886', employeeId='90131863', designation ='Project Support', department ='E&E Lighting' 
--where requestorId = 59658

--Update Hero_Users set mobilePhone1='917869033412', costCenter='Haridwar Plant',  employeeId='14417', manager='balwinder.singh@heromotocorp.com'
----department='Elect & Electronics', employeeTitle='Technical Support'
--where id =6034

select * from servicelevelTracking where sourceid = 2945939

select * from NotificationRegistry where sourceid= 3149648

Select * from NotificationRules where ruleid in (
select ruleid from NotificationRegistry where sourceid= 3149648 )

select * from Workgroup where workgroupId = 233

select * from NotificationHistory where ticketNo = 3149648

--IM3158485  

--                 exec deletetickets @ticketNo = '3170465' 
--				exec deletetickets @ticketNo = '3170614'




--Insert into VarcharCustomAttribute (
--CustomerId, SourceId, SourceType, PrimaryId, Varchar6, Varchar10, Varchar12, Varchar13,  
-- Varchar46, Varchar47, Varchar42, Varchar43, Varchar44, Varchar48, varchar49, Varchar50,   Varchar51,  Varchar52, 
-- Varchar53, Varchar54, Varchar57, Varchar58, Varchar59, Varchar60, Varchar63, Varchar64, Varchar65, 
-- Varchar66, Varchar67, Varchar68, Varchar69,  Varchar70, Varchar71, Varchar73,  Varchar82, Varchar83, Varchar84, Varchar85
--)

--		select 1, 18, 1, AssetId,PhysicalCPU,Is  RAMGB, OSVersion, OSServicePack,ChasisManagementIP, Subnet, Building, RackNo, ServerType,Gateway, DNSServer, 
--		Environment, NetworkAdapter, Traverse, ServerRole, ServiceRoleTataAIG, Verified, VerifiedBy, VerificationRemarks, PatchStatus, [Noof CorePerCPU],
--		TotalCoreorThreads, CPUMake, CPUSpeed, Partition1, Partition2, Partition3, Partition4, Partition5, WarrantyAMCEnd, GroupName, GroupHead,
--		ApplicationOwner, ApplicationDetails

--		   from Wintel_11092021$ where sourceid  = 18 and AssetId in (		
--24237,24238,24239,24240,24241,24242,24243,24244,24245,24246,24247,24248,24249,24250,24251,24252,24253,24254,
--24255,24256,24257,24258,24259,24260,24261,24262,24263,24264,24265,24266,24267,24268,24269)
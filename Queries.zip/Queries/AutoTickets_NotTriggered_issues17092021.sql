

select * from ServiceLevelTracking where sourceId = 3170479

--Update ServiceLevelTracking set adjustedDuration = 40, actualDuration = 23, isBreached = 0 where 
--serviceLevelTrackingId = 7321990


select w.currentStatusId, w.nextStatusId,wsn.name as nextstatusname, w.workflowActivityId, wa.name as activityname,
        wa.isselfdriven, wa.executionName, wa.executionPath
        from Workflow w
        inner join WorkflowStatus ws on ws.id = w.currentStatusId
        inner join WorkflowTicketStatusMapping wts on wts.WorkflowStatusId = ws.id
        inner join TicketStatus ts on ts.statusid = wts.ticketStatusId
        and ts.statusid = 3 and ts.ticketTypeId = 1
        left outer join WorkflowStatus wsn on wsn.id = w.nextStatusId
        inner join WorkflowMaster wm on wm.id = w.workflowMasterId and wm.deleted = 0
        inner join WorkflowActivity wa on wa.activityId = w.workflowActivityId
        inner join WorkflowMapping wmp on wmp.workflowMasterId = wm.id
        where wts.ticketStatusId = 3 and wm.sourceTypeId = 1
            and isnull(wm.sourceSubtypeId, 0) = isnull(null, 0) and wmp.customerId = 1 and w.deleted = 0




   select * from Workflow where workflowActivityId = 37  and workflowMasterId = 6

   BCN-LX-ESX10
BCN-LX-ESX11


select * from customer where customerName like '%Bunge%' ----->  218	Bunge

select * from Device where customerId = 218 and  deviceName like '%BCN-LX-ESX10%'  ---> 32099	bcn-lx-esx10

select * from Device where customerId = 218 and  deviceName like '%BCN-LX-ESX11%'  ---> 32100	bcn-lx-esx11

select * from Device where deviceId = 31032  ---> 31032	Generic 

31032 ,  1029773	Bunge Backup Failed

select * from ApiKey where customerId = 218   --->  

select top 100 * from AutoTicketEventLog where 
apikeyId in (select keyId from ApiKey where customerId = 218)
order by 1 desc

select * from AutoTicketServiceRule 
where apiKeyId = 137   and deviceId in (32099, 32100) ---> 1029765	Bunge CPU

select * from AutoTicketServiceRuleDetails 
where autoTicketServiceRuleId = 1029765     ----> 1029765

--1031629	Bunge CPU
--1031630	Bunge CPU

--Insert into AutoTicketServiceRuleDetails

--select autoTicketServiceRuleColumnId, criteria, criteriaValue, isDeleted, opr, 1031630 from AutoTicketServiceRuleDetails 
--where autoTicketServiceRuleId = 1029765  


--Insert into AutoTicketServiceRule (Name, IsDefault, TicketTypeId, RequestorId, ServiceId, CategoryId, SubCategoryId, ClassificationId, ImpactId, 
--PriorityId, CreatedById, CreatedOn, apiKeyId, deviceId, requesorLocationId, isDeleted)
--values 
--('Bunge CPU', 0, 1, 58155, 532, 5756, 21984, 89526, 5, 9, 6, GETDATE(), 137, 32099, 4317, 0),
--('Bunge CPU', 0, 1, 58155, 532, 5756, 21984, 89526, 5, 9, 6, GETDATE(), 137, 32100, 4317, 0)

select * from autoticketserviceemailconfig
where apikey in (Select keyname from ApiKey where customerId=218)


select top 100 * from AutoTicketEventLog where 
apikeyId in (select keyId from ApiKey where customerId = 218) and inDescription like '%BCN-LX-ESX10%'
order by 1 desc
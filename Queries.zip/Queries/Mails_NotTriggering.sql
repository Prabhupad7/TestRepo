
SR2719965  
SR2719148


select customerId,serviceId,priorityId,workgroupId ,* from ticket where TicketNo = 2627181  -- 2576690  2583088,, SR2427240

select customerId,serviceId,priorityId,workgroupId ,* from ticket where TicketNo = 2427240 ---   190	313	14	507	2427240

Select * from NotificationHistory where ticketno =2427240  2583086 2576690

--master table for notificationrules --insert

  Select * from NotificationRules where customerId = 190 and serviceId = 313  and workgroupid = 507  200   --630


  INSERT INTO NotificationRules(customerId, ticketTypeId, priorityId, duePercent, notificationMode, notificationTo, notificationCC, templateId, ruleName, workgroupid, supportgroupid, serviceId, notifyBasedOnId, entryStateId, deleted, categoryId, interval, numberOfOccurence)

  SELECT  customerId, ticketTypeId, priorityId, duePercent, notificationMode, notificationTo, notificationCC, templateId, ruleName, 630, supportgroupid, serviceId, notifyBasedOnId, entryStateId, deleted, categoryId, interval, numberOfOccurence  FROM NotificationRules WHERE customerId = 147 and workgroupid = 200 and serviceId = 84



--refere
insert into RequestorAttributeConfiguration(attributename,label,ismandatory,isvisible,createdon,createdby,deleted,customerid,sequencenumber)

select attributename,label,ismandatory,isvisible,createdon,createdby,deleted,212,sequencenumber from RequestorAttributeConfiguration where customerid = 199


 select * from AssignmentGroup

 select * from customerAssignmentGroupMapping

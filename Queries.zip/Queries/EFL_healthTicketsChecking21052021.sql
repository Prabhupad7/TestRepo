

--------> To check EFL health Tickets OR Schedular tickets: 

select top 100 * from TS_AutoTicketSchedular order by 1 desc---- ID 262,261,260,259,258,257,256

select top 100 * from TS_AutoTicketSchedularRegistry order by 1 desc
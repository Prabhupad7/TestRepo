

--Checked auto ticket event logs table and confirmed tickets are generating for all the customers (by checking the latest created on date)
--	 Identified there was no auto ticket log for Macom in past 3 hours.
--	 Sent an test email to help@macom.com to by mention subject as test ticket.
--	 In the few mins tickets was logged in the autoticket event log table.
--	 Logged into SMC portal and resolved the test ticket which is created.



-- 1)  Checked auto ticket event logs table and confirmed tickets are generating for all the customers (by checking the latest created on date)
--2)       Select top 20 * from AutoTicketEventLog  order by createdOn desc
--        open a new window & see server time   -: select GETDate() 
--3)      Sent an test email to help@macom.com to by mention subject as test ticket.
--4)      In the few mins tickets was logged in the autoticket event log table.
--5)      Logged into SMC portal and resolved the test ticket which is created.

---> from Mahesh: \

select top 100 * from AUTOTICKETSERVICERULE where id = 1028318

select * from autoticketservicemailconfig -- holds the maIL BOX DETAILS FOR AUTO TICKET CUTTING
SELECT * FROM AUTOTICKETSERVICERULE
SELECT * FROM AUTOTICKETSERVICERULEDETAILS
SELECT * FROM AUTOTICKETSERVICERULECOLUMN
SELECT * FROM APIKEYACTIONMAPPING


------------->  

select * from TS_AutoTicketSchedular t where t.customer ='MLCIS' and t.title like '%Mid-Day Report%' --and t.deleted=0 --116

select * from TS_AutoTicketSchedular t where t.customer ='MenaBev'  

select top 100  * from TS_AutoTicketSchedularRegistry  where autoTicketSchedularId = 145
order by 1 desc   -----> 145 

--2021-05-31 02:30:00.000

--2021-05-31 05:30:00.000

--2021-05-31 08:30:00.000

--2021-05-31 11:30:00.000


  select * from customer where customerName like '%MLCIS%' --> 3

  select * from customer where customerName like '%sonic%'   --> 219

Select GETDate();

Select top 100 * from AutoTicketEventLog  where apikeyid in (Select keyid from ApiKey where customerId=3) 
order by createdOn desc;  ----> apikeyId = 19



Select * from ApiKey where customerId=217 ; 


select * from autoticketserviceemailconfig
where apikey in (Select keyname from ApiKey where customerId=218)

------> mlsonicwallsupport@microlandsmartcenter.com   M!cr0land@bng1


select * from autoticketserviceemailconfig where apikey='21931B3B-EF70-422C-8D5C-5F33D0E60274'

select * from autoticketserviceemailconfig where apikey='4FC0A5A6-6911-4A42-973C-A08829D2A09C'
----> mlmenabevsupport@microlandsmartcenter.com  M!cr0land@bng1   M!cr0land@bng1

----->   https://mail.microland.com/ we have to open the this url and need to login to the mail box.


select * from autoticketserviceemailconfig where apikey in (Select keyname from ApiKey where customerId=3)


----->    MlcisAutotikcet@microlandsmartcenter.com
----->    microland@bng2

		--MlcisAutotikcet@microlandsmartcenter.com	microland@bng2	MlcisAutotikcet@microlandsmartcenter.com
		--MicrolandOne@microlandsmartcenter.com	Microland$123	MicrolandOne@microlandsmartcenter.com



 --   select * from Requestor where requestoremail like '%virendra.harne@v5global.com%'

 --   select * from Requestor where alias like '%eflitservicedesk%' --->  21229

	-- select * from CustomerRequestorMapping where requestorId = 21229
	   
	   -- update Requestor set failedLoginAttemptCount = 0 where requestorId = 57239

	       select * from CustomerRequestorMapping where requestorId = 21229

	   	   select * from CustomerRequestorMapping where requestorId = 57239

		 --  update CustomerRequestorMapping set isLoginAllowed =1 where requestorId = 57239

	--select * from Requestor where alias like '%eflitservicedesk%'

  

  ----->  Verifying the configured Category and SubCategory details for AutoTicketing: 

  Select top 100 * from AutoTicketEventLog  where apikeyid in (Select keyid from ApiKey where customerId=3) 
  order by createdOn desc;

select * from autoticketserviceemailconfig 
where apikey in (Select keyname from ApiKey where customerId=207 )


Select *  from ApiKey 
where keyname='F33233DF-CFD2-45DB-A846-0B2E95B5EEC3'   ---> 121

select top 100 * from AutoTicketEventLog where apikeyId = 121
order by 1 desc


select top 10  * from AutoTicketServiceRule where id =104

select top 10 * from AutoTicketServiceRuleDetails where autoTicketServiceRuleId = 104


----> For Menabev: 

select top 1000  * from AutoTicketServiceRule where apikeyid = 134

select count(*) from AutoTicketServiceRule where apikeyid = 134

select * from Device where deviceName like '%mp-dc-int-isp-rt%' ---->    31180

select top 100  * from AutoTicketServiceRule where apikeyid = 134 and deviceid = 31180   ----->   1030675

select top 10 * from AutoTicketServiceRuleDetails where autoTicketServiceRuleId = 1030675



Select top 1000 * from AutoTicketEventLog  where apikeyid in (Select keyid from ApiKey where customerId=217) 
--and inRequestorEmail like '%tsom_notifications@menabev.com%'
order by createdOn desc;

----->  tsom_notifications@menabev.com


select top 100 * from AutoTicketEventLog  where inInformation like '%MLCORPPUNCM01%'
order by createdOn desc

select top 10 * from ApiKey where keyId = 19   ----> 19 customerId: 3

select * from autoticketserviceemailconfig where apikey in (
select keyname from ApiKey where customerId=3
)

select * from Customer where customerName like '%Unity%' ---- 207



select * from autoticketserviceemailconfig where apikey in (
select keyname from ApiKey where customerId = 207 )



---->  mlunityhelpdesk@microlandsmartcenter.com


select * from Users where firstName like '%Mandar%'  ---> 25804	Mandar

select roleId, * from Users where userId = 25804  ----> 48

select * from MenuMaster  -----> 281	/Dashboard/99

select * from MenuRoleMapping where roleid = 48 and menuId = 281

--Insert into MenuRoleMapping

--select 48, 281, 0


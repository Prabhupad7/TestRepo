﻿
    
--please provide approval email from account head.


--step -- Cusomer table mark customer as delted


--Service Customermapping mark deleted 


--customerassignment group mapping deleted = 0


---------------------------------------------------------------------------------------------------------------------------------------------


select * from Customer where customerId in (161, 187, 191,200,164,162,165,184,146)

select * from Customer where customerName = 'Vodafone Idea' and deleted = 0 --195

--update Customer set deleted = 1 where customerId in (161, 187, 191,200,164,162,165,184,146)

select * from ServiceCustomerMapping where customerId = 195 and deleted = 0

--update ServiceCustomerMapping set deleted = 1 where serviceCustomerMappingId in(1913,1914,1915,1916,1917,1918,
--1919,1920)

--update ServiceCustomerMapping set deleted = 1  where customerid in (161, 187, 191,200,164,162,165,184,146)

select * from CustomerAssignmentGroupMapping where customerId = 195 and deleted = 0
--update CustomerAssignmentGroupMapping set deleted = 1 where custAssignmentGroupId in(2550,
--2552,2554,2556,2557,2558,2559,2562)
 
 --update CustomerAssignmentGroupMapping set deleted = 1 where customerId in (161, 187, 191,200,164,162,165,184,146)




​[11:34 AM] Sweta Saran
    these steps are followed for offcoarding






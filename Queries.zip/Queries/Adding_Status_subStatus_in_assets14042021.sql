

select * from Users where displayName like '%Mohammad%'  ----->   857   38

select * from Users where displayName like '%geeta%'  ----->   899   38

select * from Users where loginName like '%moibrah%'    ----->  713  6

select * from Users where loginName like '%moibrah%'  

select * from users where userId in (857, 899, 713)   ----->  

--Update users set LevelId = 1, roleId = 38, UserTypeId = 3 where userId in (713)

select * from Admin_UserCustomerAdminMapping where UserId = 713

    
select top 100 * from Asset_ButtonAndEntityUserMapping  where userId = 899

select top 100 * from Asset_ButtonAndEntityUserMapping  where userId = 713


------>  

--As discuss Please add the below Categories in the Status and Sub Status.

--�	Delivery Pending 
--�	Delivery Received


select * from CustomAttributeColumnMapping where DisplayName ='Sub Status' and SourceId = 5

--Update CustomAttributeColumnMapping set ValueSourceId = 2, ValueSource =ValueSource+',Delivery Pending,Delivery Received'
--where id in (
--225
--,226
--,22

select * from Asset_Status where AssetTypeId = 5

--insert into Asset_Status (Status, AssetTypeId, deleted, createdBy, createdOn, DisplayOrder)
--values ('Delivery Pending', 5, 0, 6,GETDATE(), 17),
--('Delivery Received', 5, 0, 6,GETDATE(), 18)

select * from AssetEntityType  ----->   5	Desktop





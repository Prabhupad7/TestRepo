
  SELECT  DISTINCT s.servicename AS ServiceName, 
  CASE slag.subtypeid WHEN 1 THEN 'Incident' WHEN 2 THEN 'Service Request' WHEN 3 THEN 'Change' WHEN 4 THEN 'Problem' END TicketType, 
  CASE slo.servicelevelobjectivetypeid WHEN 1 THEN 'Response' WHEN 2 THEN 'Resolution' end SLAType,   p.priority AS Priority,   i.impact AS Impact, 
  CASE WHEN wg.workgroup IS NULL THEN 'All' ELSE wg.workgroup END AS Workgroup,  slo.responsetimeinmin AS 'SLADurationTime(in mins)', 
  CASE slo.is24x7service WHEN 0 THEN 'No' WHEN 1 THEN 'Ye' END is24x7service, 
  CASE WHEN slo.workhourid = 0 THEN '12:00 AM tO 11:59 PM (Mon to Sun)' ELSE wh.description END AS ServiceWindow, 
  CASE WHEN slo.isdefault = 1 THEN 'Yes' ELSE 'No' END AS IsDefault, isnull(rl.location, 'All') TicketSLALocation  
  FROM   servicelevelobjective slo 
  JOIN service s ON s.serviceid = slo.serviceid 
  JOIN priority p ON p.priorityid = slo.priorityid 
  JOIN impact i ON i.impactid = slo.impactid 
  LEFT JOIN workgroup wg ON wg.workgroupid = slo.workgroupid 
  LEFT JOIN workhours wh ON wh.workhourid = slo.workhourid 
  JOIN servicelevelagreement slag ON slag.servicelevelid = slo.servicelevelagreementid 
  LEFT JOIN requestorlocation rl ON rl.customerid = slag.customerid 
 AND rl.locationid = slo.locationid 
 WHERE   --slo.locationId = 143 
  slag.customerId = 3
 AND slo.isdelete = 0   AND s.deleted = 0     AND p.deleted = 0   AND i.deleted = 0  

 --------------> 

   SELECT  DISTINCT s.servicename AS ServiceName, 
  CASE slag.subtypeid WHEN 1 THEN 'Incident' WHEN 2 THEN 'Service Request' WHEN 3 THEN 'Change' WHEN 4 THEN 'Problem' END TicketType, 
  CASE slo.servicelevelobjectivetypeid WHEN 1 THEN 'Response' WHEN 2 THEN 'Resolution' end SLAType,   p.priority AS Priority,   i.impact AS Impact, 
  CASE WHEN wg.workgroup IS NULL THEN 'All' ELSE wg.workgroup END AS Workgroup,  slo.responsetimeinmin AS 'SLADurationTime(in mins)', 
  CASE slo.is24x7service WHEN 0 THEN 'No' WHEN 1 THEN 'Ye' END is24x7service, 
  CASE WHEN slo.workhourid = 0 THEN '12:00 AM tO 11:59 PM (Mon to Sun)' ELSE wh.description END AS ServiceWindow, 
  CASE WHEN slo.isdefault = 1 THEN 'Yes' ELSE 'No' END AS IsDefault, isnull(rl.location, 'All') TicketSLALocation  
  FROM   servicelevelobjective slo 
  JOIN service s ON s.serviceid = slo.serviceid 
  JOIN priority p ON p.priorityid = slo.priorityid 
  JOIN impact i ON i.impactid = slo.impactid 
  LEFT JOIN workgroup wg ON wg.workgroupid = slo.workgroupid 
  LEFT JOIN workhours wh ON wh.workhourid = slo.workhourid 
  JOIN servicelevelagreement slag ON slag.servicelevelid = slo.servicelevelagreementid 
  LEFT JOIN requestorlocation rl ON rl.customerid = slag.customerid 
  AND rl.locationid = slo.locationid 
 WHERE    slag.customerId = 147  -- and slo.locationId = 143 
 AND slo.isdelete = 0   AND s.deleted = 0     AND p.deleted = 0   AND i.deleted = 0  and s.serviceId = 68 and slo.serviceId =68



 ---------------

  SELECT  DISTINCT CASE scm.tickettypeid WHEN 1 THEN 'Incident' WHEN 2 THEN 'ServiceRequest' WHEN 3 THEN 'Change' WHEN 4 THEN 'Problem' END 'TicketType', 
  s.servicename,   c.category,   sc.subcategory,   cl.classification,  
  CASE WHEN scm.deleted = 0   AND c.deleted = 0   AND sc.deleted = 0   AND cl.deleted = 0   AND scc.deleted = 0  THEN 'Yes' ELSE 'No' END as 'IsActive ?', 

  CASE WHEN s.iseupvisible = 0  AND c.iseupvisible = 0   AND sc.iseupvisible = 0   AND cl.iseupvisible = 0  THEN 'Yes' ELSE 'No' END AS 'Is Eup Enabled ?' 

  FROM   servicecustomermapping scc 
  JOIN tickettype t ON t.tickettypeid = scc.tickettypeid 
  JOIN servicecategorymapping scm ON scc.serviceid = scm.serviceid   AND scm.tickettypeid = t.tickettypeid  JOIN service s ON s.serviceid = scm.serviceid 
  JOIN category c ON scm.categoryid = c.categoryid   
  JOIN subcategory sc ON sc.categoryid = c.categoryid 
  JOIN classification cl ON cl.subcategoryid = sc.subcategoryid 

  WHERE   scc.customerid = 3   AND scm.tickettypeid IN (1, 2, 3, 4)   AND scm.deleted = 0  
  AND c.deleted = 0  AND sc.deleted = 0   AND cl.deleted = 0   AND scc.deleted = 0



  --- service category subcategory classification

     select * from Service S
	 inner join ServiceCustomerMapping SC
	 on S.serviceId = SC.serviceId
	 where customerId =147 and  S.serviceName like '%CIS%' --- 68



     select top 10 * from Service where customerid = 147

	 
	 select * from customer where customerid = 147

	  select * from customer where customerid = 68

	 select * from customer where customerName like '%hmcl%'
    

	select * from Customer where customername like '%jubil%' -- 194

	select * from device 

	select D.deviceId, D.deviceName,d.alternateName,d.ipAddress,S.serviceId, S.serviceName,  d.description, d.hostName , ds.ticketTypeId from Device D
	inner join DeviceServiceMapping DS 
	on D.deviceId = DS.deviceId
	inner join Service S
	on ds.serviceId = s.serviceId
	where d.customerId = 194 and d.deleted = 0 and ds.deleted = 0 and s.deleted =0


	select * from Customer where customerId = 3



	----> 

	select * from Users where email like '%sudhindrab%' --> SudhindraB@microland.com 25305

	select * from Users where email like '%mohammedmir@microland.com%' --> 26583



	select * from UserCustomerAssignGroupMapping 

	select * from Customer where customerName like '%MenaBev%'  --->  217

	select * from CustomerAssignmentGroupMapping where customerId = 217 and deleted = 0

	select * from UserCustomerAssignGroupMapping where custAssignmentGroupId in (

 2958
,2959
,2960
,2961   ---
,2962
,2963
,2964
,2965
,2966
,2967
,2985) and userId = 26583

select * from UserCustomerAssignGroupMapping where userId = 26583 and deleted = 0 --> 180763   2961

--Update UserCustomerAssignGroupMapping set deleted = 1 where userId = 26583

--Update UserCustomerAssignGroupMapping set deleted = 0 where userCustomerAssignGroupId = 180763

 -- Insert into UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)

 -- values 
 -- (26583, 2958, 0, 1, 1),
 -- (26583, 2959, 0, 1, 1),
 -- (26583, 2960, 0, 1, 1),
 ---- (26583, 2961, 0, 1, 1),
 -- (26583, 2962, 0, 1, 1),
 -- (26583, 2963, 0, 1, 1),
 -- (26583, 2964, 0, 1, 1),
 -- (26583, 2965, 0, 1, 1),
 -- (26583, 2966, 0, 1, 1),
 -- (26583, 2967, 0, 1, 1),
 -- (26583, 2985, 0, 1, 1)


   SELECT  DISTINCT s.servicename AS ServiceName, 
  CASE slag.subtypeid WHEN 1 THEN 'Incident' WHEN 2 THEN 'Service Request' WHEN 3 THEN 'Change' WHEN 4 THEN 'Problem' END TicketType, 
  CASE slo.servicelevelobjectivetypeid WHEN 1 THEN 'Response' WHEN 2 THEN 'Resolution' end SLAType,   p.priority AS Priority,   i.impact AS Impact, 
  CASE WHEN wg.workgroup IS NULL THEN 'All' ELSE wg.workgroup END AS Workgroup,  slo.responsetimeinmin AS 'SLADurationTime(in mins)', 
  CASE slo.is24x7service WHEN 0 THEN 'No' WHEN 1 THEN 'Ye' END is24x7service, 
  CASE WHEN slo.workhourid = 0 THEN '12:00 AM tO 11:59 PM (Mon to Sun)' ELSE wh.description END AS ServiceWindow, 
  CASE WHEN slo.isdefault = 1 THEN 'Yes' ELSE 'No' END AS IsDefault, isnull(rl.location, 'All') TicketSLALocation  
  FROM   servicelevelobjective slo 
  JOIN service s ON s.serviceid = slo.serviceid 
  JOIN priority p ON p.priorityid = slo.priorityid 
  JOIN impact i ON i.impactid = slo.impactid 
  LEFT JOIN workgroup wg ON wg.workgroupid = slo.workgroupid 
  LEFT JOIN workhours wh ON wh.workhourid = slo.workhourid 
  JOIN servicelevelagreement slag ON slag.servicelevelid = slo.servicelevelagreementid 
  LEFT JOIN requestorlocation rl ON rl.customerid = slag.customerid 
  AND rl.locationid = slo.locationid 
 WHERE    slag.customerId = 147  -- and slo.locationId = 147 and
 AND slo.isdelete = 0   AND s.deleted = 0     AND p.deleted = 0   AND i.deleted = 0  and s.serviceId = 68 and slo.serviceId = 68

 select * from Customer where customerName like '%SAP%' --->     58	SAP GD

 select * from Customer where customerName like '%Unity Bio%' --->  203	Bosch � Scottsdale

  select * from Customer where customerName like '%Bosch%' ---->  203	Bosch � Scottsdale

 ----->  207	Unity Bio

 ---> for bosch scottdale no records  and SAP GD also.

  select * from Customer where customerName like '%NT%' --->  58	SAP GD    



 select * from Workgroup where workgroup like '%DC%' 

 select w.workgroupId, w.workgroup from Workgroup W
 inner join AssignmentGroup A on A.workgroupId = W.workgroupId
 inner join CustomerAssignmentGroupMapping C on C.assignmentgroupId = A.assignmentgroupId
 where c.customerId = 203 and c.deleted = 0 and w.deleted = 0 and A.deleted = 0 and w.workgroup like '%DCTeam%'

 
 select w.workgroupId, w.workgroup from Workgroup W
 inner join AssignmentGroup A on A.workgroupId = W.workgroupId
 inner join CustomerAssignmentGroupMapping C on C.assignmentgroupId = A.assignmentgroupId
 where c.customerId = 203 and c.deleted = 0 and w.deleted = 0 and A.deleted = 0 

 ---> ,535,537,539 

  select * from NotificationRules where notificationMode='Email'  and notifyBasedOnId =3
  and deleted =0 and customerId = 194  and duePercent = 50 

   select * from NotificationRules where notificationMode='Email' -- and notifyBasedOnId =3
   and deleted =0 and customerId = 203 and workgroupid in (2)  and duePercent = 50

   --- for customerId = 203 only Response SLA records are there but there is no Resolution SLA.


-- Update NotificationRules set 
-- notificationTo ='RMCShiftManager@microland.com;rmcdcteam@microland.com;PrakashN@microland.com;DilipMY@microland.com;SunilS1@microland.com;',
--notificationCC='PramodPK@microland.com;TusharBK@microland.com;' --, ruleName ='SLA Resolution 90'
-- where notificationMode='Email' and notifyBasedOnId =3
-- and deleted =0 and customerId = 203 and workgroupid in (2)  and duePercent = 50




   select * from NotificationRules where notificationMode='Email' and notifyBasedOnId =3
   and deleted =0 and customerId = 203 and workgroupid in (2)  and duePercent = 50


   --Insert into NotificationRules( customerId,	ticketTypeId,priorityId,duePercent,notificationMode,notificationTo,notificationCC,templateId,ruleName,
   --workgroupid,supportgroupid,serviceId,notifyBasedOnId,entryStateId,deleted)

   --select customerId, ticketTypeId,priorityId,duePercent,notificationMode,notificationTo,notificationCC,templateId,ruleName,
   --625,supportgroupid,serviceId,notifyBasedOnId,entryStateId,deleted from NotificationRules where notificationMode='Email' and notifyBasedOnId =3
   --and deleted =0 and customerId = 203 and workgroupid in (2) 
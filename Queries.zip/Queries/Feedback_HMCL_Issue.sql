

select * from CustomerAssignmentGroupMapping where customerid = 218  

---> Bunge - RMC Collaboration	218	RMC Collaboration	7  2986

----> Bunge - RMC Tools	218	RMC Tools	13   2992

select * from AssignmentGroup where assignmentgroupid in (7, 13)  ----> 7, 13

select * from Requestor where requestoremail like '%carolmr@microland.com%'  ----> 28818 44815 SUv/GzSv2NSYGeW1YMGviQ==

--update Requestor set Password ='SUv/GzSv2NSYGeW1YMGviQ==' where requestorId = 28818

select * from Requestor where requestoremail like '%Monicas@microland.com%'  ----> 180	SMC NEW CIS

--Update Requestor set deleted = 1 where requestorId = 44815



select * from CustomerRequestorMapping where requestorId = 28818  ---> 55622

select * from CustomerRequestorMapping where requestorId = 55622  ---> 55622

--Insert into CustomerRequestorMapping 

--select 28818, 180, 'SMC NEW CIS', 1

select * from Ticket where workgroupid = 13

----> Tamara.Janssen@computacenter.com
 

 select * from Feedback where TicketNo = 2996176  ----> 3603	4

 select serviceId, workgroupId, workgroupName,* from Ticket where TicketNo = 2995763		 ---> 51	90

  select serviceId, workgroupId, workgroupName,* from Ticket where TicketNo = 3021505 ---> 57	161

  ----> DSAT EMails not triggering

  select * from FeedbackConfig  where CustId = 68 and ServiceId = 51 and workgroupId = 80  ---> 434

  select * from FeedbackConfig  where CustId = 68 and ServiceId = 51 and workgroupId = 90  ---> 434

  ----> DSAT EMails are triggering

  select * from FeedbackConfig  where CustId = 68 and ServiceId = 57 

 
 select top 10 * from NotificationRegistry r
 inner join Ticket t on t.ticketNo = r.sourceId
 where r.templateId = 434 and t.serviceId = 51
 order by r.notificationId desc



 select * from NotificationRegistry where sourceId ='2996176' and templateId = 434	---> 418, 583

 select * from NotificationEmailTemplate where templateId in (434, 418, 583) ----

 select serviceId, workgroupId,* from Ticket where ticketNo in (
3021505,
3016350,
3012305,
3000631,
2955803,
2816060,
2947605,
2965118,
2966611,
2955883
 )


 select * from Asset_users 
 where EmployeeId in ('19049', '20849','21153','20853',
 '21131','22587', '901779') ----> 

 ----->  9901190645

 select top 100 * from AutoTicketEventLog where ticketNo = '3038708' ----> APIKEY ID: 144


 select distinct serviceId from  ServiceCustomerMapping 
 where deleted = 0 and customerId = 204 and ticketTypeId = 4


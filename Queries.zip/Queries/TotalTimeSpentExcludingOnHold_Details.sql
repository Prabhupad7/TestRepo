

      Select * from ReportMaster where ReportMasterId = 74 

  --->  TotalTimeSpentExcludingOnHold	usp_StandardReport_TotalTimeSpentExcludingOnHold
  --->  74	TotalTimeSpentExcludingOnHold	usp_StandardReport_TotalTimeSpentExcludingOnHold


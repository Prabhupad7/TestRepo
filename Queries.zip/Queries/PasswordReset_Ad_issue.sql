 
 ---->DBName:  ADSNew


  -- Select * from ads_users
  -- Select * from ads_password_reset_
  -- Select * from ads_UnlockAttempt
  -- Update ads_UnlockAttempt set count = 0 where userId = 1234

  select * from Ads_Users where isEnrolled = 0 and id <> 1

	 select * from Customer where  customerid in (3, 194)

	 select * from Apikey where customerid =3

     select * from Apikey where keyid = 19

     select top 100 * from AutoTicketEventlog where apikeyid in (4
		,11
		,14
		,19
		,35
		,56
	 ) order by 1 desc




  select top 100  * from autoticketserviceemailconfig  where apikey in (

  select keyname from Apikey where keyid in (4
		,11
		,14
		,19
		,35
		,56)
   )



		--->   MlcisAutotikcet@microlandsmartcenter.com	  microland@bng2

		select top 100 * from AutoTicketEventLog order by 1 desc


		select top 100 * from AutoTicketEventLog

		order by 1 desc

		--->  IM2787414



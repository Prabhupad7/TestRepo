

-----Configuration Table

---> 3167960  APR3167960

select approvalEntityMappingId,* from Approval where approvalNo = 3167960 ---> 3208

select * from ApprovalEntityMapping where customerId = 167 and ISNULL(deleted,0) = 0

select * from ApprovalEntityMapping where approvalEntityMappingId = 3208 -->506

select * from ApprovalMatrix where approvalMatrixId  =506

select * from ApprovalMatrixLevel where approvalMatrixId = 506

select * from ApprovalMatrixLevel where levelId = 983

---> approverTypeId :83, levelId :983

select * from ApprovalMatrixApprover where levelId in (983,
984) and ISNULL(deleted,0) = 0


select top 100 * from UserDepartmentRole where  userTypeid in (83)


Select * from ApprovalMatrixCriteria where ApprovalMatrixCriteriaId = 161

select * from UserDepartmentRole where userTypeId =98

Select top 2000 * from ApprovalEmailRules where ApprovalEntityMappingId  =3661  order by 1 desc 


----History \ Transaction  Table

Select top 10  * from Approval order by 1 desc ----2952620

Select top 10  * from ApprovalEmail where subject like '%APR2952620%' ----76462

select top 10  * from ApprovalEntityLevelDetails where sourceId = 2952620

select top 10 * from ApproverEntityApproval where sourceId =2952620 /// after creating approval if we want to change approver name

select top 10 * from ApprovalOverrideHistory order by 1 desc /// Override approval details

select top 10 * from ApprovalTicketAttachment where ticketNo =2952620

select top 10 * from ApproverEntityApprovalHistory order by 1 desc

select * from Impact
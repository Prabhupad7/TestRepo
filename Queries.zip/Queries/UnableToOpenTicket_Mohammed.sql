Please suggest if anything is missing to check.

These are all the steps I checked and updated properly where ever it was necessary still the ticket is unable to move.

  

--update ticket set ETA= getdate()+3  where ticketno=2694851 

select TicketTypeid,priorityId,priorityName, workgroupId,serviceId, categoryId,subCategoryId,classificationId,
deviceId, ETA, workflowId, customerId from ticket where ticketno= 1469973		

 select * from ServiceLevelObjective where serviceId = 3 and priorityId =9 and workgroupId = 4
  
 ---->  IM1469721  




  select statusId, statusName, serviceId, serviceName, deviceId, deviceName, * from Ticket where ticketNo = 1469973 

  select * from Priority where ticketTypeId=1

  select * from TicketStatus where ticketTypeId =1

  select * from ServiceLevelTracking where sourceId = 1469973


    select * from ServiceLevelTracking where sourceId = 1469721

  --update ticket set priorityId = 9, priorityName = 'P3' where ticketNo = 1469973 

    update ticket set statusId = 3, statusName = 'Work in Progress' where ticketNo = 1469973 

  select * from Service where serviceId = 3

  select * from ServiceCustomerMapping where customerId = 1 and deleted = 0 and ticketTypeId = 1

     select * from ServiceCategoryMapping where serviceId = 3 and deleted =0 and ticketTypeId =1

	 select   serviceId, serviceName, workgroupId, workgroupName,categoryId ,categoryName,subCategoryId, subCategoryName, 	 classificationId ,
	 classificationName from Ticket where ticketno= 1469721  

  --   update Ticket set  serviceId=51, serviceName='Payout',workgroupId= 101,
	 --workgroupName='KLI APC portal', categoryId = 763 ,categoryName ='Partner Incentive Payout',
	 --subCategoryId=3769, subCategoryName= 'Business Fee Payout',
  --   classificationId = 7671, classificationName ='NA' where ticketno= 1469973 



    select * from ServiceCategoryMapping where serviceId = 489 and ticketTypeId =2 

	select * from Category where categoryId = 81

	select * from SubCategory where categoryId = 81

	-- update SubCategory set subCategory ='Others-Undefined' where subCategoryId = 193

	select * from Classification where subCategoryId = 193

	select * from ServCategory

  ------>   397	Software	1797	Other Software not working	1836

  Select * from Impact

  select * from Service where serviceId = 1

   select * from ServiceCustomerMapping where customerId = 1 and serviceId =3  ---> 55

		 select * from ServiceCategoryMapping where categoryId In (   select categoryId from Category where category like '%NAT%' ) 
		 and deleted = 0 and ticketTypeId =1 and serviceid = 3 ---> 397 a

		 select * from Category where categoryId in (
		 324
,402
,489
,553
,627
,643
,643
,489
,877)

   select * from Category where categoryId  = 5333

   select * from SubCategory where categoryId = 877 ---->  4260	Other

   select * from Classification where subCategoryId = 20906  ----> 8176	Other

   select * from Device where deviceId =3144

   select * from Customer where customerName like '%SMC NEW TAGIC%'

   --update Ticket set categoryId = 877 , subCategoryId=4260, subCategoryName= 'Other',
   --classificationId =8176, classificationName ='Other' where ticketno= 1418979 



   select * from ServiceCategoryMapping where categoryId = 397 and ticketTypeId =2

   select * from ServiceCategoryMapping where ticketTypeId =2 and serviceId =1
   
   --  update Ticket set statusId = 21 , statusName= 'Closed' where ticketno= 1418979 
   --  update Ticket set priorityId = 16, priorityName = 'SR4' where ticketno= 1418979 



select * from Priority where ticketTypeId =2

select * from Priority where ticketTypeId =1

select * from Priority p where p.priority like '%p4%' and ticketTypeId=27  ---

select * from TicketStatus where ticketTypeId =2

--->  21	Closed

select * from DeviceServiceMapping where serviceId=51 and deviceId=3479
select * from ServiceCategoryMapping where serviceId=51 and deleted=0 and ticketTypeId=1

select * from Classification where subCategoryId in (select subCategoryId from Category where categoryid=334)
select * from Category where serviceId=51 and deleted=0 --5210
select * from SubCategory where categoryId=5210
select * from Classification where subCategoryId=20474

select * from WorkflowMapping m where m.customerId=68 

select * from device where deviceId in (select distinct deviceId from DeviceServiceMapping where serviceId=51and deleted=0 and ticketTypeId=1) and deviceName like '%generic%'
--update device set alternateName=deviceName where deviceId=3479


    select * from Category where category like '%GroupAsia%'

select * from Category where category like '%Group Asia%'

--->  985

---> 349 , 386

   select * from ServiceCategoryMapping where categoryId in (349, 386) --- and ticket

   --->  349	Groupasia

    --Update Category set deleted = 0 where categoryId =  349

	   --Update ServiceCategoryMapping set deleted = 0 where categoryId =  349

	   select * from SubCategory where categoryId =  349

	   --update SubCategory set deleted =0 where categoryId =349

	   select * from Classification where subCategoryId in (
	   
	   1014
)

--update Classification set deleted =0 where classificationId in (
--1013
--,1014
--,1015
--)
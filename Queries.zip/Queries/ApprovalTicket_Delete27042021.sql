

select top 10 * from Approval where approvalNo = 2944339 

--delete from Approval where approvalNo = 2944339 
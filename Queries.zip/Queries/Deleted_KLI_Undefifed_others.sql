

		select * from Classification where classification like '%Production Issue � Genie%' --> 7738

		select * from Classification where classification like '%application not working - Policy servicing%' --> 7736

		select * from Classification where classificationId = 7740

		Update Classification set classification = 'Others-Undefined' where classificationId in ( 7740 ) 

		select * from SubCategory where subCategoryId = 4835

		select * from Category where categoryId = 547



		select * from Classification where classification like '%undefifed-Others%' and deleted = 0

	   -- Update Classification set deleted =1 where classificationId in (4983, 4984)


select customerId, serviceId, workgroupId, deviceId, deviceName, assetId, assetName,
categoryId, categoryName, subCategoryId, subCategoryName, classificationId , classificationName
,* from Ticket where ticketNo = 1597707 

--Update Ticket set categoryId = 627, categoryName='Software' where ticketNo = 1597707


----> Mahavir dashboard no: 56 , 21, 19

select top 50 * from Log order by 1 desc

--33109227	2	1	Error	page = TimeStamp - 6/9/2021 9:04:18 AM, Dashboard , method= getScoreCardData, UserID= user
--33109226	3	1	Error	page = TimeStamp - 6/9/2021 9:04:18 AM, Dashboard , method= getScoreCardData, UserID= user
--33109225	1	1	Error	page = TimeStamp - 6/9/2021 9:04:18 AM, Dashboard , method= getScoreCardData, UserID= user
--33109218	2	1	Error	page = TimeStamp - 6/9/2021 9:04:16 AM, Dashboard , method= getScoreCardData, UserID= user
--33109217	3	1	Error	page = TimeStamp - 6/9/2021 9:04:16 AM, Dashboard , method= getScoreCardData, UserID= user
--33109216	1	1	Error	page = TimeStamp - 6/9/2021 9:04:16 AM, Dashboard , method= getScoreCardData, UserID= user

--33109425	2	1	Error	page = TimeStamp - 6/9/2021 9:06:01 AM, Dashboard , method= getScoreCardData, UserID= user	RD00155DF227C3
--33109424	3	1	Error	page = TimeStamp - 6/9/2021 9:06:01 AM, Dashboard , method= getScoreCardData, UserID= user	RD00155DF227C3
--33109423	1	1	Error	page = TimeStamp - 6/9/2021 9:06:01 AM, Dashboard , method= getScoreCardData, UserID= user	RD00155DF227C3

--33110463	2	1	Error	page = TimeStamp - 6/9/2021 9:12:02 AM, Dashboard , method= getScoreCardData, UserID= user	2021-06-09 09:12:02.643
--33110462	3	1	Error	page = TimeStamp - 6/9/2021 9:12:02 AM, Dashboard , method= getScoreCardData, UserID= user	2021-06-09 09:12:02.643
--33110461	1	1	Error	page = TimeStamp - 6/9/2021 9:12:02 AM, Dashboard , method= getScoreCardData, UserID= user	2021-06-09 09:12:02.627
--33110457	2	1	Error	page = TimeStamp - 6/9/2021 9:12:01 AM, Dashboard , method= getScoreCardData, UserID= user
--33110456	3	1	Error	page = TimeStamp - 6/9/2021 9:12:01 AM, Dashboard , method= getScoreCardData, UserID= user
--33110455	1	1	Error	page = TimeStamp - 6/9/2021 9:12:01 AM, Dashboard , method= getScoreCardData, UserID= user
--33110454	2	1	Error	page = TimeStamp - 6/9/2021 9:12:00 AM, Dashboard , method= getScoreCardData, UserID= user
--33110453	3	1	Error	page = TimeStamp - 6/9/2021 9:12:00 AM, Dashboard , method= getScoreCardData, UserID= user
--33110452	1	1	Error	page = TimeStamp - 6/9/2021 9:12:00 AM, Dashboard , method= getScoreCardData, UserID= user
--33110451	2	1	Error	page = TimeStamp - 6/9/2021 9:12:00 AM, Dashboard , method= getScoreCardData, UserID= user
--33110450	3	1	Error	page = TimeStamp - 6/9/2021 9:12:00 AM, Dashboard , method= getScoreCardData, UserID= user
--33110449	1	1	Error	page = TimeStamp - 6/9/2021 9:12:00 AM, Dashboard , method= getScoreCardData, UserID= user

select * from users where loginName like '%Ritesh%'  ----> 665  itsd.hotl@heromotocorp.com	RiteshSH

select * from users where loginName like '%Mahavir%'  ----> 753  itsd.csdtl@heromotocorp.com	MahavirNS

select * from Users where userId in (665, 753)   ---> 
﻿
im2623004

select * from customer where customerid in(150
,151
,152
,153
,154
,155
,156
,157 
)

    SELECT * FROM customer WHERE customerName like '%Macom%'  -- 193	SMC New MACOM

    SELECT * FROM customer WHERE customerName like '%Khaitan%' --  202	SMC New khaitan and co


take from customerid 150

  -- 
  
     select * from customer where customerId = 151

	 select * from customer where customerName like '%SMC new Cis%'

  select * from NotificationRules where customerId = 157 and deleted = 0 and duePercent is null and ruleName like '%Feedback%' 

 

  select  * FROM SERVICE WHERE SERVICEID IN (SELECT DISTINCT (serviceId) FROM ServiceCustomerMapping WHERE customerId = 193 AND deleted = 0)  and deleted = 0

    select  * FROM SERVICE WHERE SERVICEID IN (SELECT DISTINCT (serviceId) FROM ServiceCustomerMapping WHERE customerId = 202 AND deleted = 0)  and deleted = 0

  SELECT * FROM NotificationEmailTemplate WHERE customerId = 150 --AND DELETED = 0

   SELECT * FROM NotificationEmailTemplate WHERE customerId = 182   -- AND  TEMPLATEID = 962

    $PRIORITYNAME Survey Notification - Ticket Number: $TICKETNOTODISPLAY

	select * from NotifyBasedOn -- Notifybasedon = 1

	select * from ticketstatus where ticketTypeId = 1          --- 11, 

		select * from ticketstatus where ticketTypeId = 2    --- 21, 

	select * from NotificationRules where customerId = 182 and templateId = 962

		select * from NotificationRules where customerId = 150 and templateId = 962



	--insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 86, 1, 11, 0, null, null, null

	--insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 86, 1, 21, 0, null, null, null


	--	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 87, 1, 11, 0, null, null, null

 --    	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 87, 1, 21, 0, null, null, null



	--	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 88, 1, 11, 0, null, null, null

	--    insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 88, 1, 21, 0, null, null, null


	--	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 89, 1, 11, 0, null, null, null

	--    insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 89, 1, 21, 0, null, null, null


	--	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 90, 1, 11, 0, null, null, null

	--    insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 90, 1, 21, 0, null, null, null


	--	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 91, 1, 11, 0, null, null, null

	--   insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 91, 1, 21, 0, null, null, null



	--	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 92, 1, 11, 0, null, null, null

	--    insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 92, 1, 21, 0, null, null, null


	--	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 93, 1, 11, 0, null, null, null

 --   	insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 93, 1, 21, 0, null, null, null


	--	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 150, 1, 11, 0, null, null, null

	--    insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 150, 1, 21, 0, null, null, null


	--	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 261, 1, 11, 0, null, null, null

	--    insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 261, 1, 21, 0, null, null, null



	--	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 262, 1, 11, 0, null, null, null

	--    insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 262, 1, 21, 0, null, null, null

	    


	--	insert into NotificationRules select 150, 1, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 263, 1, 11, 0, null, null, null

	--    insert into NotificationRules select 150, 2, null, null, 'Email', '$REQUESTOREMAIL', '', 962, 'Feedback', null, null, 263, 1, 21, 0, null, null, null


	     select top 100 * from NotificationRules where ruleName like '%feed%' 





	-- Setting AutoClose

	select * from AutoCloseInfo where customerid = 150 

		select * from AutoCloseInfo where workgroupid is null

	select * from ClosureCode where customerId = 150  -- diff for tickets


	  -- we can give null for workgroupid.
	   select * from Users where email ='NiharikaD@microland.com'

      select * from Users where email ='AnushaYG1@microland.com'


	  -- select * from UserCustomerAssignGroupMapping where userid = 26087

       select * from Admin_UserCustomerAdminMapping 


	   select * from Admin_UserCustomerAdminMapping where UserId in( 26087 , 26222)  -- 26087 , 

	   Insert into Admin_UserCustomerAdminMapping(userid, CustomerId, InstanceId, CreatedBy, deleted) values (26222, 147, 3, 6, 0)

	   select * from customer where customerId = 147

	   select * from customer where customerName like '%Unity%'

	     
	   select * from customer where customerName like '%efl%'

	      select * from Users where email = 'ArunR@microland.com'

	   select  * from  TS_AutoTicketSchedular where customer in ('Eureka Forbes Limited', 'Unity Bio',  'SMC UnityBio')and requestoremail = 'ArunR@microland.com' 
	   order by createdOn desc

	--getting 3 records:
	   select   * from  TS_AutoTicketSchedular where  requestoremail like '%ArunR@microland.com%' 
	   order by createdOn desc

--	      1.ts_Autoscheduler
--   customer and time , Requestor where createdTime 
    
--   customer : unity, efl, date : 24, time: 6;15pm, requestoremail = 'ArunR@microland.com'  

--   ts_AutoTicketSchedulerRegistry where ts_autoschedulerId = ''
--   ticket

--  // 
--feedback config table in TOlist you have to change the email address
 

     select * from FeedbackConfig where CustId = 150

	 select * from FeedbackConfig where ToAddr like '%anandka@microland%'  and  id not in
	 (
	  select * from FeedbackConfig where ToAddr like '%NatarajanG@microland.com%'  )



--	 anandk@microland;natarajang@microland.com;ParameswarN@microland.com;smartcentersupport2@microland.com;MaheshK1@microland.com;vishalds@microland.com

--	 AnandKA@microland.com; NatarajanGO@microland.com;ParameswarN@microland.com;smartcentersupport2@microland.com;MaheshK1@microland.com;vishalds@microland.com

--	 update FeedbackConfig set ToAddr = 'AnandKA@microland.com; NatarajanGO@microland.com;ParameswarN@microland.com;smartcentersupport2@microland.com;MaheshK1@microland.com;vishalds@microland.com' 

--	 where Id in (361
--,362,363


----->  sarveshsr@microland.com


select * from  ServiceLevelTracking where sourceId = 2577597

-- Update ServiceLevelTracking set statusId = 3 where sourceId = 2577597


select * from Users where email like '%siddharthm%' ----> 24278


select * from Customer where customerName like '%Men%' ---->   217	MenaBev

select * from CustomerAssignmentGroupMapping where customerId = 217 --->  

select * from UserCustomerAssignGroupMapping where userId =24278 and   custAssignmentGroupId in (
2958
,2959
,2960
,2961
,2962
,2963
,2964
,2965
,2966
,2967
,2985
,3045
,3046)


select * from ReportMaster where reportMasterID = 154


exec [dbo].[usp_StandardReport_SLAcalculation] '2020-09-01', '2020-09-10', 'CreatedOn', '1', '1,2, 3, 4', '24'

SR1393255

   Select * from ServiceLevelTracking slv where slv.serviceLevelObjectiveTypeId = 2 and slv.sourceId = 1393255

   Select * from ServiceLevelTracking slv where slv.serviceLevelObjectiveTypeId = 2 and slv.sourceId = 118581

   select top 10 * from ServiceLevelObjective  

    
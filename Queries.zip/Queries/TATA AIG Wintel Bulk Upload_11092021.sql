




select * from AssetEntityType where DisplayName like '%Wintel%'  --> 4	Laptop

----Id	Name
----17	Server (parent: )
----18	Wintel - Physical
----19	Wintel - Virtual


select  * from Assets where SourceId in (18)

select top 1000  * from Assets where SourceId in (19)

-----> 

   --ALTER TABLE Wintel_11092021$ 
   --ADD StatusId int

select * from Wintel_11092021$ where sourceid  = 18 and AssetNumber is NULL

select * from Wintel_11092021$ where sourceid  = 19

--  IpAddress
--10.32.160.25

   select * from Assets A 
   inner join Wintel_11092021$ K 
   on A.MACAddress = K.MACAddress  and A.IpAddress = K.IpAddress1
   where K.Sourceid = 18

      select A.Manufacturer, K.Make, K.Model from Assets A 
   inner join Wintel_11092021$ K 
   on A.MACAddress = K.MACAddress  and A.IpAddress = K.IpAddress1
   where K.Sourceid = 18

   ------> Step 1:

   	--   Update K set K.AssetNumber = A.AssetNumber
	   --from Wintel_11092021$ K
	   --inner join Assets A 
	   --on  A.MACAddress = K.MACAddress  and A.IpAddress = K.IpAddress1
    --   where K.Sourceid = 18



	select  * from Assets where SourceId in (18)

	select * from Wintel_11092021$ where sourceid  = 18 and AssetNumber is NULL


	Step 2: 

	---> Insert into Assets (CustomerId, SourceId, SourceTypeId, AssetNumber, SerialNumber, MacAddress, IpAddress, Hostname, LocationName, Createdbyid, CreatedOn, 
	StatusId, Status, Model, Vendor, Manufacturer, LastUpdatedOn, LastUpdatedBy, OSName, domain)

	select 1, 18, 1, '',SerialNumber,MacAddress,IpAddress1, Hostname,LocationName, 6, GETDATE(), 27, Status,Make, Vendor, Model, GETDATE(),6, OSName, Domain
	   from Wintel_11092021$ where sourceid  = 18 and AssetNumber is NULL

	   --------------->  
	   select CustomerId, SourceId, SourceType, PrimaryId, Varchar6, Varchar10, Varchar12, Varchar13, Varchar34, 
 Varchar46, Varchar47, Varchar42, Varchar43, Varchar44, Varchar48, varchar49, Varchar50,   Varchar51,  Varchar52, 
 Varchar53, Varchar54, Varchar57, Varchar58, Varchar59, Varchar60, Varchar63, Varchar64, Varchar65, 
 Varchar66, Varchar67, Varchar68, Varchar69,  Varchar70, Varchar71, Varchar73,  Varchar82, Varchar83, Varchar84, Varchar85
 from VarcharCustomAttribute where SourceId = 18	

  select DisplayName, AttributeName from CustomAttributeColumnMapping where SourceId = 18 and PageId = 2

 ----------> 

 --insert into Asset_AssetNumberConfiguration

--select 1, 19, NULL, NULL, 999999, 756, 0, null, null, 'S|Autogen'
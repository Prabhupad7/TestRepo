﻿



select top 50 * from Smc_userOtp order by 1 desc


--iCICI BANK lOAN nO:  LPBNG00040723373_IS_Katabathin

-- 8/5/2020  --Active tickets start of the day = 29


--- SR2617651  --> need to do followup on Today 04092020
---  SR2624169   ---> need to move to OHC on monday after discussing with Mohammed.

   select CCEmail, UserEmail, * from MIS_HMCL_NewEmailReport where Id in (1, 3, 4, 5, 11)

  -- Update MIS_HMCL_NewEmailReport set UserEmail = UserEmail +';smartcentersupport2@microland.com' where Id in (3, 4, 5, 11) 



	--- SmartCenterProduction

	--select * from Workgroup where workgroup like '%RMC Storage%'  -- 10

--Total tickets Resolved Today

select count(*) from ticket t
left outer join IncidentTicket it on it.ticketno = t.ticketNo
left outer join ServiceRequestTicket sr on sr.ticketNo = t.ticketNo
where customerid in (select customerid from customer where customerName like 'SMC %')
and tickettypeid in (1, 2)
and dateadd(mi, 330, case when t.TicketTypeid = 1 
then it.resolvedTime else sr.resolvedTime end) > cast(dateadd(mi, 330, getdate()) as date)

--- Total tickets created today.

select count(*) from ticket 
where customerid in (select customerid from customer where customerName like 'SMC %')
and tickettypeid in (1, 2) 
and dateadd(mi, 330, createdOn) > cast(dateadd(mi, 330, getdate()) as date)



---Total tickets Resolved in  todays tickets.

select count(*) from ticket 
where customerid in (select customerid from customer where customerName like 'SMC %')
and tickettypeid in (1, 2) and statusId in (9, 19)
and dateadd(mi, 330, createdOn) > cast(dateadd(mi, 330, getdate()) as date)


select * from ticket 
where customerid in (select customerid from customer where customerName like 'SMC %')
and tickettypeid in (1, 2) and statusId in (9, 19)
and dateadd(mi, 330, createdOn) > cast(dateadd(mi, 330, getdate()) as date)

select * from TicketStatus where ticketTypeId = 4

--> 22	Open
--> 27	RCA Approved
--> 39	Resolved


select t.ticketNo,t.description,t.statusName,t.LastUpdatedByName  from ticket t
left outer join IncidentTicket it on it.ticketno = t.ticketNo
left outer join ServiceRequestTicket sr on sr.ticketNo = t.ticketNo
where customerid in (select customerid from customer where customerName like 'SMC %')
and tickettypeid in (1, 2) and dateadd(mi, 330, case when t.TicketTypeid = 1 then it.resolvedTime else sr.resolvedTime end)
> cast(dateadd(mi, 330, getdate()) as date) order by t.LastUpdatedByName


select t.ticketNo,t.description,t.statusName,t.LastUpdatedByName  from ticket t
left outer join IncidentTicket it on it.ticketno = t.ticketNo
left outer join ServiceRequestTicket sr on sr.ticketNo = t.ticketNo
where customerid in (select customerid from customer where customerName like 'SMC %')
and tickettypeid in (1, 2) and dateadd(mi, 330, case when t.TicketTypeid = 1 then it.resolvedTime else sr.resolvedTime end)
> '2021-09-07' order by t.LastUpdatedByName


--->   SUv/GzSv2NSYGeW1YMGviQ==  microland@bng1

---    2635858
  --746289
      
	  select * from Ticket where ticketNo = IM2635858

	   ---- Updating users with Default Password:

	   ----- SUv/GzSv2NSYGeW1YMGviQ==
	   ----  microland@bng1



--------------- List of Tickets resolved Today

		   -- [dbo].[KM_ProvideKnowledgePermission] (@UserId INT, @Customerid INT)

		 ---  Exec KM_ProvideKnowledgePermission 25348, 147

		   select * from Users where firstName like '%Tirupathi%'
		   select * from ApprovalEmail where subject like '%APR2674603%'
		   select * from Menu
		   select * from MenuMaster



				--IM2731455	  Resolved     Test
				--IM2707087	  Resolved     Test
				--IM2728643	  Closed	   Test
				--IM2731379	  Closed	   Test
				--SR2716602	  Open	       Test
				--IM2731363	  Closed	   Test
				--IM2731415	  Closed	   Test
				 IM3103373   SR2974364  

				 ----> HMCL user not able to log a ticket. mankaran.singh@heromotocorp.com

2891787
3013175
3109946
3109957
3174832
3159138
3170844

			

				--exec deletetickets @ticketNo = '3013175'
				--exec deletetickets @ticketNo = '3013175'
				--exec deletetickets @ticketNo = '3109946'
				--exec deletetickets @ticketNo = '3109957'
				--exec deletetickets @ticketNo = '3174832'
				--exec deletetickets @ticketNo = '3159138'
				--exec deletetickets @ticketNo = '3170844'


				-- 3176951


--exec deletetickets @ticketNo = '2990260';  
--exec deletetickets @ticketNo = '2990296';

select top 10 * from RelatedTickets where dstTicketno in (
2896199,  
3041737, 
3047139,  
3057378, 
3057506, 
3061926,
2896192
)





    --            exec deletetickets @ticketNo = '2891787';  
    --            exec deletetickets @ticketNo = '2891787';
				--exec deletetickets @ticketNo = '3109946';
				--exec deletetickets @ticketNo = '3109957';
				--exec deletetickets @ticketNo = '3174832';
				--exec deletetickets @ticketNo = '3159138';
				--exec deletetickets @ticketNo = '3170844';






--- 665	Ritesh	Shukla	Ritesh Shukla (Service Desk)	Ritesh Shukla	919990165135	RiteshSH@microland.com	RiteshSH	)����ε/��O��w���L+���Ƕa<S$��H��]'��Py(O�I��CuW���M	84	1005	0	0	0	2015-12-22 04:05:58.197	0	94	NULL
665	2015-12-19 10:05:58.000	2020-09-11 04:30:15.000	NULL	24	NULL	1	NULL	NULL	�?%ئ� 3_�&�zujv����B	NULL	NULL	1	2

      select * from Users where  email like '%SudhirA%'  ---- 26356	Sudhir	Arora	NULL	Sudhir Arora	1234	SudhirA@microland.com	SudhirA

      select * from UserInstanceMapping where UserId = 26356

    -- update Users set password = 'SUv/GzSv2NSYGeW1YMGviQ==', SaltValue =null where userId = 26356



   select * from Users where userName like '%Bhatta%' ----- 1047	Roojvelt	Bhattacharya	Roojvelt Bhattacharya

   select * from Users where userId in ( 665, 1047)

      select * from Users where userId = 6

	  select * from UserTypes

	  --update Users set UserTypeId =2 where userId = 665

   ----- 94

   select * from Role where roleId = 94

   (150,151,152,153,154,155,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209)
   
select *  from NotificationRules where customerId =  150
and duePercent =100 and notificationMode = 'AWSSMS'



               
			   --select Distinct D.deviceId, D.deviceName, D.ipAddress from Device D
			   --inner join DeviceServiceMapping DSM
			   --on D.deviceId = DSM.deviceId
			   --where d.deleted = 0 and d.customerId = 3 and DSM.deleted = 0

--budhi.prakash@heromotocorp.com;itsd.om@heromotocorp.com;pawan9.kumar@heromotocorp.com
--budhi.prakash@heromotocorp.com;itsd.om@heromotocorp.com
--budhi.prakash@heromotocorp.com;itsd.om@heromotocorp.com
--budhi.prakash@heromotocorp.com;itsd.om@heromotocorp.com
--itsd.ptl@heromotocorp.com;itsd.om@heromotocorp.com
--itsd.ptl@heromotocorp.com;itsd.om@heromotocorp.com
--itsd.ptl@heromotocorp.com;itsd.om@heromotocorp.com

--select * from ReportParameter where reportMasterId = 
--select * from ReportRoleMapping where ReportMasterId = 
 

 select * from Asset_users where EmailId like '%akshayS1%' --->100309 AkshayS1@microland.com 97568

  select * from Asset_users where Id= 97568


 



select * from ticket  tt where tt.statusId in (9, 19)

select * from TicketStatus where ticketTypeId in (1, 2)

    select * from Ticket where ticketNo = 2609455 

       // 26/6/2020
    
	   --select * from Admin_UserCustomerAdminMapping where UserId in( 26087 , 26222)  -- 26087 , 

	   --Insert into Admin_UserCustomerAdminMapping(userid, CustomerId, InstanceId, CreatedBy, deleted) values (26222, 147, 3, 6, 0)

	   --select * from customer where customerId = 147

	   
	   -- Regarding Mohammed Ticket: 

	   select * from ServicelevelObjectiveTable

          select t.customerId, t.serviceId, t.workgroupId from ticket T where t.ticketNo in (2577666) -- customerId = 163
		  select * from Customer where customerName like '%kotak%'


		   select * from ServiceLevelObjective where serviceId = 175 and workgroupId = 302 and isDelete  = 0

		      select * from ServiceLevelObjective where serviceId = 409 and workgroupId = 301
  

          select distinct serviceId from ServiceCustomerMapping where customerId = 163 and deleted = 0 

		  select * from AssignmentGroup where assignmentgroupId in (select assignmentgroupId from CustomerAssignmentGroupMapping where customerid=163 and deleted = 0) 

		  select * from ServiceLevelAgreement where 

		  Asset Dump- SERCO SUNGARD

          MIS_AM_CIS_AssetDynamicDumpData_SercoSungard

	--    venkataramanaiah



      9874833434   -- 

	  arfa


	  4375 5156 4998 5005 

	  331


 --------------------------------


 select t.statusName,* from ticket t
join requestor r on r.requestorId=t.requestorId
where customerId=4 and r.requestorEmail='vishalds@microland.com'


     select * from NotificationEmailtemplate where customerid = 147 and templateName like '%HR%'





	 select * from servicelevelagreement where customerid=147
 
         select t.serviceid, t.workgroupid, * from ticket t where t.ticketno = 2505827   -- sr 70	wkg 221

	 select * from servicelevelObjective where serviceid = 70 and workgroupid = 221 and priorityid= 10 and isdelete = 0



      selfhelp.kotaklife.com/account/logon


[?7/?6/?2020 8:02 PM]  Mohammed K:  
select distinct(serviceId),* from ServiceCustomerMapping ... 
select distinct(serviceId),* from ServiceCustomerMapping where customerId=147 and deleted=0

select t.customerId,t.serviceId,t.workgroupId,t.priorityId, * from Ticket t where t.ticketNo = 2505827 --in

---(2000351,2000326,2000372,2000425,2505827,2506557,2506663, 2522264 ,2522615 ,2523660,2527963,2537913)

      147, 70, 221, 10


	  select * from ServicelevelTracking  --update isBreached =0 and adjusted 

select * from ServiceLevelObjective o where isDelete=0 and o.serviceId=69 and o.workgroupId=221  and priorityId =10

select * from ServiceLevelObjective o where isDelete=0 and o.serviceId=70 and o.workgroupId=221 and priorityId =10
 
[?7/?6/?2020 8:02 PM]  Mohammed K:  

--insert into ServiceLevelObjective

--select serviceLevelAgreementId	,serviceLevelObjectiveTypeId	,initialStatusId	,finalStatusId	,responseTimeInMin	,excludeStatusIds	,322 serviceid,	priorityId, impactId, holidayCalendarId, workHourId, is24X7Service, locationId, workgroupId, isDelete, isDefault from ServiceLevelObjective o where isDelete=0 and o.serviceId=69 and o.workgroupId=551  
 
-- 7/15/2020:
 -- Updating RoleId's i.e giving super admin access.
  --update users set roleId = 39 where userid=665

  --update UserRoleMapping set roleId = 39 where userid=665 

  select * from role where roleId = 39

  select * from UserRoleMapping where userid = 665

  select * from Customer where customerName like '%finan%'

  select * from device where customerid = EY

        --   F:\Services\KLI\AUTOTICKET\Log\LogBackup


		Ticket dump of application management.  


		      select * from Customer where customerName LIKE '%MACOM%'  ---  190	MACOM	MACOM

			  select  * from Users where loginName like '%TVRD%'  --- 26192


			    select  * from Users where loginName like '%chethan%'  --- 506

				select * from Instance

				select * from AuthenticationType

				select * from users where email like '%pavanr@microland.com%'

				select * from requestor where requestorEmail like '%pavanr@microland.com%'

				select * from requestor where requestorEmail like '%maryDM@microland.com%'

				NagaveniC@microland.com

			--	Insert into Requestor (requestorName, requestorPhoneNumber, requestorEmail, isCriticalUser, requestorOtherInfo, firstname, lastname, displayname, alias, 
				designation, department, location, mobileno, createdOn, UpdatedOn, createdby, updatedby, deleted)

				select 'Nagaveni C', 123, 'NagaveniC@microland.com', isCriticalUser, requestorOtherInfo, '', 'Nagaveni', 'C',  'Nagaveni C', 'NagaveniC', 
				designation, department, location, GETDATE(), GETDATE(), 6, GETDATE(), 0 from requestor where requestorId = 45391




			   select * from Customer where customerName like '%Ask%'

			  select * from Customer where customerName like '%dcs%'

			  -- 189	BOSCH DCS	BOSCH DCS
     --          203	Bosch – Scottsdale	Bosch – Scottsdale

			  select * from Customer where customerId = 3


			  select * from Workgroup W where W.displayName like '%dcs%'

			 select  * from Users where loginName like '%TVRD%'  --- 26192

			  select * from CustomerAssignmentGroupMapping where customerId in ( 189, 203 )    -- custAssignmentGroupId

			  select * from UserCustomerAssignGroupMapping where userId = 26192  and custAssignmentGroupId in(2412
,2413
,2414
,2415
,2416
,2417
)


			  INSERT INTO UserCustomerAssignGroupMapping (userId, custAssignmentGroupId, deleted, isAssignEnabled, AssignToWorkgroup)
			  values
			  (26192, 2413, 0, 1, 1),
\
			











			  select * from Customer where customerName like '%jub%'  --m 194
	          select top 200 T.statusId, statusName,  * from ticket T where customerId = 190 order by 1 desc 
	          select * from ticket where ticketNo = '249799'



	          select * from ApprovalEmailRules where ApprovalEntityMappingId in (
              select approvalEntityMappingId from ApprovalEntityMapping where customerId=147 and deleted=0 ) and NotificationBody like '%AnanthKBK@microland.com%' 
	          and isMoreInfoTemplate = 1

			   --UPDATE ApprovalEmailRules SET NotificationBody = '' WHERE ID IN ()

	        	  select * from ApprovalEmailRules where ApprovalEntityMappingId in (
            select approvalEntityMappingId from ApprovalEntityMapping where customerId=147 and deleted=0 ) and id in (4106, 4108
)
	        and isMoreInfoTemplate = 0



     select * from users where email = 'AnanthKBK@microland.com' -- 1644

	 --select *  from ApprovalEntityMapping where customerId=147 and deleted=0

	 1.	sudhir.chavan
2.	Sachin.Goutam
3.	srinivas.roula
4.	Shailendrakumar.dawane


        select * from users where loginName like '%sudhir.chavan%' --  25025
  
        select * from users where loginName like '%Sachin.Goutam%' --  24992

	    select * from users where loginName like '%srinivas%' --  24993

	    select * from users where email like '%Shai%' --  24993
		
	    select * from users where lastName like '%dawane%' --  24993

		update Users set deleted = 1 where userId in (25025, 24992, 24993)

		-- Unable to login Into the Portal:

		select * from users where loginName like  '%GV0113%' 


  select * from users where email like  '%kli.dlp-admin@kotak.com%' ---- 1285
  	 select * from Users where firstName like '%Juli%'

  SELECT TOP 10 * FROM USERS WHERE USERID = 6

  SELECT * FROM AssignmentGroup where workgroupId = 138

  SELECT * FROM CustomerAssignmentGroupMapping WHERE assignmentgroupId = 203

    --  update users set loginName =  'Lo5459', userName = 'DLPAdmin' , workgroupId = 138, custAssignmentGroupId = 222 where userId = 1285

  -- update users set isPasswordPolicyApplicable =0 , IsWorkgroup=0, roleId = 46,  custAssignmentGroupId = 0, UserTypeId = 3 where userId = 1285

   select * from workgroup where workgroup like '%Webse%'

   User Name - DLP Admin Hitachi IT KLI
   Login id - Lo5459
   Email id - kli.dlp-admin@kotak.com

   
			mangesh.khune@kotak.com - LE94280
			mangesh.khune@kotak.com - LE94280


			Ticket ID -IM1385236




	 select * from Users where userId in (1285, 1286, 1090)

	 select * from Instance where 
	 
	 select * from AuthenticationType

	 select * from UserTypes
	 -- SR2652477

	 -- create User: 

	  select * from Role

	 select * from Workgroup where workgroup like '%Biz Finance%'


	 --INSERT INTO Users(firstName,lastName,displayName,mobileNo,email,loginName,[password], deleted, IsWorkgroup, isPasswordPolicyApplicable, 
	 --isAutoAssignmentEnable, roleId, createdById, createdOn, timezoneinfoId, instanceId, SaltValue,levelid) 
	 --VALUES('Bantu','Kumar','Bantu Kumar', '9996262830', 'I_BantuK@microland.com', 'I_BantuK', 'SUv/GzSv2NSYGeW1YMGviQ==', 0,0,0,0,32,6,GETDATE(),24,1,null,0)


   --  INSERT INTO Users(firstName,lastName,displayName,mobileNo,email,loginName,[password], deleted, IsWorkgroup, isPasswordPolicyApplicable, 
	 isAutoAssignmentEnable, roleId, createdById, createdOn, timezoneinfoId, instanceId, SaltValue,levelid, UserTypeId, IsEnabled) 

	 VALUES('Varun','Sharma','Varun Sharma', '8095001401', 'VarunSh1@microland.com', 'VarunSh1', 'SUv/GzSv2NSYGeW1YMGviQ==', 0, 0, 0, 0, 138, 6, 
	 GETDATE(), 24, 1, null, 1, 3, 1),


	 
     select * from users where email like  '%VarunSh1@microland.com%' ---- 26436

	--update Users set password='SUv/GzSv2NSYGeW1YMGviQ==', saltvalue = Null, instanceId =2 where userId= 26436

	 select * from Admin_UserCustomerAdminMapping where UserId = 26436

	-- Update Admin_UserCustomerAdminMapping set InstanceId =2 where UserId = 26436

	-- Insert into Admin_UserCustomerAdminMapping(UserId, CustomerID, InstanceID, CreatedOn, CreatedBy, Deleted)

	   values(26436, 147, 3, GETDATE(), 6, 0)

	 	 select * from UserInstanceMapping where UserId = 26436

		-- Update UserInstanceMapping set InstanceId = 2 where UserId = 26436 
     
	 select * from Users where loginName like  'LE94280'

	 select * from Users where firstName like '%Juli%'  ---- 1090	Julius	Aloor	NULL	Julius Aloor (ML, IT, KLI)

	 select top 20 * from users order by userid desc

	 select * from Role where roleid = 138



	-- update Users set password = 'SUv/GzSv2NSYGeW1YMGviQ==' where userId = 26313

	 select * from Users where email like '%rajatb@microland.com%'

	 select * from Instance 

	 select * from AuthenticationType


Select * from UserCustomerAssignGroupMapping where userid = 25937
Select * from CustomerAssignmentGroupMapping where custAssignmentGroupId  = 1101




  select top 100 * from Users where deleted = 0 

  select * from UserInstanceMapping where UserId = 1285  --  --- 1285

  --insert into UserInstanceMapping (UserId, InstanceId)
  values (1286, 1)

  select * from Instance where id = 1

  select * from AuthenticationType 



  ----------------

  
 select * from Workgroup where workgroup like  '%RMC Window%'

 -- update Workgroup set workgroup = 'Oreta RMC windows', displayName = 'Oreta RMC windows' where workgroupid in (626)

 select * from Workgroup where workgroup  like  '%RMC tool%'

 -- update Workgroup set workgroup = 'RMC Tools', displayName = 'RMC Tools' where workgroupid in (13, 523, 541)  -- done

 select * from Workgroup where workgroup like  '%RMC voice%'

  select * from Workgroup where workgroup like '%RMC voip%'

  
 -- update Workgroup set workgroup = 'RMC VoIP', displayName = 'RMC VoIP' where workgroupid in (9, 556, 169)  -- done

  select * from ticket t where t.ticketNo = 2636902 --- SR2636902 , subcatergoryid, subCategoryname 

  select * from ticket t where t.ticketNo = 2638735

  --- SR2638735

    select * from ticket t where t.ticketNo = 2638735 

	Select  * from Assets where Hostname like '%LTP-O-102344%'

		Select  * from Assets where SerialNumber like '%PF1JWSPQ%'  -- 746890

	--	UPDATE Assets SET Model = 'Lenovo E590' where id in (746890, 746889)

		Select  * from Assets where id in (746890, 746889)

		-- Lenovo Thinkpad E440
		--   Lenovo E590

		Select  * from Assets where SerialNumber like '%PF1KTQSW%'  -- 746889

		------hi Vignesh Annadurai, for these CM2528061, PM2603840 2 tickets i did all primary checks like priorityid, cat/subcatid/classid, and updated missing cat-sub for CM2528061, 
		--still not able to move the tickets..

		select * from Users where loginName = 'lo1179'  --6

		-- C_SunilL@microland.com

		--- Resolution Code: 
		
		select top 10 * from ResolutionCode order by 1 desc

        select * from ResolutionCode 





		---------------------  24//82020:


		select * from WorkHours        -----

		select * from WorkHoursDetail where workHourId =  7 


		----- 7, 9, 6

		---

		select * from 

		select * from RequestorLocation where customerID = 68 and deleted = 0 and Location like '%Vijyawada ALC%'  --- 117



		   select * from Users where email like '%ShraddhaHN@microland.com%'  -- 25472

		   -- to get for which report which Proc is mapped. For KLI:

		   select * from ReportExecution

		   --- 1. RP002 - All IM and SR Combined SLA Ticket Dump

		   --- 2. TimeSpentonTicket_TimeStampBreakup


		      select * from Users where email like '%sahanasv@microland.com%'  ---- 1523

		      select * from Users where email like '%int_monicas@microland.com%'  ---- 26384

			  update Users set levelid =1 where userId = 26384

		   Monica S int_monicas@microland.com

		   sahanasv@microland.com

		   select top 100 * from RulesForAssignment where AssignToId = 26384

		  -- update RulesForAssignment set AssignToId = 26384 where RuleId = 79075

		   select * from Category where categoryId = 4711   ---  4711	Cheers	0	2	84

		    select * from Category where categoryId = 5523  ---  5523	Exception - Datacard/ Broadband bills	0	2	84

		   select * from Service where serviceId = 84

		   select * from Workgroup where workgroup like '%cheers%'  --- 233
\

		 ---  update Workgroup set workgroupEmail = 'int_monicas@microland.com;SahanaSV@microland.com' where workgroupId = 233

		    select * from UserInstanceMapping where UserId = 1523 

		     select * from UserInstanceMapping where UserId = 26384  --  --- 1285


			 select * from AssignmentGroup where workgroupId =  233   --- 349

			 select * from CustomerAssignmentGroupMapping where assignmentgroupId = 349  ---1250


			 select * from UserCustomerAssignGroupMapping where userId = 1523  and custAssignmentGroupId = 1250

			 select * from UserCustomerAssignGroupMapping where userId = 26384  and custAssignmentGroupId = 1250


			 ---[usp_StandardReport_RP002_getAllIM&SRCombinedSLATicketDump]

			 ---usp_StandardReport_TimeSpentonTicket_TimeStampBreakup]


			 select * from users where email like '%NagaveniC@microland.com%'

			 maryDM@microland.com

			  select * from users where email like '%Rahulso1@microland.com%'   ----- 26196	Rahul	Soni	NULL	Rahul Soni	919806200115	RahulSo1@microland.com	Rahul.Soni	SUv/GzSv2NSYGeW1YMGviQ==

			  select * from instance

			  select * from Authentication 



			   


  



--User creation access of Smart Center for NagaveniC@microland.com and should reflect as existing user maryDM@microland.com.

--Access need for the link - https:smcunilever.microland.comBTReference100147true

--- for Shital access to add Cat / SubCat

    select * from Users where userid in ( 6, 118)

	select * from users where loginName = 'gv0076'  ---118

	select * from customer where customerid = 147

    select * from Admin_UserCustomerAdminMapping

	-- insert into Admin_UserCustomerAdminMapping (userid, CustomerId, instanceId, createdOn, CreatedBy, updatedon, UpdatedBy, deleted)
	values(118, 1, 3, getdate(), 6, getdate(), 6, 0)


	--  need to give Asset Modulwe access for  IM2651693



	select * from customer where customerName like '%unil%'

	-- select top 100 * from Requestor where requestoremail  

	select * from customer where customerName like '%Unile%'

	select * from CustomerInstanceMapping where customerid = 179

	select * from Instance 



	select * from AuthenticationType


	    select * from Requestor where requestorEmail like '%pavanr%'  --- 48750

		select * from Requestor where requestorEmail like '%Nagavenic%'  --- 56512

		select * from Requestor where requestorEmail like '%MaryDm%'  --- 56512



		select * from Requestor where requestorId in (48750, 56512)

		select * from CustomerRequestorMapping where requestorId in ( 48750, 56512)

		select * from CustomerRequestorMapping where requestorId = 56512

		select top 100 * from userloginattempts order by 1 desc

		-- update CustomerRequestorMapping set isLoginAllowed = 0 where customerRequestorMappingId = 65057


		select * from Users where email like '%kli.sangeeta-gawde@kotak.com%'  ---- 1089	Sangeeta	Gawde

		select * from Users where email like '%kli.pradeep-vishwakarma@kotak.com%'   ----- 718	Pradeep	Vishwakarma	Pradeep Vishwakarma

		select * from Users where email like '%kli.sandeep-bhagat@kotak.com%'      ------ 1069	Sandeep	Bhagat


		select * from MenuMaster where menuName like '%Asset%'  --176

		select * from MenuMaster where MenuId = 1



		--exec Asset_ProvideAssPermission '1089',1,1,null
		--exec Asset_ProvideAssPermission '718',1,1,null
		--exec Asset_ProvideAssPermission '1069',1,1,null


		select * from Workgroup where workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
,629
,630
,631
,632
,687)


--   update Workgroup set IsVisible = NULL where  workgroupid in ( 203,214,224,225,227,229,232,233,235,238,241,249,495,496,512,513,515,525,595,596,628
--,629
--,630
--,631
--,632
--,687)

  select * from NotificationEmailtemplate where customerid = 147 and templateName like '%HR%'


  select customerId, priorityId, priorityName, workgroupId, workgroupName, serviceId,* from Ticket where ticketNo = 2657887

  select * from ServiceLevelObjective where serviceLevelObjectiveId in(
  
  779588
,779592
,779588
,779592
,779588
,779592
,779588
,779592
,1082477
,1082577) 

    select * from ServiceLevelObjective where serviceId = 68 and workgroupId = 675 
	and isDelete = 0 and priorityId = 15

	select * from Priority where ticketTypeId =2 

  select * from ServiceLevelAgreement where customerId = 147        --------74	Ask ML SR


  select * from ServiceLevelTracking where sourceId = 2657887


  select * from FeedbackConfig

  select * from FeedbackRating
  
  select * from FeedbackTextMapping

1	HighDSat
2	DSat
4	Sat
5	HighSat


  select * from NotificationEmailTemplate where customerId = 147 and template like '%feedb%'

  --  489	Resolved notication_HR

  select * from NotificationEmailTemplate where  template like '%Feedback%'


 -- update NotificationEmailTemplate set template = '' where templateId = 491






         ---  SR2666039


		 select * from Users where email like '%nikhil.sharma@heromotocorp.com%'
		 --- 910	Nikhil	Sharma

		 select * from NotificationRegistry where sourceid = 2666039


		 select * from NotificationRegistry where sourceid = 2666082


  ---TAAGIC Approval tickets report:

    select A.approvalNo, A.sourceDescription,CONVERT(date, A.approvalCreatedOn) as approvalCreatedOn, 
  A.sourceAssignedToName, A.sourceRequestorName, A.sourceCreatedByName,A.sourceWorkgroupName, A.sourceCategoryName, A.sourceSubCategoryName, 
  A.sourceClassificationName, A.sourcePriorityName, A.sourceImpactName from Approval A

  where A.sourceCustomerId = 1 and A.approvalCreatedOn between '2020-01-20' and '2020-09-24'

  order by 1 


  ---Modified one:

  
  select A.approvalNo, A.sourceDescription,CONVERT(date, A.approvalCreatedOn) as approvalCreatedOn, 
   CASE
   when  A.ApprovalCompletedTime is null then 'NO'
   Else 'YES'
   END AS ApprovalStatus,
   
  A.sourceAssignedToName, A.sourceRequestorName, A.sourceCreatedByName,A.sourceWorkgroupName, A.sourceCategoryName, A.sourceSubCategoryName, 
  A.sourceClassificationName, A.sourcePriorityName, A.sourceImpactName, A.isApprovalInitiated from Approval A
  where A.sourceCustomerId = 1 and A.approvalCreatedOn between '2020-01-20' and '2020-09-24'
  order by 1 


  ---     = TIME(HOUR(AZ2), MINUTE(AZ2), SECOND(AZ2)) - TIME(HOUR(AY2), MINUTE(AY2), SECOND(AY2))



  select * from Users where email like '%ChandrakumarE@microland.com%'

  ----> branch ops, kli -->
  select * from users where firstName like '%Seema%'  Bukhari

    select * from users where lastName like '%Bukhari%'

	------ Report 29-09-2020

	Select E.Ticketno as TicketNumner, count(E.ticketNo) NoOfEmailsTriggered, T.customerName,   T.serviceName, T.workgroupName, T.priorityName, T.impactName
	from Ticket T 
	inner join EmailTransaction  E
	on E.Ticketno = T.ticketNo
	where T.customerId in (3, 4, 8, 58, 61, 158, 161, 167, 168, 169, 188, 189, 192, 194,196, 203, 207,213)
	group by E.Ticketno, T.customerId, t.customerName, T.serviceName, T.workgroupName, T.priorityName, T.impactName, t.serviceName


		 select * from ReportMaster where reportMasterID = 157  --->  usp_StandardReport_ASKML_GetTotalTimeSpentInTicket_RP009

	  select * from ReportMaster where reportMasterID = 24  ----> usp_StandardReport_getAllIM&SRCombinedTicketDump



	        select * from workGroupEscalationMatrix where Level1Email like '%SyedAhS@microland.com%'

       select * from workGroupEscalationMatrix where    Level2Email like  '%SyedAhS@microland.com%'       

       select * from workGroupEscalationMatrix where  Level3Email like  '%SyedAhS@microland.com%'

       select * from workGroupEscalationMatrix_AskML where Level1Email like  '%SyedAhS@microland.com%'

       select * from workGroupEscalationMatrix_AskML where Level2Email like  '%SyedAhS@microland.com%'

       select * from workGroupEscalationMatrix_AskML where Level3Email like  '%SyedAhS@microland.com%'



	   
       select * from workGroupEscalationMatrix where Level1Email like '%SyedBA@microland.com%'

       select * from workGroupEscalationMatrix where    Level2Email like '%SyedBA@microland.com%'       

       select * from workGroupEscalationMatrix where  Level3Email like '%SyedBA@microland.com%'

       select * from workGroupEscalationMatrix_AskML where Level1Email like '%SyedBA@microland.com%'

       select * from workGroupEscalationMatrix_AskML where Level2Email like '%SyedBA@microland.com%'

       select * from workGroupEscalationMatrix_AskML where Level3Email like '%SyedBA@microland.com%'

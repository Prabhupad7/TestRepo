

   select * from Customer where customerName like '%Ownership%' --->   161

      --select * from Customer where customerName like '%oreta%' --->   161

   select * from ApiKey where customerId = 161


      select * from autoticketserviceemailconfig where apikey in (
	   select keyname from ApiKey where customerId = 161
	  )





   --Update ApiKey set isdelete = 1 where keyId in (54,62,103,104)

   Select * from AutoTicketServiceRule where apiKeyId in (54,62,103,104)

   --update AutoTicketServiceRule set isDeleted = 1  where id in ()

   select * from AutoTicketServiceEmailConfig where name like '%Ownership%'

   select * from AutoTicketServiceEmailConfig where apiKey in (
   select keyname from ApiKey where customerId = 161
   )

   --update AutoTicketServiceEmailConfig set isDeleted = 1 where id in (282, 285, 319)


   ---->  1
--   1174910
--1174909
--1174908
--1174907

-->  2
1174912
1174911

---> 3
1174913

---->  4

1174918
1174917
1174916
1174915
1174914

---

1174990


   select GETDATE()

   select top 100 * from AutoTicketEventLog order by createdOn desc


   select top 100 * from Requestor where requestorEmail like '%akansha.saxena@heromotocorp.com%' order by 1 desc

   select * from Requestor where requestorId = 57633

   -->   57636

  --   Insert into Requestor (requestorName,requestorEmail,isCriticalUser,employeeId,firstname,lastname,alias,designation,department,location,mobileno,createdOn,
	 --UpdatedOn,createdby,updatedby,deleted,LastLoginTime,failedLoginAttemptCount,isAccountLocked)

	 --values ('AKANSHA SAXENA', 'akansha.saxena@heromotocorp.com', 0, 90121973, 'AKANSHA', 'SAXENA', 'akansha.saxena', 'Project Support', 'MLH', 'HCHO2-The Grand -HO2','9828775280 ',GETDATE(),
	 --getdate(), 6, 6, 0, getdate(), 0, 0
	 --)


	 --update Requestor set alias = 'Deleted_akansha.saxena@heromotocorp.com', requestorEmail = 'Deleted_akansha.saxena@heromotocorp.com', deleted =1 where requestorId = 57608




    1. Add the new device into the table and map the device in service table:

    2.  INSERT INTO DEVICE(devicename,alternateName,ipAddress,customerId,deleted,hostName)
	    VALUES ('AZINSQLDB101','AZINSQLDB101','172.21.60.11',4,0,'AZINSQLDB101')

	3.  INSERT INTO DeviceServiceMapping (serviceId, deviceId,deleted,ticketTypeId) VALUES(1,24150,0,3)

	4.  INSERT INTO DeviceServiceMapping (serviceId, deviceId,deleted,ticketTypeId) VALUES(2,24150,0,3)

	5.  INSERT INTO DeviceServiceMapping (serviceId, deviceId,deleted,ticketTypeId) VALUES(3,24150,0,3)

	6. INSERT INTO DeviceServiceMapping (serviceId, deviceId,deleted,ticketTypeId) VALUES(4,24150,0,3)

	 

	 TO DELETE THE DEVICE FROM TABLE:

	7.  UPDATE DEVICE SET DELETED = 1 WHERE DEVICEID = 24150


	 TO RENAME THE DEVICE:

	8.  UPDATE device SET devicename = 'BLRECHOSPMS101' WHERE deviceid = (select deviceid from device where devicename = 'AZINSQLDB101'

	

	CREATE NEW USER:

	9. INSERT INTO Users(firstName,lastName,displayName,mobileNo,email,loginName,[password], deleted, IsWorkgroup, isPasswordPolicyApplicable,
	   isAutoAssignmentEnable, roleId, createdById, createdOn, timezoneinfoId, instanceId, SaltValue,levelid) VALUES('VENKAT','RAMAN','VENKAT RAMANA',
	  '9700940947', 'VENKAT@MICROLAND.COM', 'VENKATR', 'SUv/GzSv2NSYGeW1YMGviQ==', 0,0,0,0,32,6,GETDATE(),24,1,null,0)
	
	

	ADDING SERVICES INTO DATABASE:

    10.	INSERT INTO [dbo].[Service] ([serviceName],[alternateName] ,[description],[createdDate],[typeId] ,[createdById] ,[modifiedById] ,[deleted] ,[isEUPVisible] ,[Icon] ,[Icon_Color] ,[Icon_BgColor])
    VALUES('Example','Example','Example',GETDATE(),1,6,6,0,0,'fa fa-2x fa-shield', '#F5CF87', '#C75C5C')


   Get the generated serviceId and map into �ServiceCustomerMapping� table:

    11.  Insert into ServiceCustomerMapping(serviceId,customerId,deleted,ticketTypeId) Values(454, 199,0,1)

   Category mapping :

    12.   Insert into ServiceCategoryMapping(serviceId,categoryId,deleted,ticketTypeId) VALUES (454,57,0,1)

  Sub Category:

    13.  INSERT INTO SubCategory (subCategory,categoryId,deleted,Isdefaultcategory, isEUPVisible ,Icon,Icon_Color ,Icon_BgColor,oldSubCategoryId,CreatedBy, CreatedOn, UpdatedBy, UpdatedOn)   VALUES (�Category_Name�,57,0,0,0,'fa fa-2x fa-shield','#F5CF87', '#C75C5C',NULL,6,GETDATE(),6, GetDATE())

 Insert into Classification:


   14.  INSERT INTO Classification(classification,subCategoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)
        VALUES('Issues with Microlander',20467,0,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
        ('Issues with Microland One',20468,0,0,0,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())

	 









  select * from workgroup where workgroup in (
    
  select * from Workgroup W
  inner join AssignmentGroup AG on W.workgroupId = AG.workgroupId
  inner join CustomerAssignmentGroupMapping CG on CG.assignmentgroupId = AG.assignmentgroupId
  inner join UserCustomerAssignGroupMapping  US on US.custAssignmentGroupId = CG.custAssignmentGroupId
  where cg.customerId =1 and w.workgroupId in (2, 12, 19, 9, 8, 5, 123, 136, 137, 86)

  ---->   w.workgroupId in (2, 12, 19, 9, 8, 5, 123, 136, 137, 86)

   select distinct us.userId from Workgroup W
  inner join AssignmentGroup AG on W.workgroupId = AG.workgroupId
  inner join CustomerAssignmentGroupMapping CG on CG.assignmentgroupId = AG.assignmentgroupId
  inner join UserCustomerAssignGroupMapping  US on US.custAssignmentGroupId = CG.custAssignmentGroupId
  where cg.customerid = 1 and w.workgroupId in (2) and w.deleted=0 and ag.deleted=0 and us.deleted =0


  select * from  Workgroup where workgroupId in (2, 5, 8, 9, 12, 19 , 86, 123, 136, 137)


  select userName, displayName, email, loginName from Users where userid in (
   select distinct us.userId from Workgroup W
  inner join AssignmentGroup AG on W.workgroupId = AG.workgroupId
  inner join CustomerAssignmentGroupMapping CG on CG.assignmentgroupId = AG.assignmentgroupId
  inner join UserCustomerAssignGroupMapping  US on US.custAssignmentGroupId = CG.custAssignmentGroupId
  where cg.customerid = 1 and w.workgroupId in ( 137 ) and w.deleted=0 and ag.deleted=0 and us.deleted =0

  ) and deleted =0





Select * from reportmaster where reportmasterid = 502


   -- 9886441125 syed

   syedsaa1
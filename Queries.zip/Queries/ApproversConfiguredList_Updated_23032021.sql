

select am.approvalMatrixId, aemd.ServiceLine, aemd.Category, aemd.SubCategory, aemd.Classification, aml.levelName, apr.approverName  from ApprovalMatrix am
join (
select approvalMatrixId, case when s.serviceId is null then 'All' else s.serviceName end as ServiceLine,
case when c.categoryId is null then 'All Categories' else c.category end as Category,
case when sc.subCategoryId is null then 'All Subcategories' else sc.subCategory end as SubCategory,
case when cl.classificationId is null then 'All Classifications' else cl.classification end as Classification
from vwApprovalEntityMappingConverted aem
left join service s on s.serviceid = case when aem.serviceId = 0 then null else aem.serviceId end
left join category c on c.categoryId = case when aem.categoryId = 0 then null else aem.categoryId end
left join subcategory sc on sc.subcategoryId = case when aem.subcategoryId = 0 then null else aem.subCategoryId end
left join Classification cl on cl.classificationId = case when aem.classificationId = 0 then null else aem.classificationId end
where customerId = 167 and aem.Deleted = 0 and s.Deleted = 0 and c.Deleted = 0 and sc.Deleted = 0) aemd on aemd.approvalMatrixId = am.approvalMatrixId
join ApprovalMatrixLevel aml on aml.approvalMatrixId = am.approvalMatrixId
join ApprovalMatrixApprover apr on apr.levelId = aml.levelId
order by am.approvalMatrixId,aemd.ServiceLine, aemd.Category, aemd.SubCategory, aemd.Classification, aml.parentLevelId
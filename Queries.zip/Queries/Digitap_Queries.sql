

select top 10 * from TBL_MigrationStatus
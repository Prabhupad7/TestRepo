



    select * from category where serviceId = 6 
    select * from servicecategorymapping  
    select * from subcategory
    select * from classification

	select * from tickettype

	--  4	Problem

	 select * from Service   where serviceName like '%Server Management%' --  serviceId = 6

	 select  * from Category where category ='Other' and serviceId = 6 and ticketTypeId = 4 -- categoryid = 242
	 select  * from Category where category ='Ms-Office' and serviceId = 6 and ticketTypeId = 4 -- categoryid = 243
	 select  * from Category where category ='IIS' and serviceId = 6 and ticketTypeId = 4 -- categoryid = 244
	 select  * from Category where category ='JBOSS' and serviceId = 6 and ticketTypeId = 4 -- categoryid = 245
	 select  * from Category where category ='Access' and serviceId = 6 and ticketTypeId = 4 -- categoryid = 246
	 select  * from Category where category ='Windows OS' and serviceId = 6 and ticketTypeId = 4 -- categoryid = 247

	 INSERT INTO Category (	category, 	deleted, ticketTypeId,	serviceId,	Isdefaultcategory,	isEUPVisible,	Icon, 	Icon_Color, Icon_BgColor,CreatedBy,	CreatedOn,	UpdatedBy,	UpdatedOn)

	 values ('Windows OS', 0, 4, 6, 0, 1, null, null, null, 44, GETDATE(), 44, getdate())

	 select  * from subcategory WHERE subCategory = 'Access' AND categoryId = 241 and deleted = 0



	 -- update SubCategory set deleted =1 where subCategoryId = 1761

	 INSERT INTO SubCategory( subCategory,	categoryId,	deleted, Isdefaultcategory,	isEUPVisible,	Icon,	Icon_Color,	Icon_BgColor,	CreatedBy,	CreatedOn,	UpdatedBy,	UpdatedOn)
	 VALUES ('Server slowness', 247, 0, 0, 1, NULL, NULL, NULL, 6, GETDATE(), 6, GETDATE())

	 select * from SubCategory where subCategory = 'Server slowness' and deleted = 0 

	 select  * from classification WHERE subCategoryId = 1774

	 INSERT INTO classification(classification,	subCategoryId,	deleted,	Isdefaultcategory,	isEUPVisible,	Icon,	Icon_Color,	Icon_BgColor,	CreatedBy,	CreatedOn,	UpdatedBy,	UpdatedOn,	IsPublicTicket)

	 VALUES('others-Undefined', 1774, 0, 0, 1, NULL, NULL, NULL, 6, GETDATE(), 6, GETDATE(), NULL)

    --5	Emergency	161	0	0	1	NULL	NULL	NULL	6	2018-05-27 07:00:03.613	6	2018-05-27 07:00:03.613	NULL




 --   Credence	42	0	0	1	NULL	NULL	NULL	6	2018-05-27 07:00:03.587	6	2018-05-27 07:00:03.587

--192	Hardware config.	0	2	5	0	1	NULL	NULL	NULL	44	2019-04-25 17:32:38.013	44	2019-04-25 17:32:38.013


	 select  * from Category where category like '%Desktop/Laptop%'


	 Assigned, Resolved



	 select * from NotificationRules 

	 select * from Customer where customerId = 147

	 select * from NotificationEmailTemplate where customerId = 147
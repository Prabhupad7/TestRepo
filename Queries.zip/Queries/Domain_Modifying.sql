
  --->  https://rmcops.microland.com/Entity/120/147/True
  select * from assets where CustomerId = 147 and SourceId = 120 

  select isDeleted, * from assets 
  where CustomerId = 147 and SourceId = 120  and AssetName ='MLGTS'

  -- update Assets set isDeleted = 1 where id = 12360


		  select * from ticket t
		join requestor r on r.requestorId=t.requestorId
		where customerId=4 and r.requestorEmail='vishalds@microland.com'

		--560770	Test ticket please ignore
		--1806721	Please do not resolve - Test ticket by SMC Team for testing email transactions - Please do not resolve
		--2457051	Physical Memory Used has entered Critical state. test ticket
		--2647762	Util Out has entered Critical state
		--2665943	Physical Memory Usage has entered Critical state with polled result 95. Test has been in state for 00:15.
		--2705670	Overall CPU Load has entered Critical state

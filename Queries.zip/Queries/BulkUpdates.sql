


--update JP_21072020 set assetid =b.Id from JP_21072020 a 
--inner join assets b on a.SLNumber =b.SerialNumber and a.Laptop =b.AssetNumber


--update JP_21072020 set assignedtoengineer =b.id  from JP_21072020 a 
--inner join Asset_users b on a.eMail =b.EmailId


--update JP_21072020 set statusid=1 where statusnew = 'In Stock'

--update JP_16072020 set statusid=15 where statusnew = 'In Stock'


--update assets set StatusId = b.StatusID,Status=b.StatusNew
--from assets a inner join JP_21072020 b on a.Id = b.AssetID 
--and a.SerialNumber = b.SLNumber 
--where id in (select a.AssetID from JP_21072020 a)




--update Asset_Assignment set assignedToId =b.AssignedToEngineer ,assignedToName =b.Username  from 
--Asset_Assignment a inner join JP_21072020 b on a.assetId = b.AssetID 
--where a.IsActive = 1  and a.assetId in (
--select a.AssetID from JP_21072020 a) 


--update VarcharCustomAttribute set Varchar1 =b.WorkstationNumber
--from VarcharCustomAttribute a inner join  JP_21072020 b on a.PrimaryId = b.AssetID 
--where a.PrimaryId in (select a.AssetID from JP_21072020 a)

--update VarcharCustomAttribute set Varchar31 =b.SiteName
--from VarcharCustomAttribute a inner join  JP_21072020 b on a.PrimaryId = b.AssetID where a.PrimaryId in (select a.AssetID from JP_21072020 a)

--Table Backup query


--Select * INTO assets_210720220

--from 

--  Assets  where Id in (
--select a.AssetID from JP_21072020 a) 

--Select * INTO asset_assignment_21072020

--from 

--  asset_assignment  where assetId in (
--select a.AssetID from JP_21072020 a) and IsActive = 1

--select * from asset_assignment_21072020



select * from Customer where customerName like '%NOKIA%'  ----->  213	Nokia	Nokia

select * from ReasonForCancellation
where CustomerId = 213 and TicketTypeId = 4

--Insert into ReasonForCancellation (	ReasonForCancellationName,CustomerId,TicketTypeId,	isDeleted,
--createdOn,	createdBy)

--values ('Default', 213, 4, 0, GETDATE(), 6)



select * from TicketType ----->  4	Problem	PRO


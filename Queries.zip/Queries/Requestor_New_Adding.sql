

   select * from Customer where customerName like '%SMC%' -->  209	SMC New Nokia

   --->  --->  

   	select * from Requestor where requestorEmail like '%prasenjit.das@heromotocorp.com%'  --->  57294

	--> 313	akansha saxena	akansha.saxena@heromotocorp.com	Yes	No	Yes	No	No	32

	-- Insert into Hero_Users (firstName, lastName, emailAddress, mobilePhone1, workAddress1,employeeId,employeeTitle, department)
	   values ('anil', 'gaikwad', 'anil.gaikwad@heromotocorp.com', '7722075501', 'HCHO3- Horizon Office', '13852','Senior Manager', 'Innovation Cell' )

	-- select * from hmcl_Users

	 

	----->  <prakoso.wibowo@persada.id> --->  prakoso.wibowo

	select * from CustomerRequestorMapping where requestorId = 58343

	---> For Hmcl 

	select * from Hero_Users

	select * from hmcl_Users

	--Insert into CustomerRequestorMapping (requestorId, customerId, customerName, isLoginAllowed)
	--values (57737, 213, 'Nokia', 0),
	--       (57736, 213, 'Nokia', 0),
	--	   (57735, 213, 'Nokia', 0),
	--	   (57734, 213, 'Nokia', 0),
	--	   (57733, 213, 'Nokia', 0),
	--	   (57732, 213, 'Nokia', 0),
	--	   (57731, 213, 'Nokia', 0),
	--	   (57730, 213, 'Nokia', 0)
		  



	--Insert into Requestor (requestorName, requestorEmail, isCriticalUser,employeeId, firstname, lastname,  alias, department, designation,location, mobileno, 
	--createdOn, UpdatedOn, createdby, updatedby, deleted, LastLoginTime, CountryCode, failedLoginAttemptCount, isAccountLocked)

	--values ('Prasanth Nekkalapudi', 'Prasanth.Nekkalapudi@aveva.com', 0, '', 'Prasanth', 'Nekkalapudi', 'Prasanth.Nekkalapudi', 'IT Net Ops','Network senior Engineer',
	--'Banglore' ,'+91-8106685566',
	--GETDATE(), GETDATE(), 6, 6, 0, GETDATE(), 61, 0, 0),

	--('phil stephenson', 'phil.stephenson@aveva.com', 0, '', 'phil', 'stephenson', 'phil.stephenson', 'IT Net Ops','Network senior Engineer',
	--'Cambridge' ,'+44-07880 146 017',
	--GETDATE(), GETDATE(), 6, 6, 0, GETDATE(), 61, 0, 0),

	--('rob browning', 'rob.browning@Aveva.com', 0, '', 'rob', 'browning', 'rob.browning', 'IT Net Ops','Network senior Engineer',
	--'Cambridge' ,'121',
	--GETDATE(), GETDATE(), 6, 6, 0, GETDATE(), 61, 0, 0)

	   select top 3 * from Requestor order by 1 desc ----> 92170, 92169, 92168

	   select * from Customer where customerName like '%Aveva%'  ---> 220	Aveva



	   Select top 100 * from CustomerRequestorMapping where requestorId in (
	    92170, 92169, 92168
	   )

	   --Insert into CustomerRequestorMapping

	   --select 92170, 220, 'Aveva', 0
	   --union All
	   --select 92169, 220, 'Aveva', 0
	   --union All
	   --select 92168, 220, 'Aveva', 0
	  


	
	  select top 1 * from Requestor where requestorName like '%VAAuditScan_Corp%'  ----> 91212 VAAudit Scan_Corp

	  select top 1 * from Requestor order by 1 desc

		--Update Requestor set requestorName ='VAAuditScan_Corp', department =null,mobileno = null, location = null where requestorId in (
		--91212
		--)

		select * from CountryCode where CountryName like '%India%' ---> 103

		select * from CustomerRequestorMapping where requestorId  = 91212

		--Insert into CustomerRequestorMapping (requestorId, customerId, customerName, isLoginAllowed)
		--values (91212, 1, 'KLI', null)

--insert into CustomerRequestorMapping
--select 91212,147,'Ask Microland',1 
--union all
--select 91212,146,'Oreta-Axieo',1

  ---> sr2992385


  select * from users where loginName like '%amitdik%'   ----> 26360

  select * from Customer where customerName like '%Bung%'  ----> 218	Bunge

  select * from Admin_UserCustomerAdminMapping where userid = 26360 and CustomerID = 218

  --update Admin_UserCustomerAdminMapping set Deleted =1 where UCAMID = 1219

  --insert into Admin_UserCustomerAdminMapping

  --select 26360, 218, 0, GETDATE(), 6, GETDATE(), 6, 0 


  select * from users where email like '%JithuJR@microland.com%'

  --Update users set UserTypeId = 4 where userId = 26701

  select toolTicketNo,* from Ticket where ticketNo = 2983765 

  select * from ServiceLevelTracking where sourceId = 3064311

  --Update ServiceLevelTracking set statusId = 3 where sourceId = 3064311

  select * from Users where email = 'ManjunathKS@microland.com' ---> 25872 ManjunathKS@microland.com 75

  select * from Users where email = 'GeethaKr@microland.com' ---> 26753 GeethaKr@microland.com 75  3068

  select * from UserCustomerAssignGroupMapping 
  where userId in (25872, 26753) and custAssignmentGroupId = 3068

  --Insert into UserCustomerAssignGroupMapping

  --select 26753, 3068, 0, 0, 0

  select * from ReportMaster where reportMasterID = 102  ----> 102	RP001 - Incident and Service request SLA dump

  select * from ReportRoleMapping 
  where RoleId =  75 and ReportMasterId = 102

  --delete from ReportRoleMapping where id = 5869

  select * from Workgroup where workgroupId =  640 ---> RMC Autoremediation
  --where workgroupEmail like '%RMC%'

    select * from Workgroup where workgroup like '%Acti%'  ---> 768	Actifio Autoremediation

  select top 100 * from AssignmentGroup
  where assignmentgroupName like '%RMC Auto%' ---> 771	RMC Autoremediation - Queue 640

    select top 100 * from AssignmentGroup
  where workgroupId = 768 ---> 903	Actifio Autoremediation

  select * from customer where customerId in (4,50,3,207,192,194)

  select * from CustomerAssignmentGroupMapping 
  where assignmentgroupId = 903  ---> 3068	Actifio-Apotex - Autoremediation � Queue


---->   instancepasswordchange 

  select * from Instancepasswordchangehistory where UserId = 989

  ---update Instancepasswordchangehistory set PwdUpdatedDate = GETDATE () where id = 511

  --->  UpdatedOn =getdate(), CreatedOn= GETDATE()

select * from Users where loginName like '%AJKUMAR10%' ---> 
select * from Customer where customerId = 192 --->  Jubilant Life Sciences

select * from Customer where customerId = 192 --->  Jubilant Life Sciences


select * from notificationRules where 
customerid = 192  and deleted = 0 and duepercent is not null and notificationmode='AWSSMS'

   Select * from Workgroup where workgroup in 
   ('RMC Backup',
'RMC Managers'
,'RMC Messaging'
,'RMC Network'
,'RMC SOC'
,'RMC Storage'
,'RMC Tools'
,'RMC VoIP'
,'RMC windows')

   select * from Workgroup W
   inner join AssignmentGroup Ag on Ag.workgroupId = W.workgroupId
   inner join CustomerAssignmentGroupMapping CM on CM.assignmentgroupId =Ag.assignmentgroupId
   where cm.customerId = 192 and w.workgroupId in (
   2,3,4,5,9,10,13,47,104,169,442,490,492,523,541,556,609,727,729,731,732,733 )


  ----->  WorkgroupId in: (2,3,4,5,10,13,47,104)

  select distinct serviceId
  from ServiceCustomerMapping where deleted = 0  and customerId = 192 and ticketTypeId = 1

    select distinct serviceId
  from ServiceCustomerMapping where deleted = 0  and customerId = 192 and ticketTypeId = 2

  select * from NotificationEmailTemplate  where templateId in ( 
 1646
,1647
,1648
,2056
,2057
,2058)

select * from NotificationEmailTemplate  where customerId = 192 
and templateName like '%SMS%'



--Insert into NotificationEmailTemplate (templateName, template, customerId, isOutageNotificationTemplate, isOutageSMSNotification)

--select templateName, template, 192, isOutageNotificationTemplate, isOutageSMSNotification from NotificationEmailTemplate  where templateId in ( 
-- 1646
--,1647
--,1648
--,2056
--,2057
--,2058)

-------->   from Vignesh: 

  ----->    select * from NotificationServiceSMSConfig where CustomerId = 192


        select * from NotificationServiceSMSConfig where CustomerId in ( 3, 147, 8, 194, 192)
		 
		select * from Customer where customerName like '%jubilant%' --->  192	Jubilant Life Sciences

		--Insert into NotificationServiceSMSConfig (Name, Api, SenderId, UserName, Password, ApiPriority, Stype, IsDeleted, CustomerId, MaxMessageLength)

		--select 'Jubilant Life Sciences', Api, SenderId, UserName, Password, ApiPriority, Stype, IsDeleted, 192, MaxMessageLength 
		--from NotificationServiceSMSConfig where CustomerId = 3


		select * from notificationRules where 
		customerid = 192  and deleted = 0  
		and notificationmode='AWSSMS' and duePercent in ( 25, 40, 60, 75, 90)

		select * from notificationRules where 
		customerid = 192  and deleted = 0  
		and notificationmode='AWSSMS' and duePercent in ( 25)

		--Update notificationRules set notificationTo ='919885404183,918095088230,918861061034,918553440987' where 
		--customerid = 192  and deleted = 0  
		--and notificationmode='AWSSMS' and duePercent in ( 25, 40, 60, 75, 90)

		select * from NotificationEmailTemplate  where customerId =192
		and templateName like '%SMS%'


		select * from service where serviceid in 
		(select distinct serviceId from notificationRules where 
		customerid = 192  and deleted = 0  
		and notificationmode='AWSSMS' and duePercent in ( 25, 40, 60, 75, 90))



		select * from NotificationEmailTemplate  where customerId =8
		and templateName like '%SMS%'

		select * from NotificationEmailTemplate  where customerId =147
		and templateName like '%SMS%'

		select * from notificationRules where 
		customerid = 8  and deleted = 0  
		and notificationmode='AWSSMS' and duePercent in ( 25, 40, 60, 75, 90)



		select distinct templateId from notificationRules where 
		customerid = 8  and deleted = 0  
		and notificationmode='AWSSMS' and duePercent in ( 25, 40, 60, 75, 90)




and workgroupid =3 and ticketTypeId =1 and serviceId = 328


---->    ----->  WorkgroupId in: (2,3,4,5,10,13,47,104)

--2066	Resolution SLA 50 - SMS
--2067	Resolution SLA 75 - SMS
--2068	Resolution SLA 90 - SMS
--2069	Resolution SLA 25 - SMS
--2070	Resolution SLA 40 - SMS
--2071	Resolution SLA 60 - SMS

		--  Insert into NotificationRules (customerId,ticketTypeId,duePercent,notificationMode,notificationTo,templateId,
		--  ruleName,	workgroupid,serviceId,notifyBasedOnId,deleted)

  --      select customerId,ticketTypeId,100,notificationMode,notificationTo,2097,
  --      'ResolutionSLA 100 %',	workgroupid,serviceId,notifyBasedOnId,deleted from notificationRules where 
		--customerid = 194  and deleted = 0  
		--and notificationmode='AWSSMS' and duePercent in (25)




		select * from notificationRules where 
		customerid = 192  and deleted = 0  
		and notificationmode='AWSSMS' and duePercent in ( 25)



  Values 
  (192, 2, 25, 'AWSSMS', '919885404183,918095088230,918861061034,918553440987', 2069, 'ResolutionSLA 25 %',104 ,211 ,3, 0),
  (192, 2, 25, 'AWSSMS', '919885404183,918095088230,918861061034,918553440987', 2069, 'ResolutionSLA 25 %',104 ,212 ,3, 0),
  (192, 2, 25, 'AWSSMS', '919885404183,918095088230,918861061034,918553440987', 2069, 'ResolutionSLA 25 %',104 ,213 ,3, 0),
  (192, 2, 25, 'AWSSMS', '919885404183,918095088230,918861061034,918553440987', 2069, 'ResolutionSLA 25 %',104 ,214 ,3, 0),
  (192, 2, 25, 'AWSSMS', '919885404183,918095088230,918861061034,918553440987', 2069, 'ResolutionSLA 25 %',104 ,215 ,3, 0),
  (192, 2, 25, 'AWSSMS', '919885404183,918095088230,918861061034,918553440987', 2069, 'ResolutionSLA 25 %',104 ,216 ,3, 0),
  (192, 2, 25, 'AWSSMS', '919885404183,918095088230,918861061034,918553440987', 2069, 'ResolutionSLA 25 %',104 ,479 ,3, 0)


  ---->1   SR2782557 test ticket created:  
  -----> 2 SR2783043


  select * from NotificationRegistry where sourceId = 2789929
  and notificationMode = 'AWSSMS'
 
   select * from NotificationRegistry where sourceId = 2783043 and statusid = 2
  and notificationMode = 'AWSSMS'


     ---->  SR2789929 test ticket on 21/12/2020: 

         --exec deletetickets @ticketNo = '2782557';
         --exec deletetickets @ticketNo = '2783043';

 
 select * from NotificationRules where ruleid in (2087223
,2087219)

   select * from NotificationRegistry where sourceId = 2773674


  ---->    select * from Ticket where ticketno in (2773497, 2773674)

--Update  notificationRules set notificationTo = '919885404183,918095088230,918861061034,918553440987,919000309621,919700940947' where 
--customerid = 192  and deleted = 0 and notificationmode='AWSSMS' and duePercent in ( 25, 40, 60, 75, 90)


--manjanathn@microland.com 



--2067	Resolution SLA 75 - SMS	   Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 75% Resolution SLA
--2068	Resolution SLA 90 - SMS	   Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 90% Resolution SLA
--2069	Resolution SLA 25 - SMS	   Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 25% Resolution SLA
--2070	Resolution SLA 40 - SMS	   Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 40% Resolution SLA
--2071	Resolution SLA 60 - SMS	   Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 60% Resolution SLA

------->   Dear @Model.ASSIGNEDENGINEEREMAIL <br/> Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 75% Responce SLA


  select * from NotificationEmailTemplate where templateId = 2071

  --Update NotificationEmailTemplate set 
  --template ='Dear @Model.ASSIGNEDENGINEEREMAIL <br/> Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 60% Resolution SLA'
  --where templateId = 2071


  --Update NotificationEmailTemplate set 
  --template ='Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 60% Resolution SLA'
  --where templateId = 2071


  	    select * from NotificationEmailTemplate  where customerId =192
		and templateName like '%SMS%'

		 select * from NotificationEmailTemplate  where customerId =194
		and templateName like '%SMS%'


		  --Update NotificationEmailTemplate set templateName = 'Resolution SLA 100 - SMS'
		  --where templateId =2097

	insert into NotificationEmailTemplate(templateName,template,customerId,	isOutageNotificationTemplate,isOutageSMSNotification)
    values(  'Resolution SLA 100', 'Dear @Model.WORKGROUP <br/>  Your @Model.CUSTOMERNAME ticket @Model.TICKETNOTODISPLAY <br/>  has Elapsed 100% Resolution SLA',192,0,0)

  select * from workgroup where workgroup like '%remote resolution%' ---->  247

  --update workgroup set workgroupemail ='helpdesk@microland.com;NishantBS@microland.com;' where workgroupid = 247

  select * from NotificationRules where
  workgroupid = 247 and notificationTo like '%Monica%'

  
  select * from NotificationRules where
  workgroupid = 247 and notificationCC like '%Monica%'

  ---->  ravinanr@microland.com - RavinaNR


  ----->   SR2785313



	select * from CustomerRequestorMapping where requestorId = 57871

   select top 1000 * from CustomerRequestorMapping where customerId = 68



   select top 19 * from device order by 1 desc

   select distinct s.serviceName,s.serviceId from Service S
   inner join ServiceCustomerMapping SC on S.serviceId = sc.serviceId
   where sc.customerId =192 and s.deleted =0 and sc.deleted=0 

   select * from Service where serviceId = 479

   select * from ServiceCustomerMapping  
   where customerId =192 and serviceId = 479 and deleted =0


   select top 100 * from ApprovalEntityMapping


   select top 1000 * from ApprovalEntityMapping where customerId =147
   and approvalMappingRule like '%serviceId=68%' order by 1 desc


   select * from ApiKey  where customerId  =192

   select top 100 * from AutoTicketEventLog where apikeyId = 127 order by 1 desc


--   2785804

--2785804



   select * from Workgroup where workgroup like '%HR%'

   select * from Service where serviceName like '%HR%' --->   84



   select distinct workgroupid from NotificationRules where serviceId =84 and deleted=0 and customerId = 147


   select serviceId, serviceName, workgroupId, workgroupName,customerId, 
   * from Ticket where ticketNo = 2790968 
   --->  652  84  5014 cat	 21081

   select * from AssignmentGroup where workgroupid =652  --->   HR Tech LD - Queue

   select * from AssignmentGroup where Assignmentgroupname like '%HR Tech LD - Queue%' ---->   786

   select top 100 * from RulesForAssignment  where PrimaryAssignmentGroupId = 786

   ---->  {customerId=147;serviceId=84;categoryId=5014;subCategoryId=21081;classificationId=87503;ticketTypeId=2;}

   ----->   Ruleid: 79473    AssignToId: 24406

   select * from Users where userId = 24406  ---->  24406


   select top 100 * from RulesForPriority where customerid = 147 
   and PriorityRule like '%{customerid=147;serviceid=84;}%'



   select workgroup, workgroupEmail from Workgroup where workgroupId in (
   
   select distinct workgroupId  from ServiceLevelObjective where serviceId =84 and Isdelete =0

   )  and deleted =0 and workgroup not like 'RMC%'


      select workgroup, workgroupEmail from Workgroup where workgroupId in (
   
   select distinct workgroupId  from NotificationRules where customerId =147 and deleted =0 

   )  and deleted =0


 select w.workgroupId, w.workgroup, ca.custAssignmentGroupId from CustomerAssignmentGroupMapping CA
 inner join AssignmentGroup AG on AG.assignmentgroupId = CA.assignmentgroupId
 inner join Workgroup W on W.workgroupId = Ag.workgroupId
 where CA.customerId = 1  and W.workgroupId in ( 140)



  select * from Requestor where requestorEmail like '%sayali.mulatkar@heromotocorp.com%' ---->   57791

  select top 100 * from Hero_users where emailAddress like '%sayali.mulatkar@heromotocorp.com%'

    select top 1000 * from Hero_users order by 1 desc

	--Insert into Hero_users (firstName,lastName, emailAddress, mobilePhone1, workAddress1,employeeId,employeeTitle,	department)

	--values ('sayali', 'mulatkar', 'sayali.mulatkar@heromotocorp.com', '918055853736', 'HM2G-Gurgaon Plant', 13898,'N/A' ,'Project Engineering'
	--)



	---> ViewPoint Name: 
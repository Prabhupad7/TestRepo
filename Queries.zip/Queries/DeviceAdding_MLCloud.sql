


Services: Messaging
Customer: GCC ABinbev 

      select * from customer where CustomerName like '%GCC ABinbev%'  ---> 215
 
	  select * from customer where customerid= 192 ---->  Jubilant Life Sciences

	  select * from ServiceCustomerMapping where customerId = 192 and deleted = 0

	  select * from ServiceCustomerMapping where customerId = 192 and deleted = 0

--6
--481
--525

      select * from ServiceCustomerMapping where customerId = 215 and serviceId in (6, 481, 525)

-----> 	 215 525

	  select * from DeviceServiceMapping where serviceId = 525 and deleted = 0

	  select * from Device where deviceName like '%SmartCenterUATEUP%' and customerId = 204


	  --   BLRISEYOMCDMC01	10.109.19.8	 172.21.173.11
   --      blriseylog01	10.109.19.9	     172.21.173.12


       select * from Device where deleted = 0 and  deviceName = 'BLRISEYOMCDMC01' ---->  2931	BLRISEYOMCDMC01

	   select * from Device where deleted = 0 and  deviceName = 'blriseylog01' ---->  2932	BLRISEYOMCDMC01

	   sel

	   --Update Device set ipAddress = '172.21.173.12' where deviceid = 2932

	   --Insert into DeviceServiceMapping (serviceId, deviceId, deleted, ticketTypeId)

	   --select serviceId, 31219, deleted, ticketTypeId 
	   --from DeviceServiceMapping where deviceId in (14781) 


	   31220

	      select * from DeviceServiceMapping where deviceId in (31219, 31220)

		  select * from Service where serviceId in (
 328
,329
,330
,331
,328
,329
,330
,331)

	      select * from Device where deleted =0 and customerId = 194
	      and devicename='MTLEXCH10' 

		  ----->   215 525


--      INSERT INTO device(devicename, alternateName, ipAddress, customerId, deleted, hostName) 
--	  values 	    	  	  
--('ONESTLRT004.one.ofc.loc','ONESTLRT004.one.ofc.loc','172.21.4.34',215,0,'ONESTLRT004.one.ofc.loc'),
--('ONESTLRT005.one.ofc.loc','ONESTLRT005.one.ofc.loc','172.21.4.35',215,0,'ONESTLRT005.one.ofc.loc'),
--('ONESTLRT006.one.ofc.loc','ONESTLRT006.one.ofc.loc','172.21.4.26',215,0,'ONESTLRT006.one.ofc.loc'),
--('ONESTLRT007.one.ofc.loc','ONESTLRT007.one.ofc.loc','172.21.4.27',215,0,'ONESTLRT007.one.ofc.loc'),
--('ONESTLRT008.one.ofc.loc','ONESTLRT008.one.ofc.loc','172.21.4.20',215,0,'ONESTLRT008.one.ofc.loc'),
--('ONESTLDB017SQL.one.ofc.loc','ONESTLDB017SQL.one.ofc.loc','172.21.4.103',215,0,'ONESTLDB017SQL.one.ofc.loc'),
--('DMSTLRTEDGE03.one.ofc.loc','DMSTLRTEDGE03.one.ofc.loc','151.145.250.92',215,0,'DMSTLRTEDGE03.one.ofc.loc'),
--('DMSTLRTEDGE04.one.ofc.loc','DMSTLRTEDGE04.one.ofc.loc','151.145.250.106',215,0,'DMSTLRTEDGE04.one.ofc.loc'),
--('onestldb017fil.one.ofc.loc','onestldb017fil.one.ofc.loc','172.21.4.104',215,0,'onestldb017fil.one.ofc.loc'),
--('onestlap087.one.ofc.loc','onestlap087.one.ofc.loc','172.21.4.13',215,0,'onestlap087.one.ofc.loc'),
--('onegdart004.one.ofc.loc','onegdart004.one.ofc.loc','172.18.45.237',215,0,'onegdart004.one.ofc.loc'),
--('onegdart005.one.ofc.loc','onegdart005.one.ofc.loc','172.18.45.238',215,0,'onegdart005.one.ofc.loc'),
--('onegdart006.one.ofc.loc','onegdart006.one.ofc.loc','172.18.45.239',215,0,'onegdart006.one.ofc.loc'),
--('onegdart007.one.ofc.loc','onegdart007.one.ofc.loc','172.18.45.240',215,0,'onegdart007.one.ofc.loc'),
--('onegdadb002.one.ofc.loc','onegdadb002.one.ofc.loc','172.18.45.241',215,0,'onegdadb002.one.ofc.loc'),
--('DMGDARTEDGE03.one.ofc.loc','DMGDARTEDGE03.one.ofc.loc','172.18.30.59',215,0,'DMGDARTEDGE03.one.ofc.loc'),
--('DMGDARTEDGE04.one.ofc.loc','DMGDARTEDGE04.one.ofc.loc','172.18.30.62',215,0,'DMGDARTEDGE04.one.ofc.loc'),
--('onegdaws001.one.ofc.loc','onegdaws001.one.ofc.loc','172.18.45.242',215,0,'onegdaws001.one.ofc.loc'),
--('ONEBLRRT001.one.ofc.loc','ONEBLRRT001.one.ofc.loc','172.28.194.30',215,0,'ONEBLRRT001.one.ofc.loc'),
--('SONUS PSTN Gateway 1','SONUS PSTN Gateway 1','172.28.194.34',215,0,'SONUS PSTN Gateway 1'),
--('SONUS PSTN Gateway 2','SONUS PSTN Gateway 2','172.28.194.35',215,0,'SONUS PSTN Gateway 2'),
--('oneblrrrt002.one.ofc.loc','oneblrrrt002.one.ofc.loc','172.28.194.65',215,0,'oneblrrrt002.one.ofc.loc')



		select top 22  * from device order by 1 desc

		select * from Device where deviceId in (
  31220
, 31219)

 

    select distinct serviceId from ServiceCustomermapping
	where customerid =194 and deleted =0



--INSERT INTO DeviceServiceMapping (serviceId, deviceId , deleted, ticketTypeId)
--VALUES
--(525,32649,0,4),
--(525,32648,0,4),
--(525,32647,0,4),
--(525,32646,0,4),
--(525,32645,0,4),
--(525,32644,0,4),
--(525,32643,0,4),
--(525,32642,0,4),
--(525,32641,0,4),
--(525,32640,0,4),
--(525,32639,0,4),
--(525,32638,0,4),
--(525,32637,0,4),
--(525,32636,0,4),
--(525,32635,0,4),
--(525,32634,0,4),
--(525,32633,0,4),
--(525,32632,0,4),
--(525,32631,0,4),
--(525,32630,0,4),
--(525,32629,0,4),
--(525,32628,0,4)



	    ('AWS-VSR-081','AWS-VSR-081','10.163.0.5',192,0,'AWS-VSR-081'),
		('AWS-VSR-082','AWS-VSR-082','10.163.0.6',192,0,'AWS-VSR-082'),
		('AWS-VSR-083','AWS-VSR-083','10.163.0.7',192,0,'AWS-VSR-083'),
		('AWS-VSR-084','AWS-VSR-084','10.163.0.9',192,0,'AWS-VSR-084')

			--('SmartCenterUATEUP','SmartCenterUATEUP','13.67.9.3',204,0,'SmartCenterUATEUP'),
			--('SmartCenterWEBUAT','SmartCenterWEBUAT','13.67.9.3',204,0,'SmartCenterWEBUAT'),
			--('smartcenterneweupUAT','smartcenterneweupUAT','13.67.9.3',204,0,'smartcenterneweupUAT'),
			--('smartcenterwebapiUAT','smartcenterwebapiUAT','13.67.9.3',204,0,'smartcenterwebapiUAT'),
			--('smartcenterdev','smartcenterdev','13.67.9.3',204,0,'smartcenterdev'),
			--('smartcentereupdev','smartcentereupdev','13.67.9.3',204,0,'smartcentereupdev'),
			--('smartcenterneweupdev','smartcenterneweupdev','13.67.9.3',204,0,'smartcenterneweupdev'),
			--('smartcenterwebapidev','smartcenterwebapidev','13.67.9.3',204,0,'smartcenterwebapidev'),
			--('EUPVAPT','EUPVAPT','104.211.225.167',204,0,'EUPVAPT'),
			--('SMCVAPT','SMCVAPT','104.211.225.167',204,0,'SMCVAPT'),
			--('SmartCenterEUPUAT','SmartCenterEUPUAT','104.211.225.167',204,0,'SmartCenterEUPUAT'),
			--('SmartCenterUAT','SmartCenterUAT','104.211.225.167',204,0,'SmartCenterUAT'),
			--('sonarqubeUAT','sonarqubeUAT','13.76.44.139',204,0,'sonarqubeUAT'),


			select * from Device where deviceName ='AWS-VSR-079'

			---->   30256

			select * from Device where deviceId in (30256, 31208)

			select * from Service where serviceName like '%DCS%'  --> 420

			select * from Customer where customerId = 3

			select * from Service where serviceId in (
			select serviceId from ServiceCustomerMapping where customerId = 3 and deleted = 0 			
			)

			----->  1	DCS





			select * from Service where serviceId =502

			Select * from DeviceServiceMapping  where deviceId in (30255,30256, 31208)
			order by 3 desc

			select * from Service where serviceName like '%Cloud-App%'  --> 420

			select * from Service where serviceName like '%Cloud-AWS%'  --> 442


			select * from Service where serviceName like '%Cloud-Scaling%'

			select * from Customer where customerId = 204

			select top 10 * from Device where deleted = 0 
			and customerId = 192 order by 1 desc


			select * from Device where ipAddress='10.163.0.9'
			and customerId = 192

			select top 8 * from DeviceServiceMapping 
			order by 1 desc

			

			--INSERT INTO DeviceServiceMapping (serviceId, deviceId , deleted, ticketTypeId)

			--select 424, 

31211
31210
31209
31208

--INSERT INTO DeviceServiceMapping (serviceId, deviceId , deleted, ticketTypeId)
--	  VALUES
--(479,31211,0,1),
--(479,31210,0,1),
--(479,31209,0,1),
--(479,31208,0,1),

--(479,31211,0,2),
--(479,31210,0,2),
--(479,31209,0,2),
--(479,31208,0,2)


  --- Update DeviceServiceMapping set deleted =1 where deviceServiceMappingId in (
2377137
,2377158

  )
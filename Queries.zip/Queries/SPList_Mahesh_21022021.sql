﻿

  select * from Assets where AssetNumber = 'KLI/34260'

  select * from Asset_Assignment where assetId = 24571

  ---->   5306	Harshad Kambli (KA, KLI)

  --Update Asset_Assignment set IsActive = 0 where id  = 39491



  [2/16 6:40 PM] Mahesh K
    EUP PI Call summary - usp_MIS_HMCL_REP_ResolvedTicketDump_Daily_EUP
​[2/16 6:41 PM] Mahesh K
    Daily Ageing report - MIS_HMCL_REP_ageingTicketDump_NonML  and MIS_HMCL_REP_ageingTicketDump_ML


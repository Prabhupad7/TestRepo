


select distinct 
case scm.tickettypeid when 1 then 'Incident'  when 2 then 'Service Request' when 3 then 'Change Ticket' when 4 then 'Problem Ticket' end 'Ticket Type',
 s.serviceId,s.serviceName,c.categoryId, c.category, sc.subCategoryId, sc.subcategory,cl.classificationId, cl.classification, case when scm.deleted = 0 and c.deleted = 0 and sc.deleted = 0 and cl.deleted = 0 and scc.deleted=0 then 'Active' else 'Inactive' end as Active 
 from ServiceCategoryMapping scm
join servicecustomermapping scc on scc.serviceid= scm.serviceid
join service s on s.serviceid = scm.serviceid
join category c on scm.categoryid = c.categoryId
join subcategory sc on sc.categoryId = c.categoryId
join Classification cl on cl.subCategoryId = sc.subCategoryId
where scc.customerid=1  and c.deleted = 0 and sc.deleted = 0 and cl.deleted =0
and scm.tickettypeid in (1, 2) and scc.deleted=0  -- and s.serviceid = 2



select distinct 
c.categoryId, c.category from ServiceCategoryMapping scm
join servicecustomermapping scc on scc.serviceid= scm.serviceid
join service s on s.serviceid = scm.serviceid
join category c on scm.categoryid = c.categoryId
join subcategory sc on sc.categoryId = c.categoryId
join Classification cl on cl.subCategoryId = sc.subCategoryId
where scc.customerid=1  and c.deleted = 0 and sc.deleted = 0 and cl.deleted =0
and scm.tickettypeid in (1, 2) -- and s.serviceid = 1 
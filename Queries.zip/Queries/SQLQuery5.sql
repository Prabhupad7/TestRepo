
--> If auto ticketing not working then we need to login to the below server and 
-- we need to Re-start the service --> SmartCenter Ticket Schedular Service:

Server Name : smcnotification.southeastasia.cloudapp.azure.com:3389
User Name     : smcnotification\mluser
Password    : Microland@bng1
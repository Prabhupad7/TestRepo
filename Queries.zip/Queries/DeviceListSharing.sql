

               select * from Customer where customerName like '%Bosch%'

			   select * from Customer where customerName like '%aveva%' ---> 220	Aveva

			   select * from Customer where customerName like '%eureka%' ---> 167	Eureka Forbes Limited

			 --   61	BOSCH	BOSCH
				--189	BOSCH DCS	BOSCH DCS
				--203	Bosch � Scottsdale	Bosch � Scottsdale
                 
			   select Distinct D.deviceId, D.deviceName, D.ipAddress from Device D
			   inner join DeviceServiceMapping DSM
			   on D.deviceId = DSM.deviceId
			   where d.deleted = 0 and d.customerId = 220 and DSM.deleted = 0
			   order by d.ipAddress


			   select Distinct D.deviceId, D.deviceName, D.ipAddress from Device D
			   inner join DeviceServiceMapping DSM
			   on D.deviceId = DSM.deviceId
			   where d.deleted = 0 and d.customerId = 4 and DSM.deleted = 0


			     select Distinct D.deviceId, D.deviceName, D.ipAddress from Device D
			   inner join DeviceServiceMapping DSM
			   on D.deviceId = DSM.deviceId
			   where d.deleted = 0 and d.customerId = 203 and DSM.deleted = 0


			   select * from Device where deviceName ='TM-KZWEB-PRD1'  ---- 203
			   select * from Device where deviceName ='S2-SMTP-PRD2'  ---- 203
			    select * from Device where deviceName ='TM-ENTSVCDB-INT'  ---- 203

				--- Finding the duplicates :

				SELECT  deviceName, COUNT(deviceName) 
				FROM Device where  customerId = 4 and deleted = 0
				GROUP BY deviceName
				HAVING COUNT(deviceName) > 1

				select  D.deviceId, D.deviceName, D.ipAddress, * from Device D where d.deviceName ='HDUECO-WUS01' and d.customerId =4

				select * from DeviceServiceMapping where deviceId in (
				104,4734,6006)

				--update Device set deleted =1 where deviceId in (100, 4719)

				--Update DeviceServiceMapping set deleted =1 where deviceId in (100, 4719)


			   select * from DeviceServiceMapping where deviceId = 24080


			   select * from Service where serviceId = 415


			   select * from ServiceCustomerMapping where serviceId = 415 
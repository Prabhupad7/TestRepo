

   	 select  * from users  where Email like '%Nupur_Microland@kotak.com%'  -- 23921  roleId= 76

	   ----- Joseph Cecilraj  -- SR2632072

	select * from users 

     select * from Customer where customerName like '%Kotak%'  --  163  163	Kotak Mahindra Asset Management Co. Ltd	Kotak Mahindra Asset Management Co. Ltd	0

     select * from menurolemapping where roleID = 76

     select * from role

     select * from roleaccess

     select * from roleaccessmapping where roleId=76


	  select * from roleaccessmapping where roleId=5


	  select * from menumaster where menuurl like '%dashboard%' ----> 228	/Dashboard/56

	  select * from MenuMaster where menuID = 169

      select * from menurolemapping where roleid=94 and menuid = 228


	  --   SR2632081

	  select * from MenuMaster where menuID = 12

     -- then check the role id of user and then go for

      select * from MenuRoleMapping where roleID =76

	  IM2632325



	  
 select top 1 * from Workgroup order by 1 desc

 select * from AssignmentGroup where workgroupid = 138

 select * from customerAssignmentGroupMapping   where assignmentgroupid = 203
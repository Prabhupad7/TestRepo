


select customerId,serviceId,categoryId,subCategoryId,classificationId,
* from Ticket where ticketNo =3079413 ---> 50328


select top 1000 * from RulesForAssignment where AssignmentRule like '%classificationId=50328;%'  ---> 73854

--update RulesForAssignment set RulePriority = 2 where RuleId = 73854
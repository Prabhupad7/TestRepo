
    --SMC L1 Support Report

	select * from Workgroup where workgroup like '%password%'


	select * from Customer where customerId = 54  ----> 54 DRL

select * from Users where email like '%swetas%'

select distinct w.workgroupId, w.workgroup from Workgroup W
inner join AssignmentGroup A on W.workgroupId = A.workgroupId
inner join CustomerAssignmentGroupMapping C on C.assignmentgroupId = A.assignmentgroupId
inner join UserCustomerAssignGroupMapping U on U.custAssignmentGroupId =  C.custAssignmentGroupId
where u.userId in (26093, 25892, 26549) and u.deleted = 0 and c.deleted =0 and a.deleted = 0 and w.deleted = 0




--exec [dbo].[usp_StandardReport_getAllIM&SRCombinedTicketDump] '2021-08-01','2021-08-31','createdOn',
--'150,151,152,153,154,155,156,157,170,172,173,174,175,176,177,178,179,180,182,183,193,197,202,208,209,147',
--'256,257,258,259,260,261,262,452,453,454,455,456,457,458,459,460,461,649,725' , 330



select * from Ticket where workgroupId = 725

------> Last Year Dump

----> Mohammed 696
----> Venkat   1223
----> sweta   6774


------> Last 6 months Dump

----> Mohammed 696
----> Venkat   1223
----> sweta   6774
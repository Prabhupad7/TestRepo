


select * from Service where serviceName like '%Virtual Desktop Management%'

--> 14	AIU  Management
--47	AIX Admin
--2	  Application Management
--87	Channel Support
--11	Database Management
--1	   Desktop-Laptop Management
--7	    ID Management
--8	    IMACD
--94	Infra Security device Management
--3	   Network  Management
--16	Outage
--6	   Purchase Management
--17	Purchase Management - Peripherals
--15	Security Management
--4	    Server Management
--18	UAT Server Access Management
--31	Virtual Desktop Management

----> Category Schema adding, Rules for assignment and RulesForPriority:

select * from Service where serviceId in (14, 47,2,	87,11,1,7,8,94,3,16,6,17,15,4,18,31)

select * from Service where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)

select * from ServiceCustomerMapping 
where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)
and customerId = 1 and ticketTypeId = 4

select * from CustomerPriorityMapping where customerId = 1  ---> 89	12

select * from servicePriorityMapping where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)
and PriorityId = 12

--and ticketTypeId = 4

select * from Priority where ticketTypeid = 4   ----> 12	P3

select * from Impact   ----> 4	Low

select * from servicePriorityMapping 
where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)
and customerid =1 and  priorityId = 12


select * from ServiceCategoryMapping where ticketTypeid= 4

select * from Service where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)

---> 2	  Application Management

      select  top 100 * from category where deleted = 0

--  Insert into Category(category,deleted,ticketTypeId,serviceId,Isdefaultcategory,isEUPVisible,icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)
--values
--('ABU', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('AllSec', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('AML', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('ARL System', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('Asset management', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('Boost', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('Boost for advisors', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
--('Boost for Agents', 0,4,2,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),








select top 102 * from Category order by 1 desc



   --   Insert into ServiceCategorymapping (serviceId, categoryId, deleted, ticketTypeId) 
	  --values 
(2, 1798, 0, 4),
(2, 1799, 0, 4),
(2, 1800, 0, 4),
(2, 1801, 0, 4),

	  ------> 

	   Insert into SubCategory (subCategory,categoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn)
 
     Values

	   ('Application Down', 1798,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
       ('Application error', 1798,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   ('Report error', 1798,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())








	   select top 3 * from SubCategory order by 1 desc

	   --('Laptop Battery', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
    --   ('Monitor', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   --('Mouse', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
    --   ('PC', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   --('Printer', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
    --   ('Projector', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE()),
	   --('RAM', 1788,0,0,1,'fa fa-2x fa-shield','#F5CF87','#C75C5C',6,GETDATE(),6,GETDATE())

  ---------------------------> 

  select top 3  * from Classification where deleted = 0
  order by 1 desc

   
 Insert into Classification(classification,subCategoryId,deleted,Isdefaultcategory,isEUPVisible,Icon,Icon_Color,Icon_BgColor,CreatedBy,CreatedOn,UpdatedBy,Updatedon)
		 values 
		 ('Others-Undefined', 5301, 0, 0, 0, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5302, 0, 0, 0, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate()),
		 ('Others-Undefined', 5303, 0, 0, 0, 'fa fa-2x fa-shield', '#F5CF87', '#C75C5C', 6, GETDATE(), 6, getdate())


	-------------> Rules for Assignment and Rules for Priority:

	select top 100 * from RulesForAssignment order by 1 desc

	---> 1050	KLI Rule	{customerId=1;serviceId=2;categoryId=1735;}

	select * from workgroup ----> 14	AIU  Management

	select * from workgroup where workgroup like '%ALX%'  ---> 3	Application Management

	select * from AssignmentGroup where workgroupId = 3  ---> 16	Application Management-Queue

	select * from AssignmentGroup where assignmentgroupId = 155  --> AIX Admin-Queue	85

	select top 1000 * from RulesForAssignment where AssignmentRule like '%serviceId=47%'  --->  155

	--Insert into RulesForAssignment
	
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1798;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1799;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1800;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1801;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1802;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1803;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1804;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1805;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1806;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1807;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1808;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1809;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1810;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1811;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1812;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1813;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1814;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1815;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1816;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1817;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1818;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1819;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1820;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1821;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1822;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1823;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1824;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1825;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1826;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1827;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1828;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1829;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1830;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1831;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1832;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1833;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1834;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1835;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1836;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1837;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1838;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1839;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1840;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1841;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1842;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1843;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1844;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1845;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1846;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1847;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1848;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1849;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1850;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1851;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1852;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1853;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1854;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1855;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1856;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1857;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1858;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1859;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1860;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1861;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1862;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1863;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1864;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1865;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1866;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1867;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1868;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1869;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1870;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1871;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1872;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1873;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1874;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1875;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1876;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1877;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1878;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1879;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1880;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1881;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1882;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1883;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1884;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1885;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1886;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1887;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1888;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1889;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1890;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1891;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1892;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1893;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1894;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1895;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
	--select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1896;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1897;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1898;}', 16, 16, 1, 0, 79, 1, 1, 0, 3 UNION ALL
 --   select 'KLI Rule', '{customerId=1;serviceId=47;categoryId=1899;}', 16, 16, 1, 0, 79, 1, 1, 0, 3


   -----------> Rules for Priority:


   select top 1000 * from RulesForPriority where RuleTemplateId = 97  order by 1 desc

   ---> 2505	Apc assist	{customerid=93;serviceid=89;tickettypeid=1;}
  ----> 2658	Rules	{customerId=1;serviceId=2;ticketTypeId=1;}	1	10	1	0	97	NULL

  select * from Service where serviceId in (1,2,3,4,6,7,8,11,14,15,16,17,18,31,47,87,94)


  select * from Priority where ticketTypeId = 4  ---> 12	P3

     select top 100 * from RulesForPriority 
	 order by 1 desc

  select * from Impact  --> 1	Minor, 4	Low

  --Insert into RulesForPriority 

  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=1;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=2;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=3;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=4;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=6;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=7;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=8;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=11;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=14;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=15;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=16;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=17;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=18;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=31;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=47;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=87;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL UNION ALL
  --select 'Desktop-Laptop Management PM Ticket Rule', '{customerid=1;serviceid=94;tickettypeid=4;}', 12, 4, 1, 0, 97, NULL 



   select * from TicketStatus where deleted = 0 and ticketTypeid =1

   --->  6	On Hold (3rd Party)

   select * from Service where serviceName like '%Desktop%' --> 5

   select * from ServiceCustomerMapping where serviceId = 5 and customerId = 1
   
   select * from Workgroup


   select * from NotificationRules where 
   customerId = 1 and  serviceId = 5 and workgroupid = 4 and entryStateId = 6

   --->  39390

   select * from NotificationRules where ruleId in 
   (  select distinct ruleId from NotificationRegistry where sourceId = 72761 ) and templateId in ( 644, 476) and entryStateId = 6

			-- update NotificationRules set entryStateId = 5 where ruleId in (39390
			--,45690)

   select * from NotificationRules where    templateId = 644 and entryStateId = 6

   select * from NotifyBasedOn

   select * from NotificationEmailTemplate where templateId in (475, 476, 644)



			select * from ticket t
			join requestor r on r.requestorId=t.requestorId
			where customerId=4 and r.requestorEmail='vishalds@microland.com'

			  select * from RulesForAssignment 
			  where customerId = 194 and AssignmentRule like '%t%' and RuleTemplateId = 14




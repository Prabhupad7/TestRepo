


  ---->  select * from AutoTicketServiceEmailConfig  where name like '%menabev%' ---> 335 

  --support@paisgroup.com
  --support@paisgroup.com


  select customerId, serviceId, workgroupId, workgroupName, TicketTypeid, priorityId, * from ticket where ticketno = 2897791

  select * from ServiceLevelObjective 
  where serviceId = 68 and priorityId = 15 and isDelete =0 and workgroupId = 200 ----->   2880  workHourId = 114

  select * from WorkHours where workHourId = 114  ----> 


  select E.stateEntryId, e.ticketNo, e.statusId, t.status, e.entryTime, e.exitTime, e.activePhase from ServiceLevelStateEntry E
  inner join TicketStatus T on T.statusId = E.statusId
  where ticketNo = 2929182

  select E.stateEntryId, e.ticketNo, e.statusId, t.status, e.entryTime, e.exitTime, e.activePhase from ServiceLevelStateEntry E
  inner join TicketStatus T on T.statusId = E.statusId
  where ticketNo = 2926519

  ---->  2880
  
  
  --->  SR2910016

  ------>  Verifying the Why tickets are breached.  ---->>   Administration/MissingSLAindex

    select * from ServiceLevelTracking where sourceId = 2929202

  select * from ServiceLevelObjective where serviceLevelObjectiveId in 
  ( 498394
,498694
,498774
,498754
,498494
,498774
,498594)


  select * from ServiceLevelObjective where  serviceLevelAgreementId = 74 and serviceId = 68  

  select * from ServiceLevelTracking where sourceId = 2887808

  ----> Step to take breached tickets: 

  select distinct sourceId from ServiceLevelTracking where isBreached =1 and  startTime > '2021-03-01 00:00:00' and serviceLevelObjectiveId in (
 498394
,498694
,498574
,498494
,498774
,498754
,498494
,498774
,498454
,498754
,498694
,498774
,498494
,498774
,498614
,498774
,498654)

---->  https://rmcops.microland.com/Administration/MissingSLAindex




select * from TicketStatus where statusId in (

15,16,17, 4,5,7,8,15,16,18
) 



select * from NotificationRules where ruleId in (
select ruleId from NotificationRegistry where sourceId in (
'1560769',
'1560788',
'1560775'
))

------>   ServiceId : 1 ---->  workgroupId : 2,12, 19

------>   ServiceId : 14 ---->  workgroupId :  19

select * from NotificationRules
where customerId = 1 and ticketTypeId =1 and deleted = 0 and entryStateId = 6


---->  

select top 100 * from ServiceLevelStateEntry

select * from ServiceLevelStateEntry where ticketNo in (
select ticketNo from Ticket where customerId = 147 and 
serviceId = 68 and createdOn between  '2021-04-01'  and '2021-04-09') and statusId in (
6, 17
)

select * from TicketStatus 

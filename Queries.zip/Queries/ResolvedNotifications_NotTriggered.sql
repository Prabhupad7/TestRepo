


        select * from NotificationRegistry where sourceid = 76247 


	  
	  -- and templateId = 489  --->  2020-10-23 05:56:19.000

      select * from NotificationRegistry where  templateId = 489 and executionTime like '%2020-10-23 05:56:19.000%'

	   select top 1000 * from NotificationRegistry where  templateId = 489 and createdOn  like '%2020-10-23%'

	   select top 1000 * from NotificationRegistry where  templateId = 489 order by 1 desc


		  select * from NotificationRegistry where notificationId in (
		  32330274
,32326489
,32325984
,32325801
,32325485
,32324197
,32324017
,32323627
,32321439
,32321239
,32319816)

     select * from NotificationRules where ruleId in (
  select ruleId from NotificationRegistry where sourceid = 76247 
	 )


	 -- 475	On Hold Vendor
  --    476	On Hold Vendor - Follow Up

  --643	On Hold Customer
  --644	On Hold Customer - Follow up 

   select * from NotificationEmailTemplate where templateId in (
    select templateId from NotificationRegistry where sourceid = 76247  )
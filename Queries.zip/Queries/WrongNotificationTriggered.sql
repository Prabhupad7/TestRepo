

    select * from NotificationEmailTemplate 
	where customerId = 1


	select * from Ticket where ticketNo =  72761 


	 select * from NotificationRegistry where sourceId = 72156

	 select * from NotificationRules where ruleId in (45690
, 112314)
    
	select * from NotifyBasedOn
	-- 6	FOLLOWUP
	 
	select * from NotificationEmailTemplate where templateId in (644
,476)

    --476	On Hold Vendor - Follow Up
    --644	On Hold Customer - Follow up 

	-----  wrong information triggered IM72156

	-----  Informatio required column is blank  IM72761

	

	select * from NotificationRegistry where sourceId = 72761

--	[?9/?11/?2020 11:43 AM]  Sweta Saran:  
--http://10.160.160.172:8091 
 




 --  Raised PO shared with Suresh Sir for approval.
 
 
   select * from Customer where customerid = 1

	    SR2719965  
		SR2719148


   select * from Requestor where requestorEmail like '%venkataramana%' --> 54539
   select * from Requestor where requestorId = 2892

   select * from CustomerRequestorMapping where requestorId = 54539
   select * from CustomerRequestorMapping where customerId = 163
   Insert into 

   select * from Customer where customerName like '%kotak%' --->  163 163	Kotak Mahindra Asset Management Co. Ltd

   ---> Need to create a test ticket and then need to verify:

   select serviceId, workgroupId, customerId, * from Ticket where ticketNo = 2727539

  
  ---> Today 11/11/2020: Issue check: 

    select * from Ticket where ticketNo = 2741526  -->  2741526

    select * from NotificationHistory where TicketNo = 2741526

    SELECT * FROM NotificationHistory where TicketNo = 2741526

    select * from NotificationRegistry where sourceId = 2741526




   select * from NotificationRegistry where sourceId = 2719965 and notificationMode = 'Email'


   select * from NotificationRules where ruleId in (
      select ruleId from NotificationRegistry where sourceId = 2741526 and notificationMode = 'Email'
   )


   select * from NotificationRegistry where ruleId = 1695101 and sourceId = 2719965


     select top 100 * from NotificationRegistry where ruleId = 1695101 order by 1 desc
    
   select * from NotificationEmailTemplate where templateId in (489)



   -----.

        SR2719965  
		SR2719148

		IM2741526
		   
	   select * from NotificationRegistry where sourceId = 2741526 

	   select * from NotificationRegistry where sourceId = 2741526  and notificationMode='Email'

       select * from NotificationRules where ruleId in 
  	   (select ruleId from NotificationRegistry where sourceId = 2741526 ) and notificationMode = 'Email'



			select * from Customer where customerid = 68
  
			select * from Workgroup where workgroup like '%SOC%'

			select * from NotificationRules 



1.	PM2584382
2.	PM2500142
3.	PM2444547


  exec deletetickets 2584382
  exec deletetickets 2500142
  exec deletetickets 2444547




select * from NotificationRules 
where customerId = 192 and deleted =0 and notificationTo like '%8861061034%'



select * from NotificationRules 
where customerId = 192 and deleted =0 and notificationTo like '%918095088230%'


--Update NotificationRules set notificationTo = notificationTo +',919886404183' where ruleId in (
--select ruleId from NotificationRules 
--where customerId = 192 and deleted =0 and notificationTo like '%8861061034%'
--)

--Update NotificationRules set notificationTo ='919920899008,919886014788,,,917760011661,919886404183.917829524239.919632107476' where ruleId in ()
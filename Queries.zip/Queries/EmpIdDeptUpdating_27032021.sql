

select EmployeeId, Department,requestorEmail,* from Requestor where requestorEmail in (
'anvarks@microland.com',
'arundo@microland.com',
'arer@microland.com',
'chethank1@microland.com',
'anilpi@microland.com',
'indreshmk@microland.com',
'atifja@microland.com',
'i_ashwanik@microland.com',
'javeriyaa@microland.com',
'reemag@microland.com',
'mukeshyam@microland.com',
'himanigs@microland.com',
'SivaTB@microland.com',
'manjeett@microland.com',
'sunnyk@microland.com',
'RishabSK@microland.com',
'sagarpn@microland.com',
'maheshp1@microland.com',
'rahulku1234567@microland.com'
)


select EmployeeId, Department,EmailId,* from Asset_users where EmailId  in (
'anvarks@microland.com',
'arundo@microland.com',
'arer@microland.com',
'chethank1@microland.com',
'anilpi@microland.com',
'indreshmk@microland.com',
'atifja@microland.com',
'i_ashwanik@microland.com',
'javeriyaa@microland.com',
'reemag@microland.com',
'mukeshyam@microland.com',
'himanigs@microland.com',
'SivaTB@microland.com',
'manjeett@microland.com',
'sunnyk@microland.com',
'RishabSK@microland.com',
'sagarpn@microland.com',
'maheshp1@microland.com',
'rahulku1234567@microland.com'
)
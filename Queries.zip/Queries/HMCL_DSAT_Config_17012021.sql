   ---->   154	Network	52	Data Center, HM2G-Gurgaon Plant

   select distinct W.workgroupId, W.workgroup, w.CreatedDateTime from AssignmentGroup AG 
   inner join Workgroup W on W.workgroupId = AG.workgroupId
   inner join CustomerAssignmentGroupMapping CG 
   on Ag.assignmentgroupId = CG.assignmentgroupId
   where ag.deleted=0 and cg.deleted=0 and cg.customerId=68 and w.deleted = 0
   and w.workgroupId not in (80,87,88,89,90,91,92,93,101,102,154,167,607)


   select serviceId, workgroupId, workgroupName, * from Ticket where ticketno = 2889619   ----> IM2885660   

   select * from Feedback where TicketNo = 2885654


   select * from Feedback where TicketNo = 2885660



   select * from FeedbackConfig where CustId=68 and ServiceId = 51  and workgroupId = 128 and TicketTypeId=1


   select * from FeedbackConfig where CustId=68 and ServiceId = 51 and TicketTypeId=1



   select * from Service where serviceId in (
   select distinct serviceId from ServiceCustomerMapping where customerId =68 and deleted =0
   )

      select * from FeedbackConfig where CustId=68 and workgroupId = 87 and ServiceId = 51
	  order by serviceid 

	  select * from FeedbackConfig where CustId = 147

	  --delete from FeedbackConfig where id = 4 


	  select * from FeedbackConfig where CustId=68  and ServiceId = 51  and workgroupId = 80
	  order by serviceid 

	  --Insert into FeedbackConfig (CustId, SurveyExpiryDays,	ResurveyExpiryDays,	TicketTypeId, RatingImages,	CommentRating,
	  --SendNotificationByTime, ServiceId, ToAddr, TemplateId, RatingForEmail, ClientLogo, 
	  --FeedbackTemplate,	Interval,	NumberOfFeedbacks,	workgroupId,	Mandatorycommentrating)

	  --select CustId, SurveyExpiryDays,	ResurveyExpiryDays,	TicketTypeId, RatingImages,	CommentRating,
	  --SendNotificationByTime, ServiceId, ToAddr , TemplateId, RatingForEmail, ClientLogo, 
	  --FeedbackTemplate,	Interval,	NumberOfFeedbacks,	696,	Mandatorycommentrating from FeedbackConfig where CustId=68 and workgroupId = 80 and ServiceId = 51
	  --order by serviceid 


	( ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
,,,,,,,,,,,)





	  select * from NotificationRules


	 select * from FeedbackConfig where CustId=68  and ServiceId in (412,43, 46, 52,57,67,82,83, 412) ---- and workgroupId = 80
	 order by serviceid 

	 select distinct WorkgroupId from FeedbackConfig where CustId=68  and ServiceId in (51)  and workgroupId = 80
	 order by WorkgroupId 

	 select distinct WorkgroupId from FeedbackConfig where CustId=68   and workgroupId in( 87,89,90,101,102,167,607,88,93,91,92,154
,89,87,90,101,102,167,607,88,91,92,93,80,80,87,89,90,101,102,167,607,88,93,91,92,154,89,87,90,101,102,167,607,88,91,92,93,80,80)

	 --order by WorkgroupId 

--	  Update FeedbackConfig set ToAddr=	  'harish.bawari@heromotocorp.com;itsd.pm@heromotocorp.com;chandrashekhar.baghel@heromotocorp.com;itsd.qc@heromotocorp.com;itsd.om@heromotocorp.com'   , CcAddr='rajkumar.nagaiah@heromotocorp.com'
--	  where id in (86
--,679
--,98
--,680)


	  select Id, serviceid,workgroupid, Toaddr, ccaddr from FeedbackConfig where CustId=68  --and ServiceId = 43 ---- and workgroupId = 80
	  order by serviceid 

	  ---->  

	  ---->  


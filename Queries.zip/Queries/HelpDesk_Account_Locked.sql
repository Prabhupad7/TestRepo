

  select isAccountLocked, failedLoginAttemptCount,Password, * from Requestor
  where alias='MLITServicedesk' 

  ----> 16890  KLIhelpdesk

  ---->  select * from Requestor where alia

--Update Requestor set failedLoginAttemptCount=0, isAccountLocked =0 where requestorId in (
--2919
--,3006
--,16890
--,16891
--,53776
--,53930
--,59711,
--91280,
--21146
--)

select * from Requestor where requestorId in (
2919
,3006
,16890
,16891
,53776
,53930
,59711,
91280
)

----> 

select top 100 * from HolidayCalendarDetail 

select * From Requestor where requestorId = 16891  ----> helpdesk

--update Requestor set alias = 'kgihelpdesk' where requestorId = 16891 

---->  pageId : 3 
---->  13505   14226  Ratlami , DNS Server 13.21.21.12


  select isAccountLocked, failedLoginAttemptCount,Password, * from Requestor where alias='rmcshiftmanager' 

--  Update Requestor set failedLoginAttemptCount=0, isAccountLocked =0 where requestorId in (
--13148
--)

------> VarunRaghavaKR@microland.com  918197844433

select * from users where email like '%YadupathiKR@microland.com%'  ----> 26893 YadupathiKR@microland.com



select * from users where email like '%BHava%'  ----> 25054  4

select * from ReportRoleMapping 
where ReportMasterId = 104 and RoleId = 4



select * from ReportMaster  -----> 102	RP001 - Incident and Service request SLA dump

select top 50 * from Log order by 1 desc